// development/recruiting/src/sites.ts
var UnverifiedRecruitingAdapter = class {
  constructor(driver) {
    this.driver = driver;
  }
  driver;
  async probe(signal) {
    signal.throwIfAborted();
    return {
      verified: false,
      reason: "\u5F53\u524D\u6C42\u804C\u8005\u7F51\u9875\u7684\u8D26\u53F7\u3001\u7B80\u5386\u548C\u52A8\u4F5C\u5165\u53E3\u5C1A\u672A\u6821\u51C6\uFF1B\u8BF7\u5148\u5B8C\u6210\u8BE5\u7F51\u7AD9\u9002\u914D\u9A8C\u8BC1"
    };
  }
  async opportunities() {
    throw new Error("\u7AD9\u70B9\u9002\u914D\u5C1A\u672A\u9A8C\u8BC1");
  }
  async read() {
    throw new Error("\u7AD9\u70B9\u9002\u914D\u5C1A\u672A\u9A8C\u8BC1");
  }
  async submit() {
    throw new Error("\u7AD9\u70B9\u9002\u914D\u5C1A\u672A\u9A8C\u8BC1\uFF0C\u7981\u6B62\u5916\u53D1");
  }
  async contacts() {
    throw new Error("\u7AD9\u70B9\u9002\u914D\u5C1A\u672A\u9A8C\u8BC1");
  }
};
var BossRecruitingAdapter = class extends UnverifiedRecruitingAdapter {
  platform = "boss";
};

// development/recruiting-boss/src/inspect.ts
var inspect_default = async ({ template: t, signal }) => {
  const adapter = new BossRecruitingAdapter({ perform: async () => {
    throw new Error("\u68C0\u67E5\u5165\u53E3\u4E0D\u6267\u884C\u7F51\u7AD9\u52A8\u4F5C");
  } });
  const result = await adapter.probe(signal);
  await t.attention({ key: "site-unverified", title: result.reason, detail: { site: "boss" } });
  return t.result(result);
};
export {
  inspect_default as default
};
