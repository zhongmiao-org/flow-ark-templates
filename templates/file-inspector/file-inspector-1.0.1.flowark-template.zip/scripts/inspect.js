// development/file-inspector/src/inspect.ts
var inspect_default = async ({ template: t }) => {
  const text = await t.file("source", { operation: "read" });
  const result = { characters: text.length, lines: text.split("\n").length };
  await t.state.set(result);
  return t.result(result);
};
export {
  inspect_default as default
};
