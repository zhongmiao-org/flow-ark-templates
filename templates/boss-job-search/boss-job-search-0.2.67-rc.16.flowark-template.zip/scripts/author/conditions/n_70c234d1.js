var n = async ({ input: t, signal: s }) => {
  if (s.throwIfAborted(), !t || t.version !== 1 || t.operation !== "configuration" || !Number.isSafeInteger(t.revision) || t.revision < 0 || !t.value || typeof t.value != "object" || Array.isArray(t.value)) throw new Error("\u7F3A\u5C11\u672C\u6B21\u56FA\u5B9A\u914D\u7F6E\u53CA\u4FEE\u8BA2\uFF0C\u8BF7\u5148\u4F7F\u7528\u8BFB\u53D6\u672C\u6B21\u914D\u7F6E\u6B65\u9AA4");
  const u = t.value;
  if (!["cities", "excludedRoles", "replyDailyLimit", "replyTimeZone", "salaryMax", "salaryMin", "targetRoles", "titleKeywords", "firstContactDailyBudget"].every((e) => Object.hasOwn(u, e)) || Object.keys(u).some((e) => !["cities", "excludedRoles", "replyDailyLimit", "replyTimeZone", "salaryMax", "salaryMin", "targetRoles", "titleKeywords", "firstContactDailyBudget", "knownContactedJobs", "knownContactAccountAlias", "knownContactPhoneMask", "knownGreetingDate", "knownGreetingsUsed", "acceptanceNewGreetings", "confirmedPersonalFacts", "recoveryEvidenceName"].includes(e))) throw new Error("\u6C42\u804C\u6761\u4EF6\u5B57\u6BB5\u7ED3\u6784\u4E0D\u5339\u914D");
  if (!Number.isSafeInteger(u.replyDailyLimit) || u.replyDailyLimit < 0 || u.replyDailyLimit > 100 || typeof u.replyTimeZone != "string" || !u.replyTimeZone.trim() || u.replyTimeZone.length > 100) throw Error("\u56DE\u590D\u989D\u5EA6\u914D\u7F6E\u7ED3\u6784\u65E0\u6548");
  if (!Number.isSafeInteger(u.firstContactDailyBudget) || u.firstContactDailyBudget < 0 || u.firstContactDailyBudget > 150) throw Error("\u672C\u65E5\u81EA\u52A8\u65B0\u589E\u9884\u7B97\u683C\u5F0F\u65E0\u6548\uFF1B\u987B\u4E3A0\u81F3150\u7684\u6574\u6570");
  const r = [], a = (e) => e.normalize("NFKC").trim().toLocaleLowerCase("en-US");
  for (const e of ["targetRoles", "titleKeywords", "cities", "excludedRoles"]) {
    if (!Array.isArray(u[e]) || u[e].length > 20 || u[e].some((o) => typeof o != "string" || o.length < 1 || o.length > 100)) throw new Error("\u6C42\u804C\u6761\u4EF6\u6587\u672C\u5217\u8868\u7ED3\u6784\u65E0\u6548\uFF1A" + e);
    const i = u[e].map(a);
    i.some((o) => !o) && r.push({ field: e, reason: "\u6761\u76EE\u4E0D\u80FD\u4EC5\u542B\u7A7A\u767D" }), new Set(i).size !== i.length && r.push({ field: e, reason: "\u540C\u4E00\u5217\u8868\u5B58\u5728\u91CD\u590D\u6761\u76EE\uFF0C\u8BF7\u672C\u4EBA\u6838\u5BF9" });
  }
  u.targetRoles.length || r.push({ field: "targetRoles", reason: "\u8BF7\u81F3\u5C11\u586B\u5199\u4E00\u4E2A\u76EE\u6807\u804C\u4F4D" }), u.titleKeywords.length || r.push({ field: "titleKeywords", reason: "\u8BF7\u586B\u5199\u53EF\u63A5\u53D7\u5C97\u4F4D\u6807\u9898\u5173\u952E\u8BCD\uFF1B\u68C0\u7D22\u8BCD\u4E0D\u80FD\u8BC1\u660E\u5C97\u4F4D\u5408\u683C" });
  const l = new Set(u.excludedRoles.map(a));
  u.targetRoles.some((e) => a(e) && l.has(a(e))) && r.push({ field: "excludedRoles", reason: "\u76EE\u6807\u804C\u4F4D\u4E0E\u6392\u9664\u65B9\u5411\u5B58\u5728\u5B8C\u5168\u76F8\u540C\u6761\u76EE\uFF0C\u8BF7\u672C\u4EBA\u6838\u5BF9" });
  for (const e of ["salaryMin", "salaryMax"]) if (!Number.isSafeInteger(u[e]) || u[e] < 0 || u[e] > 1e6) throw new Error("\u6708\u85AA\u8303\u56F4\u987B\u4E3A0\u81F31000000\u6574\u6570");
  return u.salaryMax > 0 && u.salaryMin > u.salaryMax && r.push({ field: "salaryMax", reason: "\u5DF2\u8BBE\u7F6E\u7684\u6708\u85AA\u4E0A\u9650\u5C0F\u4E8E\u4E0B\u9650" }), s.throwIfAborted(), { version: 1, ready: r.length === 0, status: r.length ? "needs-review" : "ready", configurationRevision: t.revision, issues: r, summary: { targetRoleCount: u.targetRoles.length, titleKeywordCount: u.titleKeywords.length, cityCount: u.cities.length, excludedRoleCount: u.excludedRoles.length, salaryMin: u.salaryMin, salaryMax: u.salaryMax, salaryUnit: "CNY/month;0=unset" }, accountVerified: false, eligibleForActions: false, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), note: "\u4EC5\u6838\u5BF9\u672C\u6B21\u914D\u7F6E\u7684\u4E00\u81F4\u6027\uFF0C\u4E0D\u4EE3\u8868\u8D26\u53F7\u3001\u5B8C\u6574JD\u3001\u804C\u4F4D\u5339\u914D\u3001Skill\u6216\u4EFB\u4F55\u5916\u53D1\u6388\u6743\u901A\u8FC7\u3002" };
};
export {
  n as default
};
