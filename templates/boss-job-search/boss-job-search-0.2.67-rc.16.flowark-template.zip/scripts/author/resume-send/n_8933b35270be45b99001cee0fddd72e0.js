async function pinRecipientSearchResult(read, source) {
  const compact = (value) => String(value).normalize("NFKC").replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
  const inputSelector = ".list-warp.v2 input", root = ".boss-search-result .search-list";
  if (await read("count", inputSelector) !== 1) throw Error("\u5F53\u524D\u8054\u7CFB\u4EBA\u641C\u7D22\u5165\u53E3\u4E0D\u552F\u4E00\uFF0C\u672A\u56FA\u5B9A\u6536\u4EF6\u4EBA");
  const name = compact(source.recipientName), header = compact(source.recipientLabel);
  const jobTitle = compact(source.chatJobTitle.split(/\r?\n/u).map((v) => v.trim()).filter(Boolean)[0].replace(/（猎头职位）$/u, ""));
  const suffix = header.startsWith(name) ? header.slice(name.length) : "";
  if (!name || !suffix || !jobTitle) throw Error("\u7F3A\u5C11\u539F\u59D3\u540D\u3001\u516C\u53F8\u89D2\u8272\u6216\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\uFF0C\u672A\u56FA\u5B9A\u641C\u7D22\u7ED3\u679C");
  await read("fill", inputSelector, source.recipientName);
  for (let attempt = 0; attempt < 30; attempt++) {
    const count = await read("count", root), matches = [];
    if (!Number.isSafeInteger(count) || count > 50) throw Error("\u8054\u7CFB\u4EBA\u641C\u7D22\u8303\u56F4\u65E0\u6548");
    for (let index = 1; index <= count; index++) {
      const selector = root + ":nth-child(" + index + " of .search-list)", text = String(await read("read", selector)).trim(), value = compact(text);
      const split = value.indexOf("\u804C\u4F4D:");
      if (split < 0 || value.indexOf("\u804C\u4F4D:", split + 3) >= 0) continue;
      const candidateHeader = value.slice(0, split), candidateJob = value.slice(split + 3);
      if (candidateJob !== jobTitle || !candidateHeader.startsWith(name) || !candidateHeader.endsWith(suffix)) continue;
      const company = candidateHeader.slice(name.length, candidateHeader.length - suffix.length);
      if (candidateHeader !== header && (!company || company.length > 200)) continue;
      matches.push({ selector, text });
    }
    if (matches.length > 1) throw Error("\u59D3\u540D\u3001\u516C\u53F8\u89D2\u8272\u4E0E\u5C97\u4F4D\u5B58\u5728\u591A\u4E2A\u7ED3\u679C\uFF0C\u672A\u9009\u62E9");
    if (matches.length === 1) {
      const selected = matches[0];
      if (String(await read("read", selected.selector)).trim() !== selected.text) throw Error("\u8054\u7CFB\u4EBA\u5B8C\u6574\u641C\u7D22\u884C\u5DF2\u53D8\u5316");
      return selected.text;
    }
    await new Promise((resolve) => setTimeout(resolve, 150));
  }
  throw Error("\u672A\u53D6\u5F97\u552F\u4E00\u7684\u59D3\u540D\u3001\u516C\u53F8\u89D2\u8272\u53CA\u5B8C\u6574\u5C97\u4F4D\u641C\u7D22\u884C\uFF0C\u672A\u5EFA\u7ACB\u9644\u4EF6\u610F\u56FE");
}
async function nativeNavigationRead(template, signal, operation, selector, value) {
  signal.throwIfAborted();
  try {
    return await template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
  } catch (error) {
    if (operation !== "navigate" || !["https://www.zhipin.com/web/geek/chat", "https://www.zhipin.com/web/geek/resume"].includes(value) || !/^\(-3\) loading /u.test(String(error?.message || error))) throw error;
    for (let attempt = 0; attempt < 40; attempt++) {
      signal.throwIfAborted();
      const actual = await template.browser("browser", { operation: "url", timeoutMs: 3e3 });
      if (actual === value) return actual;
      await new Promise((resolve) => setTimeout(resolve, 150));
    }
    throw error;
  }
}
function titleScopeEvidence(title, configuration) {
  const normalize = (value) => value.normalize("NFKC").replace(/\s+/gu, " ").trim().toLocaleLowerCase("en-US");
  if (typeof title !== "string" || !title.trim() || title.length > 1e3 || /(?:\.{3}|…|⋯)/u.test(title)) throw Error("\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u7F3A\u5931\u6216\u622A\u65AD\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u8BB0\u5F55");
  const positive = configuration?.titleKeywords, negative = configuration?.excludedRoles;
  for (const [name, terms, minimum] of [["titleKeywords", positive, 1], ["excludedRoles", negative, 0]]) {
    if (!Array.isArray(terms) || terms.length < minimum || terms.length > 20 || terms.some((v) => typeof v !== "string" || !normalize(v) || v.length > 100) || new Set(terms.map(normalize)).size !== terms.length) throw Error("\u5C97\u4F4D\u8303\u56F4\u914D\u7F6E\u65E0\u6548\uFF1A" + name + "\uFF1B\u672A\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE");
  }
  const fullTitle = normalize(title), excluded = negative.filter((term) => fullTitle.includes(normalize(term))), matched = positive.filter((term) => fullTitle.includes(normalize(term)));
  return { version: 1, kind: "literal-full-job-title-scope", fullTitle: title, matched, excluded, allowed: excluded.length === 0 && matched.length > 0, source: "actual-complete-job-title", jdUsed: false, searchKeywordUsedAsEvidence: false };
}
import { createHash } from "node:crypto";
const checkAccountSource = /* @__PURE__ */ (() => {
  var stdin_default2 = async ({ input, signal }) => {
    signal.throwIfAborted();
    const read = input, account = read?.value;
    if (!read || read.version !== 1 || read.operation !== "read" || read.binding !== "account-source-result" || read.schemaValidation !== "passed" || read.dataChanged !== false || read.ref?.version !== 1 || read.ref.policy !== "credential-redacted-v1" || read.ref.source?.entryId !== "account-source") throw new Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u5DF2\u9009\u62E9\u4E14\u5B8C\u6574\u53EF\u590D\u7528\u7684\u8D26\u53F7\u6765\u6E90\uFF0C\u8BF7\u5230\u8D44\u6E90\u9875\u91CD\u65B0\u6838\u5BF9\u5E76\u4FDD\u5B58");
    if (!account || account.version !== 1 || account.kind !== "boss-account-source" || account.status !== "account-source-confirmed" || account.accountVerified !== true || account.platformUniqueIdVerified !== false || account.eligibleForActions !== false || account.role !== "jobseeker") throw new Error("\u6240\u9009\u8BB0\u5F55\u5C1A\u672A\u5B8C\u6210\u672C\u4EBA\u786E\u8BA4\u548C\u6765\u6E90\u590D\u9A8C\uFF1B\u8BF7\u5728\u5F53\u524D\u5B9E\u4F8B\u5B8C\u6210\u8D26\u53F7\u6838\u5BF9\uFF0C\u518D\u9009\u62E9\u8BE5\u6B21\u5DF2\u4FDD\u5B58\u7ED3\u679C");
    const keys = ["version", "kind", "status", "accountAlias", "accountName", "phoneMask", "jobseekerResumeHref", "role", "sourceUrl", "accountVerified", "platformUniqueIdVerified", "eligibleForActions", "confirmedAt", "checkedAt", "reason"];
    if (Object.keys(account).length !== keys.length || keys.some((k) => !Object.prototype.hasOwnProperty.call(account, k))) throw new Error("\u6240\u9009\u8D26\u53F7\u7ED3\u679C\u7ED3\u6784\u4E0D\u7B26\uFF0C\u505C\u6B62\u91C7\u7528");
    for (const key of ["accountAlias", "accountName", "phoneMask"]) if (typeof account[key] !== "string" || !account[key].trim() || account[key] !== account[key].trim() || account[key].length > 100 || /[\r\n]/.test(account[key])) throw new Error("\u8D26\u53F7\u5FC5\u8981\u5B57\u6BB5\u7F3A\u5931\u6216\u683C\u5F0F\u65E0\u6548\uFF0C\u505C\u6B62\u91C7\u7528");
    if (!/^[+\d ()-]*\*{2,}[\d ()-]+$/.test(account.phoneMask) || /登录|注册|验证码/.test(account.accountName)) throw new Error("\u8D26\u53F7\u6765\u6E90\u7F3A\u5C11\u6709\u6548\u7684\u53EF\u89C1\u59D3\u540D\u6216\u624B\u673A\u53F7\u63A9\u7801");
    if (typeof account.reason !== "string" || !account.reason.trim()) throw new Error("\u8D26\u53F7\u7ED3\u679C\u7F3A\u5C11\u660E\u786E\u6838\u5BF9\u8BF4\u660E");
    const confirmedAt = Date.parse(account.confirmedAt), checkedAt = Date.parse(account.checkedAt);
    if (typeof account.confirmedAt !== "string" || typeof account.checkedAt !== "string" || !Number.isFinite(confirmedAt) || !Number.isFinite(checkedAt) || confirmedAt <= 0 || checkedAt < confirmedAt || checkedAt > Date.now() + 6e4) throw new Error("\u8D26\u53F7\u786E\u8BA4\u6216\u590D\u9A8C\u65F6\u95F4\u65E0\u6CD5\u6838\u5BF9\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4");
    if (typeof account.sourceUrl !== "string" || typeof account.jobseekerResumeHref !== "string" || !account.sourceUrl.trim() || !account.jobseekerResumeHref.trim() || account.sourceUrl.length > 16384 || account.jobseekerResumeHref.length > 16384) throw new Error("\u8D26\u53F7\u9875\u9762\u6216\u7B80\u5386\u5165\u53E3\u5730\u5740\u65E0\u6548");
    const page = new URL(account.sourceUrl), resume = new URL(account.jobseekerResumeHref, account.sourceUrl);
    if (page.origin !== "https://www.zhipin.com" || page.pathname !== "/web/geek/account" || page.searchParams.get("type") !== "accountSet" || page.username || page.password || page.hash || resume.origin !== page.origin || resume.pathname !== "/web/geek/resume" || resume.username || resume.password) throw new Error("\u8D26\u53F7\u8BB0\u5F55\u7684\u9875\u9762\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u4E0D\u7B26");
    signal.throwIfAborted();
    return { version: 1, accountSourceValid: true, currentAccountVerified: false, account };
  };
  return stdin_default2;
})();
const checkCurrentAccount = /* @__PURE__ */ (() => {
  async function stdin_default2({ input, signal, template }) {
    signal.throwIfAborted();
    const a = input?.expected?.account;
    if (input?.expected?.accountSourceValid !== true || a?.kind !== "boss-account-source" || a.status !== "account-source-confirmed" || a.accountVerified !== true) throw Error("\u7F3A\u5C11\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\u6765\u6E90");
    const call = async (operation, selector, value) => {
      signal.throwIfAborted();
      const r2 = await template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
      signal.throwIfAborted();
      return r2;
    };
    let before = await call("url");
    if (before === "about:blank") {
      await call("navigate", void 0, a.sourceUrl);
      for (let n2 = 0; n2 < 40; n2++) {
        const current = await call("url");
        if (new URL(current).origin === "https://www.zhipin.com" && await call("count", "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)") === 1) break;
        await new Promise((r2) => setTimeout(r2, 150));
      }
      before = await call("url");
    }
    const p = new URL(before);
    if (p.origin !== "https://www.zhipin.com" || p.username || p.password || !p.pathname.startsWith("/web/") && !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(p.pathname)) throw Error("\u5F53\u524D\u9875\u9762\u4E0D\u662FBOSS\u6C42\u804C\u9875\u9762\uFF0C\u8BF7\u5148\u767B\u5F55");
    const n = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", r = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)";
    const nameCount = await call("count", n), resumeCount = await call("count", r);
    if (nameCount !== 1 || resumeCount !== 1) throw Error("\u5F53\u524D\u9875\u9762\u8D26\u53F7\u5165\u53E3\u6570\u91CF\u5F02\u5E38\uFF1A" + JSON.stringify({ nameCount, resumeCount }));
    const name = await call("read", n), href = await call("attribute", r, "href");
    if (typeof name !== "string" || name.normalize("NFKC").trim() !== a.accountName.normalize("NFKC").trim() || typeof href !== "string" || new URL(href, before).href !== new URL(a.jobseekerResumeHref, a.sourceUrl).href || await call("url") !== before) throw Error("\u5F53\u524D\u767B\u5F55\u8EAB\u4EFD\u3001\u6C42\u804C\u5165\u53E3\u6216\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
    return { version: 1, status: "current-account-source-matched", accountAlias: a.accountAlias, accountName: a.accountName, phoneMask: a.phoneMask, jobseekerResumeHref: a.jobseekerResumeHref, sourceUrl: a.sourceUrl, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), currentPageUrl: before, currentAccountVerified: true, platformUniqueIdVerified: false, eligibleForActions: false, accountCheckMode: "confirmed-initial-account-and-visible-header", phoneMaskRechecked: false, reason: "\u4F7F\u7528\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\uFF1B\u53EA\u8BFB\u6838\u5BF9\u5F53\u524D\u767B\u5F55\u59D3\u540D\u3001\u6C42\u804C\u5165\u53E3\u53CA\u9875\u9762\u8FDE\u7EED\u6027\uFF0C\u624B\u673A\u53F7\u63A9\u7801\u6CBF\u7528\u786E\u8BA4\u6765\u6E90\uFF0C\u6CA1\u6709\u91CD\u65B0\u8BFB\u53D6\u3002" };
  }
  return stdin_default2;
})();
const cursorCanonical = (value) => Array.isArray(value) ? value.map(cursorCanonical) : value && typeof value === "object" ? Object.fromEntries(Object.keys(value).sort().map((key) => [key, cursorCanonical(value[key])])) : value;
const cursorDigest = (value) => createHash("sha256").update(JSON.stringify(cursorCanonical(value))).digest("hex");
async function restoreRequestChat(read, source) {
  const compact = (v) => String(v).replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
  const same = async () => {
    const u = new URL(await read("url"));
    return u.origin === "https://www.zhipin.com" && u.pathname === "/web/geek/chat" && await read("count", ".chat-conversation .user-info") === 1 && compact(await read("read", ".chat-conversation .user-info")) === compact(source.recipientLabel) && await read("count", source.request.agreeSelector) === 1 && await read("count", source.request.root) === 1 && String(await read("read", source.request.root)).trim() === source.request.text && String(await read("read", ".chat-position-content")).trim() === source.chatJobTitle;
  };
  if (await same()) return;
  await read("navigate", void 0, "https://www.zhipin.com/web/geek/chat");
  const inputSelector = ".list-warp.v2 input";
  let ready = false;
  for (let n = 0; n < 40; n++) {
    if (await read("count", inputSelector) === 1) {
      ready = true;
      break;
    }
    await new Promise((r) => setTimeout(r, 150));
  }
  if (!ready) throw Error("\u539F\u4F1A\u8BDD\u5B9A\u5411\u641C\u7D22\u5C1A\u672A\u52A0\u8F7D\uFF0C\u672A\u9009\u62E9\u5176\u4ED6\u4F1A\u8BDD");
  if (await same()) return;
  await read("fill", inputSelector, source.recipientName);
  const root = ".boss-search-result .search-list";
  let matches = [];
  for (let n = 0; n < 30; n++) {
    const count = await read("count", root);
    if (!Number.isSafeInteger(count) || count > 50) throw Error("\u8054\u7CFB\u4EBA\u5B9A\u5411\u641C\u7D22\u8303\u56F4\u65E0\u6548");
    matches = [];
    for (let j = 1; j <= count; j++) {
      const selector = root + ":nth-child(" + j + " of .search-list)", text = String(await read("read", selector)).trim();
      if (typeof source.searchResultText === "string" && compact(text.split(/职位\s*[:：]/u)[0]) === compact(source.searchResultText.split(/职位\s*[:：]/u)[0])) matches.push({ selector, text });
    }
    if (matches.length) break;
    await new Promise((r) => setTimeout(r, 150));
  }
  if (matches.length !== 1) throw Error("\u672A\u627E\u5230\u552F\u4E00\u7684\u539F\u59D3\u540D\u3001\u516C\u53F8\u548C\u89D2\u8272\u7EC4\u5408\uFF0C\u672A\u6253\u5F00\u5176\u4ED6\u4F1A\u8BDD");
  const target = matches[0];
  if (String(await read("read", target.selector)).trim() !== target.text) throw Error("\u539F\u8054\u7CFB\u4EBA\u641C\u7D22\u7ED3\u679C\u53D8\u5316\uFF0C\u672A\u70B9\u51FB");
  await read("click", target.selector);
  ready = false;
  for (let n = 0; n < 40; n++) {
    if (await same()) {
      ready = true;
      break;
    }
    await new Promise((r) => setTimeout(r, 150));
  }
  if (!ready) throw Error("\u539F\u4F1A\u8BDD\u3001\u539F\u9644\u4EF6\u8BF7\u6C42\u672A\u91CD\u65B0\u8BFB\u56DE\uFF0C\u4E0D\u53D1\u9001");
}
async function stdin_default({ input, template, signal, artifact }) {
  signal.throwIfAborted();
  const raw = input?.configuration, initial = input?.state;
  if (raw?.operation !== "configuration" || initial?.operation !== "state.read" || raw.contextId !== initial.contextId || !raw.value || !initial.value) throw Error("\u7F3A\u5C11\u540C\u5B9E\u4F8B\u7684\u56FA\u5B9A\u914D\u7F6E\u4E0E\u72B6\u6001");
  const accountSource = await checkAccountSource({ input: input.account, signal });
  await checkCurrentAccount({ input: { expected: accountSource }, template, signal });
  const read = (operation, selector, value) => nativeNavigationRead(template, signal, operation, selector, value);
  const current = new URL(await read("url"));
  if (current.origin !== "https://www.zhipin.com" || current.pathname !== "/web/geek/chat") throw Error("\u8BF7\u5148\u5728\u5185\u7F6E\u7F51\u9875\u6253\u5F00\u8981\u5904\u7406\u7684\u5DF2\u6709\u4F1A\u8BDD\uFF1B\u4E0D\u4F1A\u53D1\u8D77\u65B0\u7684\u9996\u6B21\u6C9F\u901A");
  const a = accountSource.account, resume = new URL(a.jobseekerResumeHref, a.sourceUrl), accountKey = createHash("sha256").update(JSON.stringify(["boss-visible-account-source-v1", a.accountName, a.phoneMask, resume.origin + resume.pathname])).digest("hex");
  const compact = (v) => v.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
  const header = ".chat-conversation .user-info", jobSelector = ".chat-position-content";
  if (await read("count", header) !== 1 || await read("count", jobSelector) !== 1) throw Error("\u5F53\u524D\u4F1A\u8BDD\u6216\u5C97\u4F4D\u4E0D\u552F\u4E00");
  const recipientLabel = String(await read("read", header)).trim(), chatJobTitle = String(await read("read", jobSelector)).trim(), recipientName = recipientLabel.split(/\r?\n/u)[0], jobLines = chatJobTitle.split(/\r?\n/u).map((v) => v.trim()).filter(Boolean);
  if (!recipientName || recipientLabel.length > 1e3 || jobLines.length < 3) throw Error("\u7F3A\u5C11\u51C6\u786E\u62DB\u8058\u8005\u3001\u516C\u53F8\u6216\u5C97\u4F4D\u6765\u6E90");
  const messages = async () => {
    const count = await read("count", "li.message-item");
    if (!Number.isSafeInteger(count) || count < 1 || count > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u6D88\u606F\u8303\u56F4\u4E0D\u53EF\u6838\u5BF9\uFF0C\u672A\u622A\u65AD");
    const rows2 = [];
    for (let n = 1; n <= count; n++) {
      const selector = "li.message-item:nth-child(" + n + " of li.message-item)", mid = await read("attribute", selector, "data-mid"), cls = await read("attribute", selector, "class"), text = String(await read("read", selector)).trim();
      if (!/^\d{6,40}$/.test(mid || "") || typeof cls !== "string" || text.length > 2e4) throw Error("\u6D88\u606F\u8EAB\u4EFD\u6216\u5B8C\u6574\u6B63\u6587\u65E0\u6548");
      rows2.push({ mid, class: cls, text });
    }
    if (new Set(rows2.map((r) => r.mid)).size !== rows2.length) throw Error("\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
    return rows2;
  };
  const rows = await messages(), requests = [];
  for (const row of rows) {
    if (!row.class.split(/\s/u).includes("item-friend") || !row.text.includes("\u6211\u60F3\u8981\u4E00\u4EFD\u60A8\u7684\u9644\u4EF6\u7B80\u5386\uFF0C\u60A8\u662F\u5426\u540C\u610F")) continue;
    const root = 'li.message-item[data-mid="' + row.mid + '"]', agreeSelector = root + " .message-dialog-both .card-btn:nth-child(2)", rejectSelector = root + " .message-dialog-both .card-btn:nth-child(1)";
    if (await read("count", agreeSelector) === 1 && await read("count", rejectSelector) === 1 && String(await read("read", agreeSelector)).trim() === "\u540C\u610F" && String(await read("read", rejectSelector)).trim() === "\u62D2\u7EDD") requests.push({ mid: row.mid, root, agreeSelector, rejectSelector, text: row.text });
  }
  if (!requests.length) {
    const result2 = { version: 1, kind: "boss-resume-request-source", ready: false, status: "no-pending-resume-request", reason: "\u5F53\u524D\u4F1A\u8BDD\u6CA1\u6709\u51C6\u786E\u7684\u672A\u5904\u7406\u9644\u4EF6\u8BF7\u6C42\uFF0C\u4E0D\u4E0A\u4F20\u6216\u53D1\u9001", websiteMessagesSent: 0, aiCalled: false };
    await template.result(result2);
    return result2;
  }
  if (requests.length !== 1) throw Error("\u5B58\u5728\u591A\u4E2A\u672A\u5904\u7406\u9644\u4EF6\u8BF7\u6C42\uFF0C\u8BF7\u672C\u4EBA\u660E\u786E\u5F53\u524D\u8BF7\u6C42\uFF0C\u4E0D\u6309\u4F4D\u7F6E\u731C\u6D4B");
  const request = requests[0], salary = /^(\d+(?:\.\d+)?)-(\d+(?:\.\d+)?)K(?:·\d+薪)?$/iu.exec(jobLines[1]);
  if (!salary || !raw.value.cities?.includes(jobLines[2]) || Number(salary[2]) * 1e3 < raw.value.salaryMin || raw.value.salaryMax > 0 && Number(salary[1]) * 1e3 > raw.value.salaryMax) throw Error("\u5C97\u4F4D\u57CE\u5E02\u6216\u6708\u85AA\u4EA4\u96C6\u672A\u901A\u8FC7\uFF0C\u4E0D\u53D1\u9001\u9644\u4EF6");
  const titleScope = titleScopeEvidence(jobLines[0], raw.value);
  if (!titleScope.allowed) throw Error("\u9644\u4EF6\u8BF7\u6C42\u7684\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u672A\u901A\u8FC7\u672C\u4EBA\u5141\u8BB8\u8BCD\u548C\u6392\u9664\u9879\uFF1B\u672A\u5EFA\u7ACB\u53D1\u9001\u610F\u56FE");
  if ((raw.value.excludedRoles || []).some((v) => v && jobLines[0].normalize("NFKC").toLowerCase().includes(v.normalize("NFKC").toLowerCase()))) throw Error("\u5F53\u524D\u5C97\u4F4D\u547D\u4E2D\u672C\u4EBA\u6392\u9664\u6761\u4EF6");
  const searchResultText = await pinRecipientSearchResult(read, { recipientName, recipientLabel, chatJobTitle });
  if (String(await read("read", header)).trim() !== recipientLabel || JSON.stringify(await messages()) !== JSON.stringify(rows)) throw Error("\u56FA\u5B9A\u8054\u7CFB\u4EBA\u671F\u95F4\u539F\u4F1A\u8BDD\u6216\u8BF7\u6C42\u53D8\u5316");
  const sourceIdentity = { searchResultText, accountKey, recipientLabel, chatJobTitle, firstMessageId: rows[0].mid, requestMid: request.mid, rowsSha256: cursorDigest(rows) }, sourceCacheName = "resume-job-source-v1-" + cursorDigest(sourceIdentity) + ".json";
  let priorDelivery = null;
  try {
    const book = JSON.parse(await template.file("communication-cache", { operation: "read", name: "resume-delivery-index-v1-" + accountKey + ".json" })), { sha256: sha2562, ...body } = book;
    if (sha2562 !== cursorDigest(body) || book.accountKey !== accountKey || book.kind !== "boss-resume-delivery-index" || !Array.isArray(book.deliveries)) throw Error("\u539F\u9644\u4EF6\u8D26\u672C\u4E0D\u7B26\uFF0C\u672A\u91C7\u7528");
    const key = cursorDigest(["boss-resume-request-v1", accountKey, rows[0].mid, request.mid]);
    priorDelivery = book.deliveries.find((v) => v.key === key && v.effectId && v.sendKey && compact(v.recipientLabel) === compact(recipientLabel) && v.firstMessageId === rows[0].mid && v.requestMid === request.mid) || null;
  } catch (e) {
    if (!String(e.message || e).includes("ENOENT")) throw e;
  }
  let sourceCache = null;
  try {
    const text = await template.file("communication-cache", { operation: "read", name: sourceCacheName });
    sourceCache = JSON.parse(text);
    const { sha256: sha2562, ...body } = sourceCache;
    if (sha2562 !== cursorDigest(body) || sourceCache.kind !== "boss-resume-job-source" || cursorDigest(sourceCache.identity) !== cursorDigest(sourceIdentity)) throw Error("\u539F\u8BF7\u6C42\u5C97\u4F4D\u89C2\u5BDF\u7F13\u5B58\u4E0D\u7B26\uFF0C\u4E0D\u91C7\u7528");
  } catch (e) {
    if (!String(e.message || e).includes("ENOENT")) throw e;
  }
  let jobSource, jobId;
  if (priorDelivery) {
    const u = new URL(priorDelivery.jobSource);
    if (u.origin !== "https://www.zhipin.com" || !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(u.pathname) || u.search || u.hash) throw Error("\u539F\u53D1\u9001\u8BB0\u5F55\u5C97\u4F4D\u6765\u6E90\u4E0D\u7B26");
    jobSource = u.href;
    jobId = u.pathname.split("/").at(-1).slice(0, -5);
  } else if (sourceCache && Date.now() - Date.parse(sourceCache.checkedAt) >= 0 && Date.now() - Date.parse(sourceCache.checkedAt) <= 9e5) {
    const u = new URL(sourceCache.jobSource);
    if (u.origin !== "https://www.zhipin.com" || !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(u.pathname) || u.search || u.hash || sourceCache.jobTitle !== jobLines[0] || u.pathname.split("/").at(-1).slice(0, -5) !== sourceCache.jobId) throw Error("\u539F\u8BF7\u6C42\u5C97\u4F4D\u89C2\u5BDF\u7F13\u5B58\u7684\u6765\u6E90\u65E0\u6548");
    jobSource = u.href;
    jobId = sourceCache.jobId;
  } else {
    const jobLink = ".chat-position-content .right-content > :first-child";
    if (await read("count", jobLink) !== 1 || String(await read("read", jobLink)).replace(/[\uE000-\uF8FF]/gu, "").trim() !== "\u67E5\u770B\u804C\u4F4D") throw Error("\u7F3A\u5C11\u5F53\u524D\u4F1A\u8BDD\u552F\u4E00\u7684\u539F\u5173\u8054\u804C\u4F4D\u5165\u53E3");
    await read("click", jobLink);
    let jobUrl;
    for (let n = 0; n < 40; n++) {
      const u = new URL(await read("url"));
      if (u.origin === "https://www.zhipin.com" && /^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(u.pathname) && await read("count", "h1") === 1 && String(await read("read", "h1")).trim() === jobLines[0].replace(/（猎头职位）$/u, "").trim()) {
        jobUrl = u;
        break;
      }
      await new Promise((r) => setTimeout(r, 150));
    }
    if (!jobUrl) throw Error("\u539F\u5173\u8054\u804C\u4F4D\u6765\u6E90\u4E0E\u6807\u9898\u672A\u8BFB\u56DE");
    jobSource = jobUrl.origin + jobUrl.pathname;
    jobId = jobUrl.pathname.split("/").at(-1).slice(0, -5);
    sourceCache = { version: 1, kind: "boss-resume-job-source", identity: sourceIdentity, jobSource, jobId, jobTitle: jobLines[0], checkedAt: (/* @__PURE__ */ new Date()).toISOString(), isActionAuthorization: false };
    sourceCache.sha256 = cursorDigest(sourceCache);
    const content = JSON.stringify(sourceCache);
    await template.file("communication-cache", { operation: "write", name: sourceCacheName, content });
    if (await template.file("communication-cache", { operation: "read", name: sourceCacheName }) !== content) throw Error("\u539F\u5C97\u4F4D\u89C2\u5BDF\u672A\u5B8C\u6574\u8BFB\u56DE\uFF0C\u4E0D\u91C7\u7528");
    await artifact("resume-job-source-observation.json", JSON.stringify(sourceCache, null, 2));
    await restoreRequestChat(read, { recipientName, recipientLabel, request, chatJobTitle, searchResultText });
    if (JSON.stringify(await messages()) !== JSON.stringify(rows)) throw Error("\u8FD4\u56DE\u540E\u7684\u4F1A\u8BDD\u6216\u539F\u8BF7\u6C42\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62");
  }
  const state = await template.state.get(), conversationKey = "boss-job:" + jobId;
  if ((state.conversationControls || []).some((c) => c.accountKey === accountKey && [conversationKey, "boss-chat:" + rows[0].mid].includes(c.conversationKey) && c.mode === "paused")) throw Error("\u672C\u4EBA\u5DF2\u63A5\u7BA1\u6B64\u4F1A\u8BDD\uFF0C\u4E0D\u53D1\u9001\u9644\u4EF6");
  const requestKey = cursorDigest(["boss-resume-request-v1", accountKey, rows[0].mid, request.mid]);
  const indexName = "account-outbound-safety-v1-" + accountKey + ".json", index = JSON.parse(await template.file("communication-cache", { operation: "read", name: indexName }));
  const { sha256, ...indexBody } = index;
  if (sha256 !== cursorDigest(indexBody) || index.accountKey !== accountKey || index.kind !== "boss-account-outbound-safety") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\u6216\u4E0D\u7B26\uFF0C\u7981\u6B62\u9644\u4EF6\u5916\u53D1");
  const result = { version: 1, kind: "boss-resume-request-source", ready: true, contextId: raw.contextId, configurationRevision: raw.revision, configuration: raw.value, titleScope, accountSource, accountKey, recipientLabel, recipientName, chatJobTitle, searchResultText, jobTitle: jobLines[0], jobSource, jobId, conversationKey, firstMessageId: rows[0].mid, request, requestKey, rows, sourceSha256: cursorDigest({ accountKey, recipientLabel, jobSource, rows, searchResultText }), aiCalled: false, websiteMessagesSent: 0 };
  await artifact("resume-request-source.json", JSON.stringify(result, null, 2));
  return result;
}
export {
  stdin_default as default
};
