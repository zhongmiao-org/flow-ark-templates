function titleScopeEvidence(title, configuration) {
  const normalize = (value) => value.normalize("NFKC").replace(/\s+/gu, " ").trim().toLocaleLowerCase("en-US");
  if (typeof title !== "string" || !title.trim() || title.length > 1e3 || /(?:\.{3}|…|⋯)/u.test(title)) throw Error("\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u7F3A\u5931\u6216\u622A\u65AD\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u8BB0\u5F55");
  const positive = configuration?.titleKeywords, negative = configuration?.excludedRoles;
  for (const [name, terms, minimum] of [["titleKeywords", positive, 1], ["excludedRoles", negative, 0]]) {
    if (!Array.isArray(terms) || terms.length < minimum || terms.length > 20 || terms.some((v) => typeof v !== "string" || !normalize(v) || v.length > 100) || new Set(terms.map(normalize)).size !== terms.length) throw Error("\u5C97\u4F4D\u8303\u56F4\u914D\u7F6E\u65E0\u6548\uFF1A" + name + "\uFF1B\u672A\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE");
  }
  const fullTitle = normalize(title), excluded = negative.filter((term) => fullTitle.includes(normalize(term))), matched = positive.filter((term) => fullTitle.includes(normalize(term)));
  return { version: 1, kind: "literal-full-job-title-scope", fullTitle: title, matched, excluded, allowed: excluded.length === 0 && matched.length > 0, source: "actual-complete-job-title", jdUsed: false, searchKeywordUsedAsEvidence: false };
}
import { createHash } from "node:crypto";
const checkAccountSource = /* @__PURE__ */ (() => {
  var stdin_default2 = async ({ input, signal }) => {
    signal.throwIfAborted();
    const read = input, account = read?.value;
    if (!read || read.version !== 1 || read.operation !== "read" || read.binding !== "account-source-result" || read.schemaValidation !== "passed" || read.dataChanged !== false || read.ref?.version !== 1 || read.ref.policy !== "credential-redacted-v1" || read.ref.source?.entryId !== "account-source") throw new Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u5DF2\u9009\u62E9\u4E14\u5B8C\u6574\u53EF\u590D\u7528\u7684\u8D26\u53F7\u6765\u6E90\uFF0C\u8BF7\u5230\u8D44\u6E90\u9875\u91CD\u65B0\u6838\u5BF9\u5E76\u4FDD\u5B58");
    if (!account || account.version !== 1 || account.kind !== "boss-account-source" || account.status !== "account-source-confirmed" || account.accountVerified !== true || account.platformUniqueIdVerified !== false || account.eligibleForActions !== false || account.role !== "jobseeker") throw new Error("\u6240\u9009\u8BB0\u5F55\u5C1A\u672A\u5B8C\u6210\u672C\u4EBA\u786E\u8BA4\u548C\u6765\u6E90\u590D\u9A8C\uFF1B\u8BF7\u5728\u5F53\u524D\u5B9E\u4F8B\u5B8C\u6210\u8D26\u53F7\u6838\u5BF9\uFF0C\u518D\u9009\u62E9\u8BE5\u6B21\u5DF2\u4FDD\u5B58\u7ED3\u679C");
    const keys = ["version", "kind", "status", "accountAlias", "accountName", "phoneMask", "jobseekerResumeHref", "role", "sourceUrl", "accountVerified", "platformUniqueIdVerified", "eligibleForActions", "confirmedAt", "checkedAt", "reason"];
    if (Object.keys(account).length !== keys.length || keys.some((k) => !Object.prototype.hasOwnProperty.call(account, k))) throw new Error("\u6240\u9009\u8D26\u53F7\u7ED3\u679C\u7ED3\u6784\u4E0D\u7B26\uFF0C\u505C\u6B62\u91C7\u7528");
    for (const key of ["accountAlias", "accountName", "phoneMask"]) if (typeof account[key] !== "string" || !account[key].trim() || account[key] !== account[key].trim() || account[key].length > 100 || /[\r\n]/.test(account[key])) throw new Error("\u8D26\u53F7\u5FC5\u8981\u5B57\u6BB5\u7F3A\u5931\u6216\u683C\u5F0F\u65E0\u6548\uFF0C\u505C\u6B62\u91C7\u7528");
    if (!/^[+\d ()-]*\*{2,}[\d ()-]+$/.test(account.phoneMask) || /登录|注册|验证码/.test(account.accountName)) throw new Error("\u8D26\u53F7\u6765\u6E90\u7F3A\u5C11\u6709\u6548\u7684\u53EF\u89C1\u59D3\u540D\u6216\u624B\u673A\u53F7\u63A9\u7801");
    if (typeof account.reason !== "string" || !account.reason.trim()) throw new Error("\u8D26\u53F7\u7ED3\u679C\u7F3A\u5C11\u660E\u786E\u6838\u5BF9\u8BF4\u660E");
    const confirmedAt = Date.parse(account.confirmedAt), checkedAt = Date.parse(account.checkedAt);
    if (typeof account.confirmedAt !== "string" || typeof account.checkedAt !== "string" || !Number.isFinite(confirmedAt) || !Number.isFinite(checkedAt) || confirmedAt <= 0 || checkedAt < confirmedAt || checkedAt > Date.now() + 6e4) throw new Error("\u8D26\u53F7\u786E\u8BA4\u6216\u590D\u9A8C\u65F6\u95F4\u65E0\u6CD5\u6838\u5BF9\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4");
    if (typeof account.sourceUrl !== "string" || typeof account.jobseekerResumeHref !== "string" || !account.sourceUrl.trim() || !account.jobseekerResumeHref.trim() || account.sourceUrl.length > 16384 || account.jobseekerResumeHref.length > 16384) throw new Error("\u8D26\u53F7\u9875\u9762\u6216\u7B80\u5386\u5165\u53E3\u5730\u5740\u65E0\u6548");
    const page = new URL(account.sourceUrl), resume = new URL(account.jobseekerResumeHref, account.sourceUrl);
    if (page.origin !== "https://www.zhipin.com" || page.pathname !== "/web/geek/account" || page.searchParams.get("type") !== "accountSet" || page.username || page.password || page.hash || resume.origin !== page.origin || resume.pathname !== "/web/geek/resume" || resume.username || resume.password) throw new Error("\u8D26\u53F7\u8BB0\u5F55\u7684\u9875\u9762\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u4E0D\u7B26");
    signal.throwIfAborted();
    return { version: 1, accountSourceValid: true, currentAccountVerified: false, account };
  };
  return stdin_default2;
})();
const checkCurrentAccount = /* @__PURE__ */ (() => {
  async function stdin_default2({ input, signal, template }) {
    signal.throwIfAborted();
    const a = input?.expected?.account;
    if (input?.expected?.accountSourceValid !== true || a?.kind !== "boss-account-source" || a.status !== "account-source-confirmed" || a.accountVerified !== true) throw Error("\u7F3A\u5C11\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\u6765\u6E90");
    const call = async (operation, selector, value) => {
      signal.throwIfAborted();
      const r2 = await template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
      signal.throwIfAborted();
      return r2;
    };
    const before = await call("url"), p = new URL(before);
    if (p.origin !== "https://www.zhipin.com" || p.username || p.password || !p.pathname.startsWith("/web/") && !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(p.pathname)) throw Error("\u5F53\u524D\u9875\u9762\u4E0D\u662FBOSS\u6C42\u804C\u9875\u9762\uFF0C\u8BF7\u5148\u767B\u5F55");
    const n = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", r = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)";
    const nameCount = await call("count", n), resumeCount = await call("count", r);
    if (nameCount !== 1 || resumeCount !== 1) throw Error("\u5F53\u524D\u9875\u9762\u8D26\u53F7\u5165\u53E3\u6570\u91CF\u5F02\u5E38\uFF1A" + JSON.stringify({ nameCount, resumeCount }));
    const name = await call("read", n), href = await call("attribute", r, "href");
    if (typeof name !== "string" || name.normalize("NFKC").trim() !== a.accountName.normalize("NFKC").trim() || typeof href !== "string" || new URL(href, before).href !== new URL(a.jobseekerResumeHref, a.sourceUrl).href || await call("url") !== before) throw Error("\u5F53\u524D\u767B\u5F55\u8EAB\u4EFD\u3001\u6C42\u804C\u5165\u53E3\u6216\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
    return { version: 1, status: "current-account-source-matched", accountAlias: a.accountAlias, accountName: a.accountName, phoneMask: a.phoneMask, jobseekerResumeHref: a.jobseekerResumeHref, sourceUrl: a.sourceUrl, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), currentPageUrl: before, currentAccountVerified: true, platformUniqueIdVerified: false, eligibleForActions: false, accountCheckMode: "confirmed-initial-account-and-visible-header", phoneMaskRechecked: false, reason: "\u4F7F\u7528\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\uFF1B\u53EA\u8BFB\u6838\u5BF9\u5F53\u524D\u767B\u5F55\u59D3\u540D\u3001\u6C42\u804C\u5165\u53E3\u53CA\u9875\u9762\u8FDE\u7EED\u6027\uFF0C\u624B\u673A\u53F7\u63A9\u7801\u6CBF\u7528\u786E\u8BA4\u6765\u6E90\uFF0C\u6CA1\u6709\u91CD\u65B0\u8BFB\u53D6\u3002" };
  }
  return stdin_default2;
})();
const cursorCanonical = (value) => Array.isArray(value) ? value.map(cursorCanonical) : value && typeof value === "object" ? Object.fromEntries(Object.keys(value).sort().map((key) => [key, cursorCanonical(value[key])])) : value;
const cursorDigest = (value) => createHash("sha256").update(JSON.stringify(cursorCanonical(value))).digest("hex");
const canonical = (v) => Array.isArray(v) ? v.map(canonical) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical(v[k])])) : v;
const digest = (v) => createHash("sha256").update(JSON.stringify(canonical(v))).digest("hex");
async function safetyIndex(template, signal, accountKey, contextId, initialize = false) {
  const name = "account-outbound-safety-v1-" + accountKey + ".json";
  let data, existed = true, baseline;
  try {
    baseline = await template.file("communication-cache", { operation: "read", name });
    data = JSON.parse(baseline);
  } catch (error) {
    if (!String(error.message || error).includes("ENOENT")) throw error;
    if (!initialize) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
    existed = false;
    data = { version: 1, kind: "boss-account-outbound-safety", accountKey, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (existed) {
    const { sha256, ...body } = data;
    if (sha256 !== digest(body)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
  }
  if (data.version !== 1 || data.kind !== "boss-account-outbound-safety" || data.accountKey !== accountKey || !Number.isSafeInteger(data.revision) || data.revision < 0 || !Array.isArray(data.records) || data.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
  const records = /* @__PURE__ */ new Set();
  for (const r of data.records) {
    if (!["first-contact", "reply"].includes(r.type) || !/^[a-f0-9]{64}$/.test(r.businessKey) || !Array.isArray(r.sightings) || !r.sightings.length || r.sightings.length > 100 || records.has(r.type + ":" + r.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
    records.add(r.type + ":" + r.businessKey);
    for (const s of r.sightings) if (typeof s.contextId !== "string" || !s.contextId || !/^[a-f0-9]{64}$/.test(s.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(s.status) || !/^\d{4}-\d{2}-\d{2}$/.test(s.day) || typeof s.timeZone !== "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
  }
  let dirty = !existed;
  const merge = (state) => {
    if (!Array.isArray(state?.applicationIntents) || !Array.isArray(state?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
    for (const [type, rows] of [["first-contact", state.applicationIntents], ["reply", state.replyIntents]]) for (const i of rows) {
      if ((type === "first-contact" ? i.accountSourceSha256 : i.accountKey) !== accountKey) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
      if (!/^[a-f0-9]{64}$/.test(i.key) || !i.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(i.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
      const businessKey = type === "first-contact" ? digest(["boss-job-safety-v1", accountKey, i.jobId]) : createHash("sha256").update(["boss-text-reply-v1", accountKey, i.incomingMessageId].join(":")).digest("hex");
      let r = data.records.find((r2) => r2.type === type && r2.businessKey === businessKey);
      if (!r) {
        r = { type, businessKey, jobId: i.jobId, ...type === "reply" ? { conversationKey: i.conversationKey, incomingMessageId: i.incomingMessageId } : {}, sightings: [] };
        data.records.push(r);
        dirty = true;
      }
      if (r.jobId !== i.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
      const sight = { contextId, intentKey: i.key, status: i.status, day: i.day, timeZone: i.timeZone, contentSha256: i.contentSha256 || null, sourceSha256: i.sourceSha256 || null };
      if (!r.sightings.some((s) => JSON.stringify(canonical(s)) === JSON.stringify(canonical(sight)))) {
        r.sightings.push(sight);
        dirty = true;
      }
      if (r.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
    }
    if (data.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
  };
  const save = async () => {
    signal.throwIfAborted();
    if (dirty) {
      if (existed && await template.file("communication-cache", { operation: "read", name }) !== baseline) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
      data.records.sort((a, b) => (a.type + ":" + a.businessKey).localeCompare(b.type + ":" + b.businessKey));
      for (const r of data.records) r.sightings.sort((a, b) => JSON.stringify(canonical(a)).localeCompare(JSON.stringify(canonical(b))));
      data.revision++;
      data.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      delete data.sha256;
      data.sha256 = digest(data);
      await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(data) });
      dirty = false;
      baseline = JSON.stringify(data);
      existed = true;
    }
    const back = JSON.parse(await template.file("communication-cache", { operation: "read", name }));
    const { sha256, ...body } = back;
    if (sha256 !== digest(body) || sha256 !== data.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
    return { revision: data.revision, sha256: data.sha256, records: data.records.length };
  };
  return { data, name, merge, save, blocked: (type, key) => data.records.some((r) => r.type === type && r.businessKey === key) };
}
const closingRead = (template, signal) => async (operation, selector, value) => {
  signal.throwIfAborted();
  return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
};
const closingValid = (v) => {
  const { sha256, ...body } = v;
  return sha256 === digest(body);
};
async function closingProgress(template, signal, c, change) {
  const name = c.progressName, raw = await template.file("communication-cache", { operation: "read", name }), p = JSON.parse(raw);
  if (!closingValid(p) || p.accountKey !== c.accountKey || p.fixedUnreadSetSha256 !== c.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
  if (!change) return p;
  const next = change(structuredClone(p));
  next.revision++;
  next.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  delete next.sha256;
  next.sha256 = digest(next);
  if (await template.file("communication-cache", { operation: "read", name }) !== raw) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  signal.throwIfAborted();
  await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(next) });
  const back = JSON.parse(await template.file("communication-cache", { operation: "read", name }));
  if (!closingValid(back) || back.sha256 !== next.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
  return back;
}
async function closingMessages(read) {
  const count = await read("count", "li.message-item");
  if (!Number.isSafeInteger(count) || count < 1 || count > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
  const rows = [];
  for (let n = 1; n <= count; n++) {
    const selector = "li.message-item:nth-child(" + n + " of li.message-item)", mid = await read("attribute", selector, "data-mid"), cls = await read("attribute", selector, "class");
    if (!/^\d{6,40}$/.test(mid || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
    const texts = await read("count", selector + " .text-content");
    if (texts > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
    const text = texts === 1 ? String(await read("read", selector + " .text-content")).trim() : null, context = text === null ? String(await read("read", selector)).trim() : null;
    if ((text || context || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
    const systemText = !!text && /^您正在与Boss.+沟通$/u.test(text), direction = !systemText && text !== null && cls.split(/\s+/u).includes("item-myself") ? "outgoing" : !systemText && text !== null && cls.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
    rows.push({ mid, direction, text, context });
  }
  if (new Set(rows.map((r) => r.mid)).size !== rows.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
  return rows;
}
async function closingRecipient(read, c) {
  const url = new URL(await read("url"));
  if (url.origin !== "https://www.zhipin.com" || url.pathname !== "/web/geek/chat" || await read("count", ".chat-conversation .user-info") !== 1) return false;
  const header = String(await read("read", ".chat-conversation .user-info")).trim(), compact = (v) => v.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
  const expected = compact(c.member.identityLine), observed = compact(header), count = await read("count", ".friend-content.selected");
  if (count > 1) return false;
  const selected = count === 1 ? compact(String(await read("read", ".friend-content.selected"))) : null;
  if (observed === expected) return selected === null || selected.includes(expected);
  const name = /^(.{1,20}?(?:先生|女士))/u.exec(expected)?.[1];
  return !!name && expected.endsWith("\u730E\u5934\u987E\u95EE") && observed === name + "\u730E\u5934\u987E\u95EE" && (selected !== null ? selected.includes(expected) : c.member.searchIdentityProof?.identityLine === c.member.identityLine && compact(c.member.searchIdentityProof.targetText).includes(expected));
}
async function closingSourceSame(template, signal, c) {
  const read = closingRead(template, signal);
  if (!await closingRecipient(read, c)) return false;
  const name = String(await read("read", c.accountSelector)).trim();
  return name === c.accountLabel && String(await read("read", c.recipientSelector)).trim() === c.recipientLabel && String(await read("read", c.jobSelector)).trim() === c.chatJobTitle && JSON.stringify(await closingMessages(read)) === JSON.stringify(c.rows);
}
var stdin_default = async ({ input, template, signal, artifact }) => {
  const c = input?.cohort, profile = input?.profile;
  if (c?.kind !== "unread-closing-cohort" || c.closingPhase !== true || profile?.version !== 1 || !profile.ref?.versionId || !profile.markdown?.trim()) throw Error("\u7F3A\u5C11\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u6216\u672C\u6B21\u786E\u8BA4Skill");
  const base = { ...c, kind: "chat-reply-source", fixedUnreadMember: true, profile, returnToJobs: false };
  if (!c.ready) return { ...base, ready: false, status: "fixed-unread-complete", reason: "\u56FA\u5B9A\u96C6\u5408\u5DF2\u5904\u7406\u5B8C\u6BD5\uFF0C\u4E0D\u91CD\u65B0\u626B\u63CF" };
  await checkCurrentAccount({ input: { expected: c.accountSource }, template, signal });
  const read = closingRead(template, signal), member = c.member;
  let p = await closingProgress(template, signal, c);
  if (p.completed.some((x) => x.memberKey === member.key && !(x.status === "review" && x.replyPolicyVersion !== "work-questions-partial-known-v2"))) return { ...base, ready: false, status: "already-completed", reason: "\u8BE5\u56FA\u5B9A\u6210\u5458\u5DF2\u5904\u7406\uFF0C\u672A\u91CD\u590D\u6253\u5F00" };
  if (p.active && p.active.memberKey !== member.key) throw Error("\u6D3B\u8DC3\u4F1A\u8BDD\u4E0E\u56FA\u5B9A\u6210\u5458\u4E0D\u7B26");
  if (!await closingRecipient(read, c)) {
    const page = new URL(await read("url"));
    if (page.origin !== "https://www.zhipin.com" || page.pathname !== "/web/geek/chat") await read("navigate", void 0, "https://www.zhipin.com/web/geek/chat");
    const targetName = p.active?.recipientName || /^(.{1,20}?(?:先生|女士))/u.exec(member.identityLine)?.[1];
    if (!targetName) throw Error("\u56FA\u5B9A\u6210\u5458\u7F3A\u5C11\u53EF\u6838\u5BF9\u7684\u5B9A\u5411\u641C\u7D22\u59D3\u540D\uFF0C\u672A\u731C\u6D4B");
    const inputSelector = ".list-warp.v2 input";
    let inputReady = false;
    for (let n = 0; n < 40; n++) {
      if (await read("count", inputSelector) === 1) {
        inputReady = true;
        break;
      }
      await new Promise((r) => setTimeout(r, 150));
    }
    if (!inputReady) throw Error("\u4F1A\u8BDD\u5B9A\u5411\u641C\u7D22\u5C1A\u672A\u52A0\u8F7D");
    await read("fill", inputSelector, targetName);
    const compact = (v) => v.replace(/[\s\uE000-\uF8FF]/gu, ""), root = ".boss-search-result .search-list";
    let matches = [];
    for (let attempt = 0; attempt < 30; attempt++) {
      const count = await read("count", root);
      if (!Number.isSafeInteger(count) || count > 50) throw Error("\u56FA\u5B9A\u59D3\u540D\u641C\u7D22\u8FD4\u56DE\u8303\u56F4\u65E0\u6548");
      matches = [];
      for (let n = 1; n <= count; n++) {
        const sel = root + ":nth-child(" + n + " of .search-list)";
        if (await read("count", sel) !== 1) throw Error("\u59D3\u540D\u641C\u7D22\u5BF9\u8C61\u4E0D\u552F\u4E00");
        const text = String(await read("read", sel)).trim();
        if (compact(text).includes(compact(member.identityLine))) matches.push({ sel, text });
      }
      if (matches.length) break;
      await new Promise((r) => setTimeout(r, 150));
    }
    if (matches.length !== 1) throw Error("\u56FA\u5B9A\u59D3\u540D\u641C\u7D22\u672A\u53D6\u5F97\u552F\u4E00\u7684\u59D3\u540D\u3001\u516C\u53F8\u548C\u89D2\u8272\u7EC4\u5408\uFF0C\u672A\u6253\u5F00\u5176\u4ED6\u4F1A\u8BDD");
    const target = matches[0];
    p = await closingProgress(template, signal, c, (q) => {
      if (q.active && q.active.memberKey !== member.key) throw Error("\u6D3B\u8DC3\u6210\u5458\u53D8\u5316");
      q.active = { ...q.active, memberKey: member.key, identityLine: member.identityLine, contextId: c.contextId, openedAt: q.active?.openedAt || (/* @__PURE__ */ new Date()).toISOString() };
      return q;
    });
    if (String(await read("read", target.sel)).trim() !== target.text) throw Error("\u6253\u5F00\u524D\u4F1A\u8BDD\u5217\u8868\u53D8\u5316\uFF0C\u4FDD\u7559\u8FDB\u5EA6\u672A\u70B9\u51FB");
    member.searchIdentityProof = { identityLine: member.identityLine, targetText: target.text, verifiedAt: (/* @__PURE__ */ new Date()).toISOString() };
    await read("click", target.sel);
    let ready = false;
    for (let n = 0; n < 30; n++) {
      if (await closingRecipient(read, c) && await read("count", "li.message-item") > 0) {
        ready = true;
        break;
      }
      await new Promise((r) => setTimeout(r, 150));
    }
    if (!ready) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u8EAB\u4EFD\u5C1A\u672A\u8BFB\u56DE");
  }
  const recipientSelector = ".chat-conversation .user-info", recipientLabel = String(await read("read", recipientSelector)).trim(), jobSelector = ".chat-position-content", chatJobTitle = String(await read("read", jobSelector)).trim(), jobTitle = chatJobTitle.split(/\r?\n/u)[0], baseline = await closingMessages(read);
  if (!jobTitle || !recipientLabel) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u7684\u62DB\u8058\u8005\u6216\u804C\u4F4D\u4E0A\u4E0B\u6587\u7F3A\u5931");
  if (p.active?.firstMessageId && p.active.firstMessageId !== baseline[0].mid) throw Error("\u91CD\u5F00\u540E\u7684\u4F1A\u8BDD\u539F\u59CB\u6D88\u606F\u94FE\u5DF2\u53D8\u5316\uFF0C\u672A\u8986\u76D6\u65E7\u8FDB\u5EA6");
  p = await closingProgress(template, signal, c, (q) => {
    if (q.active && q.active.memberKey !== member.key) throw Error("\u6D3B\u8DC3\u6210\u5458\u53D8\u5316");
    q.active = { ...q.active, memberKey: member.key, identityLine: member.identityLine, recipientName: recipientLabel.split(/\r?\n/u)[0], contextId: c.contextId, openedAt: q.active?.openedAt || (/* @__PURE__ */ new Date()).toISOString(), firstMessageId: baseline[0].mid };
    return q;
  });
  let jobSource = p.active.jobSource, jobId = p.active.jobId;
  if (!jobSource) {
    const target = ".chat-position-content .right-content > :first-child";
    if (await read("count", target) !== 1 || String(await read("read", target)).trim() !== "\u67E5\u770B\u804C\u4F4D" || !await closingRecipient(read, c) || JSON.stringify(await closingMessages(read)) !== JSON.stringify(baseline)) throw Error("\u5173\u8054\u804C\u4F4D\u5165\u53E3\u6216\u4F1A\u8BDD\u5185\u5BB9\u53D8\u5316");
    await read("click", target);
    let page;
    for (let n = 0; n < 30; n++) {
      page = new URL(await read("url"));
      if (/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(page.pathname)) break;
      await new Promise((r) => setTimeout(r, 150));
    }
    if (page.origin !== "https://www.zhipin.com" || !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(page.pathname)) throw Error("\u672A\u8BFB\u4F1A\u8BDD\u7684\u5B9E\u9645\u804C\u4F4D\u94FE\u63A5\u672A\u6838\u5BF9");
    jobSource = page.origin + page.pathname;
    jobId = page.pathname.split("/").at(-1).slice(0, -5);
    p = await closingProgress(template, signal, c, (q) => {
      if (q.active?.memberKey !== member.key) throw Error("\u6D3B\u8DC3\u6210\u5458\u53D8\u5316");
      Object.assign(q.active, { jobSource, jobId });
      return q;
    });
    const candidates = [".job-detail-container div:nth-of-type(2) > a:nth-of-type(2)", "div:nth-of-type(2) > div:nth-of-type(1) > div > div > div:nth-of-type(1) > div:nth-of-type(3) > div:nth-of-type(1) > div > a"];
    let continuation = null;
    for (const sel of candidates) if (await read("count", sel) === 1 && String(await read("read", sel)).replace(/[\uE000-\uF8FF]/gu, "").trim() === "\u7EE7\u7EED\u6C9F\u901A") {
      continuation = sel;
      break;
    }
    if (!continuation) throw Error("\u5173\u8054\u804C\u4F4D\u6CA1\u6709\u53EF\u6838\u5BF9\u7684\u7EE7\u7EED\u6C9F\u901A\u5165\u53E3\uFF1B\u7981\u6B62\u70B9\u51FB\u7ACB\u5373\u6C9F\u901A");
    await read("click", continuation);
    let ready = false;
    for (let n = 0; n < 30; n++) {
      if (await closingRecipient(read, c) && await read("count", "li.message-item") > 0) {
        ready = true;
        break;
      }
      await new Promise((r) => setTimeout(r, 150));
    }
    if (!ready || JSON.stringify(await closingMessages(read)) !== JSON.stringify(baseline)) throw Error("\u5173\u8054\u804C\u4F4D\u8FD4\u56DE\u540E\u7684\u5B8C\u6574\u6D88\u606F\u6216\u5BF9\u8C61\u53D8\u5316\uFF0C\u672A\u751F\u6210\u56DE\u590D");
  }
  const rows = await closingMessages(read), real = rows.filter((r) => r.direction !== "system" && r.text), last = real.at(-1), accountSelector = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", accountLabel = c.accountSource.account.accountName;
  const scope = { ...base, member, jobId, jobSource, jobTitle, chatJobTitle, jobSelector, recipientSelector, recipientLabel, accountSelector, accountLabel, conversationKey: "boss-job:" + jobId, rows };
  const titleScope = titleScopeEvidence(jobTitle, c.configuration);
  if (!titleScope.allowed) return { ...scope, titleScope, ready: false, status: "job-title-outside-configured-scope", reason: "\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u672A\u901A\u8FC7\u5141\u8BB8\u8BCD\u6216\u547D\u4E2D\u6392\u9664\u9879\uFF1B\u4E0D\u8C03\u7528\u6A21\u578B\u3001\u4E0D\u5EFA\u7ACB\u56DE\u590D\u610F\u56FE" };
  if (!last || last.direction !== "incoming") return { ...scope, ready: false, status: "already-replied-or-system-only", reason: "\u6CA1\u6709\u5C1A\u672A\u56DE\u590D\u7684\u771F\u4EBA\u6587\u5B57\u6765\u4FE1\uFF1B\u7CFB\u7EDF\u5361\u7247\u4E0D\u89E6\u53D1\u56DE\u590D" };
  if (/不太?合适|不[是太]*特别契合|不[完全]*符合|不[完全]*匹配|后续有机会再合作|未能通过|暂不考虑/u.test(last.text) && !/[?？]|(?:是否|有没有|会不会|能否|请问|什么时候|多少|怎么|哪些)/u.test(last.text)) return { ...scope, ready: false, status: "rejected-no-reply", incomingMessageId: last.mid, reason: "\u5BF9\u65B9\u660E\u786E\u8868\u793A\u4E0D\u5408\u9002\uFF0C\u6309\u672C\u4EBA\u6700\u65B0\u8981\u6C42\u4E0D\u56DE\u590D\uFF1B\u4FDD\u7559\u6240\u6709\u539F\u5916\u53D1\u610F\u56FE" };
  const key = createHash("sha256").update(["boss-text-reply-v1", c.accountKey, last.mid].join(":")).digest("hex"), state = await template.state.get(), index = await safetyIndex(template, signal, c.accountKey, c.contextId);
  index.merge(state);
  await index.save();
  if (state.replyIntents.some((i) => i.accountKey === c.accountKey && i.incomingMessageId === last.mid) || index.blocked("reply", key)) return { ...scope, ready: false, status: "existing-reply-intent", incomingMessageId: last.mid, reason: "\u8BE5\u539F\u6765\u4FE1\u5DF2\u6709\u5916\u53D1\u610F\u56FE\uFF0C\u9884\u7559\u3001\u672A\u77E5\u53CA\u786E\u8BA4\u5747\u7981\u6B62\u91CD\u653E" };
  if ((state.conversationControls || []).some((x) => x.accountKey === c.accountKey && [scope.conversationKey, "boss-chat:" + rows[0].mid].includes(x.conversationKey) && x.mode === "paused")) return { ...scope, ready: false, status: "manual-control", reason: "\u672C\u4EBA\u5DF2\u63A5\u7BA1\u672C\u4F1A\u8BDD\uFF0C\u81EA\u52A8\u56DE\u590D\u8DF3\u8FC7" };
  const day = new Intl.DateTimeFormat("sv-SE", { timeZone: c.configuration.replyTimeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date()), used = new Set(index.data.records.filter((r) => r.type === "reply" && r.sightings.some((s) => s.day === day && s.timeZone === c.configuration.replyTimeZone && s.status !== "failed")).map((r) => r.businessKey));
  if (used.size >= c.configuration.replyDailyLimit) throw Error("\u5DF2\u4FDD\u5B58\u7684\u672C\u4EBA\u56DE\u590D\u989D\u5EA6\u5DF2\u6EE1\uFF0C\u4FDD\u7559\u672A\u5B8C\u6210\u6536\u5C3E");
  const source = { ...scope, ready: true, key, incomingMessageId: last.mid, incomingMessage: last.text, pendingMessages: real.slice(real.map((r) => r.direction).lastIndexOf("outgoing") + 1).filter((r) => r.direction === "incoming"), sourceSha256: createHash("sha256").update(JSON.stringify({ rows, jobSource, accountLabel })).digest("hex"), day, timeZone: c.configuration.replyTimeZone };
  if (!await closingSourceSame(template, signal, source)) throw Error("\u5B8C\u6574\u6765\u6E90\u4FDD\u5B58\u524D\u4F1A\u8BDD\u5DF2\u53D8\u5316");
  await artifact("fixed-unread-reply-source.json", JSON.stringify(source, null, 2));
  return source;
};
export {
  stdin_default as default
};
