import { createHash } from "node:crypto";
const checkAccountSource = /* @__PURE__ */ (() => {
  var stdin_default2 = async ({ input, signal }) => {
    signal.throwIfAborted();
    const read = input, account = read?.value;
    if (!read || read.version !== 1 || read.operation !== "read" || read.binding !== "account-source-result" || read.schemaValidation !== "passed" || read.dataChanged !== false || read.ref?.version !== 1 || read.ref.policy !== "credential-redacted-v1" || read.ref.source?.entryId !== "account-source") throw new Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u5DF2\u9009\u62E9\u4E14\u5B8C\u6574\u53EF\u590D\u7528\u7684\u8D26\u53F7\u6765\u6E90\uFF0C\u8BF7\u5230\u8D44\u6E90\u9875\u91CD\u65B0\u6838\u5BF9\u5E76\u4FDD\u5B58");
    if (!account || account.version !== 1 || account.kind !== "boss-account-source" || account.status !== "account-source-confirmed" || account.accountVerified !== true || account.platformUniqueIdVerified !== false || account.eligibleForActions !== false || account.role !== "jobseeker") throw new Error("\u6240\u9009\u8BB0\u5F55\u5C1A\u672A\u5B8C\u6210\u672C\u4EBA\u786E\u8BA4\u548C\u6765\u6E90\u590D\u9A8C\uFF1B\u8BF7\u5728\u5F53\u524D\u5B9E\u4F8B\u5B8C\u6210\u8D26\u53F7\u6838\u5BF9\uFF0C\u518D\u9009\u62E9\u8BE5\u6B21\u5DF2\u4FDD\u5B58\u7ED3\u679C");
    const keys = ["version", "kind", "status", "accountAlias", "accountName", "phoneMask", "jobseekerResumeHref", "role", "sourceUrl", "accountVerified", "platformUniqueIdVerified", "eligibleForActions", "confirmedAt", "checkedAt", "reason"];
    if (Object.keys(account).length !== keys.length || keys.some((k) => !Object.prototype.hasOwnProperty.call(account, k))) throw new Error("\u6240\u9009\u8D26\u53F7\u7ED3\u679C\u7ED3\u6784\u4E0D\u7B26\uFF0C\u505C\u6B62\u91C7\u7528");
    for (const key of ["accountAlias", "accountName", "phoneMask"]) if (typeof account[key] !== "string" || !account[key].trim() || account[key] !== account[key].trim() || account[key].length > 100 || /[\r\n]/.test(account[key])) throw new Error("\u8D26\u53F7\u5FC5\u8981\u5B57\u6BB5\u7F3A\u5931\u6216\u683C\u5F0F\u65E0\u6548\uFF0C\u505C\u6B62\u91C7\u7528");
    if (!/^[+\d ()-]*\*{2,}[\d ()-]+$/.test(account.phoneMask) || /登录|注册|验证码/.test(account.accountName)) throw new Error("\u8D26\u53F7\u6765\u6E90\u7F3A\u5C11\u6709\u6548\u7684\u53EF\u89C1\u59D3\u540D\u6216\u624B\u673A\u53F7\u63A9\u7801");
    if (typeof account.reason !== "string" || !account.reason.trim()) throw new Error("\u8D26\u53F7\u7ED3\u679C\u7F3A\u5C11\u660E\u786E\u6838\u5BF9\u8BF4\u660E");
    const confirmedAt = Date.parse(account.confirmedAt), checkedAt = Date.parse(account.checkedAt);
    if (typeof account.confirmedAt !== "string" || typeof account.checkedAt !== "string" || !Number.isFinite(confirmedAt) || !Number.isFinite(checkedAt) || confirmedAt <= 0 || checkedAt < confirmedAt || checkedAt > Date.now() + 6e4) throw new Error("\u8D26\u53F7\u786E\u8BA4\u6216\u590D\u9A8C\u65F6\u95F4\u65E0\u6CD5\u6838\u5BF9\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4");
    if (typeof account.sourceUrl !== "string" || typeof account.jobseekerResumeHref !== "string" || !account.sourceUrl.trim() || !account.jobseekerResumeHref.trim() || account.sourceUrl.length > 16384 || account.jobseekerResumeHref.length > 16384) throw new Error("\u8D26\u53F7\u9875\u9762\u6216\u7B80\u5386\u5165\u53E3\u5730\u5740\u65E0\u6548");
    const page = new URL(account.sourceUrl), resume = new URL(account.jobseekerResumeHref, account.sourceUrl);
    if (page.origin !== "https://www.zhipin.com" || page.pathname !== "/web/geek/account" || page.searchParams.get("type") !== "accountSet" || page.username || page.password || page.hash || resume.origin !== page.origin || resume.pathname !== "/web/geek/resume" || resume.username || resume.password) throw new Error("\u8D26\u53F7\u8BB0\u5F55\u7684\u9875\u9762\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u4E0D\u7B26");
    signal.throwIfAborted();
    return { version: 1, accountSourceValid: true, currentAccountVerified: false, account };
  };
  return stdin_default2;
})();
const checkCurrentAccount = /* @__PURE__ */ (() => {
  async function stdin_default2({ input, signal, template }) {
    signal.throwIfAborted();
    const a = input?.expected?.account;
    if (input?.expected?.accountSourceValid !== true || a?.kind !== "boss-account-source" || a.status !== "account-source-confirmed" || a.accountVerified !== true) throw Error("\u7F3A\u5C11\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\u6765\u6E90");
    const call = async (operation, selector, value) => {
      signal.throwIfAborted();
      const r2 = await template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
      signal.throwIfAborted();
      return r2;
    };
    let before = await call("url");
    if (before === "about:blank") {
      await call("navigate", void 0, a.sourceUrl);
      for (let n2 = 0; n2 < 40; n2++) {
        const current = await call("url");
        if (new URL(current).origin === "https://www.zhipin.com" && await call("count", "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)") === 1) break;
        await new Promise((r2) => setTimeout(r2, 150));
      }
      before = await call("url");
    }
    const p = new URL(before);
    if (p.origin !== "https://www.zhipin.com" || p.username || p.password || !p.pathname.startsWith("/web/") && !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(p.pathname)) throw Error("\u5F53\u524D\u9875\u9762\u4E0D\u662FBOSS\u6C42\u804C\u9875\u9762\uFF0C\u8BF7\u5148\u767B\u5F55");
    const n = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", r = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)";
    const nameCount = await call("count", n), resumeCount = await call("count", r);
    if (nameCount !== 1 || resumeCount !== 1) throw Error("\u5F53\u524D\u9875\u9762\u8D26\u53F7\u5165\u53E3\u6570\u91CF\u5F02\u5E38\uFF1A" + JSON.stringify({ nameCount, resumeCount }));
    const name = await call("read", n), href = await call("attribute", r, "href");
    if (typeof name !== "string" || name.normalize("NFKC").trim() !== a.accountName.normalize("NFKC").trim() || typeof href !== "string" || new URL(href, before).href !== new URL(a.jobseekerResumeHref, a.sourceUrl).href || await call("url") !== before) throw Error("\u5F53\u524D\u767B\u5F55\u8EAB\u4EFD\u3001\u6C42\u804C\u5165\u53E3\u6216\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
    return { version: 1, status: "current-account-source-matched", accountAlias: a.accountAlias, accountName: a.accountName, phoneMask: a.phoneMask, jobseekerResumeHref: a.jobseekerResumeHref, sourceUrl: a.sourceUrl, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), currentPageUrl: before, currentAccountVerified: true, platformUniqueIdVerified: false, eligibleForActions: false, accountCheckMode: "confirmed-initial-account-and-visible-header", phoneMaskRechecked: false, reason: "\u4F7F\u7528\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\uFF1B\u53EA\u8BFB\u6838\u5BF9\u5F53\u524D\u767B\u5F55\u59D3\u540D\u3001\u6C42\u804C\u5165\u53E3\u53CA\u9875\u9762\u8FDE\u7EED\u6027\uFF0C\u624B\u673A\u53F7\u63A9\u7801\u6CBF\u7528\u786E\u8BA4\u6765\u6E90\uFF0C\u6CA1\u6709\u91CD\u65B0\u8BFB\u53D6\u3002" };
  }
  return stdin_default2;
})();
const cursorCanonical = (value) => Array.isArray(value) ? value.map(cursorCanonical) : value && typeof value === "object" ? Object.fromEntries(Object.keys(value).sort().map((key) => [key, cursorCanonical(value[key])])) : value;
const cursorDigest = (value) => createHash("sha256").update(JSON.stringify(cursorCanonical(value))).digest("hex");
async function stdin_default({ input, template, signal }) {
  signal.throwIfAborted();
  const raw = input?.configuration, st = input?.state;
  if (raw?.operation !== "configuration" || st?.operation !== "state.read" || raw.contextId !== st.contextId || !raw.value || !st.value) throw Error("\u7F3A\u5C11\u540C\u5B9E\u4F8B\u56FA\u5B9A\u914D\u7F6E\u4E0E\u5B8C\u6574\u72B6\u6001");
  const proof = await checkAccountSource({ input: input.account, signal });
  await checkCurrentAccount({ input: { expected: proof }, template, signal });
  const a = proof.account, resume = new URL(a.jobseekerResumeHref, a.sourceUrl), accountKey = createHash("sha256").update(JSON.stringify(["boss-visible-account-source-v1", a.accountName, a.phoneMask, resume.origin + resume.pathname])).digest("hex");
  const valid = (v) => {
    const { sha256, ...body } = v;
    return sha256 === cursorDigest(body);
  };
  const optional = async (name) => {
    try {
      return JSON.parse(await template.file("communication-cache", { operation: "read", name }));
    } catch (e) {
      if (String(e.message || e).includes("ENOENT")) return null;
      throw e;
    }
  };
  const persist = async (name, value, expected) => {
    const before = await optional(name);
    if ((before?.sha256 || null) !== expected) throw Error("\u6D88\u606F\u6536\u5C3E\u8BB0\u5F55\u88AB\u5176\u4ED6\u64CD\u4F5C\u66F4\u6539\uFF0C\u672A\u8986\u76D6");
    const body = { ...value };
    delete body.sha256;
    body.sha256 = cursorDigest(body);
    await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(body) });
    const back = await optional(name);
    if (!valid(back) || back.sha256 !== body.sha256) throw Error("\u6D88\u606F\u6536\u5C3E\u8BB0\u5F55\u5199\u5165\u540E\u672A\u5B8C\u6574\u8BFB\u56DE");
    return back;
  };
  const timeZone = raw.value.replyTimeZone, today = new Intl.DateTimeFormat("sv-SE", { timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
  const pointerName = "active-unread-closing-v1-" + accountKey + ".json";
  let pointer = await optional(pointerName);
  if (pointer && (!valid(pointer) || pointer.kind !== "boss-active-unread-closing" || pointer.accountKey !== accountKey || !/^\d{4}-\d{2}-\d{2}$/.test(pointer.day))) throw Error("\u6536\u5C3E\u6062\u590D\u6307\u9488\u8EAB\u4EFD\u6216\u6458\u8981\u65E0\u6548\uFF0C\u672A\u91CD\u5EFA");
  const day = pointer?.day || today, quotaName = "site-daily-limit-v1-" + accountKey + "-" + day + ".json", quota = await optional(quotaName), setName = "fixed-unread-set-v1-" + accountKey + "-" + day + ".json", set = await optional(setName);
  if (!quota || !valid(quota) || quota.kind !== "boss-site-daily-limit" || quota.accountKey !== accountKey || quota.confirmed !== true || quota.day !== day || quota.timeZone !== timeZone) throw Error("\u672A\u627E\u5230\u672C\u8D26\u53F7\u771F\u5B9E\u7F51\u7AD9\u4E0A\u9650\u8BC1\u636E\uFF1B\u7981\u6B62\u91CD\u65B0\u6253\u62DB\u547C\u6216\u626B\u63CF\u5386\u53F2");
  if (!set || !valid(set) || set.kind !== "boss-fixed-unread-set" || set.accountKey !== accountKey || set.day !== day || set.siteDailyLimitEvidenceSha256 !== quota.sha256 || !Array.isArray(set.members) || set.members.length > 200 || new Set(set.members.map((m) => m.key)).size !== set.members.length || set.members.reduce((n, m) => n + m.unreadCount, 0) !== set.unreadMessageCount) throw Error("\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u7F3A\u5931\u6216\u8986\u76D6\u6570\u91CF\u4E0D\u4E00\u81F4\uFF1B\u672A\u91CD\u5EFA\u6216\u6269\u5C55\u96C6\u5408");
  const members = set.members.map((m) => {
    const lines = m.text.split(/\r?\n/u).map((x) => x.trim()).filter(Boolean);
    if (!/^[a-f0-9]{64}$/.test(m.key) || !/^\d+$/.test(lines[0]) || !lines[2] || lines[2].length > 500) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u53EF\u89C1\u8EAB\u4EFD\u7F3A\u5931");
    return { ...m, identityLine: lines[2] };
  });
  if (new Set(members.map((m) => m.identityLine)).size !== members.length) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u5B58\u5728\u540C\u540D\u540C\u516C\u53F8\u8EAB\u4EFD\u6B67\u4E49\uFF0C\u7981\u6B62\u731C\u6D4B");
  const indexName = "account-outbound-safety-v1-" + accountKey + ".json", index = await optional(indexName);
  if (!index || !valid(index) || index.kind !== "boss-account-outbound-safety" || index.accountKey !== accountKey || !Array.isArray(index.records) || !index.records.length) throw Error("\u539F\u8D26\u53F7\u5916\u53D1\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF0C\u963B\u6B62\u7EED\u53D1");
  if (pointer && (pointer.fixedUnreadSetSha256 !== set.sha256 || pointer.siteDailyLimitEvidenceSha256 !== quota.sha256)) throw Error("\u6062\u590D\u6307\u9488\u4E0E\u56FA\u5B9A\u96C6\u5408\u4E0D\u7B26");
  if (!pointer) pointer = await persist(pointerName, { version: 1, kind: "boss-active-unread-closing", accountKey, day, timeZone, fixedUnreadSetSha256: set.sha256, siteDailyLimitEvidenceSha256: quota.sha256, createdAt: (/* @__PURE__ */ new Date()).toISOString() }, null);
  const progressName = "fixed-unread-progress-v1-" + accountKey + "-" + day + ".json";
  let progress = await optional(progressName);
  if (progress && (!valid(progress) || progress.kind !== "boss-fixed-unread-progress" || progress.accountKey !== accountKey || progress.fixedUnreadSetSha256 !== set.sha256 || !Array.isArray(progress.completed) || progress.completed.some((c) => !members.some((m) => m.key === c.memberKey)) || new Set(progress.completed.map((c) => c.memberKey)).size !== progress.completed.length || progress.active && !members.some((m) => m.key === progress.active.memberKey))) throw Error("\u6536\u5C3E\u8FDB\u5EA6\u8EAB\u4EFD\u3001\u6458\u8981\u6216\u6210\u5458\u65E0\u6548");
  if (!progress) progress = await persist(progressName, { version: 1, kind: "boss-fixed-unread-progress", accountKey, day, timeZone, fixedUnreadSetSha256: set.sha256, revision: 0, active: null, completed: [], createdAt: (/* @__PURE__ */ new Date()).toISOString() }, null);
  const done = (c) => c.status !== "review" || c.replyPolicyVersion === "work-questions-partial-known-v2";
  const member = progress.active ? members.find((m) => m.key === progress.active.memberKey) : members.find((m) => !progress.completed.some((c) => c.memberKey === m.key && done(c)));
  const result = { version: 1, kind: "unread-closing-cohort", closingPhase: true, ready: !!member, contextId: raw.contextId, accountKey, accountSource: proof, configuration: raw.value, configurationRevision: raw.revision, siteDailyLimitEvidence: quota, fixedUnreadSetName: setName, fixedUnreadSetSha256: set.sha256, member: member || null, memberCount: members.length, unreadMessageCount: set.unreadMessageCount, progressName, progressSha256: progress.sha256, progress, remaining: members.length - progress.completed.filter(done).length, status: member ? "resume-fixed-unread" : "fixed-unread-complete", newGreeting: false, newMembersAdded: 0 };
  if (cursorDigest(await template.state.get()) !== cursorDigest(st.value)) throw Error("\u51C6\u5907\u6536\u5C3E\u671F\u95F4\u6B63\u5F0F\u72B6\u6001\u53D8\u5316\uFF0C\u672A\u7EE7\u7EED");
  result.items = members.filter((m) => !progress.completed.some((x) => x.memberKey === m.key && done(x))).sort((a2, b) => Number(b.key === progress.active?.memberKey) - Number(a2.key === progress.active?.memberKey)).map((member2) => ({ ...result, member: member2, ready: true }));
  return result;
}
export {
  stdin_default as default
};
