import { createHash } from "node:crypto";
const canonical = (v) => Array.isArray(v) ? v.map(canonical) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical(v[k])])) : v;
const digest = (v) => createHash("sha256").update(JSON.stringify(canonical(v))).digest("hex");
async function safetyIndex(template, signal, accountKey, contextId, initialize = false) {
  const name = "account-outbound-safety-v1-" + accountKey + ".json";
  let data, existed = true, baseline;
  try {
    baseline = await template.file("communication-cache", { operation: "read", name });
    data = JSON.parse(baseline);
  } catch (error) {
    if (!String(error.message || error).includes("ENOENT")) throw error;
    if (!initialize) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
    existed = false;
    data = { version: 1, kind: "boss-account-outbound-safety", accountKey, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (existed) {
    const { sha256, ...body } = data;
    if (sha256 !== digest(body)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
  }
  if (data.version !== 1 || data.kind !== "boss-account-outbound-safety" || data.accountKey !== accountKey || !Number.isSafeInteger(data.revision) || data.revision < 0 || !Array.isArray(data.records) || data.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
  const records = /* @__PURE__ */ new Set();
  for (const r of data.records) {
    if (!["first-contact", "reply"].includes(r.type) || !/^[a-f0-9]{64}$/.test(r.businessKey) || !Array.isArray(r.sightings) || !r.sightings.length || r.sightings.length > 100 || records.has(r.type + ":" + r.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
    records.add(r.type + ":" + r.businessKey);
    for (const s of r.sightings) if (typeof s.contextId !== "string" || !s.contextId || !/^[a-f0-9]{64}$/.test(s.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(s.status) || !/^\d{4}-\d{2}-\d{2}$/.test(s.day) || typeof s.timeZone !== "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
  }
  let dirty = !existed;
  const merge = (state) => {
    if (!Array.isArray(state?.applicationIntents) || !Array.isArray(state?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
    for (const [type, rows] of [["first-contact", state.applicationIntents], ["reply", state.replyIntents]]) for (const i of rows) {
      if ((type === "first-contact" ? i.accountSourceSha256 : i.accountKey) !== accountKey) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
      if (!/^[a-f0-9]{64}$/.test(i.key) || !i.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(i.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
      const businessKey = type === "first-contact" ? digest(["boss-job-safety-v1", accountKey, i.jobId]) : createHash("sha256").update(["boss-text-reply-v1", accountKey, i.incomingMessageId].join(":")).digest("hex");
      let r = data.records.find((r2) => r2.type === type && r2.businessKey === businessKey);
      if (!r) {
        r = { type, businessKey, jobId: i.jobId, ...type === "reply" ? { conversationKey: i.conversationKey, incomingMessageId: i.incomingMessageId } : {}, sightings: [] };
        data.records.push(r);
        dirty = true;
      }
      if (r.jobId !== i.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
      const sight = { contextId, intentKey: i.key, status: i.status, day: i.day, timeZone: i.timeZone, contentSha256: i.contentSha256 || null, sourceSha256: i.sourceSha256 || null };
      if (!r.sightings.some((s) => JSON.stringify(canonical(s)) === JSON.stringify(canonical(sight)))) {
        r.sightings.push(sight);
        dirty = true;
      }
      if (r.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
    }
    if (data.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
  };
  const save = async () => {
    signal.throwIfAborted();
    if (dirty) {
      if (existed && await template.file("communication-cache", { operation: "read", name }) !== baseline) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
      data.records.sort((a, b) => (a.type + ":" + a.businessKey).localeCompare(b.type + ":" + b.businessKey));
      for (const r of data.records) r.sightings.sort((a, b) => JSON.stringify(canonical(a)).localeCompare(JSON.stringify(canonical(b))));
      data.revision++;
      data.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      delete data.sha256;
      data.sha256 = digest(data);
      await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(data) });
      dirty = false;
      baseline = JSON.stringify(data);
      existed = true;
    }
    const back = JSON.parse(await template.file("communication-cache", { operation: "read", name }));
    const { sha256, ...body } = back;
    if (sha256 !== digest(body) || sha256 !== data.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
    return { revision: data.revision, sha256: data.sha256, records: data.records.length };
  };
  return { data, name, merge, save, blocked: (type, key) => data.records.some((r) => r.type === type && r.businessKey === key) };
}
const closingRead = (template, signal) => async (operation, selector, value) => {
  signal.throwIfAborted();
  return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
};
const closingValid = (v) => {
  const { sha256, ...body } = v;
  return sha256 === digest(body);
};
async function closingProgress(template, signal, c, change) {
  const name = c.progressName, raw = await template.file("communication-cache", { operation: "read", name }), p = JSON.parse(raw);
  if (!closingValid(p) || p.accountKey !== c.accountKey || p.fixedUnreadSetSha256 !== c.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
  if (!change) return p;
  const next = change(structuredClone(p));
  next.revision++;
  next.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  delete next.sha256;
  next.sha256 = digest(next);
  if (await template.file("communication-cache", { operation: "read", name }) !== raw) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  signal.throwIfAborted();
  await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(next) });
  const back = JSON.parse(await template.file("communication-cache", { operation: "read", name }));
  if (!closingValid(back) || back.sha256 !== next.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
  return back;
}
async function closingMessages(read) {
  const count = await read("count", "li.message-item");
  if (!Number.isSafeInteger(count) || count < 1 || count > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
  const rows = [];
  for (let n = 1; n <= count; n++) {
    const selector = "li.message-item:nth-child(" + n + " of li.message-item)", mid = await read("attribute", selector, "data-mid"), cls = await read("attribute", selector, "class");
    if (!/^\d{6,40}$/.test(mid || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
    const texts = await read("count", selector + " .text-content");
    if (texts > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
    const text = texts === 1 ? String(await read("read", selector + " .text-content")).trim() : null, context = text === null ? String(await read("read", selector)).trim() : null;
    if ((text || context || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
    const systemText = !!text && /^您正在与Boss.+沟通$/u.test(text), direction = !systemText && text !== null && cls.split(/\s+/u).includes("item-myself") ? "outgoing" : !systemText && text !== null && cls.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
    rows.push({ mid, direction, text, context });
  }
  if (new Set(rows.map((r) => r.mid)).size !== rows.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
  return rows;
}
async function closingRecipient(read, c) {
  const url = new URL(await read("url"));
  if (url.origin !== "https://www.zhipin.com" || url.pathname !== "/web/geek/chat" || await read("count", ".chat-conversation .user-info") !== 1) return false;
  const header = String(await read("read", ".chat-conversation .user-info")).trim(), compact = (v) => v.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
  const expected = compact(c.member.identityLine), observed = compact(header), count = await read("count", ".friend-content.selected");
  if (count > 1) return false;
  const selected = count === 1 ? compact(String(await read("read", ".friend-content.selected"))) : null;
  if (observed === expected) return selected === null || selected.includes(expected);
  const name = /^(.{1,20}?(?:先生|女士))/u.exec(expected)?.[1];
  return !!name && expected.endsWith("\u730E\u5934\u987E\u95EE") && observed === name + "\u730E\u5934\u987E\u95EE" && (selected !== null ? selected.includes(expected) : c.member.searchIdentityProof?.identityLine === c.member.identityLine && compact(c.member.searchIdentityProof.targetText).includes(expected));
}
async function closingSourceSame(template, signal, c) {
  const read = closingRead(template, signal);
  if (!await closingRecipient(read, c)) return false;
  const name = String(await read("read", c.accountSelector)).trim();
  return name === c.accountLabel && String(await read("read", c.recipientSelector)).trim() === c.recipientLabel && String(await read("read", c.jobSelector)).trim() === c.chatJobTitle && JSON.stringify(await closingMessages(read)) === JSON.stringify(c.rows);
}
var stdin_default = async ({ input, signal, template, artifact }) => {
  if (input?.kind !== "chat-reply-draft") throw Error("Missing AI reply stage");
  if (!input.send) return { ...input, kind: "chat-reply-dispatch", dispatched: false };
  const sha = (v) => createHash("sha256").update(v).digest("hex");
  if (sha(input.reply) !== input.contentSha256 || !input.model?.requestId || input.decision !== "reply" || input.closingPhase !== true || input.fixedUnreadMember !== true || input.siteDailyLimitEvidence?.confirmed !== true || !input.fixedUnreadSetSha256 || input.key !== sha(["boss-text-reply-v1", input.accountKey, input.incomingMessageId].join(":"))) throw Error("Reply text or model source changed");
  const read = (operation, selector, value) => {
    signal.throwIfAborted();
    return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value !== void 0 ? { value } : {}, timeoutMs: 3e3 });
  };
  const sourceSame = () => closingSourceSame(template, signal, input);
  if (!await sourceSame()) throw Error("Conversation changed while AI was thinking; no send");
  let state = await template.state.get();
  const index = await safetyIndex(template, signal, input.accountKey, input.contextId);
  index.merge(state);
  await index.save();
  if ((state.replyIntents || []).some((i) => i.accountKey === input.accountKey && i.incomingMessageId === input.incomingMessageId) || index.blocked("reply", input.key)) return { ...input, kind: "chat-reply-dispatch", dispatched: false, reason: "Persistent reply intent already exists; no replay" };
  const controls = (state.conversationControls || []).filter((c) => c.accountKey === input.accountKey && c.conversationKey === input.conversationKey);
  if (controls.some((c) => c.mode === "paused")) throw Error("Conversation is under manual control");
  const controlEpoch = controls.length ? Math.max(...controls.map((c) => c.controlEpoch)) : 1;
  let intents = state.replyIntents || [];
  if (intents.length >= 500 || intents.filter((i) => i.accountKey === input.accountKey && i.day === input.day && i.timeZone === input.timeZone && i.status !== "failed").length >= input.configuration.replyDailyLimit) throw Error("Reply quota or ledger capacity reached");
  if (await read("count", "#chat-input") !== 1 || String(await read("read", "#chat-input")).trim() !== "") throw Error("Composer contains an existing draft; no overwrite");
  if (await read("count", ".chat-conversation .btn-send") !== 1 || String(await read("read", ".chat-conversation .btn-send")).trim() !== "\u53D1\u9001") throw Error("Send target is ambiguous");
  const effect = await template.effect.prepare({ action: "reply", key: input.key, description: "\u5411\u5F53\u524D\u51C6\u786E\u5DF2\u6709\u4F1A\u8BDD\u56DE\u590D\u539F\u6765\u4FE1 " + input.incomingMessageId + "\uFF1B\u4EC5\u6B64\u6587\u672C\uFF0C\u4E0D\u53D1\u9001\u9644\u4EF6\u6216\u65B0\u7684\u9996\u6B21\u62DB\u547C\u3002", review: { version: 1, target: input.jobTitle + "\n" + input.jobSource + "\n\u539F\u6765\u4FE1 " + input.incomingMessageId, content: input.reply } });
  if (!effect.execute) return { ...input, kind: "chat-reply-dispatch", dispatched: false, reason: "Existing effect blocks repeated reply" };
  const intent = { key: input.key, accountKey: input.accountKey, conversationKey: input.conversationKey, incomingMessageId: input.incomingMessageId, jobId: input.jobId, contentSha256: input.contentSha256, sourceSha256: input.sourceSha256, profileVersionId: input.profile.ref.versionId, configurationRevision: input.configurationRevision, controlEpoch, day: input.day, timeZone: input.timeZone, createdAt: (/* @__PURE__ */ new Date()).toISOString(), status: "reserved" };
  let attempted = false, reserved = false;
  try {
    state = await template.state.get();
    intents = state.replyIntents || [];
    const fresh = await safetyIndex(template, signal, input.accountKey, input.contextId);
    fresh.merge(state);
    await fresh.save();
    if (intents.some((i) => i.accountKey === input.accountKey && i.incomingMessageId === input.incomingMessageId) || fresh.blocked("reply", input.key)) throw Error("\u786E\u8BA4\u671F\u95F4\u539F\u6765\u4FE1\u5DF2\u5EFA\u7ACB\u56DE\u590D\u610F\u56FE\uFF0C\u505C\u6B62\u65E7\u8349\u7A3F");
    if ((state.conversationControls || []).some((c) => c.accountKey === input.accountKey && [input.conversationKey, "boss-chat:" + input.rows[0].mid].includes(c.conversationKey) && c.mode === "paused")) throw Error("\u786E\u8BA4\u671F\u95F4\u672C\u4EBA\u5DF2\u63A5\u7BA1\u4F1A\u8BDD");
    const used = new Set(fresh.data.records.filter((r) => r.type === "reply" && r.sightings.some((s) => s.day === input.day && s.timeZone === input.timeZone && s.status !== "failed")).map((r) => r.businessKey));
    if (used.size >= input.configuration.replyDailyLimit || intents.length >= 500) throw Error("\u786E\u8BA4\u671F\u95F4\u56DE\u590D\u989D\u5EA6\u6216\u8D26\u672C\u5BB9\u91CF\u5DF2\u6EE1");
    await template.state.set({ ...state, replyIntents: [...intents, intent] });
    reserved = true;
    state = await template.state.get();
    if (state.replyIntents.filter((i) => i.key === input.key && i.status === "reserved").length !== 1 || !await sourceSame()) throw Error("Reservation or exact conversation changed");
    const reservationIndex = await safetyIndex(template, signal, input.accountKey, input.contextId);
    reservationIndex.merge(state);
    const safety = await reservationIndex.save();
    if (!reservationIndex.data.records.some((r) => r.type === "reply" && r.businessKey === input.key && r.sightings.some((s) => s.contextId === input.contextId && s.intentKey === input.key && s.status === "reserved"))) throw Error("\u56DE\u590D\u5B89\u5168\u7D22\u5F15\u9884\u7559\u672A\u8BFB\u56DE");
    await artifact("reply-reservation.json", JSON.stringify({ intent, effect, safety, sourceSha256: input.sourceSha256, reply: input.reply, model: input.model }, null, 2));
    await read("fill", "#chat-input", input.reply);
    let draftReady = false;
    for (let n = 0; n < 12; n++) {
      if (String(await read("read", "#chat-input")).trim() === input.reply) {
        draftReady = true;
        break;
      }
      await new Promise((r) => setTimeout(r, 100));
    }
    if (!draftReady || !await sourceSame() || String(await read("read", "#chat-input")).trim() !== input.reply) throw Error("Draft or recipient changed before send");
    const finalState = await template.state.get(), finalIndex = await safetyIndex(template, signal, input.accountKey, input.contextId);
    if (finalState.replyIntents.filter((i) => i.accountKey === input.accountKey && i.incomingMessageId === input.incomingMessageId).length !== 1 || finalState.replyIntents.filter((i) => i.key === input.key && i.status === "reserved").length !== 1 || !finalIndex.data.records.some((r) => r.type === "reply" && r.businessKey === input.key && r.sightings.some((s) => s.contextId === input.contextId && s.intentKey === input.key && s.status === "reserved")) || finalIndex.data.records.some((r) => r.type === "reply" && r.businessKey === input.key && r.sightings.some((s) => s.contextId !== input.contextId || s.intentKey !== input.key || s.status !== "reserved")) || (finalState.conversationControls || []).some((c) => c.accountKey === input.accountKey && [input.conversationKey, "boss-chat:" + input.rows[0].mid].includes(c.conversationKey) && c.mode === "paused") || !await sourceSame() || String(await read("read", "#chat-input")).trim() !== input.reply) throw Error("\u53D1\u9001\u524D\u5BF9\u8C61\u3001\u6765\u4FE1\u3001\u9884\u7559\u6216\u63A5\u7BA1\u72B6\u6001\u53D8\u5316");
    attempted = true;
    await read("click", ".chat-conversation .btn-send");
    return { ...input, kind: "chat-reply-dispatch", dispatched: true, effect, intent, websiteConfirmed: false };
  } catch (error) {
    const status = attempted ? "unknown" : "failed";
    await template.effect.resolve({ id: effect.id, state: status, evidence: { kind: "reply-not-confirmed", incomingMessageId: input.incomingMessageId, jobSource: input.jobSource, attempted, reason: String(error.message || error) } });
    state = await template.state.get();
    if (reserved) {
      await template.state.set({ ...state, replyIntents: state.replyIntents.map((i) => i.key === input.key ? { ...i, status } : i) });
      state = await template.state.get();
      const failedIndex = await safetyIndex(template, signal, input.accountKey, input.contextId);
      failedIndex.merge(state);
      await failedIndex.save();
    }
    throw error;
  }
};
export {
  stdin_default as default
};
