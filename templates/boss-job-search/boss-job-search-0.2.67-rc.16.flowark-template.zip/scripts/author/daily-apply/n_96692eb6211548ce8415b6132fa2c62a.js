async function stdin_default({ input, signal, template }) {
  signal.throwIfAborted();
  if (input?.kind !== "configured-city" || input.ready !== true || typeof input.searchURL !== "string") throw Error("\u7F3A\u5C11\u56FA\u5B9A\u57CE\u5E02\u4E0E\u68C0\u7D22\u76EE\u6807");
  const u = new URL(input.searchURL);
  if (u.origin !== "https://www.zhipin.com" || u.pathname !== "/web/geek/jobs" || u.username || u.password || u.hash || u.searchParams.get("query") !== input.searchRole) throw Error("\u68C0\u7D22\u76EE\u6807\u4E0D\u5728\u56FA\u5B9A\u8303\u56F4\u5185");
  const read = async (operation, selector) => {
    signal.throwIfAborted();
    return template.browser("browser", { operation, ...selector ? { selector } : {}, timeoutMs: 3e3 });
  };
  const current = await read("url");
  const reused = current === u.href && input.initializedCityReused === true;
  const result = reused ? { url: current, title: "", reusedInitializedList: true } : await template.browser("browser", { operation: "navigate", value: u.href, timeoutMs: 3e4 });
  const citySelector = "body > div:nth-of-type(1) > div:nth-of-type(2) > div:nth-of-type(2) > div > div:nth-of-type(1) > span";
  const cards = "div > div:nth-of-type(1) > li";
  let previous = "", stable = 0;
  const until = Date.now() + 1e4;
  while (Date.now() < until) {
    signal.throwIfAborted();
    if (await read("url") !== u.href) throw Error("\u521D\u59CB\u5316\u7B49\u5F85\u671F\u95F4\u68C0\u7D22\u5730\u5740\u53D8\u5316\uFF0C\u505C\u6B62\u4E14\u4E0D\u70B9\u51FB\u57CE\u5E02");
    const n = await read("count", cards), cc = await read("count", citySelector);
    if (!Number.isSafeInteger(n) || n < 0 || n > 500 || !Number.isSafeInteger(cc) || cc < 0 || cc > 1) throw Error("\u521D\u59CB\u5316\u5217\u8868\u6216\u57CE\u5E02\u5165\u53E3\u4E0D\u552F\u4E00");
    const city = cc === 1 ? String(await read("read", citySelector)).trim() : "";
    const ready = n > 0 && city.length > 0 && city.length <= 30 && !/[\r\n\t]/u.test(city);
    const signature = JSON.stringify([n, city]);
    stable = ready ? signature === previous ? stable + 1 : 1 : 0;
    previous = signature;
    if (stable >= 2) {
      signal.throwIfAborted();
      return { ...result, initialListReady: true, initialCityLabel: city, initialVisibleCount: n };
    }
    await new Promise((resolve, reject) => {
      const stop = () => {
        clearTimeout(timer);
        reject(signal.reason);
      };
      const timer = setTimeout(() => {
        signal.removeEventListener("abort", stop);
        resolve();
      }, 250);
      signal.addEventListener("abort", stop, { once: true });
      if (signal.aborted) stop();
    });
  }
  throw Error("\u521D\u59CB\u5316\u5217\u8868\u4E0E\u57CE\u5E02\u5165\u53E3\u672A\u5728\u6709\u9650\u7B49\u5F85\u5185\u7A33\u5B9A\uFF0C\u505C\u6B62\u4E14\u4E0D\u70B9\u51FB\u57CE\u5E02");
}
export {
  stdin_default as default
};
