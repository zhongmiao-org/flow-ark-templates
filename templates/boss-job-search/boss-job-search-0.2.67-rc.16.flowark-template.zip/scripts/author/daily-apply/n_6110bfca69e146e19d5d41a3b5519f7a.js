import { createHash } from "node:crypto";
import { setTimeout as pause } from "node:timers/promises";
const cursorCanonical = (value) => Array.isArray(value) ? value.map(cursorCanonical) : value && typeof value === "object" ? Object.fromEntries(Object.keys(value).sort().map((key) => [key, cursorCanonical(value[key])])) : value;
const cursorDigest = (value) => createHash("sha256").update(JSON.stringify(cursorCanonical(value))).digest("hex");
const cursorCard = (position) => "div:nth-of-type(" + position + ") > div:nth-of-type(1) > li:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1)";
function cursorJob(href, base) {
  const u = new URL(href, base), match = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(u.pathname);
  if (u.origin !== "https://www.zhipin.com" || u.username || u.password || u.hash || !match)
    throw Error("\u589E\u91CF\u4F4D\u7F6E\u7F3A\u5C11\u51C6\u786E\u5C97\u4F4D\u94FE\u63A5");
  return { jobId: match[1], jobSource: u.origin + u.pathname };
}
async function openIncrementalCursor(template, signal, scope) {
  const fields = ["accountKey", "contextId", "configurationRevision", "day", "timeZone", "searchUrl"];
  if (!scope || fields.some((key) => scope[key] === void 0) || !/^[a-f0-9]{64}$/.test(scope.accountKey) || !scope.contextId || !Number.isSafeInteger(scope.configurationRevision) || !/^\d{4}-\d{2}-\d{2}$/.test(scope.day)) throw Error("\u589E\u91CF\u4F4D\u7F6E\u7F3A\u5C11\u56FA\u5B9A\u8303\u56F4");
  const u = new URL(scope.searchUrl);
  if (u.origin !== "https://www.zhipin.com" || u.pathname !== "/web/geek/jobs" || u.username || u.password || u.hash || !u.searchParams.get("query")) throw Error("\u589E\u91CF\u68C0\u7D22\u6765\u6E90\u65E0\u6548");
  const name = "single-job-list-v1-" + scope.accountKey + "-" + cursorDigest(scope).slice(0, 32) + ".json";
  let original = null, data;
  try {
    original = await template.file("communication-cache", { operation: "read", name });
  } catch (error) {
    if (!String(error.message || error).includes("ENOENT")) throw error;
  }
  if (original !== null) {
    data = JSON.parse(original);
    const { sha256, ...body } = data;
    if (sha256 !== cursorDigest(body) || data.version !== 1 || data.kind !== "boss-single-job-list-cursor" || fields.some((key) => data[key] !== scope[key]) || !Number.isSafeInteger(data.revision) || data.revision < 0 || !Number.isSafeInteger(data.through) || data.through < 0 || !Number.isSafeInteger(data.listCount) || data.listCount < data.through || data.listCount > 500 || data.through > 0 && typeof data.throughId !== "string" || typeof data.exhausted !== "boolean")
      throw Error("\u5DF2\u4FDD\u5B58\u7684\u589E\u91CF\u4F4D\u7F6E\u8EAB\u4EFD\u3001\u6458\u8981\u6216\u7ED3\u6784\u65E0\u6548\uFF1B\u672A\u6E05\u7A7A\u91CD\u5EFA");
  } else data = {
    version: 1,
    kind: "boss-single-job-list-cursor",
    ...scope,
    revision: 0,
    through: 0,
    throughId: null,
    listCount: 0,
    firstId: null,
    tailId: null,
    exhausted: false,
    lastLoad: null
  };
  const plan = (patch) => {
    const next = { ...data, ...patch, revision: data.revision + 1 };
    delete next.sha256;
    next.sha256 = cursorDigest(next);
    return { version: 1, name, scope, beforeSha256: original === null ? null : createHash("sha256").update(original).digest("hex"), value: next };
  };
  const save = async (update) => {
    signal.throwIfAborted();
    if (!update || update.name !== name || cursorDigest(update.scope) !== cursorDigest(scope) || update.beforeSha256 !== (original === null ? null : createHash("sha256").update(original).digest("hex")))
      throw Error("\u589E\u91CF\u4F4D\u7F6E\u5199\u5165\u8BA1\u5212\u6765\u6E90\u4E0D\u7B26");
    const { sha256, ...body } = update.value;
    if (sha256 !== cursorDigest(body) || body.revision !== data.revision + 1)
      throw Error("\u589E\u91CF\u4F4D\u7F6E\u5199\u5165\u8BA1\u5212\u6458\u8981\u6216\u4FEE\u8BA2\u4E0D\u7B26");
    let before = null;
    try {
      before = await template.file("communication-cache", { operation: "read", name });
    } catch (error) {
      if (!String(error.message || error).includes("ENOENT")) throw error;
    }
    if (before !== original) throw Error("\u589E\u91CF\u4F4D\u7F6E\u5DF2\u88AB\u5176\u4ED6\u64CD\u4F5C\u4FEE\u6539\uFF0C\u505C\u6B62\u8986\u76D6");
    const content = JSON.stringify(update.value);
    await template.file("communication-cache", { operation: "write", name, content });
    if (await template.file("communication-cache", { operation: "read", name }) !== content)
      throw Error("\u589E\u91CF\u4F4D\u7F6E\u4FDD\u5B58\u540E\u672A\u5B8C\u6574\u8BFB\u56DE");
    data = update.value;
    original = content;
    return { name, revision: data.revision, through: data.through, listCount: data.listCount, sha256: data.sha256 };
  };
  return { name, get data() {
    return data;
  }, plan, save };
}
async function observeIncrementalPosition(read, cursor, count, searchUrl) {
  if (!Number.isSafeInteger(count) || count < 1 || count > 500) throw Error("\u589E\u91CF\u5217\u8868\u5C1A\u672A\u5C31\u7EEA\u6216\u8D85\u51FA\u8BFB\u53D6\u8303\u56F4");
  const idAt = async (position) => cursorJob(await read({ operation: "attribute", selector: cursorCard(position) + " > a:nth-of-type(1)", value: "href" }), searchUrl).jobId;
  const firstId = await idAt(1), tailId = await idAt(count), old = cursor.data;
  let through = old.through, restored = false;
  const anchorMatches = through === 0 || through <= count && await idAt(through) === old.throughId;
  const appendMatches = old.listCount === 0 || count >= old.listCount && firstId === old.firstId && await idAt(old.listCount) === old.tailId;
  if (!anchorMatches || !appendMatches) {
    if (!old.throughId) throw Error("\u5217\u8868\u5237\u65B0\u540E\u6CA1\u6709\u53EF\u6838\u5BF9\u7684\u5DF2\u5904\u7406\u951A\u70B9\uFF1B\u672A\u6309\u65E7\u5E8F\u53F7\u7EE7\u7EED");
    const matches = [];
    for (let position = 1; position <= count; position++) if (await idAt(position) === old.throughId) matches.push(position);
    if (matches.length !== 1) throw Error("\u5217\u8868\u5237\u65B0\u6216\u91CD\u6392\u540E\u6062\u590D\u4F4D\u7F6E\u4E0D\u660E\u786E\uFF0C\u672A\u6E05\u7A7A\u8FDB\u5EA6\u6216\u731C\u6D4B\u4F4D\u7F6E");
    through = matches[0];
    restored = true;
  }
  if (await read({ operation: "url" }) !== searchUrl || await read({ operation: "count", selector: "div > div:nth-of-type(1) > li" }) !== count || await idAt(1) !== firstId || await idAt(count) !== tailId) throw Error("\u8BFB\u53D6\u589E\u91CF\u4F4D\u7F6E\u671F\u95F4\u5217\u8868\u53D8\u5316");
  return { through, throughId: through > 0 ? await idAt(through) : null, listCount: count, firstId, tailId, restored };
}
var stdin_default = async ({ input, signal, template }) => {
  signal.throwIfAborted();
  if (!input || Object.keys(input).sort().join(",") !== "check,scroll") throw Error("\u7F3A\u5C11\u672C\u6B21\u53D1\u73B0\u5224\u65AD\u6216\u5B9E\u9645\u6EDA\u52A8\u56DE\u6267");
  const { check: c, scroll: r } = input;
  if (c?.version !== 1 || c.kind !== "daily-discovery-scroll-check" || c.shouldScroll !== true || c.eligibleForActions !== false || c.dayTaskComplete !== false || !Number.isSafeInteger(c.visibleCount) || c.visibleCount < 1 || c.visibleCount > 500 || typeof c.actualCity !== "string" || !c.actualCity) throw Error("\u672C\u6B21\u4E0D\u8DB3\u5019\u9009\u7684\u6765\u6E90\u5C1A\u672A\u6838\u5BF9");
  if (r?.version !== 1 || r.operation !== "scroll" || r.url !== c.searchUrl || r.documentUrl !== r.url || r.selector !== "body" || r.region !== "document" || !Array.isArray(r.framePath) || r.framePath.length || r.direction !== "down" || r.distance !== 2e3 || !["target", "ancestor", "document"].includes(r.region) || !Number.isSafeInteger(r.ancestorDepth) || r.ancestorDepth < 0 || r.ancestorDepth > 64 || typeof r.moved !== "boolean" || typeof r.atStart !== "boolean" || typeof r.atEnd !== "boolean") throw Error("\u5B9E\u9645\u6EDA\u52A8\u56DE\u6267\u4E0E\u672C\u6B21\u56FA\u5B9A\u7F51\u9875\u8303\u56F4\u4E0D\u4E00\u81F4\uFF1A" + JSON.stringify({ selector: r?.selector, region: r?.region, offsetBefore: r?.offsetBefore, offsetAfter: r?.offsetAfter, heightBefore: r?.heightBefore, viewportBefore: r?.viewportBefore }));
  for (const k of ["offsetBefore", "offsetAfter", "heightBefore", "heightAfter", "viewportBefore", "viewportAfter"]) if (typeof r[k] !== "number" || !Number.isFinite(r[k]) || r[k] < 0 || r[k] > 1e9) throw Error("\u6EDA\u52A8\u5B9E\u9645\u4F4D\u7F6E\u56DE\u6267\u65E0\u6548");
  const delta = r.offsetAfter - r.offsetBefore;
  if (delta < 0 || delta > 2001 || r.moved !== (delta !== 0) || r.viewportBefore <= 0 || r.viewportAfter <= 0 || r.offsetBefore > Math.max(0, r.heightBefore - r.viewportBefore) + 1 || r.offsetAfter > Math.max(0, r.heightAfter - r.viewportAfter) + 1 || r.atStart !== r.offsetAfter <= 0.5 || r.atEnd !== r.offsetAfter >= Math.max(0, r.heightAfter - r.viewportAfter) - 0.5) throw Error("\u5B9E\u9645\u4F4D\u79FB\u4E0E\u6EDA\u52A8\u8FB9\u754C\u56DE\u6267\u4E0D\u4E00\u81F4");
  if (r.heightAfter <= r.viewportAfter) throw Error("\u5F53\u524D\u89C2\u5BDF\u533A\u57DF\u6CA1\u6709\u53EF\u6EDA\u52A8\u9875\u9762\u8303\u56F4\uFF0C\u4E0D\u80FD\u636E\u6B64\u8BA4\u5B9A\u5217\u8868\u8017\u5C3D\uFF1B\u8BF7\u6269\u5927\u7F51\u9875\u67E5\u770B\u540E\u6062\u590D");
  if (!r.moved && !r.atEnd) throw Error("\u5217\u8868\u6EDA\u52A8\u6CA1\u6709\u5B9E\u9645\u4F4D\u79FB\u4E14\u672A\u89E6\u5E95\uFF0C\u505C\u6B62\u91CD\u590D\u52A0\u8F7D");
  const dayOf = () => new Intl.DateTimeFormat("sv-SE", { timeZone: c.timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
  const deadline = Date.now() + 3e4, read = async (command) => {
    signal.throwIfAborted();
    const remaining = deadline - Date.now();
    if (remaining < 100) throw Error("\u6EDA\u52A8\u540E\u7B49\u5F85\u8D85\u8FC7\u6709\u9650\u671F\u9650");
    return template.browser("browser", { ...command, timeoutMs: Math.min(3e3, remaining) });
  };
  const cards = "div > div:nth-of-type(1) > li", citySelector = "body > div:nth-of-type(1) > div:nth-of-type(2) > div:nth-of-type(2) > div > div:nth-of-type(1) > span";
  const source = (v) => {
    if (typeof v !== "string" || !v.trim() || v.length > 4096 || v.trim() !== v || /[\u0000-\u0020\u007f…]/.test(v)) throw Error("\u5217\u8868\u8FB9\u754C\u94FE\u63A5\u7F3A\u5931\u6216\u7F29\u7565");
    const u = new URL(v, c.searchUrl);
    if (u.origin !== "https://www.zhipin.com" || u.username || u.password || u.hash || !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(u.pathname)) throw Error("\u5217\u8868\u8FB9\u754C\u94FE\u63A5\u6765\u6E90\u65E0\u6548");
    return u.origin + u.pathname;
  };
  let previous = null, stable = 0, refreshed = false, beforeRefreshBoundary = null, observedSince = Date.now();
  for (let sample = 1; sample <= 20; sample++) {
    signal.throwIfAborted();
    if (dayOf() !== c.configuredDay || await read({ operation: "url" }) !== c.searchUrl) throw Error("\u6EDA\u52A8\u540E\u5B9E\u9645\u9875\u9762\u6216\u65E5\u671F\u5DF2\u53D8\u5316");
    const cityMatches = refreshed ? await read({ operation: "count", selector: citySelector }) : 1;
    const count = await read({ operation: "count", selector: cards });
    if (!Number.isSafeInteger(cityMatches) || cityMatches < 0 || cityMatches > 1 || !Number.isSafeInteger(count) || count < 0 || count > 500) throw Error("\u91CD\u68C0\u540E\u7684\u57CE\u5E02\u6216\u5217\u8868\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u91C7\u7528\u6765\u6E90");
    if (refreshed && (cityMatches === 0 || count === 0)) {
      previous = null;
      stable = 0;
      if (sample < 20) await pause(500, void 0, { signal });
      continue;
    }
    const city = await read({ operation: "read", selector: citySelector });
    if (typeof city !== "string" || city.trim() !== c.actualCity || !Number.isSafeInteger(count) || count < (refreshed ? 1 : c.visibleCount) || count > 500) throw Error("\u6EDA\u52A8\u540E\u5B9E\u9645\u57CE\u5E02\u6216\u5217\u8868\u8303\u56F4\u4E0D\u7B26\uFF08\u91CD\u68C0=" + refreshed + "\uFF0C\u6570\u91CF=" + count + "\uFF0C\u57CE\u5E02=" + city + "\uFF09");
    const links = [];
    for (const position of [.../* @__PURE__ */ new Set([1, count])]) {
      const selector = "div:nth-of-type(" + position + ") > div:nth-of-type(1) > li:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1) > a:nth-of-type(1)";
      links.push(source(await read({ operation: "attribute", selector, value: "href" })));
    }
    const after = await read({ operation: "count", selector: cards });
    if (await read({ operation: "url" }) !== c.searchUrl || (await read({ operation: "read", selector: citySelector })).trim() !== c.actualCity) throw Error("\u6EDA\u52A8\u7B49\u5F85\u91C7\u6837\u671F\u95F4\u9875\u9762\u6216\u5B9E\u9645\u57CE\u5E02\u53D8\u5316");
    const signature = JSON.stringify([count, ...links]);
    stable = after === count && previous === signature ? stable + 1 : 0;
    previous = after === count ? signature : null;
    if (stable >= 2 && (count > c.visibleCount || Date.now() - observedSince >= (r.atEnd ? 6e3 : 1500))) {
      signal.throwIfAborted();
      const result = { version: 1, kind: "daily-scroll-list-ready", pass: c.pass, searchUrl: c.searchUrl, actualCity: c.actualCity, configuredDay: c.configuredDay, countBefore: c.visibleCount, countAfter: count, samples: sample, observedCountGrowth: count > c.visibleCount, refreshedSameSearch: refreshed, refreshCount: refreshed ? 1 : 0, refreshedBoundaryChanged: refreshed && signature !== beforeRefreshBoundary, moved: r.moved, atEnd: r.atEnd, newLinksNotYetAdopted: count > c.visibleCount, eligibleForActions: false, dayTaskComplete: false, siteDailyLimitConfirmed: false };
      if (!c.cursorScope) throw Error("\u7F3A\u5C11\u672C\u6B21\u589E\u91CF\u5217\u8868\u8303\u56F4");
      const cursor = await openIncrementalCursor(template, signal, c.cursorScope);
      const load = { scrollTarget: r.selector, region: r.region, atEnd: r.atEnd, moved: r.moved, offsetAfter: r.offsetAfter, heightAfter: r.heightAfter, viewportAfter: r.viewportAfter, countBefore: c.visibleCount, countAfter: count, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
      result.cursorReceipt = await cursor.save(cursor.plan({ exhausted: r.atEnd && count === c.visibleCount, lastLoad: load }));
      const body = { ...result, kind: "boss-list-scroll-observation", accountSourceSha256: c.accountSourceSha256, configurationRevision: c.configurationRevision, day: c.configuredDay, timeZone: c.timeZone, boundary: links, scrollTarget: r.selector, region: r.region, ancestorDepth: r.ancestorDepth, offsetAfter: r.offsetAfter, heightAfter: r.heightAfter, viewportAfter: r.viewportAfter };
      const sha256 = createHash("sha256").update(JSON.stringify(body)).digest("hex");
      const name = "daily-list-scroll-v1-" + c.accountSourceSha256 + "-" + c.configurationRevision + "-" + c.configuredDay + ".json", content = JSON.stringify({ ...body, sha256 });
      await template.file("communication-cache", { operation: "write", name, content });
      if (await template.file("communication-cache", { operation: "read", name }) !== content) throw Error("\u5B9E\u9645\u6EDA\u52A8\u89C2\u5BDF\u8BB0\u5F55\u672A\u5B8C\u6574\u8BFB\u56DE");
      return result;
    }
    if (sample < 20) await pause(500, void 0, { signal });
  }
  throw Error("\u6EDA\u52A8\u540E\u5217\u8868\u5728\u6709\u9650\u89C2\u5BDF\u5185\u4ECD\u672A\u7A33\u5B9A\uFF0C\u672A\u91C7\u7528\u5019\u9009\u6216\u7EE7\u7EED\u5916\u53D1");
};
export {
  stdin_default as default
};
