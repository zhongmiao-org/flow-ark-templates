import { createHash as G } from "node:crypto";
const mu = /* @__PURE__ */ (() => {
  async function Q(a, d, r) {
    const { accountKey: i, contextId: o, day: n, timeZone: F, revision: e, configuration: f } = r, l = f.acceptanceNewGreetings ?? 0;
    if (l !== 0 && l !== 2) throw Error("\u9A8C\u6536\u65B0\u62DB\u547C\u6570\u53EA\u80FD\u4E3A0\uFF08\u6B63\u5F0F\u6A21\u5F0F\uFF09\u62162");
    if (!l) return null;
    d.throwIfAborted();
    const c = (s) => Array.isArray(s) ? s.map(c) : s && typeof s == "object" ? Object.fromEntries(Object.keys(s).sort().map((D) => [D, c(s[D])])) : s, g = (s) => G("sha256").update(JSON.stringify(c(s))).digest("hex"), h = (s) => {
      const { sha256: D, ...w } = s;
      if (D !== g(w)) throw Error("\u9A8C\u6536\u6765\u6E90\u6458\u8981\u4E0D\u7B26\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55");
      return s;
    }, E = h(JSON.parse(await a.file("communication-cache", { operation: "read", name: "account-outbound-safety-v1-" + i + ".json" })));
    if (E.kind !== "boss-account-outbound-safety" || E.accountKey !== i || !Array.isArray(E.records)) throw Error("\u9A8C\u6536\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u4E0D\u7B26");
    const S = new Intl.DateTimeFormat("sv-SE", { timeZone: F, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
    if (n !== S) throw Error("\u9A8C\u6536\u8DE8\u65E5\uFF0C\u505C\u6B62\u65B0\u589E");
    const x = E.records.filter((s) => s.type === "first-contact" && s.sightings.some((D) => D.day === n && D.timeZone === F)), I = x.map((s) => s.businessKey);
    if (new Set(I).size !== I.length) throw Error("\u9A8C\u6536\u5360\u989D\u952E\u91CD\u590D");
    const A = { accountKey: i, contextId: o, day: n, timeZone: F, revision: e, target: l }, y = "test-greeting-baseline-v1-" + i + "-" + g(A).slice(0, 24) + ".json";
    let k = null;
    try {
      k = await a.file("communication-cache", { operation: "read", name: y });
    } catch (s) {
      if (!String(s.message || s).includes("ENOENT")) throw s;
    }
    let b;
    if (k === null) {
      if (f.firstContactDailyBudget !== I.length + l) throw Error("\u6D4B\u8BD5\u9884\u7B97\u5FC5\u987B\u7B49\u4E8E\u672C\u65E5\u5DF2\u6709\u5360\u989D\u52A02\uFF0C\u7981\u6B62\u6269\u5927\u6216\u91CD\u7F6E\u672C\u8F6E");
      if (b = { version: 1, kind: "boss-test-greeting-baseline", identity: A, keys: I.slice().sort(), budget: f.firstContactDailyBudget, indexSha256: E.sha256, createdAt: (/* @__PURE__ */ new Date()).toISOString() }, b.sha256 = g(b), await a.file("communication-cache", { operation: "write", name: y, content: JSON.stringify(b) }), k = await a.file("communication-cache", { operation: "read", name: y }), JSON.stringify(h(JSON.parse(k))) !== JSON.stringify(b)) throw Error("\u6D4B\u8BD5\u57FA\u7EBF\u672A\u51C6\u786E\u8BFB\u56DE");
    } else b = h(JSON.parse(k));
    if (g(b.identity) !== g(A) || b.budget !== f.firstContactDailyBudget || !Array.isArray(b.keys) || b.keys.some((s) => !I.includes(s))) throw Error("\u6D4B\u8BD5\u57FA\u7EBF\u6216\u9884\u7B97\u53D8\u5316\uFF0C\u505C\u6B62\u4E14\u4FDD\u7559\u5386\u53F2");
    const j = x.filter((s) => !b.keys.includes(s.businessKey));
    if (j.length > l) throw Error("\u6D4B\u8BD5\u5360\u989D\u8D85\u51FA\u4E24\u6B21\uFF0C\u505C\u6B62");
    for (const s of j) if (s.sightings.some((D) => D.day === n && D.timeZone === F && (D.contextId !== o || D.status === "unknown" || D.status === "failed"))) throw Error("\u6D4B\u8BD5\u65B0\u589E\u6765\u6E90\u51B2\u7A81\u6216\u7ED3\u679C\u672A\u77E5\uFF0C\u7981\u6B62\u8865\u53D1");
    const K = j.filter((s) => s.sightings.some((D) => D.day === n && D.timeZone === F && D.contextId === o && D.status === "confirmed"));
    return { version: 1, kind: "boss-test-new-greeting-completion", ...A, baselineName: y, baselineSha256: b.sha256, newOccupied: j.length, newConfirmed: K.length, confirmedKeys: K.map((s) => s.businessKey).sort(), confirmed: K.length === l, siteDailyLimitConfirmed: false, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  async function V(a, d, r) {
    const { accountKey: i, contextId: o, day: n, timeZone: F, limit: e, state: f, ownIntent: l = null, jobId: c = null } = r, g = (t) => G("sha256").update(JSON.stringify(t)).digest("hex"), h = (t) => Array.isArray(t) ? t.map(h) : t && typeof t == "object" ? Object.fromEntries(Object.keys(t).sort().map((B) => [B, h(t[B])])) : t, E = (t) => typeof t == "string" && /^\d{4}-\d{2}-\d{2}$/u.test(t) && Number.isFinite(Date.parse(t + "T00:00:00Z")) && (/* @__PURE__ */ new Date(t + "T00:00:00Z")).toISOString().slice(0, 10) === t, S = (t) => ["reserved", "confirmed", "unknown", "failed"].includes(t);
    if (!/^[a-f0-9]{64}$/u.test(i || "") || typeof o != "string" || !o || !E(n) || typeof F != "string" || !F || !Number.isSafeInteger(e) || e < 0 || e > 150) throw Error("\u672C\u65E5\u81EA\u52A8\u65B0\u589E\u9884\u7B97\u7684\u8D26\u53F7\u3001\u65E5\u671F\u3001\u65F6\u533A\u6216\u6570\u91CF\u65E0\u6548");
    if (new Intl.DateTimeFormat("sv-SE", { timeZone: F, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date()) !== n) throw Error("\u9884\u7B97\u6838\u5BF9\u671F\u95F4\u8DE8\u65E5\uFF0C\u505C\u6B62\u539F\u4F1A\u8BDD\u5E76\u4FDD\u7559\u8BB0\u5F55");
    d.throwIfAborted();
    const I = "account-outbound-safety-v1-" + i + ".json", A = await a.file("communication-cache", { operation: "read", name: I });
    if (typeof A != "string" || Buffer.byteLength(A) > 10 * 1024 * 1024) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\u6216\u8D85\u51FA\u8303\u56F4\uFF0C\u4E0D\u5EFA\u7ACB\u7A7A\u9884\u7B97");
    const y = JSON.parse(A), { sha256: k, ...b } = y;
    if (y.version !== 1 || y.kind !== "boss-account-outbound-safety" || y.accountKey !== i || !Number.isSafeInteger(y.revision) || y.revision < 0 || !Array.isArray(y.records) || y.records.length > 2e3 || k !== g(h(b))) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u6458\u8981\u4E0D\u7B26\uFF0C\u4E0D\u5EFA\u7ACB\u65B0\u9884\u7B97");
    const j = /* @__PURE__ */ new Set(), K = /* @__PURE__ */ new Set();
    let s = null, D = false;
    for (const t of y.records) {
      if (d.throwIfAborted(), !t || !["first-contact", "reply"].includes(t.type) || !/^[a-f0-9]{64}$/u.test(t.businessKey || "") || !Array.isArray(t.sightings) || t.sightings.length < 1 || t.sightings.length > 100 || j.has(t.type + ":" + t.businessKey)) throw Error("\u5B89\u5168\u7D22\u5F15\u8BB0\u5F55\u7ED3\u6784\u3001\u5BB9\u91CF\u6216\u552F\u4E00\u6027\u65E0\u6548");
      if (j.add(t.type + ":" + t.businessKey), t.type === "first-contact" && (typeof t.jobId != "string" || !t.jobId || t.businessKey !== g(["boss-job-safety-v1", i, t.jobId]))) throw Error("\u9996\u6B21\u6C9F\u901A\u4E1A\u52A1\u952E\u4E0E\u51C6\u786E\u5C97\u4F4D\u4E0D\u7B26");
      for (const B of t.sightings) {
        if (!B || typeof B.contextId != "string" || !B.contextId || !/^[a-f0-9]{64}$/u.test(B.intentKey || "") || !S(B.status) || !E(B.day) || typeof B.timeZone != "string" || !B.timeZone) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u6765\u6E90\u6216\u72B6\u6001\u65E0\u6548");
        if (t.type === "first-contact") {
          if (B.timeZone !== F || B.day > n) throw Error("\u9996\u6B21\u6C9F\u901A\u7D22\u5F15\u65F6\u533A\u51B2\u7A81\u6216\u5B58\u5728\u672A\u6765\u65E5\u671F\uFF0C\u4FDD\u7559\u539F\u9884\u7B97\u505C\u6B62");
          B.day === n && K.add(t.businessKey);
        }
      }
      t.type === "first-contact" && c !== null && t.jobId === c && (D = true), t.type === "first-contact" && l && t.jobId === l.jobId && (s = t);
    }
    if (!f || !Array.isArray(f.applicationIntents) || f.applicationIntents.length > 500) throw Error("\u7F3A\u5C11\u5F53\u524D\u5B8C\u6574\u610F\u56FE\u8D26\u672C\uFF0C\u4E0D\u80FD\u8BA1\u7B97\u9884\u7B97");
    const w = /* @__PURE__ */ new Set();
    for (const t of f.applicationIntents) {
      if (!t || t.accountSourceSha256 !== i || t.timeZone !== F || !E(t.day) || t.day > n || !S(t.status) || typeof t.jobId != "string" || !t.jobId || t.key !== g(["boss-application-v1", i, t.jobId]) || w.has(t.key)) throw Error("\u672C\u5B9E\u4F8B\u610F\u56FE\u6765\u6E90\u3001\u65F6\u533A\u6216\u552F\u4E00\u6027\u65E0\u6548\uFF0C\u4E0D\u80FD\u8BA1\u7B97\u9884\u7B97");
      w.add(t.key), t.day === n && K.add(g(["boss-job-safety-v1", i, t.jobId]));
    }
    let R = false;
    if (l) {
      const t = f.applicationIntents.filter((B) => B.key === l.key);
      if (l.status !== "reserved" || l.day !== n || l.timeZone !== F || t.length !== 1 || JSON.stringify(h(t[0])) !== JSON.stringify(h(l)) || !s || !s.sightings.every((B) => B.contextId === o && B.intentKey === l.key && B.status === "reserved" && B.day === n && B.timeZone === F)) throw Error("\u63D0\u4EA4\u524D\u7F3A\u5C11\u672C\u6B21\u552F\u4E00\u3001\u5DF2\u5199\u51FA\u5E76\u8BFB\u56DE\u7684\u9884\u7B97\u9884\u7559");
      if (R = K.has(s.businessKey), !R) throw Error("\u672C\u6B21\u9884\u7559\u672A\u8BA1\u5165\u786C\u9884\u7B97\uFF0C\u505C\u6B62\u63D0\u4EA4");
    }
    const q = K.size, N = Math.max(0, e - q);
    return { version: 1, kind: "boss-first-contact-daily-budget", accountKey: i, day: n, timeZone: F, limit: e, used: q, remaining: N, exhausted: N === 0, withinLimit: q <= e, candidateAlreadyRecorded: D, ownReservationCounted: R, readyForReservation: !l && N > 0 && !D, readyForSubmission: !!l && R && e > 0 && q <= e, safetyRevision: y.revision, safetySha256: k, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), siteDailyLimitConfirmed: false, countBasis: "unique-account-job-keys-in-day-index-and-current-state", failedAttemptsRemainOccupied: true };
  }
  const $ = (a) => Array.isArray(a) ? a.map($) : a && typeof a == "object" ? Object.fromEntries(Object.keys(a).sort().map((d) => [d, $(a[d])])) : a, C = (a) => G("sha256").update(JSON.stringify($(a))).digest("hex"), T = (a) => "div:nth-of-type(" + a + ") > div:nth-of-type(1) > li:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1)";
  function W(a, d) {
    const r = new URL(a, d), i = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(r.pathname);
    if (r.origin !== "https://www.zhipin.com" || r.username || r.password || r.hash || !i) throw Error("\u589E\u91CF\u4F4D\u7F6E\u7F3A\u5C11\u51C6\u786E\u5C97\u4F4D\u94FE\u63A5");
    return { jobId: i[1], jobSource: r.origin + r.pathname };
  }
  async function Eu(a, d, r) {
    const i = ["accountKey", "contextId", "configurationRevision", "day", "timeZone", "searchUrl"];
    if (!r || i.some((c) => r[c] === void 0) || !/^[a-f0-9]{64}$/.test(r.accountKey) || !r.contextId || !Number.isSafeInteger(r.configurationRevision) || !/^\d{4}-\d{2}-\d{2}$/.test(r.day)) throw Error("\u589E\u91CF\u4F4D\u7F6E\u7F3A\u5C11\u56FA\u5B9A\u8303\u56F4");
    const o = new URL(r.searchUrl);
    if (o.origin !== "https://www.zhipin.com" || o.pathname !== "/web/geek/jobs" || o.username || o.password || o.hash || !o.searchParams.get("query")) throw Error("\u589E\u91CF\u68C0\u7D22\u6765\u6E90\u65E0\u6548");
    const n = "single-job-list-v1-" + r.accountKey + "-" + C(r).slice(0, 32) + ".json";
    let F = null, e;
    try {
      F = await a.file("communication-cache", { operation: "read", name: n });
    } catch (c) {
      if (!String(c.message || c).includes("ENOENT")) throw c;
    }
    if (F !== null) {
      e = JSON.parse(F);
      const { sha256: c, ...g } = e;
      if (c !== C(g) || e.version !== 1 || e.kind !== "boss-single-job-list-cursor" || i.some((h) => e[h] !== r[h]) || !Number.isSafeInteger(e.revision) || e.revision < 0 || !Number.isSafeInteger(e.through) || e.through < 0 || !Number.isSafeInteger(e.listCount) || e.listCount < e.through || e.listCount > 500 || e.through > 0 && typeof e.throughId != "string" || typeof e.exhausted != "boolean") throw Error("\u5DF2\u4FDD\u5B58\u7684\u589E\u91CF\u4F4D\u7F6E\u8EAB\u4EFD\u3001\u6458\u8981\u6216\u7ED3\u6784\u65E0\u6548\uFF1B\u672A\u6E05\u7A7A\u91CD\u5EFA");
    } else e = { version: 1, kind: "boss-single-job-list-cursor", ...r, revision: 0, through: 0, throughId: null, listCount: 0, firstId: null, tailId: null, exhausted: false, lastLoad: null };
    return { name: n, get data() {
      return e;
    }, plan: (c) => {
      const g = { ...e, ...c, revision: e.revision + 1 };
      return delete g.sha256, g.sha256 = C(g), { version: 1, name: n, scope: r, beforeSha256: F === null ? null : G("sha256").update(F).digest("hex"), value: g };
    }, save: async (c) => {
      if (d.throwIfAborted(), !c || c.name !== n || C(c.scope) !== C(r) || c.beforeSha256 !== (F === null ? null : G("sha256").update(F).digest("hex"))) throw Error("\u589E\u91CF\u4F4D\u7F6E\u5199\u5165\u8BA1\u5212\u6765\u6E90\u4E0D\u7B26");
      const { sha256: g, ...h } = c.value;
      if (g !== C(h) || h.revision !== e.revision + 1) throw Error("\u589E\u91CF\u4F4D\u7F6E\u5199\u5165\u8BA1\u5212\u6458\u8981\u6216\u4FEE\u8BA2\u4E0D\u7B26");
      let E = null;
      try {
        E = await a.file("communication-cache", { operation: "read", name: n });
      } catch (x) {
        if (!String(x.message || x).includes("ENOENT")) throw x;
      }
      if (E !== F) throw Error("\u589E\u91CF\u4F4D\u7F6E\u5DF2\u88AB\u5176\u4ED6\u64CD\u4F5C\u4FEE\u6539\uFF0C\u505C\u6B62\u8986\u76D6");
      const S = JSON.stringify(c.value);
      if (await a.file("communication-cache", { operation: "write", name: n, content: S }), await a.file("communication-cache", { operation: "read", name: n }) !== S) throw Error("\u589E\u91CF\u4F4D\u7F6E\u4FDD\u5B58\u540E\u672A\u5B8C\u6574\u8BFB\u56DE");
      return e = c.value, F = S, { name: n, revision: e.revision, through: e.through, listCount: e.listCount, sha256: e.sha256 };
    } };
  }
  async function du(a, d, r, i) {
    if (!Number.isSafeInteger(r) || r < 1 || r > 500) throw Error("\u589E\u91CF\u5217\u8868\u5C1A\u672A\u5C31\u7EEA\u6216\u8D85\u51FA\u8BFB\u53D6\u8303\u56F4");
    const o = async (h) => W(await a({ operation: "attribute", selector: T(h) + " > a:nth-of-type(1)", value: "href" }), i).jobId, n = await o(1), F = await o(r), e = d.data;
    let f = e.through, l = false;
    const c = f === 0 || f <= r && await o(f) === e.throughId, g = e.listCount === 0 || r >= e.listCount && n === e.firstId && await o(e.listCount) === e.tailId;
    if (!c || !g) {
      if (!e.throughId) throw Error("\u5217\u8868\u5237\u65B0\u540E\u6CA1\u6709\u53EF\u6838\u5BF9\u7684\u5DF2\u5904\u7406\u951A\u70B9\uFF1B\u672A\u6309\u65E7\u5E8F\u53F7\u7EE7\u7EED");
      const h = [];
      for (let E = 1; E <= r; E++) await o(E) === e.throughId && h.push(E);
      if (h.length !== 1) throw Error("\u5217\u8868\u5237\u65B0\u6216\u91CD\u6392\u540E\u6062\u590D\u4F4D\u7F6E\u4E0D\u660E\u786E\uFF0C\u672A\u6E05\u7A7A\u8FDB\u5EA6\u6216\u731C\u6D4B\u4F4D\u7F6E");
      f = h[0], l = true;
    }
    if (await a({ operation: "url" }) !== i || await a({ operation: "count", selector: "div > div:nth-of-type(1) > li" }) !== r || await o(1) !== n || await o(r) !== F) throw Error("\u8BFB\u53D6\u589E\u91CF\u4F4D\u7F6E\u671F\u95F4\u5217\u8868\u53D8\u5316");
    return { through: f, throughId: f > 0 ? await o(f) : null, listCount: r, firstId: n, tailId: F, restored: l };
  }
  var Fu = async ({ input: a, template: d, signal: r }) => {
    r.throwIfAborted();
    const i = a?.fixedConfiguration, o = a?.closing, n = a?.closingSummary;
    if (o?.version !== 1 || o.kind !== "unread-closing-cohort" || typeof o.closingPhase != "boolean" || i?.contextId !== o.contextId) throw Error("\u7F3A\u5C11\u540C\u5B9E\u4F8B\u672C\u6279\u6536\u5C3E\u9636\u6BB5\u6838\u5BF9");
    if (o.closingPhase) {
      if (n?.kind !== "fixed-unread-closing-summary" || n.siteDailyLimitConfirmed !== true && !(o.closingTrigger === "two-new-greetings-test" && n.testCompletionConfirmed === true) || n.fixedUnreadSetSha256 !== o.fixedUnreadSetSha256 || n.memberCount !== o.memberCount || n.newGreeting !== false || !["complete", "review"].includes(n.decision)) throw Error("\u56FA\u5B9A\u6536\u5C3E\u6C47\u603B\u4E0E\u672C\u8F6E\u6210\u5458\u4E0D\u7B26");
      const u = { ...n, kind: "daily-continuous-decision", closingPhase: true, reason: n.reason };
      return await d.result(u), u;
    }
    const F = await Q(d, r, { accountKey: o.accountKey, contextId: i.contextId, day: o.day, timeZone: o.timeZone, revision: i.revision, configuration: i.value });
    if (F?.confirmed) {
      const u = { version: 1, kind: "daily-continuous-decision", decision: "continue", progress: F.baselineSha256 + ":two-confirmed-start-unread", reason: "\u672C\u8F6E\u4E24\u6B21\u65B0\u62DB\u547C\u5DF2\u53D6\u5F97\u56DE\u6267\uFF0C\u4E0B\u4E00\u6279\u81EA\u52A8\u56FA\u5B9A\u5E76\u5904\u7406\u672A\u8BFB\uFF1B\u975E\u7F51\u7AD9\u4E0A\u9650", siteDailyLimitConfirmed: false, testCompletionConfirmed: true, newGreeting: false, dayTaskComplete: false };
      return await d.result(u), u;
    }
    const e = "site-daily-limit-v1-" + o.accountKey + "-" + o.day + ".json";
    let f = null;
    try {
      f = JSON.parse(await d.file("communication-cache", { operation: "read", name: e }));
    } catch (u) {
      if (!String(u?.message || u).includes("ENOENT") || !String(u?.message || u).includes(e)) throw u;
    }
    if (f) {
      const { sha256: u, ...L } = f;
      if (u !== C(L) || f.kind !== "boss-site-daily-limit" || f.accountKey !== o.accountKey || f.day !== o.day || f.timeZone !== o.timeZone || f.confirmed !== true) throw Error("\u771F\u5B9E\u4E0A\u9650\u8BC1\u636E\u8EAB\u4EFD\u6216\u6458\u8981\u4E0D\u7B26");
      const p = { version: 1, kind: "daily-continuous-decision", decision: "continue", progress: f.sha256 + ":start-unread-closing", reason: "\u771F\u5B9E\u7F51\u7AD9\u4E0A\u9650\u5DF2\u4FDD\u5B58\uFF0C\u4E0B\u4E00\u6279\u76F4\u63A5\u6062\u590D\u6D88\u606F\u6536\u5C3E\uFF0C\u4E0D\u518D\u521D\u59CB\u5316\u6295\u9012", siteDailyLimitConfirmed: true, newGreeting: false, dayTaskComplete: false };
      return await d.result(p), p;
    }
    const l = i?.value?.firstContactDailyBudget;
    if (!Number.isSafeInteger(l) || l < 0 || l > 150) throw Error("\u7EED\u6279\u7F3A\u5C11\u672C\u4EBA\u660E\u786E\u914D\u7F6E\u7684\u672C\u65E5\u786C\u9884\u7B97");
    if (l === 0) {
      const u = { version: 1, kind: "daily-continuous-decision", decision: "review", progress: o.day + ":budget-disabled", reason: "\u672C\u65E5\u81EA\u52A8\u65B0\u589E\u9884\u7B97\u4E3A0\uFF0C\u672A\u65B0\u589E\u62DB\u547C\uFF1B\u4E0D\u662F\u7F51\u7AD9\u4E0A\u9650", siteDailyLimitConfirmed: false, dayTaskComplete: false, newGreeting: false };
      return await d.result(u), u;
    }
    const c = a?.accountBranch;
    if (!c || typeof c != "object" || Array.isArray(c) || Object.keys(c).length > 200) throw Error("\u7EED\u6279\u8D26\u53F7\u6765\u6E90\u5206\u652F\u7F3A\u5931\u6216\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
    const g = Object.values(c).filter((u) => u && typeof u == "object" && !Array.isArray(u) && u.version === 1 && u.status === "current-account-source-matched" && u.currentAccountVerified === true && u.eligibleForActions === false);
    if (g.length !== 1) throw Error("\u7EED\u6279\u9700\u8981\u552F\u4E00\u7684\u672C\u6B21\u5DF2\u590D\u9A8C\u8D26\u53F7\u7ED3\u679C\uFF0C\u4E0D\u6309\u65E7\u8282\u70B9ID\u731C\u6D4B\u6765\u6E90");
    const h = g[0];
    if (!i || i.version !== 1 || i.operation !== "configuration" || !i.contextId || !Number.isSafeInteger(i.revision) || !h || h.status !== "current-account-source-matched") throw Error("\u7EED\u6279\u7F3A\u5C11\u672C\u6B21\u56FA\u5B9A\u914D\u7F6E\u53CA\u8D26\u53F7\u6765\u6E90");
    const E = await d.configuration();
    if (C(E) !== C(i.value)) throw Error("\u7EED\u6279\u914D\u7F6E\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u539F\u4F1A\u8BDD");
    const S = new URL(h.jobseekerResumeHref, h.sourceUrl);
    if (S.origin !== "https://www.zhipin.com" || S.pathname !== "/web/geek/resume") throw Error("\u7EED\u6279\u8D26\u53F7\u5165\u53E3\u4E0D\u7B26");
    const x = G("sha256").update(JSON.stringify(["boss-visible-account-source-v1", h.accountName, h.phoneMask, S.origin + S.pathname])).digest("hex"), I = await d.state.get();
    if (r.throwIfAborted(), !E || !I || !Array.isArray(I.queueEntries) || !Array.isArray(I.applicationIntents)) throw Error("\u8FDE\u7EED\u5904\u7406\u7684\u914D\u7F6E\u6216\u5B8C\u6574\u72B6\u6001\u6765\u6E90\u4E0D\u4E00\u81F4");
    const A = E.replyTimeZone, y = new Intl.DateTimeFormat("sv-SE", { timeZone: A, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
    if (y !== o.day || A !== o.timeZone) throw Error("\u8FDE\u7EED\u4F1A\u8BDD\u8DE8\u65E5\u6216\u65F6\u533A\u53D8\u5316\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u539F\u8BB0\u5F55");
    const k = I.queueEntries.filter((u) => u.day === y && u.timeZone === A), b = I.applicationIntents.filter((u) => u.day === y && u.timeZone === A), j = k.filter((u) => u.status === "processing").length, K = k.filter((u) => u.status === "queued").length, s = b.filter((u) => u.status === "confirmed").length, D = await V(d, r, { accountKey: x, contextId: i.contextId, day: y, timeZone: A, limit: l, state: I });
    if (D.exhausted || !D.withinLimit) {
      const u = { version: 1, kind: "daily-continuous-decision", decision: "review", progress: C({ day: y, timeZone: A, accountKey: x, firstContactBudget: D }), reason: "\u672C\u65E5\u81EA\u52A8\u65B0\u589E\u786C\u9884\u7B97\u5DF2\u7528\u5B8C\uFF0C\u505C\u6B62\u65B0\u589E\uFF1B\u5C1A\u672A\u53D6\u5F97\u771F\u5B9E\u7F51\u7AD9\u4E0A\u9650\uFF0C\u9996\u6B21\u63A5\u7EED\u672A\u9A8C\u6536", firstContactBudget: D, siteDailyLimitConfirmed: false, dayTaskComplete: false, newGreeting: false };
      return await d.result(u), u;
    }
    const w = (u) => (r.throwIfAborted(), d.browser("browser", { ...u, timeoutMs: 1e4 })), R = "body > div:nth-of-type(1) > div:nth-of-type(2) > div:nth-of-type(2) > div > div:nth-of-type(1) > span", q = "div > div:nth-of-type(1) > li", N = await w({ operation: "url" }), t = new URL(N);
    if (t.origin !== "https://www.zhipin.com" || t.pathname !== "/web/geek/jobs" || t.username || t.password || t.hash) throw Error("\u7EED\u6279\u8FDB\u5EA6\u7F3A\u5C11\u771F\u5B9E\u5C97\u4F4D\u5217\u8868\u6765\u6E90");
    if (!Array.isArray(E.targetRoles) || !E.targetRoles.some((u) => typeof u == "string" && u.trim() === t.searchParams.get("query"))) throw Error("\u7EED\u6279\u7B49\u5F85\u524D\u7684\u5B9E\u9645\u68C0\u7D22\u8BCD\u4E0E\u56FA\u5B9A\u914D\u7F6E\u4E0D\u7B26");
    const B = () => new Promise((u, L) => {
      r.throwIfAborted();
      const p = () => {
        clearTimeout(z), L(r.reason || Error("\u5DF2\u53D6\u6D88"));
      }, z = setTimeout(() => {
        r.removeEventListener("abort", p), u();
      }, 250);
      r.addEventListener("abort", p, { once: true });
    });
    let Z = "", v = 0, X = 0, ou = "";
    const fu = Date.now() + 1e4;
    for (; Date.now() < fu; ) {
      if (await w({ operation: "url" }) !== N) throw Error("\u7EED\u6279\u7B49\u5F85\u671F\u95F4\u5C97\u4F4D\u5217\u8868\u6765\u6E90\u53D8\u5316");
      const u = await w({ operation: "count", selector: R });
      if (v = await w({ operation: "count", selector: q }), !Number.isSafeInteger(u) || u < 0 || u > 1 || !Number.isSafeInteger(v) || v < 0 || v > 500) throw Error("\u7EED\u6279\u5217\u8868\u5B9A\u4F4D\u6570\u91CF\u4E0D\u7B26");
      if (Z = u === 1 ? await w({ operation: "read", selector: R }) : "", typeof Z != "string" || !Array.isArray(E.cities) || Z.trim() && !E.cities.includes(Z.trim())) throw Error("\u7EED\u6279\u7B49\u5F85\u671F\u95F4\u5B9E\u9645\u57CE\u5E02\u4E0E\u914D\u7F6E\u4E0D\u7B26");
      const L = JSON.stringify([Z.trim(), v]);
      if (X = E.cities.includes(Z.trim()) && v > 0 ? L === ou ? X + 1 : 1 : 0, ou = L, X >= 2) break;
      await B();
    }
    if (X < 2) throw Error("\u7EED\u6279\u5217\u8868\u5728\u6709\u9650\u7B49\u5F85\u5185\u672A\u5C31\u7EEA\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u539F\u8FD0\u884C");
    if (typeof Z != "string" || !Array.isArray(E.cities) || !E.cities.includes(Z.trim()) || !Number.isSafeInteger(v) || v < 1 || v > 500) throw Error("\u7EED\u6279\u8FDB\u5EA6\u7684\u5B9E\u9645\u57CE\u5E02\u6216\u5217\u8868\u6570\u91CF\u4E0D\u7B26");
    const iu = "div:nth-of-type(" + v + ") > div:nth-of-type(1) > li:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1) > a:nth-of-type(1)", J = await w({ operation: "attribute", selector: iu, value: "href" });
    if (typeof J != "string" || !J || J.length > 4096 || J.trim() !== J) throw Error("\u7EED\u6279\u8FDB\u5EA6\u7F3A\u5C11\u5B8C\u6574\u5C97\u4F4D\u94FE\u63A5");
    const M = new URL(J, N), lu = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(M.pathname);
    if (M.origin !== "https://www.zhipin.com" || M.username || M.password || M.hash || !lu) throw Error("\u7EED\u6279\u8FDB\u5EA6\u7684\u5C97\u4F4D\u8EAB\u4EFD\u65E0\u6548");
    if (await w({ operation: "url" }) !== N || await w({ operation: "count", selector: q }) !== v || await w({ operation: "attribute", selector: iu, value: "href" }) !== J || (await w({ operation: "read", selector: R })).trim() !== Z.trim()) throw Error("\u7EED\u6279\u8FDB\u5EA6\u8BFB\u53D6\u671F\u95F4\u5217\u8868\u6765\u6E90\u53D8\u5316");
    const U = t.searchParams.get("query");
    if (!Array.isArray(E.targetRoles) || !E.targetRoles.length || typeof U != "string" || !E.targetRoles.some((u) => typeof u == "string" && U === u.trim())) throw Error("\u7EED\u6279\u8FDB\u5EA6\u7684\u5B9E\u9645\u68C0\u7D22\u8BCD\u4E0E\u56FA\u5B9A\u914D\u7F6E\u4E0D\u7B26");
    const O = await Eu(d, r, { accountKey: x, contextId: i.contextId, configurationRevision: i.revision, day: y, timeZone: A, searchUrl: N }), _ = await du(w, O, v, N), nu = k.filter((u) => u.status === "queued" && u.searchUrl === N).length, P = E.targetRoles.map((u) => u.trim());
    if (new Set(P).size !== P.length) throw Error("\u68C0\u7D22\u8BCD\u91CD\u590D\uFF0C\u672A\u81EA\u52A8\u6269\u5927\u6216\u6539\u5199\u914D\u7F6E");
    const ru = { accountKey: x, contextId: i.contextId, configurationRevision: i.revision, day: y, timeZone: A, queries: P }, Y = "single-job-queries-v1-" + x + "-" + C(ru).slice(0, 32) + ".json";
    let uu = null, m;
    try {
      uu = await d.file("communication-cache", { operation: "read", name: Y });
    } catch (u) {
      if (!String(u.message || u).includes("ENOENT")) throw u;
    }
    if (uu === null) m = { version: 1, kind: "boss-single-job-query-progress", scope: ru, exhaustedQueries: [] };
    else {
      m = JSON.parse(uu);
      const { sha256: u, ...L } = m;
      if (u !== C(L) || m.version !== 1 || m.kind !== "boss-single-job-query-progress" || C(m.scope) !== C(ru) || !Array.isArray(m.exhaustedQueries) || new Set(m.exhaustedQueries).size !== m.exhaustedQueries.length || m.exhaustedQueries.some((p) => !P.includes(p))) throw Error("\u68C0\u7D22\u8F6E\u6362\u8BB0\u5F55\u7F3A\u5931\u8EAB\u4EFD\u6216\u6458\u8981\u4E0D\u7B26");
    }
    m.loadEvidenceVersion !== 2 && (m.exhaustedQueries = [], m.loadEvidenceVersion = 2);
    let H = U, tu = false, eu = false;
    const su = O.data.exhausted === true && O.data.lastLoad?.scrollTarget === "body" && O.data.lastLoad?.region === "document" && O.data.lastLoad?.heightAfter > O.data.lastLoad?.viewportAfter && _.through >= v && nu === 0;
    if (su) {
      m.exhaustedQueries.includes(U) || m.exhaustedQueries.push(U), H = P.find((p) => !m.exhaustedQueries.includes(p)) || U, eu = m.exhaustedQueries.length === P.length, delete m.sha256, m.sha256 = C(m);
      const u = JSON.stringify(m);
      let L = null;
      try {
        L = await d.file("communication-cache", { operation: "read", name: Y });
      } catch (p) {
        if (!String(p.message || p).includes("ENOENT")) throw p;
      }
      if (L !== uu) throw Error("\u68C0\u7D22\u8F6E\u6362\u8FDB\u5EA6\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u8986\u76D6");
      if (await d.file("communication-cache", { operation: "write", name: Y, content: u }), await d.file("communication-cache", { operation: "read", name: Y }) !== u) throw Error("\u68C0\u7D22\u8F6E\u6362\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
      if (!eu) {
        if (await w({ operation: "url" }) !== N) throw Error("\u5207\u6362\u68C0\u7D22\u524D\u6765\u6E90\u53D8\u5316");
        const p = new URL(N);
        p.searchParams.set("query", H), await w({ operation: "navigate", value: p.href });
        let z = 0;
        const gu = Date.now() + 1e4;
        for (; Date.now() < gu; ) {
          if (await w({ operation: "url" }) !== p.href) throw Error("\u5207\u6362\u540E\u7684\u68C0\u7D22\u6765\u6E90\u4E0D\u7B26");
          const cu = await w({ operation: "count", selector: q });
          if (cu > 0 && cu <= 500 && await w({ operation: "count", selector: R }) === 1 && String(await w({ operation: "read", selector: R })).trim() === Z.trim() ? z++ : z = 0, z >= 2) break;
          await B();
        }
        if (z < 2) throw Error("\u4E0B\u4E00\u68C0\u7D22\u8BCD\u672A\u5728\u6709\u9650\u7B49\u5F85\u5185\u5C31\u7EEA");
        tu = true;
      }
    }
    const hu = nu > 0 || _.through < v || !su || tu, Du = C({ day: y, timeZone: A, query: H, through: _.through, listCount: v, tail: _.tailId, lastLoad: O.data.lastLoad ? [O.data.lastLoad.offsetAfter, O.data.lastLoad.heightAfter, O.data.lastLoad.countAfter, O.data.lastLoad.atEnd] : null, exhaustedQueries: m.exhaustedQueries, queue: k.map((u) => [u.key, u.status]).sort(), intents: b.map((u) => [u.key, u.status]).sort() }), yu = j || eu || !hu ? "review" : "continue", Bu = j ? "\u4ECD\u6709\u5C97\u4F4D\u5904\u7406\u72B6\u6001\u672A\u6536\u5C3E\uFF0C\u505C\u6B62\u7EED\u53D1\u6838\u5BF9\u539F\u8BB0\u5F55" : eu ? "\u5168\u90E8\u914D\u7F6E\u68C0\u7D22\u8BCD\u5728\u672C\u6B21\u89E6\u5E95\u7B49\u5F85\u540E\u5747\u65E0\u65B0\u589E\uFF1B\u4FDD\u5B58\u539F\u56E0\u505C\u6B62\uFF0C\u4E0D\u7B97\u7F51\u7AD9\u5F53\u5929\u4E0A\u9650" : tu ? "\u5F53\u524D\u68C0\u7D22\u672C\u6B21\u52A0\u8F7D\u672A\u89C1\u65B0\u589E\uFF0C\u5DF2\u5207\u6362\u5230 " + H : "\u4ECE\u5DF2\u4FDD\u5B58\u4F4D\u7F6E\u7EE7\u7EED\u5904\u7406\uFF1B\u5F53\u524D\u4F1A\u8BDD\u4E0D\u4EE520\u6B21\u4F5C\u4E3A\u53D1\u9001\u4E0A\u9650", au = { version: 1, kind: "daily-continuous-decision", decision: yu, progress: Du, reason: Bu, day: y, timeZone: A, firstContactBudget: D, confirmedToday: s, pending: K, processing: j, query: H, rotated: tu, exhaustedQueries: m.exhaustedQueries, through: _.through, visibleCount: v, siteDailyLimitConfirmed: false, dayTaskComplete: false };
    return await d.result(au), au;
  };
  return Fu;
})(), wu = async function({ input: V, template: $ }) {
  const C = V.closing, T = V.closingSummary;
  if (!C?.unknownRecovery || T?.kind !== "unknown-chat-review-summary" || T.newGreeting !== false || T.memberCount !== C.memberCount) throw Error("unknown\u63A5\u7BA1\u6C47\u603B\u6765\u6E90\u4E0D\u7B26");
  const W = { ...T, kind: "daily-continuous-decision", closingPhase: true, decision: T.decision, reason: T.reason };
  return await $.result(W), W;
};
async function Au(Q) {
  return Q.input?.closing?.unknownRecovery ? wu(Q) : mu(Q);
}
export {
  Au as default
};
