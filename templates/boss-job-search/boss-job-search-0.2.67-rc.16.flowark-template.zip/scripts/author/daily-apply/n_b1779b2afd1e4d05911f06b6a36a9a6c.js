import { createHash as X } from "node:crypto";
const tt = /* @__PURE__ */ (() => {
  function x(t) {
    return t.status === "review" && !t.operationKey && !t.modelRequestId && t.sourceReviewVersion !== "chat-list-direct-v5" && /固定成员姓名控件不唯一|固定成员定向搜索结果不唯一|关联职位没有可核对的继续沟通入口|固定成员缺少可核对的定向搜索姓名，未猜测|固定成员缺少唯一可见身份|关联职位返回后的完整消息或对象变化/u.test(String(t.reason || ""));
  }
  async function N(t, n) {
    const r = ".user-list-content", c = (o) => o.replace(/[\s\uE000-\uF8FF]/gu, ""), e = ".list-warp.v2 input";
    await t("count", e) === 1 && String(await t("inputValue", e, null)) !== "" && await t("fill", e, "");
    const i = ".list-warp.v2 ul:has(> .selected)", u = i + " > :nth-child(2)";
    await t("count", u) === 1 && /^未读(?:\s*\(\d+\))?$/u.test(String(await t("read", u)).trim()) && !/^未读/u.test(String(await t("read", i + " .selected")).trim()) && await t("click", u);
    for (let o = 0; o < 30 && await t("count", r) !== 1; o++) await new Promise((m) => setTimeout(m, 150));
    if (await t("count", r) !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u6765\u6E90\u4E0D\u552F\u4E00");
    const a = [{ selector: r, depth: 0 }], l = [];
    let f = 0;
    for (; a.length; ) {
      const o = a.shift();
      if (++f > 400) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
      const m = await t("count", o.selector + ".friend-content") === 1, p = m ? 1 : await t("count", o.selector + " .friend-content");
      if (p === 1) {
        const g = m ? o.selector : o.selector + " .friend-content", B = String(await t("read", o.selector)).trim();
        c(B).includes(c(String(n.member.text).split(/\r?\n/u).slice(3).join(`
`).trim())) && l.push({ sel: o.selector, label: g, text: B });
        continue;
      }
      if (p > 1 && o.depth < 4) {
        const g = await t("count", o.selector + " > *");
        if (!Number.isSafeInteger(g) || g > 200) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
        for (let B = 1; B <= g; B++) a.push({ selector: o.selector + " > :nth-child(" + B + ")", depth: o.depth + 1 });
      }
    }
    if (l.length === 0 && n.member.lookupName) {
      await t("fill", e, n.member.lookupName);
      const o = ".boss-search-result .search-list";
      for (let D = 0; D < 30 && !(await t("count", o) > 0); D++) await new Promise((S) => setTimeout(S, 150));
      if (await t("count", o) !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u5B9A\u5411\u641C\u7D22\u7ED3\u679C\u4E0D\u552F\u4E00");
      const m = [o], p = [];
      let g = 0;
      for (; m.length; ) {
        const D = m.shift();
        if (++g > 100) throw Error("\u8054\u7CFB\u4EBA\u59D3\u540D\u63A7\u4EF6\u8303\u56F4\u8FC7\u5927");
        const S = await t("count", D + " > *"), k = String(await t("read", D)).trim();
        if (k === n.member.lookupName && p.push({ label: D, text: k }), S > 0 && S < 30) for (let M = 1; M <= S; M++) m.push(D + " > :nth-child(" + M + ")");
      }
      const B = p.filter((D) => !p.some((S) => S !== D && S.label.startsWith(D.label + " > ")));
      if (B.length !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u59D3\u540D\u63A7\u4EF6\u4E0D\u552F\u4E00");
      l.push(B[0]);
    }
    if (l.length !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u7F3A\u5C11\u552F\u4E00\u53EF\u89C1\u8EAB\u4EFD\uFF0C\u672A\u731C\u6D4B\u59D3\u540D");
    const w = l[0];
    if (String(await t("read", w.label)).trim() !== w.text) throw Error("\u56FA\u5B9A\u6210\u5458\u53EF\u89C1\u8EAB\u4EFD\u53D8\u5316");
    await t("click", w.label);
    for (let o = 0; o < 30; o++) {
      if (await t("count", ".chat-conversation .user-info") === 1 && await t("count", "li.message-item") > 0) {
        const m = String(await t("read", ".chat-conversation .user-info")).trim(), p = await y(t), g = c(String(n.member.text).split(/\r?\n/u).slice(3).join(`
`).trim());
        if (m && p.some((B) => B.direction === "incoming" && c(B.text || "") === g)) {
          n.recipientLabel = m, n.rows = [{ mid: p[0].mid }];
          return;
        }
      }
      await new Promise((m) => setTimeout(m, 150));
    }
    throw Error("\u56FA\u5B9A\u6210\u5458\u53EF\u89C1\u8EAB\u4EFD\u672A\u5B8C\u6574\u8BFB\u56DE");
  }
  async function G(t, n, r) {
    if (typeof r != "string" || !r.trim()) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u539F\u59D3\u540D\u6765\u6E90\u7F3A\u5931");
    await t("navigate", void 0, "https://www.zhipin.com/web/geek/chat"), await N(t, n);
  }
  function $(t, n) {
    const r = (l) => l.normalize("NFKC").replace(/\s+/gu, " ").trim().toLocaleLowerCase("en-US");
    if (typeof t != "string" || !t.trim() || t.length > 1e3 || /(?:\.{3}|…|⋯)/u.test(t)) throw Error("\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u7F3A\u5931\u6216\u622A\u65AD\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u8BB0\u5F55");
    const c = n?.titleKeywords, e = n?.excludedRoles;
    for (const [l, f, w] of [["titleKeywords", c, 1], ["excludedRoles", e, 0]]) if (!Array.isArray(f) || f.length < w || f.length > 20 || f.some((o) => typeof o != "string" || !r(o) || o.length > 100) || new Set(f.map(r)).size !== f.length) throw Error("\u5C97\u4F4D\u8303\u56F4\u914D\u7F6E\u65E0\u6548\uFF1A" + l + "\uFF1B\u672A\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE");
    const i = r(t), u = e.filter((l) => i.includes(r(l))), a = c.filter((l) => i.includes(r(l)));
    return { version: 1, kind: "literal-full-job-title-scope", fullTitle: t, matched: a, excluded: u, allowed: u.length === 0 && a.length > 0, source: "actual-complete-job-title", jdUsed: false, searchKeywordUsedAsEvidence: false };
  }
  const q = /* @__PURE__ */ (() => {
    var t = async ({ input: n, signal: r }) => {
      r.throwIfAborted();
      const c = n, e = c?.value;
      if (!c || c.version !== 1 || c.operation !== "read" || c.binding !== "account-source-result" || c.schemaValidation !== "passed" || c.dataChanged !== false || c.ref?.version !== 1 || c.ref.policy !== "credential-redacted-v1" || c.ref.source?.entryId !== "account-source") throw new Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u5DF2\u9009\u62E9\u4E14\u5B8C\u6574\u53EF\u590D\u7528\u7684\u8D26\u53F7\u6765\u6E90\uFF0C\u8BF7\u5230\u8D44\u6E90\u9875\u91CD\u65B0\u6838\u5BF9\u5E76\u4FDD\u5B58");
      if (!e || e.version !== 1 || e.kind !== "boss-account-source" || e.status !== "account-source-confirmed" || e.accountVerified !== true || e.platformUniqueIdVerified !== false || e.eligibleForActions !== false || e.role !== "jobseeker") throw new Error("\u6240\u9009\u8BB0\u5F55\u5C1A\u672A\u5B8C\u6210\u672C\u4EBA\u786E\u8BA4\u548C\u6765\u6E90\u590D\u9A8C\uFF1B\u8BF7\u5728\u5F53\u524D\u5B9E\u4F8B\u5B8C\u6210\u8D26\u53F7\u6838\u5BF9\uFF0C\u518D\u9009\u62E9\u8BE5\u6B21\u5DF2\u4FDD\u5B58\u7ED3\u679C");
      const i = ["version", "kind", "status", "accountAlias", "accountName", "phoneMask", "jobseekerResumeHref", "role", "sourceUrl", "accountVerified", "platformUniqueIdVerified", "eligibleForActions", "confirmedAt", "checkedAt", "reason"];
      if (Object.keys(e).length !== i.length || i.some((w) => !Object.prototype.hasOwnProperty.call(e, w))) throw new Error("\u6240\u9009\u8D26\u53F7\u7ED3\u679C\u7ED3\u6784\u4E0D\u7B26\uFF0C\u505C\u6B62\u91C7\u7528");
      for (const w of ["accountAlias", "accountName", "phoneMask"]) if (typeof e[w] != "string" || !e[w].trim() || e[w] !== e[w].trim() || e[w].length > 100 || /[\r\n]/.test(e[w])) throw new Error("\u8D26\u53F7\u5FC5\u8981\u5B57\u6BB5\u7F3A\u5931\u6216\u683C\u5F0F\u65E0\u6548\uFF0C\u505C\u6B62\u91C7\u7528");
      if (!/^[+\d ()-]*\*{2,}[\d ()-]+$/.test(e.phoneMask) || /登录|注册|验证码/.test(e.accountName)) throw new Error("\u8D26\u53F7\u6765\u6E90\u7F3A\u5C11\u6709\u6548\u7684\u53EF\u89C1\u59D3\u540D\u6216\u624B\u673A\u53F7\u63A9\u7801");
      if (typeof e.reason != "string" || !e.reason.trim()) throw new Error("\u8D26\u53F7\u7ED3\u679C\u7F3A\u5C11\u660E\u786E\u6838\u5BF9\u8BF4\u660E");
      const u = Date.parse(e.confirmedAt), a = Date.parse(e.checkedAt);
      if (typeof e.confirmedAt != "string" || typeof e.checkedAt != "string" || !Number.isFinite(u) || !Number.isFinite(a) || u <= 0 || a < u || a > Date.now() + 6e4) throw new Error("\u8D26\u53F7\u786E\u8BA4\u6216\u590D\u9A8C\u65F6\u95F4\u65E0\u6CD5\u6838\u5BF9\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4");
      if (typeof e.sourceUrl != "string" || typeof e.jobseekerResumeHref != "string" || !e.sourceUrl.trim() || !e.jobseekerResumeHref.trim() || e.sourceUrl.length > 16384 || e.jobseekerResumeHref.length > 16384) throw new Error("\u8D26\u53F7\u9875\u9762\u6216\u7B80\u5386\u5165\u53E3\u5730\u5740\u65E0\u6548");
      const l = new URL(e.sourceUrl), f = new URL(e.jobseekerResumeHref, e.sourceUrl);
      if (l.origin !== "https://www.zhipin.com" || l.pathname !== "/web/geek/account" || l.searchParams.get("type") !== "accountSet" || l.username || l.password || l.hash || f.origin !== l.origin || f.pathname !== "/web/geek/resume" || f.username || f.password) throw new Error("\u8D26\u53F7\u8BB0\u5F55\u7684\u9875\u9762\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u4E0D\u7B26");
      return r.throwIfAborted(), { version: 1, accountSourceValid: true, currentAccountVerified: false, account: e };
    };
    return t;
  })(), Z = /* @__PURE__ */ (() => {
    async function t({ input: n, signal: r, template: c }) {
      r.throwIfAborted();
      const e = n?.expected?.account;
      if (n?.expected?.accountSourceValid !== true || e?.kind !== "boss-account-source" || e.status !== "account-source-confirmed" || e.accountVerified !== true) throw Error("\u7F3A\u5C11\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\u6765\u6E90");
      const i = async (g, B, D) => {
        r.throwIfAborted();
        const S = await c.browser("browser", { operation: g, ...B ? { selector: B } : {}, ...D === void 0 ? {} : { value: D }, timeoutMs: 3e3 });
        return r.throwIfAborted(), S;
      }, u = await i("url"), a = new URL(u);
      if (a.origin !== "https://www.zhipin.com" || a.username || a.password || !a.pathname.startsWith("/web/") && !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(a.pathname)) throw Error("\u5F53\u524D\u9875\u9762\u4E0D\u662FBOSS\u6C42\u804C\u9875\u9762\uFF0C\u8BF7\u5148\u767B\u5F55");
      const l = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", f = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)", w = await i("count", l), o = await i("count", f);
      if (w !== 1 || o !== 1) throw Error("\u5F53\u524D\u9875\u9762\u8D26\u53F7\u5165\u53E3\u6570\u91CF\u5F02\u5E38\uFF1A" + JSON.stringify({ nameCount: w, resumeCount: o }));
      const m = await i("read", l), p = await i("attribute", f, "href");
      if (typeof m != "string" || m.normalize("NFKC").trim() !== e.accountName.normalize("NFKC").trim() || typeof p != "string" || new URL(p, u).href !== new URL(e.jobseekerResumeHref, e.sourceUrl).href || await i("url") !== u) throw Error("\u5F53\u524D\u767B\u5F55\u8EAB\u4EFD\u3001\u6C42\u804C\u5165\u53E3\u6216\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
      return { version: 1, status: "current-account-source-matched", accountAlias: e.accountAlias, accountName: e.accountName, phoneMask: e.phoneMask, jobseekerResumeHref: e.jobseekerResumeHref, sourceUrl: e.sourceUrl, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), currentPageUrl: u, currentAccountVerified: true, platformUniqueIdVerified: false, eligibleForActions: false, accountCheckMode: "confirmed-initial-account-and-visible-header", phoneMaskRechecked: false, reason: "\u4F7F\u7528\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\uFF1B\u53EA\u8BFB\u6838\u5BF9\u5F53\u524D\u767B\u5F55\u59D3\u540D\u3001\u6C42\u804C\u5165\u53E3\u53CA\u9875\u9762\u8FDE\u7EED\u6027\uFF0C\u624B\u673A\u53F7\u63A9\u7801\u6CBF\u7528\u786E\u8BA4\u6765\u6E90\uFF0C\u6CA1\u6709\u91CD\u65B0\u8BFB\u53D6\u3002" };
    }
    return t;
  })(), J = (t) => Array.isArray(t) ? t.map(J) : t && typeof t == "object" ? Object.fromEntries(Object.keys(t).sort().map((n) => [n, J(t[n])])) : t, V = (t) => I("sha256").update(JSON.stringify(J(t))).digest("hex"), j = (t) => Array.isArray(t) ? t.map(j) : t && typeof t == "object" ? Object.fromEntries(Object.keys(t).sort().map((n) => [n, j(t[n])])) : t, O = (t) => I("sha256").update(JSON.stringify(j(t))).digest("hex");
  async function _(t, n, r, c, e = false) {
    const i = "account-outbound-safety-v1-" + r + ".json";
    let u, a = true, l;
    try {
      l = await t.file("communication-cache", { operation: "read", name: i }), u = JSON.parse(l);
    } catch (o) {
      if (!String(o.message || o).includes("ENOENT")) throw o;
      if (!e) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
      a = false, u = { version: 1, kind: "boss-account-outbound-safety", accountKey: r, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    }
    if (a) {
      const { sha256: o, ...m } = u;
      if (o !== O(m)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
    }
    if (u.version !== 1 || u.kind !== "boss-account-outbound-safety" || u.accountKey !== r || !Number.isSafeInteger(u.revision) || u.revision < 0 || !Array.isArray(u.records) || u.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
    const f = /* @__PURE__ */ new Set();
    for (const o of u.records) {
      if (!["first-contact", "reply"].includes(o.type) || !/^[a-f0-9]{64}$/.test(o.businessKey) || !Array.isArray(o.sightings) || !o.sightings.length || o.sightings.length > 100 || f.has(o.type + ":" + o.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
      f.add(o.type + ":" + o.businessKey);
      for (const m of o.sightings) if (typeof m.contextId != "string" || !m.contextId || !/^[a-f0-9]{64}$/.test(m.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(m.status) || !/^\d{4}-\d{2}-\d{2}$/.test(m.day) || typeof m.timeZone != "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
    }
    let w = !a;
    return { data: u, name: i, merge: (o) => {
      if (!Array.isArray(o?.applicationIntents) || !Array.isArray(o?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
      for (const [m, p] of [["first-contact", o.applicationIntents], ["reply", o.replyIntents]]) for (const g of p) {
        if ((m === "first-contact" ? g.accountSourceSha256 : g.accountKey) !== r) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
        if (!/^[a-f0-9]{64}$/.test(g.key) || !g.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(g.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
        const B = m === "first-contact" ? O(["boss-job-safety-v1", r, g.jobId]) : I("sha256").update(["boss-text-reply-v1", r, g.incomingMessageId].join(":")).digest("hex");
        let D = u.records.find((k) => k.type === m && k.businessKey === B);
        if (D || (D = { type: m, businessKey: B, jobId: g.jobId, ...m === "reply" ? { conversationKey: g.conversationKey, incomingMessageId: g.incomingMessageId } : {}, sightings: [] }, u.records.push(D), w = true), D.jobId !== g.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
        const S = { contextId: c, intentKey: g.key, status: g.status, day: g.day, timeZone: g.timeZone, contentSha256: g.contentSha256 || null, sourceSha256: g.sourceSha256 || null };
        if (D.sightings.some((k) => JSON.stringify(j(k)) === JSON.stringify(j(S))) || (D.sightings.push(S), w = true), D.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
      }
      if (u.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
    }, save: async () => {
      if (n.throwIfAborted(), w) {
        if (a && await t.file("communication-cache", { operation: "read", name: i }) !== l) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
        u.records.sort((g, B) => (g.type + ":" + g.businessKey).localeCompare(B.type + ":" + B.businessKey));
        for (const g of u.records) g.sightings.sort((B, D) => JSON.stringify(j(B)).localeCompare(JSON.stringify(j(D))));
        u.revision++, u.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete u.sha256, u.sha256 = O(u), await t.file("communication-cache", { operation: "write", name: i, content: JSON.stringify(u) }), w = false, l = JSON.stringify(u), a = true;
      }
      const o = JSON.parse(await t.file("communication-cache", { operation: "read", name: i })), { sha256: m, ...p } = o;
      if (m !== O(p) || m !== u.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
      return { revision: u.revision, sha256: u.sha256, records: u.records.length };
    }, blocked: (o, m) => u.records.some((p) => p.type === o && p.businessKey === m) };
  }
  const s = (t, n) => async (r, c, e) => {
    n.throwIfAborted();
    try {
      return await t.browser("browser", { operation: r, ...c ? { selector: c } : {}, ...e === void 0 ? {} : { value: e }, timeoutMs: 3e3 });
    } catch (i) {
      const u = String(i.message || i);
      if (!/^\(-3\) loading /u.test(u)) throw i;
      let a = null;
      if (r === "navigate" && e === "https://www.zhipin.com/web/geek/chat" && (a = new URL(e)), r === "click" && c === ".chat-position-content .right-content > :first-child") {
        const l = /^\(-3\) loading '([^']+)'/u.exec(u);
        if (l) {
          const f = new URL(l[1]);
          f.origin === "https://www.zhipin.com" && /^\/job_detail\/[A-Za-z0-9_~-]+\.html$/u.test(f.pathname) && !f.username && !f.password && (a = f);
        }
      }
      if (!a) throw i;
      for (let l = 0; l < 30; l++) {
        n.throwIfAborted();
        const f = await t.browser("browser", { operation: "url", timeoutMs: 3e3 }), w = new URL(f);
        if (w.origin === a.origin && w.pathname === a.pathname) return { navigationObserved: true, url: f, originalClickRepeated: false };
        await new Promise((o) => setTimeout(o, 150));
      }
      throw i;
    }
  }, h = (t) => {
    const { sha256: n, ...r } = t;
    return n === O(r);
  };
  async function b(t, n, r, c) {
    const e = r.progressName, i = await t.file("communication-cache", { operation: "read", name: e }), u = JSON.parse(i);
    if (!h(u) || u.accountKey !== r.accountKey || u.fixedUnreadSetSha256 !== r.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
    if (!c) return u;
    const a = c(structuredClone(u));
    if (a.revision++, a.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete a.sha256, a.sha256 = O(a), await t.file("communication-cache", { operation: "read", name: e }) !== i) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
    n.throwIfAborted(), await t.file("communication-cache", { operation: "write", name: e, content: JSON.stringify(a) });
    const l = JSON.parse(await t.file("communication-cache", { operation: "read", name: e }));
    if (!h(l) || l.sha256 !== a.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
    return l;
  }
  async function y(t) {
    const n = await t("count", "li.message-item");
    if (!Number.isSafeInteger(n) || n < 1 || n > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
    const r = [];
    for (let c = 1; c <= n; c++) {
      const e = "li.message-item:nth-child(" + c + " of li.message-item)", i = await t("attribute", e, "data-mid"), u = await t("attribute", e, "class");
      if (!/^\d{6,40}$/.test(i || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
      const a = await t("count", e + " .text-content");
      if (a > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
      const l = a === 1 ? String(await t("read", e + " .text-content")).trim() : null, f = l === null ? String(await t("read", e)).trim() : null;
      if ((l || f || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
      const w = !!l && /^您正在与Boss.+沟通$/u.test(l), o = !w && l !== null && u.split(/\s+/u).includes("item-myself") ? "outgoing" : !w && l !== null && u.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
      r.push({ mid: i, direction: o, text: l, context: f });
    }
    if (new Set(r.map((c) => c.mid)).size !== r.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
    return r;
  }
  async function F(t, n) {
    const r = new URL(await t("url"));
    if (r.origin !== "https://www.zhipin.com" || r.pathname !== "/web/geek/chat" || await t("count", ".chat-conversation .user-info") !== 1) return false;
    const c = String(await t("read", ".chat-conversation .user-info")).trim(), e = (i) => i.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
    return n.recipientLabel ? String(await t("read", ".chat-conversation .user-info")).trim() === n.recipientLabel && (!n.rows?.length || await t("count", 'li.message-item[data-mid="' + n.rows[0].mid + '"]') === 1) : await t("count", ".friend-content.selected") === 1 && e(String(await t("read", ".friend-content.selected"))).includes(e(n.member.identityLine));
  }
  async function A(t, n, r) {
    const c = s(t, n);
    return await F(c, r) ? String(await c("read", r.accountSelector)).trim() === r.accountLabel && String(await c("read", r.recipientSelector)).trim() === r.recipientLabel && JSON.stringify(await y(c)) === JSON.stringify(r.rows) : false;
  }
  var E = async ({ input: t, template: n, signal: r, artifact: c, onAccountVerified: e }) => {
    const i = t?.cohort, u = t?.profile;
    if (i?.kind !== "unread-closing-cohort" || i.closingPhase !== true || u?.version !== 1 || !u.ref?.versionId || !u.markdown?.trim()) throw Error("\u7F3A\u5C11\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u6216\u672C\u6B21\u786E\u8BA4Skill");
    const a = { ...i, sourceReviewVersion: "chat-list-direct-v5", kind: "chat-reply-source", fixedUnreadMember: true, profile: u, returnToJobs: false };
    if (!i.ready) return { ...a, ready: false, status: "fixed-unread-complete", reason: "\u56FA\u5B9A\u96C6\u5408\u5DF2\u5904\u7406\u5B8C\u6BD5\uFF0C\u4E0D\u91CD\u65B0\u626B\u63CF" };
    await Z({ input: { expected: i.accountSource }, template: n, signal: r }), e?.();
    const l = String(i.member?.text || "").split(/\r?\n/u).slice(3).join(`
`).trim();
    if (/背景不完全相符|需要其他资质|不太符合|不太?合适|不[是太]*特别契合|不[完全]*符合|不[完全]*匹配|后续有机会再合作|未能通过|暂不考虑/u.test(l) && !/[?？]|(?:是否|有没有|会不会|能否|请问|什么时候|多少|怎么|哪些)/u.test(l)) return { ...a, member: i.member, ready: false, jobId: null, jobSource: null, status: "rejected-no-reply", reason: "\u56FA\u5B9A\u672A\u8BFB\u5FEB\u7167\u4E2D\u5BF9\u65B9\u5DF2\u660E\u786E\u62D2\u7EDD\uFF0C\u4E0D\u56DE\u590D\u3001\u4E0D\u6267\u884C\u539F\u751F\u8BF7\u6C42", previewSource: true };
    const f = s(n, r), w = i.member;
    let o = await b(n, r, i);
    if (o.completed.some((d) => d.memberKey === w.key && !x(d) && !(d.status === "review" && d.replyPolicyVersion !== "work-questions-partial-known-v2"))) return { ...a, ready: false, status: "already-completed", reason: "\u8BE5\u56FA\u5B9A\u6210\u5458\u5DF2\u5904\u7406\uFF0C\u672A\u91CD\u590D\u6253\u5F00" };
    if (o.active && o.active.memberKey !== w.key) throw Error("\u6D3B\u8DC3\u4F1A\u8BDD\u4E0E\u56FA\u5B9A\u6210\u5458\u4E0D\u7B26");
    if (!await F(f, i)) {
      const d = new URL(await f("url"));
      (d.origin !== "https://www.zhipin.com" || d.pathname !== "/web/geek/chat") && await f("navigate", void 0, "https://www.zhipin.com/web/geek/chat"), await N(f, i);
    }
    const m = ".chat-conversation .user-info", p = String(await f("read", m)).trim(), g = ".chat-position-content", B = String(await f("read", g)).trim(), D = B.split(/\r?\n/u)[0], S = await y(f);
    if (!D || !p) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u7684\u62DB\u8058\u8005\u6216\u804C\u4F4D\u4E0A\u4E0B\u6587\u7F3A\u5931");
    if (/校招|校园|应届/u.test(D)) return { ...a, member: w, ready: false, status: "campus-no-reply", reason: "\u804A\u5929\u4E2D\u660E\u786E\u6821\u62DB\uFF0C\u7EE7\u7EED\u6392\u9664" };
    if (o.active?.firstMessageId && o.active.firstMessageId !== S[0].mid) throw Error("\u91CD\u5F00\u540E\u7684\u4F1A\u8BDD\u539F\u59CB\u6D88\u606F\u94FE\u5DF2\u53D8\u5316\uFF0C\u672A\u8986\u76D6\u65E7\u8FDB\u5EA6");
    o = await b(n, r, i, (d) => {
      if (d.active && d.active.memberKey !== w.key) throw Error("\u6D3B\u8DC3\u6210\u5458\u53D8\u5316");
      return d.active = { ...d.active, memberKey: w.key, identityLine: w.identityLine, recipientName: p.split(/\r?\n/u)[0], contextId: i.contextId, openedAt: d.active?.openedAt || (/* @__PURE__ */ new Date()).toISOString(), firstMessageId: S[0].mid }, d;
    });
    const k = "https://www.zhipin.com/web/geek/chat", M = "chat-" + S[0].mid, R = await y(f), U = R.filter((d) => d.direction !== "system" && d.text), v = U.at(-1), Y = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", Q = i.accountSource.account.accountName, K = { ...a, ownedConversation: U[0]?.direction === "outgoing", member: w, jobId: M, jobSource: k, jobTitle: D, chatJobTitle: B, jobSelector: g, recipientSelector: m, recipientLabel: p, accountSelector: Y, accountLabel: Q, conversationKey: "boss-chat:" + R[0].mid, rows: R };
    if (U[0]?.direction === "incoming") return { ...K, ready: false, status: "inbound-first-no-reply", reason: "\u53EF\u89C1\u4F1A\u8BDD\u7531\u5BF9\u65B9\u53D1\u8D77\uFF0C\u6309\u672C\u4EBA\u89C4\u5219\u8DF3\u8FC7" };
    if (!v || v.direction !== "incoming") return { ...K, ready: false, status: "already-replied-or-system-only", reason: "\u6CA1\u6709\u5C1A\u672A\u56DE\u590D\u7684\u771F\u4EBA\u6587\u5B57\u6765\u4FE1\uFF1B\u7CFB\u7EDF\u5361\u7247\u4E0D\u89E6\u53D1\u56DE\u590D" };
    if (/背景不完全相符|需要其他资质|不太符合|不太?合适|不[是太]*特别契合|不[完全]*符合|不[完全]*匹配|后续有机会再合作|未能通过|暂不考虑/u.test(v.text) && !/[?？]|(?:是否|有没有|会不会|能否|请问|什么时候|多少|怎么|哪些)/u.test(v.text)) return { ...K, ready: false, status: "rejected-no-reply", incomingMessageId: v.mid, reason: "\u5BF9\u65B9\u660E\u786E\u8868\u793A\u4E0D\u5408\u9002\uFF0C\u6309\u672C\u4EBA\u6700\u65B0\u8981\u6C42\u4E0D\u56DE\u590D\uFF1B\u4FDD\u7559\u6240\u6709\u539F\u5916\u53D1\u610F\u56FE" };
    const z = I("sha256").update(["boss-text-reply-v1", i.accountKey, v.mid].join(":")).digest("hex"), P = await n.state.get(), L = await _(n, r, i.accountKey, i.contextId);
    if (L.merge(P), await L.save(), P.replyIntents.some((d) => d.accountKey === i.accountKey && d.incomingMessageId === v.mid && ["reserved", "unknown", "failed"].includes(d.status)) || L.data.records.some((d) => d.type === "reply" && d.businessKey === z && d.sightings.some((T) => ["reserved", "unknown", "failed"].includes(T.status)))) {
      const d = "\u539F\u6765\u4FE1\u5DF2\u6709\u9884\u7559\u3001\u672A\u77E5\u6216\u5931\u8D25\u8BB0\u5F55\uFF0C\u4FDD\u7559\u5F85\u529E\u5E76\u7981\u6B62\u91CD\u53D1";
      return await n.attention({ key: "reply-existing-uncertain:" + i.accountKey + ":" + v.mid, title: "\u539F\u56DE\u590D\u7ED3\u679C\u5F85\u6838\u5BF9\uFF0C\u8BF7\u52FF\u91CD\u53D1", detail: { contact: w.identityLine, jobSource: k, incomingMessageId: v.mid, reason: d, externalAction: false } }), { ...K, ready: false, status: "existing-uncertain-reply", decision: "review", replyPolicyVersion: "work-questions-partial-known-v2", incomingMessageId: v.mid, key: z, reason: d };
    }
    if (P.replyIntents.some((d) => d.accountKey === i.accountKey && d.incomingMessageId === v.mid) || L.blocked("reply", z)) return { ...K, ready: false, status: "existing-reply-intent", incomingMessageId: v.mid, reason: "\u8BE5\u539F\u6765\u4FE1\u5DF2\u6709\u5916\u53D1\u610F\u56FE\uFF0C\u9884\u7559\u3001\u672A\u77E5\u53CA\u786E\u8BA4\u5747\u7981\u6B62\u91CD\u653E" };
    if ((P.conversationControls || []).some((d) => d.accountKey === i.accountKey && [K.conversationKey, "boss-chat:" + R[0].mid].includes(d.conversationKey) && d.mode === "paused")) return { ...K, ready: false, status: "manual-control", reason: "\u672C\u4EBA\u5DF2\u63A5\u7BA1\u672C\u4F1A\u8BDD\uFF0C\u81EA\u52A8\u56DE\u590D\u8DF3\u8FC7" };
    const W = new Intl.DateTimeFormat("sv-SE", { timeZone: i.configuration.replyTimeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
    if (new Set(L.data.records.filter((d) => d.type === "reply" && d.sightings.some((T) => T.day === W && T.timeZone === i.configuration.replyTimeZone && T.status !== "failed")).map((d) => d.businessKey)).size >= i.configuration.replyDailyLimit) throw Error("\u5DF2\u4FDD\u5B58\u7684\u672C\u4EBA\u56DE\u590D\u989D\u5EA6\u5DF2\u6EE1\uFF0C\u4FDD\u7559\u672A\u5B8C\u6210\u6536\u5C3E");
    const H = { ...K, ready: true, key: z, incomingMessageId: v.mid, incomingMessage: v.text, pendingMessages: U.slice(U.map((d) => d.direction).lastIndexOf("outgoing") + 1).filter((d) => d.direction === "incoming"), sourceSha256: I("sha256").update(JSON.stringify({ rows: R, jobSource: k, accountLabel: Q })).digest("hex"), day: W, timeZone: i.configuration.replyTimeZone };
    if (!await A(n, r, H)) throw Error("\u5B8C\u6574\u6765\u6E90\u4FDD\u5B58\u524D\u4F1A\u8BDD\u5DF2\u53D8\u5316");
    return await c("fixed-unread-reply-source.json", JSON.stringify(H, null, 2)), H;
  };
  async function C(t) {
    let n = false;
    try {
      return await E({ ...t, onAccountVerified: () => {
        n = true;
      } });
    } catch (r) {
      const c = String(r.message || r), e = t.input?.cohort, i = /关联职位返回后的完整消息或对象变化|完整岗位标题缺失或截断|固定姓名搜索未取得唯一的姓名、公司和角色组合|固定成员缺少可核对的定向搜索姓名，未猜测|未读会话的实际职位链接未核对|关联职位没有可核对的继续沟通入口|固定成员当前列表|固定成员缺少唯一可见身份|固定成员可见身份|固定会话返回|关联职位完整标题与固定会话不符/u.test(c), u = n && !/账号|安全索引|账本|摘要|配置|状态|进度|Skill|预留/u.test(c) && /固定成员|固定会话|关联职位|网页操作超时|元素|目标不可见|点击目标|点击期间|\(-3\) loading/u.test(c);
      if (!(i || u) || e?.kind !== "unread-closing-cohort" || !e.member?.key) throw r;
      return await t.template.attention({ key: "fixed-member-source-review:" + e.accountKey + ":" + e.member.key, title: "\u8BE5\u672A\u8BFB\u4F1A\u8BDD\u6765\u6E90\u5F85\u6838\u5BF9\uFF0C\u672A\u6267\u884C\u5916\u53D1", detail: { contact: e.member.identityLine, fixedUnreadSetSha256: e.fixedUnreadSetSha256, memberKey: e.member.key, reason: c, externalAction: false } }), { ...e, sourceReviewVersion: "chat-list-direct-v5", kind: "chat-reply-source", fixedUnreadMember: true, profile: t.input.profile, ready: false, jobId: null, jobSource: null, status: "member-needs-review", decision: "review", replyPolicyVersion: "work-questions-partial-known-v2", reason: c };
    }
  }
  return C;
})(), et = /* @__PURE__ */ (() => {
  const x = (s) => Array.isArray(s) ? s.map(x) : s && typeof s == "object" ? Object.fromEntries(Object.keys(s).sort().map((h) => [h, x(s[h])])) : s, N = (s) => X("sha256").update(JSON.stringify(x(s))).digest("hex"), G = (s) => X("sha256").update(s).digest("hex"), $ = (s, h) => (b, y, F) => (h.throwIfAborted(), s.browser("browser", { operation: b, ...y ? { selector: y } : {}, ...F === void 0 ? {} : { value: F }, timeoutMs: 3e3 }));
  async function q(s, h, b, y, F = null) {
    let A = null;
    try {
      A = await s.file("communication-cache", { operation: "read", name: h });
    } catch (C) {
      if (!String(C.message || C).includes("ENOENT")) throw C;
    }
    const E = A === null ? F : JSON.parse(A);
    if (!E) throw Error("\u7F3A\u5C11\u6062\u590D\u6765\u6E90 " + h);
    if (A !== null) {
      const { sha256: C, ...t } = E;
      if (C !== N(t)) throw Error("\u6062\u590D\u6765\u6E90\u6458\u8981\u4E0D\u7B26 " + h);
    }
    if (E.kind !== b || E.accountKey !== y) throw Error("\u6062\u590D\u6765\u6E90\u8D26\u53F7\u6216\u7C7B\u578B\u4E0D\u7B26");
    return { name: h, raw: A, value: E };
  }
  async function Z(s, h) {
    let b = null;
    try {
      b = await s.file("communication-cache", { operation: "read", name: h.name });
    } catch (A) {
      if (!String(A.message || A).includes("ENOENT")) throw A;
    }
    if (b !== h.raw) throw Error("\u6062\u590D\u8BB0\u5F55\u5E76\u53D1\u53D8\u5316");
    const y = h.value;
    y.revision++, y.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete y.sha256, y.sha256 = N(y);
    const F = JSON.stringify(y);
    if (await s.file("communication-cache", { operation: "write", name: h.name, content: F }), await s.file("communication-cache", { operation: "read", name: h.name }) !== F) throw Error("\u6062\u590D\u8BB0\u5F55\u672A\u51C6\u786E\u8BFB\u56DE");
    h.raw = F;
  }
  async function J(s, h) {
    return q(s, "unknown-chat-reviews-v1-" + h + ".json", "boss-unknown-chat-reviews", h, { version: 1, kind: "boss-unknown-chat-reviews", accountKey: h, revision: 0, reviews: [] });
  }
  async function V(s) {
    const h = await s("count", "li.message-item");
    if (!Number.isSafeInteger(h) || h < 1 || h > 150) throw Error("\u4F1A\u8BDD\u53EF\u89C1\u6D88\u606F\u8303\u56F4\u65E0\u6548");
    const b = [];
    for (let y = 1; y <= h; y++) {
      const F = "li.message-item:nth-child(" + y + " of li.message-item)", A = await s("attribute", F, "data-mid"), E = String(await s("attribute", F, "class") || "");
      if (!/^\d{6,40}$/u.test(A || "")) throw Error("\u7F3A\u5C11\u771F\u5B9E\u670D\u52A1\u5668\u6D88\u606F\u7F16\u53F7");
      const C = await s("count", F + " .text-content");
      if (C > 1) throw Error("\u5355\u6761\u6B63\u6587\u4E0D\u552F\u4E00");
      const t = C === 1 ? String(await s("read", F + " .text-content")).trim() : null, n = C === 1 ? null : String(await s("read", F)).trim(), r = !!t && /^您正在与Boss.+沟通$/u.test(t), c = !r && t !== null && E.split(/\s/u).includes("item-myself") ? "outgoing" : !r && t !== null && E.split(/\s/u).includes("item-friend") ? "incoming" : "system", e = F + " > div > div > i", i = await s("count", e) === 1 ? String(await s("read", e)).trim() : null;
      b.push({ mid: A, direction: c, text: t, context: n, receipt: i });
    }
    if (new Set(b.map((y) => y.mid)).size !== b.length) throw Error("\u670D\u52A1\u5668\u6D88\u606F\u7F16\u53F7\u91CD\u590D");
    return b;
  }
  async function j(s, h, b = true) {
    const y = new URL(await s("url"));
    if (y.origin !== "https://www.zhipin.com" || y.pathname !== "/web/geek/chat" || String(await s("read", h.accountSelector)).trim() !== h.accountLabel || await s("count", 'li.message-item[data-mid="' + h.member.originalIncomingMid + '"]') !== 1 || await s("count", 'li.message-item[data-mid="' + h.member.firstMessageId + '"]') !== 1) throw Error("\u672A\u77E5\u6062\u590D\u7684\u8D26\u53F7\u6216\u539F\u6D88\u606F\u94FE\u53D8\u5316");
    if (b && N(await V(s)) !== h.messagesHash) throw Error("AI\u5224\u65AD\u671F\u95F4\u804A\u5929\u5185\u5BB9\u53D8\u5316\uFF0C\u672A\u5916\u53D1");
  }
  async function O(s, h) {
    const b = 'li.message-item[data-mid="' + h.originalIncomingMid + '"]';
    if (await s("count", b) === 1) return;
    if (h.lookupQuery && h.recipientName) {
      const n = ".list-warp.v2 input";
      if (await s("count", n) !== 1) throw Error("\u8054\u7CFB\u4EBA\u641C\u7D22\u5165\u53E3\u4E0D\u552F\u4E00");
      await s("click", n), await s("fill", n, h.lookupQuery), await new Promise((u) => setTimeout(u, 600));
      const r = ".boss-search-result .search-list";
      let c = 0;
      for (let u = 0; u < 30 && (c = await s("count", r), !(c > 0)); u++) await new Promise((a) => setTimeout(a, 150));
      if (c < 1 || c > 50) throw Error("\u672A\u627E\u5230\u539Funknown\u8054\u7CFB\u4EBA");
      const e = [];
      for (let u = 1; u <= c; u++) {
        const a = [r + ":nth-child(" + u + " of .search-list)"];
        let l = 0;
        for (; a.length; ) {
          const f = a.shift();
          if (++l > 150) throw Error("\u59D3\u540D\u63A7\u4EF6\u8303\u56F4\u8FC7\u5927");
          const w = String(await s("read", f)).trim(), o = await s("count", f + " > *");
          if (w === h.recipientName && e.push({ selector: f, text: w }), o > 0 && o < 30) for (let m = 1; m <= o; m++) a.push(f + " > :nth-child(" + m + ")");
        }
      }
      const i = e.filter((u) => !e.some((a) => a !== u && a.selector.startsWith(u.selector + " > ")));
      if (i.length < 1 || i.length > 8) throw Error("\u539Funknown\u59D3\u540D\u5019\u9009\u8303\u56F4\u4E0D\u660E\u786E");
      for (const u of i) {
        if (String(await s("read", u.selector)).trim() !== u.text) throw Error("\u641C\u7D22\u7ED3\u679C\u53D8\u5316");
        await s("click", u.selector);
        for (let a = 0; a < 16; a++) {
          if (await s("count", b) === 1) return;
          await new Promise((l) => setTimeout(l, 100));
        }
        i.length > 1 && (await s("click", n), await s("fill", n, h.lookupQuery), await new Promise((a) => setTimeout(a, 600)));
      }
      throw Error("\u59D3\u540D\u5019\u9009\u4E2D\u672A\u8BFB\u56DE\u539Funknown\u6D88\u606F\u94FE");
    }
    const y = ".list-warp.v2 input";
    await s("count", y) === 1 && (await s("click", y), await s("fill", y, ""));
    const F = ".list-warp.v2 ul:has(> .selected)", A = F + " > :first-child";
    if (await s("count", A) !== 1 || String(await s("read", A)).trim() !== "\u5168\u90E8") throw Error("\u65E0\u6CD5\u8BFB\u53D6\u65E2\u6709\u4F1A\u8BDD\u5217\u8868");
    await s("click", A);
    const E = ".user-list-content > :first-child", C = /* @__PURE__ */ new Set();
    let t = 0;
    for (let n = 0; n < 20; n++) {
      const r = await s("count", E + " > *");
      if (r < 1 || r > 500) throw Error("\u65E2\u6709\u4F1A\u8BDD\u5217\u8868\u8303\u56F4\u65E0\u6548");
      let c = 0;
      for (let e = 1; e <= r; e++) {
        const i = E + " > :nth-child(" + e + ")", u = i + " .friend-content";
        if (await s("count", u) !== 1) continue;
        const a = String(await s("read", u)).trim();
        if (!(!a || C.has(a))) {
          if (C.add(a), c++, await s("click", u), await new Promise((l) => setTimeout(l, 250)), await s("count", b) === 1) return;
          if (C.size >= 200) throw Error("\u5DF2\u8BFB\u53D6200\u4E2A\u65E2\u6709\u4F1A\u8BDD\uFF0C\u539F\u6D88\u606F\u4ECD\u672A\u627E\u5230");
        }
      }
      if (t = c ? 0 : t + 1, t >= 2) break;
      await new Promise((e) => setTimeout(e, 250));
    }
    throw Error("\u65E2\u6709\u4F1A\u8BDD\u8303\u56F4\u5185\u6CA1\u6709\u539F\u670D\u52A1\u5668\u6D88\u606F\uFF0C\u4E0D\u731C\u6D4B\u6536\u4EF6\u4EBA");
  }
  return async function({ input: s, template: h, signal: b, artifact: y }) {
    const F = s.cohort, A = s.profile;
    if (!F?.unknownRecovery || !F.member || !A?.ref?.versionId || !A.markdown) throw Error("\u7F3A\u5C11unknown\u961F\u5217\u6216\u786E\u8BA4Skill");
    const E = $(h, b), C = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)";
    if (String(await E("read", C)).trim() !== F.accountSource.account.accountName) throw Error("\u5F53\u524D\u8D26\u53F7\u53D8\u5316");
    try {
      await O(E, F.member);
    } catch (p) {
      return { ...F, profile: A, kind: "unknown-chat-review-source", ready: false, sourceIssue: String(p.message || p), rows: [], messagesHash: N([]) };
    }
    if (!F.member.firstMessageId) {
      const p = await V(E);
      F.member = { ...F.member, firstMessageId: p[0]?.mid };
    }
    const t = await V(E), n = t.findIndex((p) => p.mid === F.member.originalIncomingMid);
    if (n < 0) throw Error("\u7F3A\u5C11\u539Funknown\u6765\u4FE1");
    const r = t.filter((p) => p.direction !== "system" && p.text), c = r.at(-1), e = String(await E("read", ".chat-conversation .user-info")).trim(), i = await E("count", ".chat-position-content") === 1 ? String(await E("read", ".chat-position-content")).trim() : "", u = t.slice(n + 1).filter((p) => /您的附件简历[\s\S]*已发送给Boss/u.test(p.text || p.context || "")), a = 'li.message-item[data-mid="' + F.member.originalIncomingMid + '"]', l = a + " .message-dialog-both .card-btn:nth-child(2)", f = a + " .message-dialog-both .card-btn:nth-child(1)", w = F.member.parentKind === "resume" && await E("count", l) === 1 && await E("count", f) === 1 && String(await E("read", l)).trim() === "\u540C\u610F" && String(await E("read", f)).trim() === "\u62D2\u7EDD", o = F.member.originalApprovedText ? t.slice(n + 1).filter((p) => p.direction === "outgoing" && p.text?.replace(/\s/gu, "") === F.member.originalApprovedText.replace(/\s/gu, "")) : [], m = { ...F, kind: "unknown-chat-review-source", ready: true, profile: A, rows: t, messagesHash: N(t), accountSelector: C, accountLabel: F.accountSource.account.accountName, recipientLabel: e, jobContext: i, firstMessageId: F.member.firstMessageId, latestIncomingMid: c?.direction === "incoming" ? c.mid : null, lastRealDirection: c?.direction || null, priorExactOutgoing: o, attachmentReceiptRows: u, nativePending: w, nativeAgreeSelector: l, nativeRequestRoot: a, nativeRequestText: String(await E("read", a)).trim(), nativeResumeEligible: w && u.length === 0 && F.member.historicalVerification?.state !== "confirmed", campus: /校招|校园|应届/u.test(i), initiatedByUs: r[0]?.direction === "outgoing", confirmedSupplementalFacts: String(F.configuration.confirmedPersonalFacts || "") };
    return await j(E, m), await y("unknown-chat-source-" + F.member.key.split(":")[1] + ".json", JSON.stringify(m)), m;
  };
})();
async function rt(x) {
  return x.input?.cohort?.unknownRecovery ? et(x) : tt(x);
}
export {
  rt as default
};
