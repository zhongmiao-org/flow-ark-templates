import { createHash as oe } from "node:crypto";
const me = /* @__PURE__ */ (() => {
  function V(E) {
    return E.status === "review" && !E.operationKey && !E.modelRequestId && E.sourceReviewVersion !== "chat-list-direct-v5" && /关联职位没有可核对的继续沟通入口|固定成员缺少可核对的定向搜索姓名，未猜测|固定成员缺少唯一可见身份|关联职位返回后的完整消息或对象变化/u.test(String(E.reason || ""));
  }
  async function M(E, A, I) {
    const { accountKey: F, contextId: u, day: t, timeZone: c, revision: s, configuration: e } = I, i = e.acceptanceNewGreetings ?? 0;
    if (i !== 0 && i !== 2) throw Error("\u9A8C\u6536\u65B0\u62DB\u547C\u6570\u53EA\u80FD\u4E3A0\uFF08\u6B63\u5F0F\u6A21\u5F0F\uFF09\u62162");
    if (!i) return null;
    A.throwIfAborted();
    const o = (f) => Array.isArray(f) ? f.map(o) : f && typeof f == "object" ? Object.fromEntries(Object.keys(f).sort().map((r) => [r, o(f[r])])) : f, d = (f) => q("sha256").update(JSON.stringify(o(f))).digest("hex"), l = (f) => {
      const { sha256: r, ...N } = f;
      if (r !== d(N)) throw Error("\u9A8C\u6536\u6765\u6E90\u6458\u8981\u4E0D\u7B26\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55");
      return f;
    }, h = l(JSON.parse(await E.file("communication-cache", { operation: "read", name: "account-outbound-safety-v1-" + F + ".json" })));
    if (h.kind !== "boss-account-outbound-safety" || h.accountKey !== F || !Array.isArray(h.records)) throw Error("\u9A8C\u6536\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u4E0D\u7B26");
    const m = new Intl.DateTimeFormat("sv-SE", { timeZone: c, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
    if (t !== m) throw Error("\u9A8C\u6536\u8DE8\u65E5\uFF0C\u505C\u6B62\u65B0\u589E");
    const a = h.records.filter((f) => f.type === "first-contact" && f.sightings.some((r) => r.day === t && r.timeZone === c)), D = a.map((f) => f.businessKey);
    if (new Set(D).size !== D.length) throw Error("\u9A8C\u6536\u5360\u989D\u952E\u91CD\u590D");
    const v = { accountKey: F, contextId: u, day: t, timeZone: c, revision: s, target: i }, b = "test-greeting-baseline-v1-" + F + "-" + d(v).slice(0, 24) + ".json";
    let p = null;
    try {
      p = await E.file("communication-cache", { operation: "read", name: b });
    } catch (f) {
      if (!String(f.message || f).includes("ENOENT")) throw f;
    }
    let B;
    if (p === null) {
      if (e.firstContactDailyBudget !== D.length + i) throw Error("\u6D4B\u8BD5\u9884\u7B97\u5FC5\u987B\u7B49\u4E8E\u672C\u65E5\u5DF2\u6709\u5360\u989D\u52A02\uFF0C\u7981\u6B62\u6269\u5927\u6216\u91CD\u7F6E\u672C\u8F6E");
      if (B = { version: 1, kind: "boss-test-greeting-baseline", identity: v, keys: D.slice().sort(), budget: e.firstContactDailyBudget, indexSha256: h.sha256, createdAt: (/* @__PURE__ */ new Date()).toISOString() }, B.sha256 = d(B), await E.file("communication-cache", { operation: "write", name: b, content: JSON.stringify(B) }), p = await E.file("communication-cache", { operation: "read", name: b }), JSON.stringify(l(JSON.parse(p))) !== JSON.stringify(B)) throw Error("\u6D4B\u8BD5\u57FA\u7EBF\u672A\u51C6\u786E\u8BFB\u56DE");
    } else B = l(JSON.parse(p));
    if (d(B.identity) !== d(v) || B.budget !== e.firstContactDailyBudget || !Array.isArray(B.keys) || B.keys.some((f) => !D.includes(f))) throw Error("\u6D4B\u8BD5\u57FA\u7EBF\u6216\u9884\u7B97\u53D8\u5316\uFF0C\u505C\u6B62\u4E14\u4FDD\u7559\u5386\u53F2");
    const y = a.filter((f) => !B.keys.includes(f.businessKey));
    if (y.length > i) throw Error("\u6D4B\u8BD5\u5360\u989D\u8D85\u51FA\u4E24\u6B21\uFF0C\u505C\u6B62");
    for (const f of y) if (f.sightings.some((r) => r.day === t && r.timeZone === c && (r.contextId !== u || r.status === "unknown" || r.status === "failed"))) throw Error("\u6D4B\u8BD5\u65B0\u589E\u6765\u6E90\u51B2\u7A81\u6216\u7ED3\u679C\u672A\u77E5\uFF0C\u7981\u6B62\u8865\u53D1");
    const C = y.filter((f) => f.sightings.some((r) => r.day === t && r.timeZone === c && r.contextId === u && r.status === "confirmed"));
    return { version: 1, kind: "boss-test-new-greeting-completion", ...v, baselineName: b, baselineSha256: B.sha256, newOccupied: y.length, newConfirmed: C.length, confirmedKeys: C.map((f) => f.businessKey).sort(), confirmed: C.length === i, siteDailyLimitConfirmed: false, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  const _ = /* @__PURE__ */ (() => {
    var E = async ({ input: A, signal: I }) => {
      I.throwIfAborted();
      const F = A, u = F?.value;
      if (!F || F.version !== 1 || F.operation !== "read" || F.binding !== "account-source-result" || F.schemaValidation !== "passed" || F.dataChanged !== false || F.ref?.version !== 1 || F.ref.policy !== "credential-redacted-v1" || F.ref.source?.entryId !== "account-source") throw new Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u5DF2\u9009\u62E9\u4E14\u5B8C\u6574\u53EF\u590D\u7528\u7684\u8D26\u53F7\u6765\u6E90\uFF0C\u8BF7\u5230\u8D44\u6E90\u9875\u91CD\u65B0\u6838\u5BF9\u5E76\u4FDD\u5B58");
      if (!u || u.version !== 1 || u.kind !== "boss-account-source" || u.status !== "account-source-confirmed" || u.accountVerified !== true || u.platformUniqueIdVerified !== false || u.eligibleForActions !== false || u.role !== "jobseeker") throw new Error("\u6240\u9009\u8BB0\u5F55\u5C1A\u672A\u5B8C\u6210\u672C\u4EBA\u786E\u8BA4\u548C\u6765\u6E90\u590D\u9A8C\uFF1B\u8BF7\u5728\u5F53\u524D\u5B9E\u4F8B\u5B8C\u6210\u8D26\u53F7\u6838\u5BF9\uFF0C\u518D\u9009\u62E9\u8BE5\u6B21\u5DF2\u4FDD\u5B58\u7ED3\u679C");
      const t = ["version", "kind", "status", "accountAlias", "accountName", "phoneMask", "jobseekerResumeHref", "role", "sourceUrl", "accountVerified", "platformUniqueIdVerified", "eligibleForActions", "confirmedAt", "checkedAt", "reason"];
      if (Object.keys(u).length !== t.length || t.some((o) => !Object.prototype.hasOwnProperty.call(u, o))) throw new Error("\u6240\u9009\u8D26\u53F7\u7ED3\u679C\u7ED3\u6784\u4E0D\u7B26\uFF0C\u505C\u6B62\u91C7\u7528");
      for (const o of ["accountAlias", "accountName", "phoneMask"]) if (typeof u[o] != "string" || !u[o].trim() || u[o] !== u[o].trim() || u[o].length > 100 || /[\r\n]/.test(u[o])) throw new Error("\u8D26\u53F7\u5FC5\u8981\u5B57\u6BB5\u7F3A\u5931\u6216\u683C\u5F0F\u65E0\u6548\uFF0C\u505C\u6B62\u91C7\u7528");
      if (!/^[+\d ()-]*\*{2,}[\d ()-]+$/.test(u.phoneMask) || /登录|注册|验证码/.test(u.accountName)) throw new Error("\u8D26\u53F7\u6765\u6E90\u7F3A\u5C11\u6709\u6548\u7684\u53EF\u89C1\u59D3\u540D\u6216\u624B\u673A\u53F7\u63A9\u7801");
      if (typeof u.reason != "string" || !u.reason.trim()) throw new Error("\u8D26\u53F7\u7ED3\u679C\u7F3A\u5C11\u660E\u786E\u6838\u5BF9\u8BF4\u660E");
      const c = Date.parse(u.confirmedAt), s = Date.parse(u.checkedAt);
      if (typeof u.confirmedAt != "string" || typeof u.checkedAt != "string" || !Number.isFinite(c) || !Number.isFinite(s) || c <= 0 || s < c || s > Date.now() + 6e4) throw new Error("\u8D26\u53F7\u786E\u8BA4\u6216\u590D\u9A8C\u65F6\u95F4\u65E0\u6CD5\u6838\u5BF9\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4");
      if (typeof u.sourceUrl != "string" || typeof u.jobseekerResumeHref != "string" || !u.sourceUrl.trim() || !u.jobseekerResumeHref.trim() || u.sourceUrl.length > 16384 || u.jobseekerResumeHref.length > 16384) throw new Error("\u8D26\u53F7\u9875\u9762\u6216\u7B80\u5386\u5165\u53E3\u5730\u5740\u65E0\u6548");
      const e = new URL(u.sourceUrl), i = new URL(u.jobseekerResumeHref, u.sourceUrl);
      if (e.origin !== "https://www.zhipin.com" || e.pathname !== "/web/geek/account" || e.searchParams.get("type") !== "accountSet" || e.username || e.password || e.hash || i.origin !== e.origin || i.pathname !== "/web/geek/resume" || i.username || i.password) throw new Error("\u8D26\u53F7\u8BB0\u5F55\u7684\u9875\u9762\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u4E0D\u7B26");
      return I.throwIfAborted(), { version: 1, accountSourceValid: true, currentAccountVerified: false, account: u };
    };
    return E;
  })(), W = /* @__PURE__ */ (() => {
    async function E({ input: A, signal: I, template: F }) {
      I.throwIfAborted();
      const u = A?.expected?.account;
      if (A?.expected?.accountSourceValid !== true || u?.kind !== "boss-account-source" || u.status !== "account-source-confirmed" || u.accountVerified !== true) throw Error("\u7F3A\u5C11\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\u6765\u6E90");
      const t = async (m, a, D) => {
        I.throwIfAborted();
        const v = await F.browser("browser", { operation: m, ...a ? { selector: a } : {}, ...D === void 0 ? {} : { value: D }, timeoutMs: 3e3 });
        return I.throwIfAborted(), v;
      };
      let c = await t("url");
      if (c === "about:blank") {
        await t("navigate", void 0, u.sourceUrl);
        for (let m = 0; m < 40; m++) {
          const a = await t("url");
          if (new URL(a).origin === "https://www.zhipin.com" && await t("count", "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)") === 1) break;
          await new Promise((D) => setTimeout(D, 150));
        }
        c = await t("url");
      }
      const s = new URL(c);
      if (s.origin !== "https://www.zhipin.com" || s.username || s.password || !s.pathname.startsWith("/web/") && !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(s.pathname)) throw Error("\u5F53\u524D\u9875\u9762\u4E0D\u662FBOSS\u6C42\u804C\u9875\u9762\uFF0C\u8BF7\u5148\u767B\u5F55");
      const e = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", i = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)", o = await t("count", e), d = await t("count", i);
      if (o !== 1 || d !== 1) throw Error("\u5F53\u524D\u9875\u9762\u8D26\u53F7\u5165\u53E3\u6570\u91CF\u5F02\u5E38\uFF1A" + JSON.stringify({ nameCount: o, resumeCount: d }));
      const l = await t("read", e), h = await t("attribute", i, "href");
      if (typeof l != "string" || l.normalize("NFKC").trim() !== u.accountName.normalize("NFKC").trim() || typeof h != "string" || new URL(h, c).href !== new URL(u.jobseekerResumeHref, u.sourceUrl).href || await t("url") !== c) throw Error("\u5F53\u524D\u767B\u5F55\u8EAB\u4EFD\u3001\u6C42\u804C\u5165\u53E3\u6216\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
      return { version: 1, status: "current-account-source-matched", accountAlias: u.accountAlias, accountName: u.accountName, phoneMask: u.phoneMask, jobseekerResumeHref: u.jobseekerResumeHref, sourceUrl: u.sourceUrl, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), currentPageUrl: c, currentAccountVerified: true, platformUniqueIdVerified: false, eligibleForActions: false, accountCheckMode: "confirmed-initial-account-and-visible-header", phoneMaskRechecked: false, reason: "\u4F7F\u7528\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\uFF1B\u53EA\u8BFB\u6838\u5BF9\u5F53\u524D\u767B\u5F55\u59D3\u540D\u3001\u6C42\u804C\u5165\u53E3\u53CA\u9875\u9762\u8FDE\u7EED\u6027\uFF0C\u624B\u673A\u53F7\u63A9\u7801\u6CBF\u7528\u786E\u8BA4\u6765\u6E90\uFF0C\u6CA1\u6709\u91CD\u65B0\u8BFB\u53D6\u3002" };
    }
    return E;
  })(), J = (E) => Array.isArray(E) ? E.map(J) : E && typeof E == "object" ? Object.fromEntries(Object.keys(E).sort().map((A) => [A, J(E[A])])) : E, O = (E) => q("sha256").update(JSON.stringify(J(E))).digest("hex");
  async function Q({ input: E, template: A, signal: I, artifact: F }, u) {
    const t = E.configuration, c = await _({ input: E.account, signal: I });
    await W({ input: { expected: c }, template: A, signal: I });
    const s = async (y) => {
      const C = JSON.parse(await A.file("communication-cache", { operation: "read", name: y })), { sha256: f, ...r } = C;
      if (f !== O(r)) throw Error("\u539F\u6062\u590D\u8BC1\u636E\u6458\u8981\u4E0D\u7B26");
      return C;
    };
    if (!/^test-greeting-completion-v1-[a-f0-9]{64}-[a-f0-9]{24}\.json$/u.test(u)) throw Error("\u6062\u590D\u6765\u6E90\u6587\u4EF6\u540D\u65E0\u6548");
    const e = await s(u), i = new URL(c.account.jobseekerResumeHref, c.account.sourceUrl), o = q("sha256").update(JSON.stringify(["boss-visible-account-source-v1", c.account.accountName, c.account.phoneMask, i.origin + i.pathname])).digest("hex");
    if (e.accountKey !== o || e.contextId !== t.contextId || e.kind !== "boss-test-new-greeting-completion" || e.confirmed !== true || e.newConfirmed !== 2) throw Error("\u6062\u590D\u8D26\u53F7\u3001\u5B9E\u4F8B\u6216\u539F\u4E24\u6B21\u56DE\u6267\u4E0D\u7B26");
    const d = u.match(/-([a-f0-9]{24})\.json$/u)[1], l = "test-fixed-unread-set-v1-" + d + "-" + o + "-" + e.day + ".json", h = "test-fixed-unread-progress-v1-" + d + "-" + o + "-" + e.day + ".json", m = await s(l), a = await s(h);
    if (m.sha256 !== a.fixedUnreadSetSha256 || m.siteDailyLimitEvidenceSha256 !== e.sha256 || m.accountKey !== o || a.accountKey !== o || m.sourceContextId !== t.contextId) throw Error("\u56FA\u5B9A\u6210\u5458\u3001\u8FDB\u5EA6\u6216\u6D3B\u52A8\u64CD\u4F5C\u6765\u6E90\u4E0D\u7B26");
    if (a.active) {
      const y = await A.state.get(), C = a.active, f = y.replyIntents.filter((k) => k.accountKey === o && k.conversationKey === "boss-chat:" + C.firstMessageId && k.status === "unknown");
      if (f.length !== 1) throw Error("\u5B58\u5728\u672A\u6838\u5BF9\u7684\u6D3B\u52A8\u64CD\u4F5C\uFF0C\u4E0D\u81EA\u52A8\u6E05\u9664");
      const r = a.completed.find((k) => k.memberKey === C.memberKey);
      if (!r || r.status !== "review" || r.operationKey) throw Error("\u6D3B\u52A8\u6765\u6E90\u5F85\u529E\u4E0D\u53EF\u66FF\u6362");
      const N = JSON.stringify(a);
      a.reviewHistory = [...a.reviewHistory || [], r], a.completed = a.completed.filter((k) => k.memberKey !== C.memberKey), a.completed.push({ ...r, status: "review", reason: "\u56DE\u8F66\u53D1\u9001\u672A\u53D6\u5F97\u9001\u8FBE\u56DE\u6267\uFF0Cunknown\u7981\u6B62\u91CD\u53D1", operationKey: f[0].key, incomingMessageId: f[0].incomingMessageId, sourceReviewVersion: "chat-list-direct-v5", checkedAt: (/* @__PURE__ */ new Date()).toISOString() }), a.active = null, a.revision++, a.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete a.sha256, a.sha256 = O(a);
      const g = JSON.parse(await A.file("communication-cache", { operation: "read", name: h }));
      if (O(g) !== O(JSON.parse(N))) throw Error("\u4FDD\u5B58\u672A\u77E5\u5F85\u529E\u524D\u8FDB\u5EA6\u53D8\u5316");
      if (await A.file("communication-cache", { operation: "write", name: h, content: JSON.stringify(a) }), (await s(h)).sha256 !== a.sha256) throw Error("\u672A\u77E5\u5F85\u529E\u672A\u8BFB\u56DE");
    }
    let D = false;
    for (const y of [...a.completed]) if (y.status === "review" && !y.operationKey && !y.modelRequestId && y.reason === "\u5173\u8054\u804C\u4F4D\u5B8C\u6574\u6807\u9898\u4E0E\u56FA\u5B9A\u4F1A\u8BDD\u4E0D\u7B26\uFF0C\u672A\u91C7\u7528\u6765\u6E90") {
      a.reviewHistory = [...a.reviewHistory || [], y];
      const C = a.completed.indexOf(y);
      a.completed[C] = { ...y, status: "skipped-job-source-mismatch", reason: "\u6309\u672C\u4EBA\u89C4\u5219\uFF0C\u65E2\u6709\u5C97\u4F4D\u6765\u6E90\u4E0D\u4E00\u81F4\u76F4\u63A5\u8DF3\u8FC7\uFF0C\u4E0D\u67E5\u8BE2\u516C\u53F8\u5C97\u4F4D\u3001\u4E0D\u5916\u53D1", sourceReviewVersion: "chat-list-direct-v5", checkedAt: (/* @__PURE__ */ new Date()).toISOString() }, D = true;
    }
    if (D) {
      if ((await s(h)).sha256 !== a.sha256) throw Error("\u6765\u6E90\u8DF3\u8FC7\u767B\u8BB0\u524D\u8FDB\u5EA6\u53D8\u5316");
      if (a.revision++, a.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete a.sha256, a.sha256 = O(a), await A.file("communication-cache", { operation: "write", name: h, content: JSON.stringify(a) }), (await s(h)).sha256 !== a.sha256) throw Error("\u6765\u6E90\u8DF3\u8FC7\u8FDB\u5EA6\u672A\u8BFB\u56DE");
    }
    const v = a.completed.filter((y) => y.status === "review" && !y.operationKey && !y.modelRequestId && ["\u56FA\u5B9A\u6210\u5458\u7F3A\u5C11\u552F\u4E00\u53EF\u89C1\u8EAB\u4EFD\uFF0C\u672A\u731C\u6D4B\u59D3\u540D", "\u56FA\u5B9A\u6210\u5458\u5B9A\u5411\u641C\u7D22\u7ED3\u679C\u4E0D\u552F\u4E00", "\u56FA\u5B9A\u6210\u5458\u59D3\u540D\u63A7\u4EF6\u4E0D\u552F\u4E00"].includes(y.reason) && y.sourceReviewVersion !== "chat-list-direct-v5"), b = m.members.filter((y) => v.some((C) => C.memberKey === y.key)).map((y) => ({ ...y, identityLine: y.text.split(/\r?\n/u).map((C) => C.trim()).filter(Boolean)[2] })), p = { version: 1, kind: "unread-closing-cohort", restoredExistingClosing: true, closingPhase: true, contextId: t.contextId, accountKey: o, day: e.day, timeZone: e.timeZone, accountSource: c, configuration: t.value, configurationRevision: t.revision, siteDailyLimitEvidence: null, testCompletionEvidence: e, closingTrigger: "two-new-greetings-test", fixedUnreadSetName: l, fixedUnreadSetSha256: m.sha256, progressName: h, progressSha256: a.sha256, progress: a, memberCount: m.members.length, unreadMessageCount: m.unreadMessageCount, newGreeting: false, newMembersAdded: 0, remaining: b.length, ready: b.length > 0, status: "resume-fixed-unread", member: b[0] || null }, B = { ...p, items: b.map((y) => ({ ...p, member: y, ready: true })) };
    return await F("fixed-cohort-recovery-source.json", JSON.stringify({ evidenceName: u, setName: l, progressName: h, memberCount: b.length, originalDay: e.day, newGreeting: false })), B;
  }
  async function X({ input: E, template: A, signal: I }) {
    I.throwIfAborted();
    const F = E?.configuration, u = E?.state;
    if (E?.restoreExistingClosing === true && F?.value?.recoveryEvidenceName) return Q({ input: E, template: A, signal: I, artifact: async () => {
    } }, F.value.recoveryEvidenceName);
    if (F?.operation !== "configuration" || u?.operation !== "state.read" || F.contextId !== u.contextId || !F.value || !u.value) throw Error("\u7F3A\u5C11\u540C\u5B9E\u4F8B\u56FA\u5B9A\u914D\u7F6E\u4E0E\u5B8C\u6574\u72B6\u6001");
    const t = await _({ input: E.account, signal: I });
    await W({ input: { expected: t }, template: A, signal: I });
    const c = t.account, s = new URL(c.jobseekerResumeHref, c.sourceUrl), e = q("sha256").update(JSON.stringify(["boss-visible-account-source-v1", c.accountName, c.phoneMask, s.origin + s.pathname])).digest("hex"), i = (n) => {
      const { sha256: w, ...R } = n;
      return w === O(R);
    }, o = async (n) => {
      try {
        return JSON.parse(await A.file("communication-cache", { operation: "read", name: n }));
      } catch (w) {
        if (String(w.message || w).includes("ENOENT")) return null;
        throw w;
      }
    }, d = async (n, w, R) => {
      if (((await o(n))?.sha256 || null) !== R) throw Error("\u6D88\u606F\u6536\u5C3E\u8BB0\u5F55\u88AB\u5176\u4ED6\u64CD\u4F5C\u66F4\u6539\uFF0C\u672A\u8986\u76D6");
      const x = { ...w };
      delete x.sha256, x.sha256 = O(x), await A.file("communication-cache", { operation: "write", name: n, content: JSON.stringify(x) });
      const H = await o(n);
      if (!i(H) || H.sha256 !== x.sha256) throw Error("\u6D88\u606F\u6536\u5C3E\u8BB0\u5F55\u5199\u5165\u540E\u672A\u5B8C\u6574\u8BFB\u56DE");
      return H;
    }, l = F.value.replyTimeZone, h = new Intl.DateTimeFormat("sv-SE", { timeZone: l, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date()), m = F.value.acceptanceNewGreetings === 2;
    if (m && E?.restoreExistingClosing === true) throw Error("\u4E24\u6B21\u65B0\u62DB\u547C\u6D4B\u8BD5\u4E0D\u5F97\u4F7F\u7528\u65E7\u6536\u5C3E\u6062\u590D\u5F00\u5173");
    const a = m ? O({ contextId: F.contextId, revision: F.revision, day: h, timeZone: l }).slice(0, 24) : null, D = await M(A, I, { accountKey: e, contextId: F.contextId, day: h, timeZone: l, revision: F.revision, configuration: F.value });
    if (m && !D.confirmed) return { version: 1, kind: "unread-closing-cohort", closingPhase: false, ready: false, contextId: F.contextId, accountKey: e, day: h, timeZone: l, items: [], memberCount: 0, remaining: 0, status: "test-greeting-phase", testGreetingProgress: D, newGreeting: false, newMembersAdded: 0 };
    const v = m ? "test-greeting-completion-v1-" + e + "-" + a + ".json" : null;
    if (m) {
      const n = await o(v);
      if (n) {
        if (!i(n) || n.baselineSha256 !== D.baselineSha256 || O(n.confirmedKeys) !== O(D.confirmedKeys)) throw Error("\u4E24\u6B21\u62DB\u547C\u6D4B\u8BD5\u5B8C\u6210\u8BC1\u636E\u53D8\u5316\uFF0C\u505C\u6B62");
      } else await d(v, D, null);
    }
    const b = (m ? "test-active-unread-closing-v1-" + a + "-" : "active-unread-closing-v1-") + e + ".json";
    let p = await o(b);
    if (p && (!i(p) || p.kind !== "boss-active-unread-closing" || p.accountKey !== e || !/^\d{4}-\d{2}-\d{2}$/.test(p.day))) throw Error("\u6536\u5C3E\u6062\u590D\u6307\u9488\u8EAB\u4EFD\u6216\u6458\u8981\u65E0\u6548\uFF0C\u672A\u91CD\u5EFA");
    const B = E?.restoreExistingClosing === true;
    if (E?.restoreExistingClosing !== void 0 && typeof E.restoreExistingClosing != "boolean") throw Error("\u4EC5\u6062\u590D\u65E2\u6709\u6D88\u606F\u6536\u5C3E\u987B\u4E3A\u660E\u786E\u5F00\u5173");
    if (B && !p) throw Error("\u6CA1\u6709\u672C\u8D26\u53F7\u539F\u6536\u5C3E\u6307\u9488\uFF0C\u672A\u65B0\u5EFA\u96C6\u5408\u6216\u53D1\u9001\u62DB\u547C");
    const y = p?.sha256 || null;
    if (p && p.day !== h && !B) {
      const n = await o((m ? "test-fixed-unread-set-v1-" + a + "-" : "fixed-unread-set-v1-") + e + "-" + p.day + ".json"), w = await o((m ? "test-fixed-unread-progress-v1-" + a + "-" : "fixed-unread-progress-v1-") + e + "-" + p.day + ".json");
      if (!n || !w || !i(n) || !i(w) || n.sha256 !== p.fixedUnreadSetSha256 || w.fixedUnreadSetSha256 !== n.sha256 || w.accountKey !== e || !Array.isArray(n.members) || !Array.isArray(w.completed)) throw Error("\u5F80\u65E5\u6536\u5C3E\u6765\u6E90\u7F3A\u5931\u6216\u635F\u574F\uFF1B\u7981\u6B62\u91CD\u65B0\u6295\u9012");
      const R = new Set(n.members.map((x) => x.key));
      if (new Set(w.completed.map((x) => x.memberKey)).size !== w.completed.length || w.completed.some((x) => !R.has(x.memberKey))) throw Error("\u5F80\u65E5\u6536\u5C3E\u6210\u5458\u4E0D\u5B8C\u6574");
      !w.active && w.completed.length === n.members.length && w.completed.every((x) => x.status !== "review" || x.replyPolicyVersion === "work-questions-partial-known-v2") && (p = null);
    }
    const C = p?.day || h, f = m ? v : "site-daily-limit-v1-" + e + "-" + C + ".json", r = await o(f), N = (m ? "test-fixed-unread-set-v1-" + a + "-" : "fixed-unread-set-v1-") + e + "-" + C + ".json";
    let g = await o(N);
    if (!r && !p && !g) return { version: 1, kind: "unread-closing-cohort", closingPhase: false, ready: false, contextId: F.contextId, accountKey: e, day: C, timeZone: l, items: [], memberCount: 0, remaining: 0, status: "greeting-phase", newGreeting: false, newMembersAdded: 0 };
    if (!r || !i(r) || r.kind !== (m ? "boss-test-new-greeting-completion" : "boss-site-daily-limit") || r.accountKey !== e || r.confirmed !== true || r.day !== C || r.timeZone !== l) throw Error("\u672A\u627E\u5230\u672C\u8D26\u53F7\u771F\u5B9E\u7F51\u7AD9\u4E0A\u9650\u8BC1\u636E\uFF1B\u7981\u6B62\u91CD\u65B0\u6253\u62DB\u547C\u6216\u626B\u63CF\u5386\u53F2");
    if (B && !g) throw Error("\u539F\u56FA\u5B9A\u4F1A\u8BDD\u96C6\u5408\u7F3A\u5931\uFF0C\u672A\u626B\u63CF\u65B0\u589E\u6216\u91CD\u5EFA\u5386\u53F2");
    if (!g) {
      const n = async (K, U, L) => (I.throwIfAborted(), A.browser("browser", { operation: K, ...U ? { selector: U } : {}, ...L === void 0 ? {} : { value: L }, timeoutMs: 3e3 })), w = "https://www.zhipin.com/web/geek/chat", R = new URL(await n("url"));
      (R.origin !== new URL(w).origin || R.pathname !== "/web/geek/chat") && await n("navigate", null, w);
      const x = ".list-warp.v2 ul:has(> .selected)", H = x + " > :nth-child(2)", z = ".user-list-content > :first-child";
      let ae = false;
      for (let K = 0; K < 40; K++) {
        if (await n("count", H) === 1 && /^未读(?:\s*\(\d{1,4}\))?$/u.test(String(await n("read", H)).trim())) {
          ae = true;
          break;
        }
        await new Promise((U) => setTimeout(U, 250));
      }
      if (!ae) throw Error("\u7F51\u7AD9\u672A\u8BFB\u7B5B\u9009\u5165\u53E3\u672A\u5C31\u7EEA\uFF1B\u672A\u626B\u63CF\u5168\u90E8\u5386\u53F2");
      (await n("count", x + " .selected") !== 1 || !/^未读/u.test(String(await n("read", x + " .selected")).trim())) && await n("click", H);
      let j = null, G = 0;
      for (let K = 0; K < 40; K++) {
        if (await n("count", x + " .selected") === 1 && await n("count", z) === 1) {
          const U = String(await n("read", x + " .selected")).trim(), L = await n("count", z + " > *"), $ = String(await n("read", z)), Z = { tabText: U, count: L, text: $ };
          if (/^未读(?:\s*\(\d{1,4}\))?$/u.test(U) && JSON.stringify(Z) === JSON.stringify(j) ? G++ : G = 0, j = Z, G >= 2) break;
        }
        await new Promise((U) => setTimeout(U, 250));
      }
      if (G < 2 || !j || !Number.isSafeInteger(j.count) || j.count < 0 || j.count > 200) throw Error("\u672A\u8BFB\u5217\u8868\u672A\u7A33\u5B9A\uFF0C\u672A\u56FA\u5B9A\u90E8\u5206\u96C6\u5408");
      const se = /^未读\s*\((\d{1,4})\)$/u.exec(j.tabText), re = se ? Number(se[1]) : 0, P = [];
      for (let K = 1; K <= j.count; K++) {
        const U = z + " > :nth-child(" + K + ")", L = String(await n("read", U)).trim(), $ = U + " .friend-content";
        if (re === 0 && await n("count", $) === 0 && /^(?:暂无消息|暂无未读消息|暂无未读会话|没有未读消息)$/u.test(L)) continue;
        if (L.length > 1e4 || await n("count", $) !== 1) throw Error("\u672A\u8BFB\u6210\u5458\u8EAB\u4EFD\u6216\u5B8C\u6574\u6B63\u6587\u65E0\u6CD5\u6838\u5BF9");
        const Z = String(await n("read", $)).trim(), ce = L.split(/\r?\n/u).map((de) => de.trim()).filter(Boolean), ne = /^\d{1,4}$/u.test(ce[0] || "") ? Number(ce[0]) : null;
        if (!Z || !Number.isSafeInteger(ne) || ne < 1) throw Error("\u672A\u8BFB\u6210\u5458\u8BA1\u6570\u65E0\u6CD5\u6838\u5BF9");
        P.push({ position: K, displayIdentity: Z, unreadCount: ne, text: L, attributes: [], key: O(["boss-fixed-unread-visible-member-v1", e, Z]) });
      }
      if (P.reduce((K, U) => K + U.unreadCount, 0) !== re || new Set(P.map((K) => K.key)).size !== P.length) throw Error("\u672A\u8BFB\u4F1A\u8BDD\u96C6\u5408\u8986\u76D6\u6570\u91CF\u4E0D\u4E00\u81F4\uFF0C\u672A\u56FA\u5B9A\u90E8\u5206\u96C6\u5408");
      if (await n("url") !== w || String(await n("read", x + " .selected")).trim() !== j.tabText || await n("count", z + " > *") !== j.count || String(await n("read", z)) !== j.text || O(await A.state.get()) !== O(u.value)) throw Error("\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u524D\u6765\u6E90\u6216\u72B6\u6001\u53D8\u5316\uFF0C\u672A\u4FDD\u5B58");
      g = await d(N, { version: 1, kind: "boss-fixed-unread-set", accountKey: e, sourceContextId: F.contextId, day: C, timeZone: l, configurationRevision: F.revision, siteDailyLimitEvidenceName: f, siteDailyLimitEvidenceSha256: r.sha256, sourceUrl: w, selectedTabText: j.tabText, unreadMessageCount: re, members: P, createdAt: (/* @__PURE__ */ new Date()).toISOString(), membershipImmutable: true }, null);
    }
    if (!g || !i(g) || g.kind !== "boss-fixed-unread-set" || g.accountKey !== e || g.day !== C || g.siteDailyLimitEvidenceSha256 !== r.sha256 || !Array.isArray(g.members) || g.members.length > 200 || new Set(g.members.map((n) => n.key)).size !== g.members.length || g.members.reduce((n, w) => n + w.unreadCount, 0) !== g.unreadMessageCount) throw Error("\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u7F3A\u5931\u6216\u8986\u76D6\u6570\u91CF\u4E0D\u4E00\u81F4\uFF1B\u672A\u91CD\u5EFA\u6216\u6269\u5C55\u96C6\u5408");
    const k = g.members.map((n) => {
      const w = n.text.split(/\r?\n/u).map((R) => R.trim()).filter(Boolean);
      if (!/^[a-f0-9]{64}$/.test(n.key) || !/^\d+$/.test(w[0]) || !w[2] || w[2].length > 500) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u53EF\u89C1\u8EAB\u4EFD\u7F3A\u5931");
      return { ...n, identityLine: w[2] };
    });
    if (new Set(k.map((n) => n.identityLine)).size !== k.length) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u5B58\u5728\u540C\u540D\u540C\u516C\u53F8\u8EAB\u4EFD\u6B67\u4E49\uFF0C\u7981\u6B62\u731C\u6D4B");
    const le = "account-outbound-safety-v1-" + e + ".json", T = await o(le);
    if (!T || !i(T) || T.kind !== "boss-account-outbound-safety" || T.accountKey !== e || !Array.isArray(T.records) || !T.records.length) throw Error("\u539F\u8D26\u53F7\u5916\u53D1\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF0C\u963B\u6B62\u7EED\u53D1");
    if (p && (p.fixedUnreadSetSha256 !== g.sha256 || p.siteDailyLimitEvidenceSha256 !== r.sha256)) throw Error("\u6062\u590D\u6307\u9488\u4E0E\u56FA\u5B9A\u96C6\u5408\u4E0D\u7B26");
    p || (p = await d(b, { version: 1, kind: "boss-active-unread-closing", accountKey: e, day: C, timeZone: l, fixedUnreadSetSha256: g.sha256, siteDailyLimitEvidenceSha256: r.sha256, createdAt: (/* @__PURE__ */ new Date()).toISOString() }, y));
    const Y = (m ? "test-fixed-unread-progress-v1-" + a + "-" : "fixed-unread-progress-v1-") + e + "-" + C + ".json";
    let S = await o(Y);
    if (S && (!i(S) || S.kind !== "boss-fixed-unread-progress" || S.accountKey !== e || S.fixedUnreadSetSha256 !== g.sha256 || !Array.isArray(S.completed) || S.completed.some((n) => !k.some((w) => w.key === n.memberKey)) || new Set(S.completed.map((n) => n.memberKey)).size !== S.completed.length || S.active && !k.some((n) => n.key === S.active.memberKey))) throw Error("\u6536\u5C3E\u8FDB\u5EA6\u8EAB\u4EFD\u3001\u6458\u8981\u6216\u6210\u5458\u65E0\u6548");
    if (B && !S) throw Error("\u539F\u6D88\u606F\u6536\u5C3E\u8FDB\u5EA6\u7F3A\u5931\uFF0C\u672A\u91CD\u5EFA\u6216\u91CD\u653E");
    S || (S = await d(Y, { version: 1, kind: "boss-fixed-unread-progress", accountKey: e, day: C, timeZone: l, fixedUnreadSetSha256: g.sha256, revision: 0, active: null, completed: [], createdAt: (/* @__PURE__ */ new Date()).toISOString() }, null));
    const ee = (n) => !V(n) && (n.status !== "review" || n.replyPolicyVersion === "work-questions-partial-known-v2"), ue = S.active ? k.find((n) => n.key === S.active.memberKey) : k.find((n) => !S.completed.some((w) => w.memberKey === n.key && ee(w))), te = { version: 1, kind: "unread-closing-cohort", restoredExistingClosing: B, closingPhase: true, ready: !!ue, contextId: F.contextId, accountKey: e, accountSource: t, configuration: F.value, configurationRevision: F.revision, siteDailyLimitEvidence: m ? null : r, testCompletionEvidence: m ? r : null, closingTrigger: m ? "two-new-greetings-test" : "real-site-daily-limit", fixedUnreadSetName: N, fixedUnreadSetSha256: g.sha256, member: ue || null, memberCount: k.length, unreadMessageCount: g.unreadMessageCount, progressName: Y, progressSha256: S.sha256, progress: S, remaining: k.length - S.completed.filter(ee).length, status: ue ? "resume-fixed-unread" : "fixed-unread-complete", newGreeting: false, newMembersAdded: 0 };
    if (O(await A.state.get()) !== O(u.value)) throw Error("\u51C6\u5907\u6536\u5C3E\u671F\u95F4\u6B63\u5F0F\u72B6\u6001\u53D8\u5316\uFF0C\u672A\u7EE7\u7EED");
    return te.items = k.filter((n) => !S.completed.some((w) => w.memberKey === n.key && ee(w))).sort((n, w) => +(w.key === S.active?.memberKey) - +(n.key === S.active?.memberKey)).map((n) => ({ ...te, member: n, ready: true })), te;
  }
  var ie = X;
  return ie;
})(), fe = /* @__PURE__ */ (() => {
  const V = (u) => Array.isArray(u) ? u.map(V) : u && typeof u == "object" ? Object.fromEntries(Object.keys(u).sort().map((t) => [t, V(u[t])])) : u, M = (u) => oe("sha256").update(JSON.stringify(V(u))).digest("hex"), _ = (u) => oe("sha256").update(u).digest("hex"), W = (u, t) => (c, s, e) => (t.throwIfAborted(), u.browser("browser", { operation: c, ...s ? { selector: s } : {}, ...e === void 0 ? {} : { value: e }, timeoutMs: 3e3 }));
  async function J(u, t, c, s, e = null) {
    let i = null;
    try {
      i = await u.file("communication-cache", { operation: "read", name: t });
    } catch (d) {
      if (!String(d.message || d).includes("ENOENT")) throw d;
    }
    const o = i === null ? e : JSON.parse(i);
    if (!o) throw Error("\u7F3A\u5C11\u6062\u590D\u6765\u6E90 " + t);
    if (i !== null) {
      const { sha256: d, ...l } = o;
      if (d !== M(l)) throw Error("\u6062\u590D\u6765\u6E90\u6458\u8981\u4E0D\u7B26 " + t);
    }
    if (o.kind !== c || o.accountKey !== s) throw Error("\u6062\u590D\u6765\u6E90\u8D26\u53F7\u6216\u7C7B\u578B\u4E0D\u7B26");
    return { name: t, raw: i, value: o };
  }
  async function O(u, t) {
    let c = null;
    try {
      c = await u.file("communication-cache", { operation: "read", name: t.name });
    } catch (i) {
      if (!String(i.message || i).includes("ENOENT")) throw i;
    }
    if (c !== t.raw) throw Error("\u6062\u590D\u8BB0\u5F55\u5E76\u53D1\u53D8\u5316");
    const s = t.value;
    s.revision++, s.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete s.sha256, s.sha256 = M(s);
    const e = JSON.stringify(s);
    if (await u.file("communication-cache", { operation: "write", name: t.name, content: e }), await u.file("communication-cache", { operation: "read", name: t.name }) !== e) throw Error("\u6062\u590D\u8BB0\u5F55\u672A\u51C6\u786E\u8BFB\u56DE");
    t.raw = e;
  }
  async function Q(u, t) {
    return J(u, "unknown-chat-reviews-v1-" + t + ".json", "boss-unknown-chat-reviews", t, { version: 1, kind: "boss-unknown-chat-reviews", accountKey: t, revision: 0, reviews: [] });
  }
  async function X(u) {
    const t = await u("count", "li.message-item");
    if (!Number.isSafeInteger(t) || t < 1 || t > 150) throw Error("\u4F1A\u8BDD\u53EF\u89C1\u6D88\u606F\u8303\u56F4\u65E0\u6548");
    const c = [];
    for (let s = 1; s <= t; s++) {
      const e = "li.message-item:nth-child(" + s + " of li.message-item)", i = await u("attribute", e, "data-mid"), o = String(await u("attribute", e, "class") || "");
      if (!/^\d{6,40}$/u.test(i || "")) throw Error("\u7F3A\u5C11\u771F\u5B9E\u670D\u52A1\u5668\u6D88\u606F\u7F16\u53F7");
      const d = await u("count", e + " .text-content");
      if (d > 1) throw Error("\u5355\u6761\u6B63\u6587\u4E0D\u552F\u4E00");
      const l = d === 1 ? String(await u("read", e + " .text-content")).trim() : null, h = d === 1 ? null : String(await u("read", e)).trim(), m = !!l && /^您正在与Boss.+沟通$/u.test(l), a = !m && l !== null && o.split(/\s/u).includes("item-myself") ? "outgoing" : !m && l !== null && o.split(/\s/u).includes("item-friend") ? "incoming" : "system", D = e + " > div > div > i", v = await u("count", D) === 1 ? String(await u("read", D)).trim() : null;
      c.push({ mid: i, direction: a, text: l, context: h, receipt: v });
    }
    if (new Set(c.map((s) => s.mid)).size !== c.length) throw Error("\u670D\u52A1\u5668\u6D88\u606F\u7F16\u53F7\u91CD\u590D");
    return c;
  }
  async function ie(u, t, c = true) {
    const s = new URL(await u("url"));
    if (s.origin !== "https://www.zhipin.com" || s.pathname !== "/web/geek/chat" || String(await u("read", t.accountSelector)).trim() !== t.accountLabel || await u("count", 'li.message-item[data-mid="' + t.member.originalIncomingMid + '"]') !== 1 || await u("count", 'li.message-item[data-mid="' + t.member.firstMessageId + '"]') !== 1) throw Error("\u672A\u77E5\u6062\u590D\u7684\u8D26\u53F7\u6216\u539F\u6D88\u606F\u94FE\u53D8\u5316");
    if (c && M(await X(u)) !== t.messagesHash) throw Error("AI\u5224\u65AD\u671F\u95F4\u804A\u5929\u5185\u5BB9\u53D8\u5316\uFF0C\u672A\u5916\u53D1");
  }
  async function E(u, t) {
    const c = ".list-warp.v2 input";
    if (await u("count", c) !== 1) throw Error("\u8054\u7CFB\u4EBA\u641C\u7D22\u5165\u53E3\u4E0D\u552F\u4E00");
    await u("click", c), await u("fill", c, t.lookupQuery || t.recipientName);
    const s = ".boss-search-result .search-list";
    let e = 0;
    for (let d = 0; d < 30 && (e = await u("count", s), !(e > 0)); d++) await new Promise((l) => setTimeout(l, 150));
    if (e < 1 || e > 50) throw Error("\u672A\u627E\u5230\u539Funknown\u8054\u7CFB\u4EBA");
    const i = [];
    for (let d = 1; d <= e; d++) {
      const l = s + ":nth-child(" + d + " of .search-list)", h = [l];
      let m = 0;
      for (; h.length; ) {
        const a = h.shift();
        if (++m > 150) throw Error("\u59D3\u540D\u63A7\u4EF6\u8303\u56F4\u8FC7\u5927");
        const D = String(await u("read", a)).trim(), v = await u("count", a + " > *");
        if (D === t.recipientName && i.push({ selector: a, text: D }), v > 0 && v < 30) for (let b = 1; b <= v; b++) h.push(a + " > :nth-child(" + b + ")");
      }
    }
    const o = i.filter((d) => !i.some((l) => l !== d && l.selector.startsWith(d.selector + " > ")));
    if (o.length !== 1) throw Error("\u539Funknown\u59D3\u540D\u63A7\u4EF6\u4E0D\u552F\u4E00");
    if (String(await u("read", o[0].selector)).trim() !== o[0].text) throw Error("\u641C\u7D22\u7ED3\u679C\u53D8\u5316");
    await u("click", o[0].selector);
    for (let d = 0; d < 40; d++) {
      if (await u("count", 'li.message-item[data-mid="' + t.originalIncomingMid + '"]') === 1 && await u("count", 'li.message-item[data-mid="' + t.firstMessageId + '"]') === 1) return;
      await new Promise((l) => setTimeout(l, 150));
    }
    throw Error("\u641C\u7D22\u540E\u672A\u8BFB\u56DE\u539Funknown\u670D\u52A1\u5668\u6D88\u606F\u94FE");
  }
  const A = /* @__PURE__ */ (() => {
    var u = async ({ input: t, signal: c }) => {
      c.throwIfAborted();
      const s = t, e = s?.value;
      if (!s || s.version !== 1 || s.operation !== "read" || s.binding !== "account-source-result" || s.schemaValidation !== "passed" || s.dataChanged !== false || s.ref?.version !== 1 || s.ref.policy !== "credential-redacted-v1" || s.ref.source?.entryId !== "account-source") throw new Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u5DF2\u9009\u62E9\u4E14\u5B8C\u6574\u53EF\u590D\u7528\u7684\u8D26\u53F7\u6765\u6E90\uFF0C\u8BF7\u5230\u8D44\u6E90\u9875\u91CD\u65B0\u6838\u5BF9\u5E76\u4FDD\u5B58");
      if (!e || e.version !== 1 || e.kind !== "boss-account-source" || e.status !== "account-source-confirmed" || e.accountVerified !== true || e.platformUniqueIdVerified !== false || e.eligibleForActions !== false || e.role !== "jobseeker") throw new Error("\u6240\u9009\u8BB0\u5F55\u5C1A\u672A\u5B8C\u6210\u672C\u4EBA\u786E\u8BA4\u548C\u6765\u6E90\u590D\u9A8C\uFF1B\u8BF7\u5728\u5F53\u524D\u5B9E\u4F8B\u5B8C\u6210\u8D26\u53F7\u6838\u5BF9\uFF0C\u518D\u9009\u62E9\u8BE5\u6B21\u5DF2\u4FDD\u5B58\u7ED3\u679C");
      const i = ["version", "kind", "status", "accountAlias", "accountName", "phoneMask", "jobseekerResumeHref", "role", "sourceUrl", "accountVerified", "platformUniqueIdVerified", "eligibleForActions", "confirmedAt", "checkedAt", "reason"];
      if (Object.keys(e).length !== i.length || i.some((m) => !Object.prototype.hasOwnProperty.call(e, m))) throw new Error("\u6240\u9009\u8D26\u53F7\u7ED3\u679C\u7ED3\u6784\u4E0D\u7B26\uFF0C\u505C\u6B62\u91C7\u7528");
      for (const m of ["accountAlias", "accountName", "phoneMask"]) if (typeof e[m] != "string" || !e[m].trim() || e[m] !== e[m].trim() || e[m].length > 100 || /[\r\n]/.test(e[m])) throw new Error("\u8D26\u53F7\u5FC5\u8981\u5B57\u6BB5\u7F3A\u5931\u6216\u683C\u5F0F\u65E0\u6548\uFF0C\u505C\u6B62\u91C7\u7528");
      if (!/^[+\d ()-]*\*{2,}[\d ()-]+$/.test(e.phoneMask) || /登录|注册|验证码/.test(e.accountName)) throw new Error("\u8D26\u53F7\u6765\u6E90\u7F3A\u5C11\u6709\u6548\u7684\u53EF\u89C1\u59D3\u540D\u6216\u624B\u673A\u53F7\u63A9\u7801");
      if (typeof e.reason != "string" || !e.reason.trim()) throw new Error("\u8D26\u53F7\u7ED3\u679C\u7F3A\u5C11\u660E\u786E\u6838\u5BF9\u8BF4\u660E");
      const o = Date.parse(e.confirmedAt), d = Date.parse(e.checkedAt);
      if (typeof e.confirmedAt != "string" || typeof e.checkedAt != "string" || !Number.isFinite(o) || !Number.isFinite(d) || o <= 0 || d < o || d > Date.now() + 6e4) throw new Error("\u8D26\u53F7\u786E\u8BA4\u6216\u590D\u9A8C\u65F6\u95F4\u65E0\u6CD5\u6838\u5BF9\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4");
      if (typeof e.sourceUrl != "string" || typeof e.jobseekerResumeHref != "string" || !e.sourceUrl.trim() || !e.jobseekerResumeHref.trim() || e.sourceUrl.length > 16384 || e.jobseekerResumeHref.length > 16384) throw new Error("\u8D26\u53F7\u9875\u9762\u6216\u7B80\u5386\u5165\u53E3\u5730\u5740\u65E0\u6548");
      const l = new URL(e.sourceUrl), h = new URL(e.jobseekerResumeHref, e.sourceUrl);
      if (l.origin !== "https://www.zhipin.com" || l.pathname !== "/web/geek/account" || l.searchParams.get("type") !== "accountSet" || l.username || l.password || l.hash || h.origin !== l.origin || h.pathname !== "/web/geek/resume" || h.username || h.password) throw new Error("\u8D26\u53F7\u8BB0\u5F55\u7684\u9875\u9762\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u4E0D\u7B26");
      return c.throwIfAborted(), { version: 1, accountSourceValid: true, currentAccountVerified: false, account: e };
    };
    return u;
  })(), I = /* @__PURE__ */ (() => {
    async function u({ input: t, signal: c, template: s }) {
      c.throwIfAborted();
      const e = t?.expected?.account;
      if (t?.expected?.accountSourceValid !== true || e?.kind !== "boss-account-source" || e.status !== "account-source-confirmed" || e.accountVerified !== true) throw Error("\u7F3A\u5C11\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\u6765\u6E90");
      const i = async (b, p, B) => {
        c.throwIfAborted();
        const y = await s.browser("browser", { operation: b, ...p ? { selector: p } : {}, ...B === void 0 ? {} : { value: B }, timeoutMs: 3e3 });
        return c.throwIfAborted(), y;
      };
      let o = await i("url");
      if (o === "about:blank") {
        await i("navigate", void 0, e.sourceUrl);
        for (let b = 0; b < 40; b++) {
          const p = await i("url");
          if (new URL(p).origin === "https://www.zhipin.com" && await i("count", "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)") === 1) break;
          await new Promise((B) => setTimeout(B, 150));
        }
        o = await i("url");
      }
      const d = new URL(o);
      if (d.origin !== "https://www.zhipin.com" || d.username || d.password || !d.pathname.startsWith("/web/") && !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(d.pathname)) throw Error("\u5F53\u524D\u9875\u9762\u4E0D\u662FBOSS\u6C42\u804C\u9875\u9762\uFF0C\u8BF7\u5148\u767B\u5F55");
      const l = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", h = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)", m = await i("count", l), a = await i("count", h);
      if (m !== 1 || a !== 1) throw Error("\u5F53\u524D\u9875\u9762\u8D26\u53F7\u5165\u53E3\u6570\u91CF\u5F02\u5E38\uFF1A" + JSON.stringify({ nameCount: m, resumeCount: a }));
      const D = await i("read", l), v = await i("attribute", h, "href");
      if (typeof D != "string" || D.normalize("NFKC").trim() !== e.accountName.normalize("NFKC").trim() || typeof v != "string" || new URL(v, o).href !== new URL(e.jobseekerResumeHref, e.sourceUrl).href || await i("url") !== o) throw Error("\u5F53\u524D\u767B\u5F55\u8EAB\u4EFD\u3001\u6C42\u804C\u5165\u53E3\u6216\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
      return { version: 1, status: "current-account-source-matched", accountAlias: e.accountAlias, accountName: e.accountName, phoneMask: e.phoneMask, jobseekerResumeHref: e.jobseekerResumeHref, sourceUrl: e.sourceUrl, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), currentPageUrl: o, currentAccountVerified: true, platformUniqueIdVerified: false, eligibleForActions: false, accountCheckMode: "confirmed-initial-account-and-visible-header", phoneMaskRechecked: false, reason: "\u4F7F\u7528\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\uFF1B\u53EA\u8BFB\u6838\u5BF9\u5F53\u524D\u767B\u5F55\u59D3\u540D\u3001\u6C42\u804C\u5165\u53E3\u53CA\u9875\u9762\u8FDE\u7EED\u6027\uFF0C\u624B\u673A\u53F7\u63A9\u7801\u6CBF\u7528\u786E\u8BA4\u6765\u6E90\uFF0C\u6CA1\u6709\u91CD\u65B0\u8BFB\u53D6\u3002" };
    }
    return u;
  })();
  return async function({ input: u, template: t, signal: c, artifact: s }) {
    const e = u.configuration;
    if (e?.operation !== "configuration") throw Error("\u7F3A\u5C11\u5F53\u524D\u914D\u7F6E");
    const i = await A({ input: u.account, signal: c });
    await I({ input: { expected: i }, template: t, signal: c });
    const o = i.account, d = new URL(o.jobseekerResumeHref, o.sourceUrl), l = oe("sha256").update(JSON.stringify(["boss-visible-account-source-v1", o.accountName, o.phoneMask, d.origin + d.pathname])).digest("hex"), h = async (r, N) => {
      try {
        return await J(t, r, N, l);
      } catch (g) {
        if (String(g.message || g).startsWith("\u7F3A\u5C11\u6062\u590D\u6765\u6E90 ")) return null;
        throw g;
      }
    }, m = await h("account-outbound-safety-v1-" + l + ".json", "boss-account-outbound-safety");
    if (!m) return null;
    const a = await h("resume-delivery-index-v1-" + l + ".json", "boss-resume-delivery-index"), D = await h("unknown-chat-sources-v1-" + l + ".json", "boss-unknown-chat-sources"), v = await Q(t, l), b = [];
    for (const r of m.value.records) {
      if (r.type !== "reply" || r.parentBusinessKey || !r.sightings.some((k) => k.status === "unknown") || r.sightings.some((k) => k.status === "confirmed")) continue;
      const N = "reply:" + r.businessKey, g = D?.value.items.find((k) => k.key === N);
      b.push({ ...g, key: N, parentKind: "reply", parentKey: r.businessKey, parentRecordHash: M(r), originalIncomingMid: r.incomingMessageId, conversationKey: r.conversationKey, lookupQuery: g?.recipientName || null, sourceMissing: !g });
    }
    for (const r of a?.value.deliveries || []) {
      if (r.status !== "unknown") continue;
      const N = String(r.recipientLabel || "").split(/\r?\n/u)[0].trim();
      b.push({ key: "resume:" + r.key, parentKind: "resume", parentKey: r.key, parentRecordHash: M(r), originalIncomingMid: r.requestMid, firstMessageId: r.firstMessageId, recipientLabel: r.recipientLabel, recipientName: N, lookupQuery: N, historicalVerification: r.verification || null });
    }
    const p = /* @__PURE__ */ new Set(["skipped", "existing-answer", "confirmed-reply", "confirmed-native"]), B = b.filter((r) => !p.has(v.value.reviews.find((N) => N.key === r.key)?.status));
    if (!B.length) return null;
    const y = e.value.replyTimeZone, C = new Intl.DateTimeFormat("sv-SE", { timeZone: y, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date()), f = { version: 1, kind: "unread-closing-cohort", unknownRecovery: true, closingPhase: true, closingTrigger: "unknown-chat-ai-takeover", accountKey: l, accountSource: i, contextId: e.contextId, configuration: e.value, configurationRevision: e.revision, day: C, timeZone: y, reviewSetHash: M(B.map((r) => r.key).sort()), memberCount: B.length, newGreeting: false, newMembersAdded: 0, readOnly: false, metadataKeys: B.map((r) => r.key), authorization: "\u4F7F\u7528\u8005\u660E\u786E\u542F\u52A8\u5DF2\u6388\u6743\u5165\u53E3\uFF1Aunknown\u5148\u8BFB\u53D6\u5B8C\u6574\u804A\u5929\uFF0C\u4F9D\u636E\u672C\u4EBA\u786E\u8BA4Skill\u548C\u4E8B\u5B9E\u5224\u65AD\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55\uFF0C\u4EC5\u56DE\u590D\u672A\u56DE\u7B54\u95EE\u9898\u4E00\u6B21" };
    return await s("unknown-review-inventory.json", JSON.stringify({ ...f, items: B.map((r) => ({ key: r.key, kind: r.parentKind, hasLookupSource: !r.sourceMissing })) })), { ...f, ready: true, items: B.map((r) => ({ ...f, member: r, ready: true })) };
  };
})();
async function we(V) {
  return await fe(V) || me(V);
}
export {
  we as default
};
