import { createHash as O } from "node:crypto";
const E = (e) => Array.isArray(e) ? e.map(E) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((i) => [i, E(e[i])])) : e, p = (e) => O("sha256").update(JSON.stringify(E(e))).digest("hex"), A = (e, i) => (o, r, t) => (i.throwIfAborted(), e.browser("browser", { operation: o, ...r ? { selector: r } : {}, ...t === void 0 ? {} : { value: t }, timeoutMs: 3e3 }));
async function k(e, i, o) {
  const r = new URL(await e("url"));
  if (r.origin !== "https://www.zhipin.com" || r.pathname !== "/web/geek/chat" || String(await e("read", i.recipientSelector)).trim() !== i.recipientLabel || String(await e("read", i.accountSelector)).trim() !== i.accountLabel || await e("count", 'li.message-item[data-mid="' + i.firstMessageId + '"]') !== 1) throw Error("\u5F53\u524D\u8D26\u53F7\u6216\u4F1A\u8BDD\u6D88\u606F\u94FE\u53D8\u5316\uFF0C\u4E0D\u64CD\u4F5C");
  if (((await o.state.get()).conversationControls || []).some((u) => u.accountKey === i.accountKey && [i.conversationKey, "boss-chat:" + i.firstMessageId].includes(u.conversationKey) && u.mode === "paused")) throw Error("\u672C\u4EBA\u5DF2\u63A5\u7BA1\u4F1A\u8BDD");
}
async function K(e) {
  const i = await e("count", "li.message-item");
  if (!Number.isSafeInteger(i) || i < 1 || i > 100) throw Error("\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u8303\u56F4\u65E0\u6548");
  const o = [];
  for (let r = 1; r <= i; r++) {
    const t = "li.message-item:nth-child(" + r + " of li.message-item)", u = await e("attribute", t, "data-mid"), a = String(await e("attribute", t, "class") || ""), n = String(await e("read", t)).trim();
    if (!/^\d{6,40}$/u.test(u || "") || n.length > 2e4) throw Error("\u539F\u751F\u6D88\u606F\u8EAB\u4EFD\u4E0D\u5B8C\u6574");
    o.push({ mid: u, cls: a, text: n });
  }
  return o;
}
async function I(e, i) {
  const o = "resume-delivery-index-v1-" + i.accountKey + ".json";
  let r = null;
  try {
    r = await e.file("communication-cache", { operation: "read", name: o });
  } catch (a) {
    if (!String(a.message || a).includes("ENOENT")) throw a;
  }
  const t = r ? JSON.parse(r) : { version: 1, kind: "boss-resume-delivery-index", accountKey: i.accountKey, revision: 0, uploads: [], deliveries: [] };
  if (r) {
    const { sha256: a, ...n } = t;
    if (a !== p(n)) throw Error("\u539F\u9644\u4EF6\u8D26\u672C\u6458\u8981\u4E0D\u7B26");
  }
  if (t.accountKey !== i.accountKey || t.kind !== "boss-resume-delivery-index" || !Array.isArray(t.deliveries) || !Array.isArray(t.uploads) || t.deliveries.length > 2e3 || new Set(t.deliveries.map((a) => a.key)).size !== t.deliveries.length) throw Error("\u539F\u9644\u4EF6\u8D26\u672C\u7ED3\u6784\u4E0D\u7B26");
  return { book: t, save: async () => {
    let a = null;
    try {
      a = await e.file("communication-cache", { operation: "read", name: o });
    } catch (g) {
      if (!String(g.message || g).includes("ENOENT")) throw g;
    }
    if (a !== r) throw Error("\u9644\u4EF6\u8D26\u672C\u5E76\u53D1\u53D8\u5316");
    t.revision++, t.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete t.sha256, t.sha256 = p(t);
    const n = JSON.stringify(t);
    if (await e.file("communication-cache", { operation: "write", name: o, content: n }), await e.file("communication-cache", { operation: "read", name: o }) !== n) throw Error("\u9644\u4EF6\u8D26\u672C\u672A\u51C6\u786E\u8BFB\u56DE");
    r = n;
  } };
}
async function stdin_default({ input: e, template: i, signal: o, artifact: r }) {
  if (e?.kind !== "boss-native-resume-preparation" || !e.execute) return { status: "no-new-native-send", websiteMessagesSent: 0 };
  const t = A(i, o), u = [];
  for (const n of e.freshKeys) {
    const { book: g, save: y } = await I(i, e), s = g.deliveries.find((w) => w.key === n), c = e.requests.find((w) => w.key === n);
    if (!s || s.status !== "reserved" || s.effectId || !c) throw Error("\u672C\u6B21\u552F\u4E00\u9644\u4EF6\u9884\u7559\u7F3A\u5931\u6216\u51B2\u7A81");
    if (await k(t, e, i), String(await t("read", c.root)).trim() !== c.text || String(await t("read", c.agree)).trim() !== "\u540C\u610F") throw Error("\u539F\u751F\u8BF7\u6C42\u5DF2\u53D8\u5316");
    const b = await i.effect.prepare({ action: "send-resume", key: p(["boss-native-resume-send-v1", e.accountKey, n]), description: "\u4EC5\u901A\u8FC7\u539F\u751F\u540C\u610F\u3001\u51C6\u786E\u9009\u4EF6\u4E0E\u53D1\u9001\u63A7\u4EF6\u53D1\u9001\u672C\u4EBA\u786E\u8BA4\u7684\u73B0\u6709PDF\u4E00\u6B21", review: { version: 1, target: e.recipientLabel + `
\u539F\u8BF7\u6C42 ` + c.mid, content: e.fileName } });
    if (s.effectId = b.id, s.sendKey = b.key || p(["boss-native-resume-send-v1", e.accountKey, n]), await y(), !b.execute) {
      s.status = "unknown", await y();
      continue;
    }
    let N = false;
    try {
      if (await k(t, e, i), String(await t("read", c.root)).trim() !== c.text) throw Error("\u540C\u610F\u524D\u539F\u8BF7\u6C42\u53D8\u5316");
      const w = new Set((await K(t)).map((d) => d.mid));
      await t("click", c.agree);
      const x = ".choose-resume-dialog .resume-list li.list-item:not(.video-list-item)";
      let S = 0;
      for (let d = 0; d < 30 && (S = await t("count", x), !(S > 0)); d++) await new Promise((l) => setTimeout(l, 150));
      if (S < 1 || S > 20) throw Error("\u6CA1\u6709\u53EF\u6838\u5BF9\u7684\u539F\u751F\u9009\u4EF6\u5F39\u7A97");
      const m = [];
      for (let d = 1; d <= S; d++) {
        const l = x + ":nth-child(" + d + ")";
        await t("count", l + " .resume-name") === 1 && String(await t("read", l + " .resume-name")).trim() === e.fileName && m.push(l);
      }
      if (m.length !== 1) throw Error("\u7F51\u7AD9\u73B0\u6709\u9644\u4EF6\u6CA1\u6709\u552F\u4E00\u5B8C\u6574\u540D\u79F0\u5339\u914D");
      if (await t("click", m[0]), !String(await t("attribute", m[0], "class")).split(/\s/u).includes("selected") || await t("count", ".choose-resume-dialog .resume-list li.selected") !== 1) throw Error("\u539F\u751F\u9009\u4EF6\u672A\u6838\u5BF9");
      await k(t, e, i);
      const v = ".choose-resume-dialog .btn-confirm";
      if (await t("count", v) !== 1 || String(await t("read", v)).trim() !== "\u53D1\u9001" || await t("attribute", v, "disabled") !== null || String(await t("attribute", v, "class")).split(/\s/u).includes("disabled")) throw Error("\u539F\u751F\u53D1\u9001\u63A7\u4EF6\u4E0D\u53EF\u7528");
      if (s.fileSelection = { exactFileName: e.fileName, selectedLabel: String(await t("read", m[0] + " .resume-name")).trim(), serverBytesVerified: false, checkedAt: (/* @__PURE__ */ new Date()).toISOString() }, await y(), s.fileSelection.selectedLabel !== e.fileName || !String(await t("attribute", m[0], "class")).split(/\s/u).includes("selected")) throw Error("\u53D1\u9001\u524D\u9009\u4EF6\u53D8\u5316");
      N = true, await t("click", v);
      let h = null;
      for (let d = 0; d < 30; d++) {
        await k(t, e, i);
        const l = (await K(t)).filter((f) => !w.has(f.mid) && /您的附件简历[\s\S]*已发送给Boss/u.test(f.text));
        if (l.length > 1) throw Error("\u591A\u4E2A\u65B0\u9644\u4EF6\u56DE\u6267\u65E0\u6CD5\u5F52\u56E0");
        if (l.length === 1) {
          const f = /您的附件简历\s+(.+?)\s+已发送给Boss/u.exec(l[0].text)?.[1]?.trim();
          if (f === e.fileName || f && /[.…]/u.test(f) && e.fileName.startsWith(f.split(/…|\.\.\./u)[0])) {
            h = { requestMid: c.mid, outgoingMessageId: l[0].mid, text: l[0].text, exactFileSelected: true, selectedFile: e.fileName, nativeWebsiteFunction: true, serverBytesVerified: false, observedAt: (/* @__PURE__ */ new Date()).toISOString() };
            break;
          }
        }
        await new Promise((f) => setTimeout(f, 200));
      }
      if (!h) throw Error("\u672A\u53D6\u5F97\u540C\u4F1A\u8BDD\u552F\u4E00\u539F\u751F\u9644\u4EF6\u56DE\u6267");
      s.status = "confirmed", s.receipt = h, s.evidence = h, await y(), await i.effect.resolve({ id: b.id, state: "confirmed", evidence: h }), u.push({ requestMid: c.mid, status: "confirmed", receipt: h });
    } catch (w) {
      throw s.status = "unknown", s.reason = String(w.message || w), await y(), await i.effect.resolve({ id: b.id, state: "unknown", evidence: { requestMid: c.mid, clickedSend: N, reason: s.reason, doNotReplay: true } }), await i.attention({ key: "native-resume-unknown-" + n, title: "\u539F\u751F\u9644\u4EF6\u7ED3\u679C\u672A\u77E5\uFF0C\u7981\u6B62\u91CD\u53D1", detail: { contact: e.recipientLabel, requestMid: c.mid, reason: s.reason, doNotReplay: true } }), w;
    }
  }
  const a = { version: 1, kind: "resume-send-result", status: "native-resume-requests-processed", results: u, websiteMessagesSent: u.length, websiteUploads: 0, aiCalled: false };
  return await r("native-resume-stage-result.json", JSON.stringify(a)), a;
}
export {
  stdin_default as default
};
