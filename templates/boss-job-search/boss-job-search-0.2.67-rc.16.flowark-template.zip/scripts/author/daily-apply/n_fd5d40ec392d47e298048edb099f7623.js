function titleScopeEvidence(title, configuration) {
  const normalize = (value) => value.normalize("NFKC").replace(/\s+/gu, " ").trim().toLocaleLowerCase("en-US");
  const positive = configuration?.titleKeywords, negative = configuration?.excludedRoles;
  for (const [name, terms, minimum] of [["titleKeywords", positive, 1], ["excludedRoles", negative, 0]]) {
    if (!Array.isArray(terms) || terms.length < minimum || terms.length > 20 || terms.some((v) => typeof v !== "string" || !normalize(v) || v.length > 100) || new Set(terms.map(normalize)).size !== terms.length) throw Error("\u5C97\u4F4D\u8303\u56F4\u914D\u7F6E\u65E0\u6548\uFF1A" + name + "\uFF1B\u672A\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE");
  }
  if (typeof title !== "string" || !title.trim() || title.length > 1e3) throw Error("\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u7F3A\u5931\u6216\u622A\u65AD\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u8BB0\u5F55");
  const normalizedTitle = normalize(title);
  const excluded = negative.filter((term) => normalizedTitle.includes(normalize(term)));
  const truncated = /(?:\.{3}|…|⋯)/u.test(title);
  if (truncated) {
    if (!excluded.length) throw Error("\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u7F3A\u5931\u6216\u622A\u65AD\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u8BB0\u5F55");
    return { version: 1, kind: "literal-observed-job-title-exclusion", fullTitle: null, observedTitle: title, matched: [], excluded, allowed: false, completeTitleVerified: false, source: "actual-observed-truncated-job-title", jdUsed: false, searchKeywordUsedAsEvidence: false };
  }
  const matched = positive.filter((term) => normalizedTitle.includes(normalize(term)));
  return { version: 1, kind: "literal-full-job-title-scope", fullTitle: title, matched, excluded, allowed: excluded.length === 0 && matched.length > 0, completeTitleVerified: true, source: "actual-complete-job-title", jdUsed: false, searchKeywordUsedAsEvidence: false };
}
import { createHash } from "node:crypto";
const PANEL = Object.freeze({
  title: "head > title",
  jobTitle: ".job-detail-container .job-name",
  jobCity: ".job-header-info .tag-list > :nth-child(1)",
  companyLabel: ".job-boss-info > :nth-child(2) > :nth-child(2)",
  description: ".job-detail-body > .desc",
  salary: ".job-detail-container .job-salary",
  closedStatus: ".job-detail-container .job-close",
  contact: ".job-detail-container div:nth-of-type(2) > a:nth-of-type(2)"
});
const panelClean = (v) => String(v).replace(/\s+/gu, " ").trim();
const panelCompany = (v) => String(v).trim().split(/\s+·\s+/u).slice(0, -1).join(" \xB7 ").trim();
function panelJobIdentity(source) {
  const u = new URL(source), m = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(u.pathname);
  if (u.origin !== "https://www.zhipin.com" || u.username || u.password || u.search || u.hash || !m) throw Error("\u5C97\u4F4D\u5B8C\u6574\u94FE\u63A5\u65E0\u6548");
  const hrefs = [u.pathname, u.href].flatMap((v) => ['[href="' + v + '"]', '[href^="' + v + '?"]']).join(",");
  const relative = "> div:nth-of-type(1) > div > a:is(" + hrefs + ")";
  return { jobId: m[1], cardSelector: ".job-card-box:has(" + relative + ")", linkSelector: ".job-card-box " + relative };
}
async function panelFontCodec(read) {
  const sources = ["https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/app~0.1e6caebe.css", "https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/8026.de407e2f.css"];
  for (const href of sources) {
    const selector = 'head > link[rel="stylesheet"][href="' + href + '"]';
    if (await read("count", selector) !== 1 || await read("attribute", selector, "href") !== href) throw Error("\u85AA\u8D44\u5B57\u4F53\u6765\u6E90\u53D8\u5316\uFF0C\u672A\u731C\u6D4B\u91D1\u989D");
  }
  return "kanzhun-mix-2023-digits-v1";
}
function panelSalary(raw, codec) {
  if (typeof raw !== "string" || !raw.trim() || raw.length > 256) throw Error("\u85AA\u8D44\u539F\u6587\u7F3A\u5931\u6216\u8D85\u957F");
  if (/[\uE000-\uF8FF]/u.test(raw)) {
    if (codec !== "kanzhun-mix-2023-digits-v1" || /[\uE000-\uE030\uE03B-\uF8FF]/u.test(raw)) throw Error("\u85AA\u8D44\u5305\u542B\u672A\u7ECF\u6838\u5BF9\u7684\u5B57\u4F53\u7F16\u7801");
    return raw.replace(/[\uE031-\uE03A]/gu, (c) => String(c.charCodeAt(0) - 57393)).normalize("NFKC").trim();
  }
  return raw.normalize("NFKC").trim();
}
const directMode = "salary-and-selected-ui";
const directHash = (v) => createHash("sha256").update(typeof v === "string" ? v : JSON.stringify(v)).digest("hex");
const directDay = (zone) => new Intl.DateTimeFormat("sv-SE", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
function directSalary(raw) {
  const m = /^(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)\s*[Kk](?:\s*[·•]\s*\d{1,2}薪)?$/.exec(raw);
  if (!m) return null;
  const minimumYuan = Number(m[1]) * 1e3, maximumYuan = Number(m[2]) * 1e3;
  return Number.isSafeInteger(minimumYuan) && Number.isSafeInteger(maximumYuan) && minimumYuan > 0 && maximumYuan >= minimumYuan ? { minimumYuan, maximumYuan, period: "month" } : null;
}
async function directClosedEvidence(read, c, url, selected, selector) {
  const exactSource = panelJobIdentity(c.jobSource), page = new URL(url), sameJob = page.origin + page.pathname === c.jobSource;
  if (url !== c.returnUrl && !sameJob) return null;
  const candidates = sameJob ? ["div:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1) > span:nth-of-type(1)"] : [PANEL.closedStatus, PANEL.contact];
  for (const markerSelector of candidates) {
    if (await read("count", markerSelector) !== 1) continue;
    const text = String(await read("read", markerSelector)).trim();
    if (text !== "\u804C\u4F4D\u5DF2\u5173\u95ED") continue;
    if (await read("url") !== url) throw Error("\u6838\u5BF9\u5173\u95ED\u6807\u8BB0\u671F\u95F4\u6765\u6E90\u53D8\u5316");
    return { kind: "boss-job-closed-proof", jobSource: c.jobSource, sourceUrl: url, sourceMode: sameJob ? "exact-job-detail-url" : "unique-selected-list-card", marker: text, selector: markerSelector, selected, selectionSelector: selector, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), aiCalled: false, websiteMessagesSent: 0 };
  }
  return null;
}
async function directSelected(template, signal, c, { requireImmediate = false } = {}) {
  const read = async (operation, selector, value) => {
    signal.throwIfAborted();
    return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
  };
  const id = panelJobIdentity(c.jobSource), url = await read("url");
  if (url !== c.returnUrl) {
    const closedEvidence2 = await directClosedEvidence(read, c, url, false, null);
    if (!closedEvidence2 || requireImmediate) throw Error("\u5F53\u524D\u68C0\u7D22\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55\uFF0C\u4E0D\u5916\u53D1");
    return { mode: directMode, jobSource: c.jobSource, selected: false, selector: null, salaryRaw: c.salaryRaw || "", salary: null, contactLabel: null, closed: true, closedEvidence: closedEvidence2, checkedAt: closedEvidence2.checkedAt };
  }
  const activeTotal = await read("count", ".job-card-wrap.active");
  const matchingActive = await read("count", ":is(" + id.cardSelector + "):is(.job-card-wrap.active *)");
  if (!Number.isSafeInteger(activeTotal) || activeTotal < 1 || activeTotal > 500 || matchingActive !== activeTotal) throw Error("\u5F53\u524D\u9009\u4E2D\u72B6\u6001\u5305\u542B\u5176\u4ED6\u5C97\u4F4D\u6216\u6CA1\u6709\u76EE\u6807\u5C97\u4F4D\uFF1B\u672A\u5916\u53D1");
  if (matchingActive > 1) {
    const count2 = await read("count", "div > div:nth-of-type(1) > li");
    if (!Number.isSafeInteger(count2) || count2 < 1 || count2 > 500) throw Error("\u5F53\u524D\u5217\u8868\u8303\u56F4\u65E0\u6548");
    let chosen = null;
    for (let position = 1; position <= count2; position++) {
      const card = "div:nth-of-type(" + position + ") > div:nth-of-type(1) > li:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1)";
      if (await read("count", ":is(" + card + "):is(.job-card-wrap.active *)") !== 1) continue;
      const link = card + " > a:nth-of-type(1)", href2 = new URL(await read("attribute", link, "href"), url);
      if (href2.origin + href2.pathname === c.jobSource) {
        chosen = { card, link };
        break;
      }
    }
    if (!chosen) throw Error("\u91CD\u590D\u9009\u4E2D\u5C55\u793A\u6CA1\u6709\u53EF\u6838\u5BF9\u7684\u5177\u4F53\u5C97\u4F4D\u5361\u7247");
    id.cardSelector = chosen.card;
    id.linkSelector = chosen.link;
  }
  id.linkSelector = ":is(" + id.linkSelector + "):is(.job-card-wrap.active *)";
  const active = ":is(" + id.cardSelector + "):is(.job-card-wrap.active *)";
  if (await read("count", active) !== 1 || await read("count", id.linkSelector) !== 1) throw Error("\u672C\u9879\u5C97\u4F4D\u672A\u5904\u4E8E\u552F\u4E00\u9009\u4E2D\u72B6\u6001");
  const href = new URL(await read("attribute", id.linkSelector, "href"), url);
  if (href.origin + href.pathname !== c.jobSource || await read("url") !== url) throw Error("\u9009\u4E2D\u5C97\u4F4D\u6765\u6E90\u53D8\u5316");
  const closedEvidence = await directClosedEvidence(read, c, url, true, active);
  if (closedEvidence) {
    if (requireImmediate) throw Error("\u5C97\u4F4D\u5DF2\u5173\u95ED\uFF0C\u672A\u70B9\u51FB\u7ACB\u5373\u6C9F\u901A");
    return { mode: directMode, jobSource: c.jobSource, selected: true, selector: active, salaryRaw: c.salaryRaw || "", salary: null, contactLabel: null, closed: true, closedEvidence, checkedAt: closedEvidence.checkedAt };
  }
  const salarySelector = active + " .job-salary";
  if (await read("count", salarySelector) !== 1) throw Error("\u9009\u4E2D\u5C97\u4F4D\u85AA\u8D44\u4E0D\u552F\u4E00");
  const raw = String(await read("read", salarySelector)).trim(), codec = /[\uE000-\uF8FF]/u.test(raw) ? await panelFontCodec(read) : null, salaryRaw = panelSalary(raw, codec), salary = directSalary(salaryRaw);
  const count = await read("count", PANEL.contact), contactLabel = count === 1 ? String(await read("read", PANEL.contact)).trim() : null;
  if (!["\u7ACB\u5373\u6C9F\u901A", "\u7EE7\u7EED\u6C9F\u901A"].includes(contactLabel)) throw Error("\u9009\u4E2D\u5C97\u4F4D\u7684\u6C9F\u901A\u5165\u53E3\u5C1A\u672A\u5C31\u7EEA");
  if (requireImmediate && contactLabel !== "\u7ACB\u5373\u6C9F\u901A") throw Error("\u5F53\u524D\u4E0D\u662F\u7ACB\u5373\u6C9F\u901A\uFF0C\u672A\u91CD\u590D\u53D1\u9001");
  if (await read("count", active) !== 1 || await read("url") !== url) throw Error("\u6838\u5BF9\u671F\u95F4\u9009\u4E2D\u72B6\u6001\u53D8\u5316");
  return { mode: directMode, jobSource: c.jobSource, selected: true, selector: active, salaryRaw, salary, contactLabel, closed: false, closedEvidence: null, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
}
function directVerifiedClosed(c) {
  const p = c?.selection?.closedEvidence;
  return c?.closedObserved === true && c.selection?.closed === true && p?.kind === "boss-job-closed-proof" && p.jobSource === c.jobSource && p.marker === "\u804C\u4F4D\u5DF2\u5173\u95ED" && p.aiCalled === false && p.websiteMessagesSent === 0 && ["exact-job-detail-url", "unique-selected-list-card"].includes(p.sourceMode);
}
function directIntersection(salary, conditions) {
  return !!salary && (!conditions.salaryMin || salary.maximumYuan >= conditions.salaryMin) && (!conditions.salaryMax || salary.minimumYuan <= conditions.salaryMax);
}
function jobExclusionMatches(candidate, configuration) {
  const terms = configuration?.excludedRoles;
  if (!Array.isArray(terms) || terms.length > 20 || terms.some((v) => typeof v !== "string" || !v.trim() || v.length > 100)) throw Error("\u6392\u9664\u65B9\u5411\u914D\u7F6E\u65E0\u6548\uFF0C\u672A\u5916\u53D1");
  const title = candidate?.jobTitle;
  const cardText = candidate?.exclusionText ?? candidate?.leftCardText;
  if (typeof title !== "string" || !title.trim() || title.length > 1e3 || typeof cardText !== "string" || !cardText.trim() || cardText.length > 4e3) throw Error("\u5C97\u4F4D\u6807\u9898\u6216\u5361\u7247\u6765\u6E90\u7F3A\u5931\uFF0C\u672A\u5916\u53D1");
  const norm = (value) => value.normalize("NFKC").replace(/\s+/gu, " ").trim().toLocaleLowerCase("en-US");
  const source = norm(title + "\n" + cardText);
  return terms.filter((term) => source.includes(norm(term)));
}
var stdin_default = async ({ input, signal }) => {
  signal.throwIfAborted();
  const c = input?.candidate, f = input?.configuration;
  if (c?.kind !== "daily-verified-selected-candidate" || c.evaluationMode !== directMode || c.selected !== true && !directVerifiedClosed(c) || c.configurationRevision !== f?.configurationRevision || c.configuredDay !== f?.configuredDay || f.readyForLoop !== true || directDay(f.timeZone) !== f.configuredDay) throw Error("\u9009\u4E2D\u6765\u6E90\u6216\u672C\u6B21\u85AA\u8D44\u914D\u7F6E\u4E0D\u4E00\u81F4");
  const salary = directSalary(c.salaryRaw), checks = [];
  const titleScope = titleScopeEvidence(c.jobTitle, f.conditions);
  checks.push({ field: "\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u5141\u8BB8\u8BCD", state: titleScope.allowed ? "pass" : "mismatch", reason: titleScope.excluded.length ? "\u6807\u9898\u547D\u4E2D\u6392\u9664\u9879\uFF1A" + titleScope.excluded.join("\u3001") : titleScope.matched.length ? "\u6807\u9898\u547D\u4E2D\u5141\u8BB8\u8BCD\uFF1A" + titleScope.matched.join("\u3001") : "\u5B8C\u6574\u6807\u9898\u672A\u547D\u4E2D\u5141\u8BB8\u8BCD\uFF1B\u4E0D\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE" });
  const excluded = jobExclusionMatches(c, f.conditions);
  checks.push({ field: "\u5C97\u4F4D\u6807\u9898\u4E0E\u6807\u7B7E\u6392\u9664", state: excluded.length ? "mismatch" : "pass", reason: excluded.length ? "\u547D\u4E2D\u672C\u4EBA\u6392\u9664\u65B9\u5411\uFF1A" + excluded.join("\u3001") : "\u672A\u547D\u4E2D\u672C\u4EBA\u914D\u7F6E\u7684\u6392\u9664\u65B9\u5411" });
  checks.push({ field: "\u5217\u8868\u85AA\u8D44", state: directIntersection(salary, f.conditions) ? "pass" : "mismatch", reason: salary ? "\u6309\u4F7F\u7528\u8005\u914D\u7F6E\u6838\u5BF9\u6708\u85AA\u533A\u95F4\u4EA4\u96C6" : "\u85AA\u8D44\u65E0\u6CD5\u786E\u5B9A\uFF0C\u8DF3\u8FC7\u672C\u9879" });
  if (directVerifiedClosed(c)) checks.push({ field: "\u804C\u4F4D\u72B6\u6001", state: "mismatch", reason: "\u7F51\u7AD9\u660E\u786E\u663E\u793A\u804C\u4F4D\u5DF2\u5173\u95ED\uFF1B\u4E0D\u8FDB\u5165\u6A21\u578B\u6216\u5916\u53D1" });
  else if (c.contactLabel === "\u7EE7\u7EED\u6C9F\u901A") checks.push({ field: "\u6C9F\u901A\u72B6\u6001", state: "mismatch", reason: "\u5DF2\u6C9F\u901A\uFF0C\u8DF3\u8FC7\u9996\u6B21\u62DB\u547C" });
  else if (c.contactLabel === "\u7ACB\u5373\u7F51\u7533") checks.push({ field: "\u6C9F\u901A\u72B6\u6001", state: "mismatch", reason: "\u7F51\u7AD9\u4EC5\u63D0\u4F9B\u7ACB\u5373\u7F51\u7533\uFF0C\u4E0D\u5C5E\u4E8E\u672C\u6B21\u9996\u6B21\u6C9F\u901A\uFF1B\u8DF3\u8FC7\u4E14\u4E0D\u70B9\u51FB\u7F51\u7533" });
  else if (c.contactLabel !== "\u7ACB\u5373\u6C9F\u901A") throw Error("\u4E0D\u662F\u53EF\u7528\u7684\u6C9F\u901A\u5165\u53E3");
  const ready = checks.every((v) => v.state === "pass");
  return { version: 1, kind: "daily-job-hard-conditions", evaluationMode: directMode, status: ready ? "hard-conditions-ready-for-skill" : "hard-condition-mismatch", readyForSkillAssessment: ready, readyForFirstContact: ready, selectedSource: c, closedEvidence: directVerifiedClosed(c) ? c.selection.closedEvidence : null, jobTitle: c.jobTitle, jobSource: c.jobSource, actualCity: c.actualCity, jobCity: c.actualCity, configurationRevision: f.configurationRevision, configuredDay: f.configuredDay, position: c.position, salaryRaw: c.salaryRaw, salary, titleScope, checks, descriptionHash: null, decision: ready ? "\u6309\u85AA\u8D44\u53CA\u9009\u4E2D\u6001\u9996\u6B21\u6C9F\u901A" : "\u8DF3\u8FC7\u672C\u9879", skipped: !ready, needsUserReview: false, aiCalled: false, accountVerified: false, eligibleForActions: false, applied: false, dayTaskComplete: false, siteDailyLimitConfirmed: false, note: "\u4EC5\u5217\u8868\u85AA\u8D44\u4EA4\u96C6\u4E0E\u9009\u4E2D\u6001\u51B3\u5B9A\u9996\u6B21\u62DB\u547C\uFF1Blegacy readyForSkillAssessment\u5B57\u6BB5\u4EC5\u6CBF\u7528\u65E2\u6709\u5206\u652F\u5F15\u7528\uFF0C\u4E0D\u8BFB\u53D6Skill\u5185\u5BB9\u6216\u8C03\u7528AI\u5224\u65AD\u3002" };
};
export {
  stdin_default as default
};
