import { createHash } from "node:crypto";
const cursorCanonical = (value) => Array.isArray(value) ? value.map(cursorCanonical) : value && typeof value === "object" ? Object.fromEntries(Object.keys(value).sort().map((key) => [key, cursorCanonical(value[key])])) : value;
const cursorDigest = (value) => createHash("sha256").update(JSON.stringify(cursorCanonical(value))).digest("hex");
const cursorCard = (position) => "div:nth-of-type(" + position + ") > div:nth-of-type(1) > li:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1)";
function cursorJob(href, base) {
  const u = new URL(href, base), match = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(u.pathname);
  if (u.origin !== "https://www.zhipin.com" || u.username || u.password || u.hash || !match)
    throw Error("\u589E\u91CF\u4F4D\u7F6E\u7F3A\u5C11\u51C6\u786E\u5C97\u4F4D\u94FE\u63A5");
  return { jobId: match[1], jobSource: u.origin + u.pathname };
}
async function openIncrementalCursor(template, signal, scope) {
  const fields = ["accountKey", "contextId", "configurationRevision", "day", "timeZone", "searchUrl"];
  if (!scope || fields.some((key) => scope[key] === void 0) || !/^[a-f0-9]{64}$/.test(scope.accountKey) || !scope.contextId || !Number.isSafeInteger(scope.configurationRevision) || !/^\d{4}-\d{2}-\d{2}$/.test(scope.day)) throw Error("\u589E\u91CF\u4F4D\u7F6E\u7F3A\u5C11\u56FA\u5B9A\u8303\u56F4");
  const u = new URL(scope.searchUrl);
  if (u.origin !== "https://www.zhipin.com" || u.pathname !== "/web/geek/jobs" || u.username || u.password || u.hash || !u.searchParams.get("query")) throw Error("\u589E\u91CF\u68C0\u7D22\u6765\u6E90\u65E0\u6548");
  const name = "single-job-list-v1-" + scope.accountKey + "-" + cursorDigest(scope).slice(0, 32) + ".json";
  let original = null, data;
  try {
    original = await template.file("communication-cache", { operation: "read", name });
  } catch (error) {
    if (!String(error.message || error).includes("ENOENT")) throw error;
  }
  if (original !== null) {
    data = JSON.parse(original);
    const { sha256, ...body } = data;
    if (sha256 !== cursorDigest(body) || data.version !== 1 || data.kind !== "boss-single-job-list-cursor" || fields.some((key) => data[key] !== scope[key]) || !Number.isSafeInteger(data.revision) || data.revision < 0 || !Number.isSafeInteger(data.through) || data.through < 0 || !Number.isSafeInteger(data.listCount) || data.listCount < data.through || data.listCount > 500 || data.through > 0 && typeof data.throughId !== "string" || typeof data.exhausted !== "boolean")
      throw Error("\u5DF2\u4FDD\u5B58\u7684\u589E\u91CF\u4F4D\u7F6E\u8EAB\u4EFD\u3001\u6458\u8981\u6216\u7ED3\u6784\u65E0\u6548\uFF1B\u672A\u6E05\u7A7A\u91CD\u5EFA");
  } else data = {
    version: 1,
    kind: "boss-single-job-list-cursor",
    ...scope,
    revision: 0,
    through: 0,
    throughId: null,
    listCount: 0,
    firstId: null,
    tailId: null,
    exhausted: false,
    lastLoad: null
  };
  const plan = (patch) => {
    const next = { ...data, ...patch, revision: data.revision + 1 };
    delete next.sha256;
    next.sha256 = cursorDigest(next);
    return { version: 1, name, scope, beforeSha256: original === null ? null : createHash("sha256").update(original).digest("hex"), value: next };
  };
  const save = async (update) => {
    signal.throwIfAborted();
    if (!update || update.name !== name || cursorDigest(update.scope) !== cursorDigest(scope) || update.beforeSha256 !== (original === null ? null : createHash("sha256").update(original).digest("hex")))
      throw Error("\u589E\u91CF\u4F4D\u7F6E\u5199\u5165\u8BA1\u5212\u6765\u6E90\u4E0D\u7B26");
    const { sha256, ...body } = update.value;
    if (sha256 !== cursorDigest(body) || body.revision !== data.revision + 1)
      throw Error("\u589E\u91CF\u4F4D\u7F6E\u5199\u5165\u8BA1\u5212\u6458\u8981\u6216\u4FEE\u8BA2\u4E0D\u7B26");
    let before = null;
    try {
      before = await template.file("communication-cache", { operation: "read", name });
    } catch (error) {
      if (!String(error.message || error).includes("ENOENT")) throw error;
    }
    if (before !== original) throw Error("\u589E\u91CF\u4F4D\u7F6E\u5DF2\u88AB\u5176\u4ED6\u64CD\u4F5C\u4FEE\u6539\uFF0C\u505C\u6B62\u8986\u76D6");
    const content = JSON.stringify(update.value);
    await template.file("communication-cache", { operation: "write", name, content });
    if (await template.file("communication-cache", { operation: "read", name }) !== content)
      throw Error("\u589E\u91CF\u4F4D\u7F6E\u4FDD\u5B58\u540E\u672A\u5B8C\u6574\u8BFB\u56DE");
    data = update.value;
    original = content;
    return { name, revision: data.revision, through: data.through, listCount: data.listCount, sha256: data.sha256 };
  };
  return { name, get data() {
    return data;
  }, plan, save };
}
async function observeIncrementalPosition(read, cursor, count, searchUrl) {
  if (!Number.isSafeInteger(count) || count < 1 || count > 500) throw Error("\u589E\u91CF\u5217\u8868\u5C1A\u672A\u5C31\u7EEA\u6216\u8D85\u51FA\u8BFB\u53D6\u8303\u56F4");
  const idAt = async (position) => cursorJob(await read({ operation: "attribute", selector: cursorCard(position) + " > a:nth-of-type(1)", value: "href" }), searchUrl).jobId;
  const firstId = await idAt(1), tailId = await idAt(count), old = cursor.data;
  let through = old.through, restored = false;
  const anchorMatches = through === 0 || through <= count && await idAt(through) === old.throughId;
  const appendMatches = old.listCount === 0 || count >= old.listCount && firstId === old.firstId && await idAt(old.listCount) === old.tailId;
  if (!anchorMatches || !appendMatches) {
    if (!old.throughId) throw Error("\u5217\u8868\u5237\u65B0\u540E\u6CA1\u6709\u53EF\u6838\u5BF9\u7684\u5DF2\u5904\u7406\u951A\u70B9\uFF1B\u672A\u6309\u65E7\u5E8F\u53F7\u7EE7\u7EED");
    const matches = [];
    for (let position = 1; position <= count; position++) if (await idAt(position) === old.throughId) matches.push(position);
    if (matches.length !== 1) throw Error("\u5217\u8868\u5237\u65B0\u6216\u91CD\u6392\u540E\u6062\u590D\u4F4D\u7F6E\u4E0D\u660E\u786E\uFF0C\u672A\u6E05\u7A7A\u8FDB\u5EA6\u6216\u731C\u6D4B\u4F4D\u7F6E");
    through = matches[0];
    restored = true;
  }
  if (await read({ operation: "url" }) !== searchUrl || await read({ operation: "count", selector: "div > div:nth-of-type(1) > li" }) !== count || await idAt(1) !== firstId || await idAt(count) !== tailId) throw Error("\u8BFB\u53D6\u589E\u91CF\u4F4D\u7F6E\u671F\u95F4\u5217\u8868\u53D8\u5316");
  return { through, throughId: through > 0 ? await idAt(through) : null, listCount: count, firstId, tailId, restored };
}
var stdin_default = async ({ input, signal, template }) => {
  signal.throwIfAborted();
  const obj = (v) => !!v && typeof v === "object" && !Array.isArray(v), hash = (v) => createHash("sha256").update(JSON.stringify(v)).digest("hex");
  if (!obj(input) || Object.keys(input).sort().join(",") !== "account,configuration,fixedConfiguration,pass") throw Error("\u7F3A\u5C11\u6709\u9650\u53D1\u73B0\u7684\u56FA\u5B9A\u914D\u7F6E\u3001\u8D26\u53F7\u6216\u6B21\u6570");
  const { account: a, configuration: c, fixedConfiguration: raw, pass } = input;
  if (!Number.isSafeInteger(pass) || pass < 1 || pass > 24 || c?.kind !== "daily-apply-configuration" || c.readyForLoop !== true || c.configurationRevision !== raw?.revision || raw.operation !== "configuration" || raw.version !== 1 || !obj(raw.value) || !Number.isSafeInteger(c.batchSize) || c.batchSize < 1 || c.batchSize > 150 || c.timeZone !== raw.value.replyTimeZone || !Array.isArray(c.conditions?.cities) || !c.conditions.cities.length) throw Error("\u6709\u9650\u53D1\u73B0\u7684\u6B21\u6570\u3001\u914D\u7F6E\u6216\u57CE\u5E02\u65E0\u6548");
  for (const k of ["cities", "targetRoles", "excludedRoles", "salaryMin", "salaryMax"]) if (JSON.stringify(c.conditions[k]) !== JSON.stringify(raw.value[k])) throw Error("\u6709\u9650\u53D1\u73B0\u7684\u6574\u7406\u6761\u4EF6\u4E0E\u672C\u6B21\u56FA\u5B9A\u914D\u7F6E\u4E0D\u4E00\u81F4");
  const dayOf = (d) => new Intl.DateTimeFormat("sv-SE", { timeZone: c.timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(d), day = dayOf(/* @__PURE__ */ new Date());
  if (day !== c.configuredDay || a?.status !== "current-account-source-matched" || a.currentAccountVerified !== true || a.platformUniqueIdVerified !== false || a.eligibleForActions !== false || typeof a.accountName !== "string" || typeof a.phoneMask !== "string" || !Number.isFinite(Date.parse(a.checkedAt)) || Date.parse(a.checkedAt) > Date.now() || dayOf(new Date(a.checkedAt)) !== day) throw Error("\u6709\u9650\u53D1\u73B0\u671F\u95F4\u8D26\u53F7\u6765\u6E90\u6216\u65E5\u671F\u5DF2\u53D8\u5316");
  const resume = new URL(a.jobseekerResumeHref, a.sourceUrl);
  if (resume.origin !== "https://www.zhipin.com" || resume.pathname !== "/web/geek/resume" || resume.username || resume.password) throw Error("\u6709\u9650\u53D1\u73B0\u7F3A\u5C11\u6709\u6548\u6C42\u804C\u8005\u8D26\u53F7\u6765\u6E90");
  const accountHash = hash(["boss-visible-account-source-v1", a.accountName, a.phoneMask, resume.origin + resume.pathname]);
  const identity = (v, base2) => {
    if (typeof v !== "string" || !v.trim() || v.length > 4096 || v.trim() !== v || /[\u0000- \u007f…]/.test(v)) throw Error("\u53D1\u73B0\u94FE\u63A5\u7F3A\u5931\u3001\u7F29\u7565\u6216\u683C\u5F0F\u65E0\u6548");
    const u = new URL(v, base2), m = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(u.pathname);
    if (u.origin !== "https://www.zhipin.com" || u.username || u.password || u.hash || !m) throw Error("\u53D1\u73B0\u94FE\u63A5\u4E0D\u662F\u5B8C\u6574\u5B89\u5168\u7684\u72EC\u7ACB\u804C\u4F4D");
    return { key: hash(["boss-application-v1", accountHash, m[1]]), jobSource: u.origin + u.pathname };
  };
  const validateExistingIntents = (rows) => {
    const fields = ["accountSourceSha256", "batchId", "configurationRevision", "createdAt", "day", "jobId", "jobSource", "jobSourceSha256", "key", "profileVersionId", "resumeSha256", "status", "timeZone"].sort().join(",");
    if (!Array.isArray(rows) || rows.length > 500) throw Error("\u62DB\u547C\u610F\u56FE\u7F3A\u5931\u6216\u8D85\u8FC7\u5BB9\u91CF\uFF0C\u4E0D\u80FD\u6309\u7A7A\u8D26\u672C\u5904\u7406");
    const keys = /* @__PURE__ */ new Set();
    for (const r of rows) {
      signal.throwIfAborted();
      if (!obj(r) || Object.keys(r).sort().join(",") !== fields || r.accountSourceSha256 !== accountHash || r.timeZone !== c.timeZone || !["reserved", "confirmed", "failed", "unknown"].includes(r.status) || keys.has(r.key) || !["key", "jobSourceSha256", "resumeSha256"].every((k) => typeof r[k] === "string" && /^[a-f0-9]{64}$/.test(r[k])) || !Number.isSafeInteger(r.configurationRevision) || r.configurationRevision < 0 || typeof r.batchId !== "string" || !/^[a-f0-9-]{36}$/.test(r.batchId) || typeof r.profileVersionId !== "string" || !r.profileVersionId.trim() || r.profileVersionId.length > 200 || typeof r.createdAt !== "string" || typeof r.day !== "string") throw Error("\u62DB\u547C\u610F\u56FE\u635F\u574F\u3001\u8D26\u53F7\u6216\u65F6\u533A\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u6279");
      const id = identity(r.jobSource), at = new Date(r.createdAt), jobId = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(new URL(r.jobSource).pathname)?.[1];
      if (r.key !== id.key || r.jobSource !== id.jobSource || r.jobId !== jobId || !Number.isFinite(at.getTime()) || at.toISOString() !== r.createdAt || at.getTime() > Date.now() || dayOf(at) !== r.day || r.day > day) throw Error("\u62DB\u547C\u610F\u56FE\u65E5\u671F\u6216\u5B8C\u6574\u5C97\u4F4D\u8EAB\u4EFD\u4E0D\u4E00\u81F4\uFF0C\u505C\u6B62\u7EED\u6279");
      keys.add(r.key);
    }
    return rows.filter((r) => r.status === "reserved" || r.status === "unknown");
  };
  const state = await template.state.get();
  if (!obj(state) || Object.keys(state).sort().join(",") !== "applicationIntents,conversationControls,queueEntries,replyIntents" || !Array.isArray(state.queueEntries) || state.queueEntries.length > 1e3 || !Array.isArray(state.applicationIntents)) throw Error("\u53D1\u73B0\u524D\u6700\u65B0\u961F\u5217\u7ED3\u6784\u65E0\u6548\uFF0C\u4E0D\u80FD\u5F53\u7A7A\u72B6\u6001");
  const quarantined = validateExistingIntents(state.applicationIntents);
  const known = raw.value.knownContactedJobs ?? [];
  if (!Array.isArray(known) || known.length > 500) throw Error("\u5DF2\u6709\u6C9F\u901A\u6392\u9664\u9879\u683C\u5F0F\u65E0\u6548");
  if (known.length && (raw.value.knownContactAccountAlias !== a.accountAlias || raw.value.knownContactPhoneMask !== a.phoneMask)) throw Error("\u5DF2\u6709\u6C9F\u901A\u6392\u9664\u9879\u6240\u5C5E\u8D26\u53F7\u4E0E\u5F53\u524D\u8D26\u53F7\u4E0D\u7B26");
  const seen = /* @__PURE__ */ new Set(), intentKeys = /* @__PURE__ */ new Set();
  for (const r of state.applicationIntents) {
    intentKeys.add(r.key);
    seen.add(r.key);
  }
  for (const v of known) seen.add(identity(v).key);
  let pending = 0;
  for (const r of state.queueEntries) {
    if (r.accountSourceSha256 !== accountHash || r.timeZone !== c.timeZone || r.key !== identity(r.jobSource).key) throw Error("\u53D1\u73B0\u524D\u961F\u5217\u8D26\u53F7\u3001\u65F6\u533A\u6216\u5C97\u4F4D\u8EAB\u4EFD\u4E0D\u7B26");
    if (r.status === "unknown" && !intentKeys.has(r.key)) throw Error("\u672A\u77E5\u961F\u5217\u7F3A\u5C11\u540C\u5C97\u4F4D\u62DB\u547C\u610F\u56FE\uFF0C\u505C\u6B62\u7EED\u6279");
    seen.add(r.key);
    if (["queued", "processing"].includes(r.status) && r.configurationRevision === raw.revision && r.day === day && !intentKeys.has(r.key) && !known.some((v) => identity(v).key === r.key)) pending++;
  }
  const base = { version: 1, kind: "daily-discovery-scroll-check", pass, configurationRevision: raw.revision, configuredDay: day, timeZone: c.timeZone, accountSourceSha256: accountHash, batchSize: c.batchSize, pending, quarantinedCount: quarantined.length, eligibleForActions: false, dayTaskComplete: false, siteDailyLimitConfirmed: false };
  if (pending > 0) return { ...base, shouldScroll: false, reason: "\u6301\u4E45\u961F\u5217\u5DF2\u6709\u8DB3\u591F\u672C\u6279\u5019\u9009\uFF0C\u8DF3\u8FC7\u672C\u6B21\u6EDA\u52A8" };
  const read = (command) => {
    signal.throwIfAborted();
    return template.browser("browser", { ...command, timeoutMs: 1e4 });
  };
  const citySelector = "body > div:nth-of-type(1) > div:nth-of-type(2) > div:nth-of-type(2) > div > div:nth-of-type(1) > span", cards = "div > div:nth-of-type(1) > li";
  const searchUrl = await read({ operation: "url" }), page = new URL(searchUrl), city = await read({ operation: "read", selector: citySelector }), count = await read({ operation: "count", selector: cards });
  if (page.origin !== "https://www.zhipin.com" || page.pathname !== "/web/geek/jobs" || page.username || page.password || page.hash || !Array.isArray(c.conditions.targetRoles) || !c.conditions.targetRoles.some((role) => role.trim() === page.searchParams.get("query")) || searchUrl.length > 4096 || typeof city !== "string" || !c.conditions.cities.includes(city.trim()) || !Number.isSafeInteger(count) || count < 1 || count > 500) throw Error("\u53D1\u73B0\u524D\u5B9E\u9645\u57CE\u5E02\u3001\u9875\u9762\u6216\u5019\u9009\u6570\u91CF\u4E0D\u7B26");
  const cursor = await openIncrementalCursor(template, signal, { accountKey: accountHash, contextId: raw.contextId, configurationRevision: raw.revision, day, timeZone: c.timeZone, searchUrl });
  const position = await observeIncrementalPosition(read, cursor, count, searchUrl);
  const currentPending = state.queueEntries.filter((r) => r.status === "queued" && r.configurationRevision === raw.revision && r.day === day && r.searchUrl === searchUrl && !intentKeys.has(r.key)).length;
  const available = count - position.through;
  const shouldScroll = currentPending === 0 && available === 0 && !(cursor.data.exhausted && cursor.data.lastLoad?.scrollTarget === "body" && cursor.data.lastLoad?.region === "document" && cursor.data.lastLoad?.heightAfter > cursor.data.lastLoad?.viewportAfter);
  return {
    ...base,
    actualCity: city.trim(),
    searchUrl,
    visibleCount: count,
    newLinkCount: available,
    shouldScroll,
    cursorScope: cursor.data.searchUrl ? { accountKey: accountHash, contextId: raw.contextId, configurationRevision: raw.revision, day, timeZone: c.timeZone, searchUrl } : null,
    reason: shouldScroll ? "\u5F53\u524D\u5DF2\u52A0\u8F7D\u5C97\u4F4D\u5904\u7406\u5B8C\uFF0C\u5141\u8BB8\u4E00\u6B21\u52A0\u8F7D\u5468\u671F" : "\u5F53\u524D\u5217\u8868\u4ECD\u6709\u672A\u5904\u7406\u5C97\u4F4D\u6216\u5DF2\u786E\u8BA4\u65E0\u65B0\u589E\uFF0C\u4E0D\u6EDA\u52A8"
  };
};
export {
  stdin_default as default
};
