import { createHash } from "node:crypto";
const PANEL = Object.freeze({
  title: "head > title",
  jobTitle: ".job-detail-container .job-name",
  jobCity: ".job-header-info .tag-list > :nth-child(1)",
  companyLabel: ".job-boss-info > :nth-child(2) > :nth-child(2)",
  description: ".job-detail-body > .desc",
  salary: ".job-detail-container .job-salary",
  closedStatus: ".job-detail-container .job-close",
  contact: ".job-detail-container div:nth-of-type(2) > a:nth-of-type(2)"
});
const panelClean = (v) => String(v).replace(/\s+/gu, " ").trim();
const panelCompany = (v) => String(v).trim().split(/\s+·\s+/u).slice(0, -1).join(" \xB7 ").trim();
function panelJobIdentity(source) {
  const u = new URL(source), m = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(u.pathname);
  if (u.origin !== "https://www.zhipin.com" || u.username || u.password || u.search || u.hash || !m) throw Error("\u5C97\u4F4D\u5B8C\u6574\u94FE\u63A5\u65E0\u6548");
  const hrefs = [u.pathname, u.href].flatMap((v) => ['[href="' + v + '"]', '[href^="' + v + '?"]']).join(",");
  const relative = "> div:nth-of-type(1) > div > a:is(" + hrefs + ")";
  return { jobId: m[1], cardSelector: ".job-card-box:has(" + relative + ")", linkSelector: ".job-card-box " + relative };
}
async function panelFontCodec(read) {
  const sources = ["https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/app~0.1e6caebe.css", "https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/8026.de407e2f.css"];
  for (const href of sources) {
    const selector = 'head > link[rel="stylesheet"][href="' + href + '"]';
    if (await read("count", selector) !== 1 || await read("attribute", selector, "href") !== href) throw Error("\u85AA\u8D44\u5B57\u4F53\u6765\u6E90\u53D8\u5316\uFF0C\u672A\u731C\u6D4B\u91D1\u989D");
  }
  return "kanzhun-mix-2023-digits-v1";
}
function panelSalary(raw, codec) {
  if (typeof raw !== "string" || !raw.trim() || raw.length > 256) throw Error("\u85AA\u8D44\u539F\u6587\u7F3A\u5931\u6216\u8D85\u957F");
  if (/[\uE000-\uF8FF]/u.test(raw)) {
    if (codec !== "kanzhun-mix-2023-digits-v1" || /[\uE000-\uE030\uE03B-\uF8FF]/u.test(raw)) throw Error("\u85AA\u8D44\u5305\u542B\u672A\u7ECF\u6838\u5BF9\u7684\u5B57\u4F53\u7F16\u7801");
    return raw.replace(/[\uE031-\uE03A]/gu, (c) => String(c.charCodeAt(0) - 57393)).normalize("NFKC").trim();
  }
  return raw.normalize("NFKC").trim();
}
const directMode = "salary-and-selected-ui";
const directHash = (v) => createHash("sha256").update(typeof v === "string" ? v : JSON.stringify(v)).digest("hex");
const directDay = (zone) => new Intl.DateTimeFormat("sv-SE", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
function directSalary(raw) {
  const m = /^(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)\s*[Kk](?:\s*[·•]\s*\d{1,2}薪)?$/.exec(raw);
  if (!m) return null;
  const minimumYuan = Number(m[1]) * 1e3, maximumYuan = Number(m[2]) * 1e3;
  return Number.isSafeInteger(minimumYuan) && Number.isSafeInteger(maximumYuan) && minimumYuan > 0 && maximumYuan >= minimumYuan ? { minimumYuan, maximumYuan, period: "month" } : null;
}
async function directSelected(template, signal, c, { requireImmediate = false } = {}) {
  const read = async (operation, selector, value) => {
    signal.throwIfAborted();
    return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
  };
  const id = panelJobIdentity(c.jobSource), url = await read("url");
  if (url !== c.returnUrl) throw Error("\u5F53\u524D\u68C0\u7D22\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55");
  const activeTotal = await read("count", ".job-card-wrap.active");
  const matchingActive = await read("count", ":is(" + id.cardSelector + "):is(.job-card-wrap.active *)");
  if (!Number.isSafeInteger(activeTotal) || activeTotal < 1 || activeTotal > 500 || matchingActive !== activeTotal) throw Error("\u5F53\u524D\u9009\u4E2D\u72B6\u6001\u5305\u542B\u5176\u4ED6\u5C97\u4F4D\u6216\u6CA1\u6709\u76EE\u6807\u5C97\u4F4D\uFF1B\u672A\u5916\u53D1");
  if (matchingActive > 1) {
    const count2 = await read("count", "div > div:nth-of-type(1) > li");
    if (!Number.isSafeInteger(count2) || count2 < 1 || count2 > 500) throw Error("\u5F53\u524D\u5217\u8868\u8303\u56F4\u65E0\u6548");
    let chosen = null;
    for (let position = 1; position <= count2; position++) {
      const card = "div:nth-of-type(" + position + ") > div:nth-of-type(1) > li:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1)";
      if (await read("count", ":is(" + card + "):is(.job-card-wrap.active *)") !== 1) continue;
      const link = card + " > a:nth-of-type(1)", href2 = new URL(await read("attribute", link, "href"), url);
      if (href2.origin + href2.pathname === c.jobSource) {
        chosen = { card, link };
        break;
      }
    }
    if (!chosen) throw Error("\u91CD\u590D\u9009\u4E2D\u5C55\u793A\u6CA1\u6709\u53EF\u6838\u5BF9\u7684\u5177\u4F53\u5C97\u4F4D\u5361\u7247");
    id.cardSelector = chosen.card;
    id.linkSelector = chosen.link;
  }
  id.linkSelector = ":is(" + id.linkSelector + "):is(.job-card-wrap.active *)";
  const active = ":is(" + id.cardSelector + "):is(.job-card-wrap.active *)";
  if (await read("count", active) !== 1 || await read("count", id.linkSelector) !== 1) throw Error("\u672C\u9879\u5C97\u4F4D\u672A\u5904\u4E8E\u552F\u4E00\u9009\u4E2D\u72B6\u6001");
  const salarySelector = active + " .job-salary";
  if (await read("count", salarySelector) !== 1) throw Error("\u9009\u4E2D\u5C97\u4F4D\u85AA\u8D44\u4E0D\u552F\u4E00");
  const raw = String(await read("read", salarySelector)).trim(), codec = /[\uE000-\uF8FF]/u.test(raw) ? await panelFontCodec(read) : null, salaryRaw = panelSalary(raw, codec), salary = directSalary(salaryRaw);
  const href = new URL(await read("attribute", id.linkSelector, "href"), url);
  if (href.origin + href.pathname !== c.jobSource || await read("url") !== url) throw Error("\u9009\u4E2D\u5C97\u4F4D\u6765\u6E90\u53D8\u5316");
  let contactLabel = null, closed = false;
  const count = await read("count", PANEL.contact);
  if (count === 1) contactLabel = String(await read("read", PANEL.contact)).trim();
  else if (count === 0) closed = String(await read("read", "body")).split(/\r?\n/u).some((v) => v.trim() === "\u804C\u4F4D\u5DF2\u5173\u95ED");
  if (!closed && !["\u7ACB\u5373\u6C9F\u901A", "\u7EE7\u7EED\u6C9F\u901A"].includes(contactLabel)) throw Error("\u9009\u4E2D\u5C97\u4F4D\u7684\u6C9F\u901A\u5165\u53E3\u5C1A\u672A\u5C31\u7EEA");
  if (requireImmediate && contactLabel !== "\u7ACB\u5373\u6C9F\u901A") throw Error("\u5F53\u524D\u4E0D\u662F\u7ACB\u5373\u6C9F\u901A\uFF0C\u672A\u91CD\u590D\u53D1\u9001");
  if (await read("count", active) !== 1 || await read("url") !== url) throw Error("\u6838\u5BF9\u671F\u95F4\u9009\u4E2D\u72B6\u6001\u53D8\u5316");
  return { mode: directMode, jobSource: c.jobSource, selected: true, selector: active, salaryRaw, salary, contactLabel, closed, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
}
function directIntersection(salary, conditions) {
  return !!salary && (!conditions.salaryMin || salary.maximumYuan >= conditions.salaryMin) && (!conditions.salaryMax || salary.minimumYuan <= conditions.salaryMax);
}
var stdin_default = async ({ input, signal }) => {
  signal.throwIfAborted();
  const p = input;
  if (p?.kind !== "direct-first-contact-prepared" || p.ready !== true || p.evaluationMode !== directMode || p.aiCalled !== false || p.source?.kind !== "selected-card-salary-source" || p.source.selectedSource?.selected !== true) throw Error("\u7F3A\u5C11\u76F4\u63A5\u62DB\u547C\u7684\u85AA\u8D44\u53CA\u9009\u4E2D\u6765\u6E90");
  return { version: 1, kind: "direct-contact-rule-result", aiCalled: false, result: { version: 1, kind: "direct-salary-selection-decision", evaluationMode: directMode, decision: "match", source: p.source, issues: [], aiCalled: false, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), reason: "\u4F7F\u7528\u8005\u5DF2\u9009\u62E9\uFF1A\u5217\u8868\u85AA\u8D44\u6709\u4EA4\u96C6\u4E14\u5C97\u4F4D\u9009\u4E2D\u5373\u9996\u6B21\u6C9F\u901A\uFF0C\u4E0D\u4F5CJD\u3001\u516C\u53F8\u6216AI\u5339\u914D", accountVerified: false, eligibleForActions: false } };
};
export {
  stdin_default as default
};
