import { createHash as w } from "node:crypto";
const l = (t) => Array.isArray(t) ? t.map(l) : t && typeof t == "object" ? Object.fromEntries(Object.keys(t).sort().map((r) => [r, l(t[r])])) : t, h = (t) => w("sha256").update(JSON.stringify(l(t))).digest("hex"), y = (t, r) => (o, i, e) => (r.throwIfAborted(), t.browser("browser", { operation: o, ...i ? { selector: i } : {}, ...e === void 0 ? {} : { value: e }, timeoutMs: 3e3 }));
async function g(t, r, o) {
  const i = new URL(await t("url"));
  if (i.origin !== "https://www.zhipin.com" || i.pathname !== "/web/geek/chat" || String(await t("read", r.recipientSelector)).trim() !== r.recipientLabel || String(await t("read", r.accountSelector)).trim() !== r.accountLabel || await t("count", 'li.message-item[data-mid="' + r.firstMessageId + '"]') !== 1) throw Error("\u5F53\u524D\u8D26\u53F7\u6216\u4F1A\u8BDD\u6D88\u606F\u94FE\u53D8\u5316\uFF0C\u4E0D\u64CD\u4F5C");
  if (((await o.state.get()).conversationControls || []).some((a) => a.accountKey === r.accountKey && [r.conversationKey, "boss-chat:" + r.firstMessageId].includes(a.conversationKey) && a.mode === "paused")) throw Error("\u672C\u4EBA\u5DF2\u63A5\u7BA1\u4F1A\u8BDD");
}
async function v(t) {
  const r = await t("count", "li.message-item");
  if (!Number.isSafeInteger(r) || r < 1 || r > 100) throw Error("\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u8303\u56F4\u65E0\u6548");
  const o = [];
  for (let i = 1; i <= r; i++) {
    const e = "li.message-item:nth-child(" + i + " of li.message-item)", a = await t("attribute", e, "data-mid"), s = String(await t("attribute", e, "class") || ""), n = String(await t("read", e)).trim();
    if (!/^\d{6,40}$/u.test(a || "") || n.length > 2e4) throw Error("\u539F\u751F\u6D88\u606F\u8EAB\u4EFD\u4E0D\u5B8C\u6574");
    o.push({ mid: a, cls: s, text: n });
  }
  return o;
}
async function b(t, r) {
  const o = "resume-delivery-index-v1-" + r.accountKey + ".json";
  let i = null;
  try {
    i = await t.file("communication-cache", { operation: "read", name: o });
  } catch (s) {
    if (!String(s.message || s).includes("ENOENT")) throw s;
  }
  const e = i ? JSON.parse(i) : { version: 1, kind: "boss-resume-delivery-index", accountKey: r.accountKey, revision: 0, uploads: [], deliveries: [] };
  if (i) {
    const { sha256: s, ...n } = e;
    if (s !== h(n)) throw Error("\u539F\u9644\u4EF6\u8D26\u672C\u6458\u8981\u4E0D\u7B26");
  }
  if (e.accountKey !== r.accountKey || e.kind !== "boss-resume-delivery-index" || !Array.isArray(e.deliveries) || !Array.isArray(e.uploads) || e.deliveries.length > 2e3 || new Set(e.deliveries.map((s) => s.key)).size !== e.deliveries.length) throw Error("\u539F\u9644\u4EF6\u8D26\u672C\u7ED3\u6784\u4E0D\u7B26");
  return { book: e, save: async () => {
    let s = null;
    try {
      s = await t.file("communication-cache", { operation: "read", name: o });
    } catch (c) {
      if (!String(c.message || c).includes("ENOENT")) throw c;
    }
    if (s !== i) throw Error("\u9644\u4EF6\u8D26\u672C\u5E76\u53D1\u53D8\u5316");
    e.revision++, e.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete e.sha256, e.sha256 = h(e);
    const n = JSON.stringify(e);
    if (await t.file("communication-cache", { operation: "write", name: o, content: n }), await t.file("communication-cache", { operation: "read", name: o }) !== n) throw Error("\u9644\u4EF6\u8D26\u672C\u672A\u51C6\u786E\u8BFB\u56DE");
    i = n;
  } };
}
async function stdin_default({ input: t, template: r, signal: o, artifact: i }) {
  const e = t?.source;
  if (e?.kind !== "boss-resume-request-source") throw Error("\u7F3A\u5C11\u539F\u751F\u9644\u4EF6\u6765\u6E90");
  if (!e.ready) return { ...e, kind: "boss-native-resume-preparation", execute: false };
  const a = String(t.fileName || "").trim();
  if (!a || a.length > 1e3 || !a.toLowerCase().endsWith(".pdf")) throw Error("\u987B\u586B\u5199\u672C\u4EBA\u786E\u8BA4\u7684\u7F51\u7AD9PDF\u5B8C\u6574\u540D\u79F0");
  const s = y(r, o);
  await g(s, e, r);
  const { book: n, save: c } = await b(r, e), u = [];
  for (const d of e.requests) if (!n.deliveries.find((f) => f.key === d.key || f.requestMid === d.mid)) {
    if (n.deliveries.length >= 2e3) throw Error("\u9644\u4EF6\u8D26\u672C\u5BB9\u91CF\u5DF2\u6EE1");
    n.deliveries.push({ key: d.key, requestMid: d.mid, firstMessageId: e.firstMessageId, memberKey: e.member.key, recipientLabel: e.recipientLabel, jobSource: e.jobSource, file: { displayName: a, mode: "native-existing-attachment", serverBytesVerified: false }, status: "reserved", sourceSha256: e.sourceSha256, createdAt: (/* @__PURE__ */ new Date()).toISOString() }), u.push(d.key);
  }
  u.length && await c();
  const m = { ...e, kind: "boss-native-resume-preparation", execute: u.length > 0, fileName: a, freshKeys: u, status: u.length ? "native-resume-reserved" : "existing-resume-intent-no-replay" };
  return await i("native-resume-preparation.json", JSON.stringify(m)), m;
}
export {
  stdin_default as default
};
