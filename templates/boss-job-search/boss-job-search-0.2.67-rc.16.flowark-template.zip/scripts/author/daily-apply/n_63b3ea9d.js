import "node:crypto";
const k = /* @__PURE__ */ (() => {
  const l = (d) => Array.isArray(d) ? d.map(l) : d && typeof d == "object" ? Object.fromEntries(Object.keys(d).sort().map((o) => [o, l(d[o])])) : d, p = (d) => K("sha256").update(JSON.stringify(l(d))).digest("hex");
  async function C({ input: d, template: o, signal: D, artifact: B }) {
    const e = d, n = "wechat";
    if (!["wechat", "phone"].includes(n) || e?.kind !== "chat-reply-source" || !e.fixedUnreadMember || !e.member?.key) throw Error("\u539F\u751F\u4EA4\u6362\u7F3A\u5C11\u56FA\u5B9A\u6210\u5458\u6765\u6E90");
    const F = { version: 1, kind: "boss-native-contact-result", contactType: n, memberKey: e.member.key, actions: [], websiteMessagesSent: 0 };
    if (e.ownedConversation !== true || !e.jobId || ["job-title-outside-configured-scope", "rejected-no-reply", "manual-control", "already-completed", "fixed-unread-complete"].includes(e.status)) return { ...F, status: "skipped", reason: e.reason };
    const r = async (t, u, m) => {
      D.throwIfAborted();
      const a = await o.browser("browser", { operation: t, ...u ? { selector: u } : {}, ...m === void 0 ? {} : { value: m }, timeoutMs: 3e3 });
      return D.throwIfAborted(), a;
    }, E = async () => {
      const t = new URL(await r("url"));
      if (t.origin !== "https://www.zhipin.com" || t.pathname !== "/web/geek/chat" || await r("count", e.recipientSelector) !== 1 || String(await r("read", e.recipientSelector)).trim() !== e.recipientLabel || String(await r("read", e.accountSelector)).trim() !== e.accountLabel) throw Error("\u539F\u751F\u4EA4\u6362\u8D26\u53F7\u3001\u5BF9\u8C61\u6216\u5C97\u4F4D\u53D8\u5316");
      if (((await o.state.get()).conversationControls || []).some((u) => u.accountKey === e.accountKey && [e.conversationKey, "boss-chat:" + e.rows[0].mid].includes(u.conversationKey) && u.mode === "paused")) throw Error("\u4F1A\u8BDD\u5DF2\u7531\u672C\u4EBA\u63A5\u7BA1");
    };
    await E();
    const b = "native-contact-index-v1-" + e.accountKey + ".json";
    let c, g = null;
    try {
      g = await o.file("communication-cache", { operation: "read", name: b }), c = JSON.parse(g);
      const { sha256: t, ...u } = c;
      if (t !== p(u) || c.accountKey !== e.accountKey || c.kind !== "boss-native-contact-index" || !Array.isArray(c.actions)) throw Error("\u539F\u751F\u4EA4\u6362\u8D26\u672C\u4E0D\u7B26");
    } catch (t) {
      if (!String(t.message || t).includes("ENOENT")) throw t;
      c = { version: 1, kind: "boss-native-contact-index", accountKey: e.accountKey, revision: 0, actions: [] };
    }
    const h = async () => {
      let t = null;
      try {
        t = await o.file("communication-cache", { operation: "read", name: b });
      } catch (m) {
        if (!String(m.message || m).includes("ENOENT")) throw m;
      }
      if (t !== g) throw Error("\u539F\u751F\u4EA4\u6362\u8D26\u672C\u5E76\u53D1\u53D8\u5316");
      c.revision++, delete c.sha256, c.sha256 = p(c);
      const u = JSON.stringify(c);
      if (await o.file("communication-cache", { operation: "write", name: b, content: u }), await o.file("communication-cache", { operation: "read", name: b }) !== u) throw Error("\u4EA4\u6362\u8BB0\u5F55\u672A\u5B8C\u6574\u8BFB\u56DE");
      g = u;
    }, v = [], A = await r("count", "li.message-item");
    if (!Number.isSafeInteger(A) || A > 500) throw Error("\u6D88\u606F\u6570\u91CF\u65E0\u6CD5\u6838\u5BF9");
    for (let t = 1; t <= A; t++) {
      const u = "li.message-item:nth-of-type(" + t + ")", m = String(await r("attribute", u, "class") || ""), a = String(await r("read", u)).trim();
      if (!m.split(/\s/u).includes("item-friend") || !(n === "wechat" ? /交换微信/u : /交换(?:手机号|手机号码|电话)/u).test(a) || !/(?:希望|想|请求|是否同意)/u.test(a)) continue;
      const s = await r("attribute", u, "data-mid");
      if (typeof s != "string" || !/^\d+$/u.test(s)) throw Error("\u539F\u751F\u8BF7\u6C42\u7F16\u53F7\u7F3A\u5931");
      const i = 'li.message-item[data-mid="' + s + '"]', w = await r("count", i + " .card-btn");
      let f = null;
      for (let y = 1; y <= w; y++) {
        const S = i + " .card-btn:nth-child(" + y + ")";
        if (await r("count", S) === 1 && String(await r("read", S)).trim() === "\u540C\u610F") {
          if (f) throw Error("\u4EA4\u6362\u540C\u610F\u63A7\u4EF6\u4E0D\u552F\u4E00");
          f = S;
        }
      }
      f ? v.push({ mid: s, root: i, text: a, agree: f }) : /已同意|已交换|已拒绝|已取消|已过期/u.test(a) || (F.actions.push({ requestMid: s, status: "todo", reason: "\u539F\u751F\u8BF7\u6C42\u63A7\u4EF6\u5C1A\u672A\u6838\u5B9E" }), await o.attention({ key: p(["contact-control-review", e.accountKey, s, n]), title: "\u8054\u7CFB\u65B9\u5F0F\u8BF7\u6C42\u5F85\u6838\u5BF9", detail: { contact: e.recipientLabel, jobSource: e.jobSource, contactType: n, requestMid: s } }));
    }
    for (const t of v) {
      const u = p(["boss-native-contact-v1", e.accountKey, e.rows[0].mid, t.mid, n]), m = c.actions.find((i) => i.key === u || i.requestMid === t.mid && i.contactType === n);
      if (m) {
        F.actions.push({ requestMid: t.mid, status: "existing-no-replay", priorStatus: m.status });
        continue;
      }
      if (await E(), String(await r("read", t.root)).trim() !== t.text || String(await r("read", t.agree)).trim() !== "\u540C\u610F") throw Error("\u4EA4\u6362\u8BF7\u6C42\u5DF2\u53D8\u5316");
      const a = { key: u, contactType: n, requestMid: t.mid, firstMessageId: e.rows[0].mid, memberKey: e.member.key, recipientLabel: e.recipientLabel, jobSource: e.jobSource, contextId: e.contextId, status: "reserved", createdAt: (/* @__PURE__ */ new Date()).toISOString() };
      c.actions.push(a), await h();
      const s = await o.effect.prepare({ action: n === "wechat" ? "exchange-wechat" : "exchange-phone", key: u, description: "\u539F\u751F\u540C\u610F\u5F53\u524D\u56FA\u5B9A\u4F1A\u8BDD\u7684" + (n === "wechat" ? "\u5FAE\u4FE1" : "\u624B\u673A\u53F7") + "\u4EA4\u6362\u8BF7\u6C42" });
      if (a.effectId = s.id, await h(), !s.execute) {
        a.status = "unknown", await h(), F.actions.push({ requestMid: t.mid, status: "existing-effect-no-replay" });
        continue;
      }
      try {
        if (await E(), String(await r("read", t.root)).trim() !== t.text || String(await r("read", t.agree)).trim() !== "\u540C\u610F") throw Error("\u70B9\u51FB\u524D\u4EA4\u6362\u8BF7\u6C42\u53D8\u5316");
        await r("click", t.agree);
        let i = null;
        for (let w = 0; w < 20; w++) {
          await E();
          const f = String(await r("read", t.root)).trim();
          if (f !== t.text && /已同意|已交换|交换成功/u.test(f)) {
            i = { requestMid: t.mid, text: f, observedAt: (/* @__PURE__ */ new Date()).toISOString() };
            break;
          }
          await new Promise((y) => setTimeout(y, 250));
        }
        if (!i) throw Error("\u672A\u53D6\u5F97\u539F\u751F\u4EA4\u6362\u660E\u786E\u56DE\u6267");
        if (a.status = "confirmed", a.agreementConfirmed = true, a.receipt = i, await h(), await o.effect.resolve({ id: s.id, state: "confirmed", evidence: i }), F.actions.push({ requestMid: t.mid, status: "confirmed", receipt: i }), n === "wechat") {
          const w = /(?:微信号|微信账号)\s*[:：]\s*([A-Za-z][A-Za-z0-9_-]{5,19}|\d{6,20})(?![A-Za-z0-9_-])/u.exec(i.text);
          a.contactValueObserved = !!w, await h(), await o.attention({ key: p(["boss-wechat-contact", e.accountKey, e.rows[0].mid, t.mid]), title: w ? "\u5DF2\u53D6\u5F97\u8054\u7CFB\u4EBA\u5FAE\u4FE1\u53F7" : "\u5FAE\u4FE1\u4EA4\u6362\u5DF2\u540C\u610F\uFF0C\u53F7\u7801\u5F85\u6838\u5BF9", detail: { contact: e.recipientLabel, jobSource: e.jobSource, requestMid: t.mid, ...w ? { wechat: w[1] } : {}, source: "BOSS\u539F\u751F\u4EA4\u6362\u56DE\u6267", agreementConfirmed: true, contactValueObserved: !!w } });
        }
      } catch (i) {
        throw a.status === "confirmed" || (a.status = "unknown", a.reason = String(i.message || i), await h(), await o.effect.resolve({ id: s.id, state: "unknown", evidence: { requestMid: t.mid, reason: a.reason } }), await o.attention({ key: p(["contact-unknown", u]), title: "\u539F\u751F\u4EA4\u6362\u7ED3\u679C\u5F85\u6838\u5BF9\uFF0C\u8BF7\u52FF\u91CD\u590D\u64CD\u4F5C", detail: { contact: e.recipientLabel, jobSource: e.jobSource, requestMid: t.mid, contactType: n, reason: a.reason } })), i;
      }
    }
    return F.status = F.actions.length ? "processed" : "no-pending-request", await B("native-" + n + "-result.json", JSON.stringify(F, null, 2)), F;
  }
  return C;
})(), x = async function() {
  return { version: 1, kind: "boss-native-contact-result", status: "unknown-review-no-native-replay", actions: [] };
};
async function q(l) {
  return l.input?.unknownRecovery ? x(l) : k(l);
}
export {
  q as default
};
