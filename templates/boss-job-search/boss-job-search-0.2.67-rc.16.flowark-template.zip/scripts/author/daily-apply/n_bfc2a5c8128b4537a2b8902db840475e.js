import { createHash } from "node:crypto";
const PANEL = Object.freeze({
  title: "head > title",
  jobTitle: ".job-detail-container .job-name",
  jobCity: ".job-header-info .tag-list > :nth-child(1)",
  companyLabel: ".job-boss-info > :nth-child(2) > :nth-child(2)",
  description: ".job-detail-body > .desc",
  salary: ".job-detail-container .job-salary",
  closedStatus: ".job-detail-container .job-close",
  contact: ".job-detail-container div:nth-of-type(2) > a:nth-of-type(2)"
});
const panelClean = (v) => String(v).replace(/\s+/gu, " ").trim();
const panelCompany = (v) => String(v).trim().split(/\s+·\s+/u).slice(0, -1).join(" \xB7 ").trim();
function panelJobIdentity(source) {
  const u = new URL(source), m = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(u.pathname);
  if (u.origin !== "https://www.zhipin.com" || u.username || u.password || u.search || u.hash || !m) throw Error("\u5C97\u4F4D\u5B8C\u6574\u94FE\u63A5\u65E0\u6548");
  const hrefs = [u.pathname, u.href].flatMap((v) => ['[href="' + v + '"]', '[href^="' + v + '?"]']).join(",");
  const relative = "> div:nth-of-type(1) > div > a:is(" + hrefs + ")";
  return { jobId: m[1], cardSelector: ".job-card-box:has(" + relative + ")", linkSelector: ".job-card-box " + relative };
}
async function panelFontCodec(read) {
  const sources = ["https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/app~0.1e6caebe.css", "https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/8026.de407e2f.css"];
  for (const href of sources) {
    const selector = 'head > link[rel="stylesheet"][href="' + href + '"]';
    if (await read("count", selector) !== 1 || await read("attribute", selector, "href") !== href) throw Error("\u85AA\u8D44\u5B57\u4F53\u6765\u6E90\u53D8\u5316\uFF0C\u672A\u731C\u6D4B\u91D1\u989D");
  }
  return "kanzhun-mix-2023-digits-v1";
}
function panelSalary(raw, codec) {
  if (typeof raw !== "string" || !raw.trim() || raw.length > 256) throw Error("\u85AA\u8D44\u539F\u6587\u7F3A\u5931\u6216\u8D85\u957F");
  if (/[\uE000-\uF8FF]/u.test(raw)) {
    if (codec !== "kanzhun-mix-2023-digits-v1" || /[\uE000-\uE030\uE03B-\uF8FF]/u.test(raw)) throw Error("\u85AA\u8D44\u5305\u542B\u672A\u7ECF\u6838\u5BF9\u7684\u5B57\u4F53\u7F16\u7801");
    return raw.replace(/[\uE031-\uE03A]/gu, (c) => String(c.charCodeAt(0) - 57393)).normalize("NFKC").trim();
  }
  return raw.normalize("NFKC").trim();
}
const directMode = "salary-and-selected-ui";
const directHash = (v) => createHash("sha256").update(typeof v === "string" ? v : JSON.stringify(v)).digest("hex");
const directDay = (zone) => new Intl.DateTimeFormat("sv-SE", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
function directSalary(raw) {
  const m = /^(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)\s*[Kk](?:\s*[·•]\s*\d{1,2}薪)?$/.exec(raw);
  if (!m) return null;
  const minimumYuan = Number(m[1]) * 1e3, maximumYuan = Number(m[2]) * 1e3;
  return Number.isSafeInteger(minimumYuan) && Number.isSafeInteger(maximumYuan) && minimumYuan > 0 && maximumYuan >= minimumYuan ? { minimumYuan, maximumYuan, period: "month" } : null;
}
async function directSelected(template, signal, c, { requireImmediate = false } = {}) {
  const read = async (operation, selector, value) => {
    signal.throwIfAborted();
    return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
  };
  const id = panelJobIdentity(c.jobSource), url = await read("url");
  if (url !== c.returnUrl) throw Error("\u5F53\u524D\u68C0\u7D22\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55");
  const activeTotal = await read("count", ".job-card-wrap.active");
  const matchingActive = await read("count", ":is(" + id.cardSelector + "):is(.job-card-wrap.active *)");
  if (!Number.isSafeInteger(activeTotal) || activeTotal < 1 || activeTotal > 500 || matchingActive !== activeTotal) throw Error("\u5F53\u524D\u9009\u4E2D\u72B6\u6001\u5305\u542B\u5176\u4ED6\u5C97\u4F4D\u6216\u6CA1\u6709\u76EE\u6807\u5C97\u4F4D\uFF1B\u672A\u5916\u53D1");
  if (matchingActive > 1) {
    const count2 = await read("count", "div > div:nth-of-type(1) > li");
    if (!Number.isSafeInteger(count2) || count2 < 1 || count2 > 500) throw Error("\u5F53\u524D\u5217\u8868\u8303\u56F4\u65E0\u6548");
    let chosen = null;
    for (let position = 1; position <= count2; position++) {
      const card = "div:nth-of-type(" + position + ") > div:nth-of-type(1) > li:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1)";
      if (await read("count", ":is(" + card + "):is(.job-card-wrap.active *)") !== 1) continue;
      const link = card + " > a:nth-of-type(1)", href2 = new URL(await read("attribute", link, "href"), url);
      if (href2.origin + href2.pathname === c.jobSource) {
        chosen = { card, link };
        break;
      }
    }
    if (!chosen) throw Error("\u91CD\u590D\u9009\u4E2D\u5C55\u793A\u6CA1\u6709\u53EF\u6838\u5BF9\u7684\u5177\u4F53\u5C97\u4F4D\u5361\u7247");
    id.cardSelector = chosen.card;
    id.linkSelector = chosen.link;
  }
  id.linkSelector = ":is(" + id.linkSelector + "):is(.job-card-wrap.active *)";
  const active = ":is(" + id.cardSelector + "):is(.job-card-wrap.active *)";
  if (await read("count", active) !== 1 || await read("count", id.linkSelector) !== 1) throw Error("\u672C\u9879\u5C97\u4F4D\u672A\u5904\u4E8E\u552F\u4E00\u9009\u4E2D\u72B6\u6001");
  const salarySelector = active + " .job-salary";
  if (await read("count", salarySelector) !== 1) throw Error("\u9009\u4E2D\u5C97\u4F4D\u85AA\u8D44\u4E0D\u552F\u4E00");
  const raw = String(await read("read", salarySelector)).trim(), codec = /[\uE000-\uF8FF]/u.test(raw) ? await panelFontCodec(read) : null, salaryRaw = panelSalary(raw, codec), salary = directSalary(salaryRaw);
  const href = new URL(await read("attribute", id.linkSelector, "href"), url);
  if (href.origin + href.pathname !== c.jobSource || await read("url") !== url) throw Error("\u9009\u4E2D\u5C97\u4F4D\u6765\u6E90\u53D8\u5316");
  let contactLabel = null, closed = false;
  const count = await read("count", PANEL.contact);
  if (count === 1) contactLabel = String(await read("read", PANEL.contact)).trim();
  else if (count === 0) closed = String(await read("read", "body")).split(/\r?\n/u).some((v) => v.trim() === "\u804C\u4F4D\u5DF2\u5173\u95ED");
  if (!closed && !["\u7ACB\u5373\u6C9F\u901A", "\u7EE7\u7EED\u6C9F\u901A"].includes(contactLabel)) throw Error("\u9009\u4E2D\u5C97\u4F4D\u7684\u6C9F\u901A\u5165\u53E3\u5C1A\u672A\u5C31\u7EEA");
  if (requireImmediate && contactLabel !== "\u7ACB\u5373\u6C9F\u901A") throw Error("\u5F53\u524D\u4E0D\u662F\u7ACB\u5373\u6C9F\u901A\uFF0C\u672A\u91CD\u590D\u53D1\u9001");
  if (await read("count", active) !== 1 || await read("url") !== url) throw Error("\u6838\u5BF9\u671F\u95F4\u9009\u4E2D\u72B6\u6001\u53D8\u5316");
  return { mode: directMode, jobSource: c.jobSource, selected: true, selector: active, salaryRaw, salary, contactLabel, closed, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
}
function directIntersection(salary, conditions) {
  return !!salary && (!conditions.salaryMin || salary.maximumYuan >= conditions.salaryMin) && (!conditions.salaryMax || salary.minimumYuan <= conditions.salaryMax);
}
function communicationCache(template, signal, contextId, accountSourceSha256) {
  const object = (v) => !!v && typeof v === "object" && !Array.isArray(v);
  const canonical2 = (v) => Array.isArray(v) ? v.map(canonical2) : object(v) ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical2(v[k])])) : v;
  const encode = (v) => JSON.stringify(canonical2(v));
  const sha = (v) => createHash("sha256").update(v).digest("hex");
  const digest2 = (v) => typeof v === "string" && /^[a-f0-9]{64}$/.test(v);
  const timestamp = (v) => typeof v === "string" && Number.isFinite(Date.parse(v)) && new Date(v).toISOString() === v && Date.parse(v) <= Date.now();
  if (typeof contextId !== "string" || !contextId || contextId.length > 200 || !digest2(accountSourceSha256)) throw Error("\u7F13\u5B58\u6240\u5C5E\u4E0A\u4E0B\u6587\u6216\u8D26\u53F7\u6765\u6E90\u65E0\u6548");
  const scope = { version: 1, kind: "boss-communication-cache-scope", contextId, accountSourceSha256 };
  const scopeText = encode(scope), scopeName = "scope-v1-" + sha(scopeText) + ".json";
  let initialized = false;
  const guarded = (fn) => async (...args) => {
    try {
      return await fn(...args);
    } catch (error) {
      if (signal.aborted || error?.communicationCacheFailure === true) throw error;
      const failure = Error("\u6C9F\u901A\u7F13\u5B58\u6545\u969C\uFF1A" + String(error?.message || error));
      failure.communicationCacheFailure = true;
      throw failure;
    }
  };
  const controlled = (name) => typeof name === "string" && /^(?:scope|observation|positive)-v1-[a-f0-9]{64}\.json$/.test(name);
  const missingTarget = (error, name) => {
    const match = /^ENOENT: no such file or directory, realpath '([^'\r\n]+)'$/.exec(String(error?.message || ""));
    return !!match && controlled(name) && match[1].endsWith("/" + name);
  };
  const rawRead = async (name) => {
    if (!controlled(name)) throw Error("\u7F13\u5B58\u6587\u4EF6\u540D\u4E0D\u53D7\u652F\u6301");
    signal.throwIfAborted();
    const content = await template.file("communication-cache", { operation: "read", name });
    signal.throwIfAborted();
    if (typeof content !== "string" || Buffer.byteLength(content) > 10 * 1024 * 1024) throw Error("\u7F13\u5B58\u5185\u5BB9\u8D85\u51FA\u65E2\u6709\u6587\u4EF6\u8BFB\u53D6\u8303\u56F4");
    return content;
  };
  const checkScope = async () => {
    if (await rawRead(scopeName) !== scopeText) throw Error("\u7F13\u5B58\u8303\u56F4\u6807\u8BB0\u4E0E\u672C\u5B9E\u4F8B\u8D26\u53F7\u4E0D\u4E00\u81F4\uFF0C\u4FDD\u7559\u539F\u6587\u4EF6");
  };
  const init = async () => {
    try {
      if (await rawRead(scopeName) !== scopeText) throw Error("\u7F13\u5B58\u8303\u56F4\u6807\u8BB0\u635F\u574F\u6216\u4E0D\u4E00\u81F4\uFF0C\u4FDD\u7559\u539F\u6587\u4EF6");
    } catch (error) {
      if (!missingTarget(error, scopeName)) throw error;
      signal.throwIfAborted();
      await template.file("communication-cache", { operation: "write", name: scopeName, content: scopeText });
      await checkScope();
    }
    initialized = true;
  };
  const read = async (name) => {
    if (!initialized) throw Error("\u7F13\u5B58\u8303\u56F4\u5C1A\u672A\u6838\u5BF9");
    try {
      return await rawRead(name);
    } catch (error) {
      if (!missingTarget(error, name)) throw error;
      await checkScope();
      return null;
    }
  };
  const put = async (name, value) => {
    const content = encode(value);
    if (typeof content !== "string" || Buffer.byteLength(content) > 10 * 1024 * 1024) throw Error("\u7F13\u5B58\u8F93\u51FA\u8D85\u8FC7\u65E2\u6709SDK\u4E0A\u9650\uFF0C\u672A\u622A\u65AD\u5199\u5165");
    const previous = await read(name);
    if (previous !== null && previous !== content) throw Error("\u7F13\u5B58\u6587\u4EF6\u5DF2\u6709\u4E0D\u540C\u5185\u5BB9\uFF0C\u4FDD\u7559\u539F\u6587\u4EF6");
    if (previous === null) {
      signal.throwIfAborted();
      await template.file("communication-cache", { operation: "write", name, content });
    }
    if (await rawRead(name) !== content) throw Error("\u7F13\u5B58\u5199\u51FA\u4E0E\u56DE\u8BFB\u4E0D\u4E00\u81F4");
    return { name, sha256: sha(content) };
  };
  const parse = (content) => {
    let value;
    try {
      value = JSON.parse(content);
    } catch {
      throw Error("\u7F13\u5B58JSON\u635F\u574F\uFF0C\u4E0D\u80FD\u6309\u7A7A\u7F13\u5B58\u5904\u7406");
    }
    if (!object(value) || encode(value) !== content) throw Error("\u7F13\u5B58\u4E0D\u662F\u5B8C\u6574\u89C4\u8303\u5BF9\u8C61\uFF0C\u4E0D\u80FD\u6309\u7A7A\u7F13\u5B58\u5904\u7406");
    return value;
  };
  const identity = (value, jobSource, jobId) => {
    let source;
    try {
      source = new URL(jobSource);
    } catch {
      throw Error("\u7F13\u5B58\u5C97\u4F4D\u6765\u6E90\u65E0\u6548");
    }
    const match = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(source.pathname);
    if (source.origin !== "https://www.zhipin.com" || source.username || source.password || source.port || source.search || source.hash || source.href !== jobSource || match?.[1] !== jobId || value.version !== 1 || value.contextId !== contextId || value.accountSourceSha256 !== accountSourceSha256 || value.jobSource !== jobSource || value.jobId !== jobId) throw Error("\u7F13\u5B58\u4E0A\u4E0B\u6587\u3001\u8D26\u53F7\u6216\u5B8C\u6574\u5C97\u4F4D\u6765\u6E90\u4E0D\u4E00\u81F4");
  };
  const observe = async (value) => {
    const record = { ...value, version: 1, kind: "boss-communication-observation", contextId, accountSourceSha256 };
    identity(record, value.jobSource, value.jobId);
    if (!timestamp(record.observedAt) || record.doNotReplay !== true) throw Error("\u7F13\u5B58\u89C2\u5BDF\u65F6\u95F4\u6216\u672A\u77E5\u91CD\u653E\u8FB9\u754C\u65E0\u6548");
    const content = encode(record), name = "observation-v1-" + sha(content) + ".json";
    return put(name, record);
  };
  return { init: guarded(init), observe: guarded(observe) };
}
const canonical = (v) => Array.isArray(v) ? v.map(canonical) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical(v[k])])) : v;
const digest = (v) => createHash("sha256").update(JSON.stringify(canonical(v))).digest("hex");
async function safetyIndex(template, signal, accountKey, contextId, initialize = false) {
  const name = "account-outbound-safety-v1-" + accountKey + ".json";
  let data, existed = true, baseline;
  try {
    baseline = await template.file("communication-cache", { operation: "read", name });
    data = JSON.parse(baseline);
  } catch (error) {
    if (!String(error.message || error).includes("ENOENT")) throw error;
    if (!initialize) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
    existed = false;
    data = { version: 1, kind: "boss-account-outbound-safety", accountKey, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (existed) {
    const { sha256, ...body } = data;
    if (sha256 !== digest(body)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
  }
  if (data.version !== 1 || data.kind !== "boss-account-outbound-safety" || data.accountKey !== accountKey || !Number.isSafeInteger(data.revision) || data.revision < 0 || !Array.isArray(data.records) || data.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
  const records = /* @__PURE__ */ new Set();
  for (const r of data.records) {
    if (!["first-contact", "reply"].includes(r.type) || !/^[a-f0-9]{64}$/.test(r.businessKey) || !Array.isArray(r.sightings) || !r.sightings.length || r.sightings.length > 100 || records.has(r.type + ":" + r.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
    records.add(r.type + ":" + r.businessKey);
    for (const s of r.sightings) if (typeof s.contextId !== "string" || !s.contextId || !/^[a-f0-9]{64}$/.test(s.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(s.status) || !/^\d{4}-\d{2}-\d{2}$/.test(s.day) || typeof s.timeZone !== "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
  }
  let dirty = !existed;
  const merge = (state) => {
    if (!Array.isArray(state?.applicationIntents) || !Array.isArray(state?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
    for (const [type, rows] of [["first-contact", state.applicationIntents], ["reply", state.replyIntents]]) for (const i of rows) {
      if ((type === "first-contact" ? i.accountSourceSha256 : i.accountKey) !== accountKey) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
      if (!/^[a-f0-9]{64}$/.test(i.key) || !i.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(i.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
      const businessKey = type === "first-contact" ? digest(["boss-job-safety-v1", accountKey, i.jobId]) : createHash("sha256").update(["boss-text-reply-v1", accountKey, i.incomingMessageId].join(":")).digest("hex");
      let r = data.records.find((r2) => r2.type === type && r2.businessKey === businessKey);
      if (!r) {
        r = { type, businessKey, jobId: i.jobId, ...type === "reply" ? { conversationKey: i.conversationKey, incomingMessageId: i.incomingMessageId } : {}, sightings: [] };
        data.records.push(r);
        dirty = true;
      }
      if (r.jobId !== i.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
      const sight = { contextId, intentKey: i.key, status: i.status, day: i.day, timeZone: i.timeZone, contentSha256: i.contentSha256 || null, sourceSha256: i.sourceSha256 || null };
      if (!r.sightings.some((s) => JSON.stringify(canonical(s)) === JSON.stringify(canonical(sight)))) {
        r.sightings.push(sight);
        dirty = true;
      }
      if (r.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
    }
    if (data.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
  };
  const save = async () => {
    signal.throwIfAborted();
    if (dirty) {
      if (existed && await template.file("communication-cache", { operation: "read", name }) !== baseline) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
      data.records.sort((a, b) => (a.type + ":" + a.businessKey).localeCompare(b.type + ":" + b.businessKey));
      for (const r of data.records) r.sightings.sort((a, b) => JSON.stringify(canonical(a)).localeCompare(JSON.stringify(canonical(b))));
      data.revision++;
      data.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      delete data.sha256;
      data.sha256 = digest(data);
      await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(data) });
      dirty = false;
      baseline = JSON.stringify(data);
      existed = true;
    }
    const back = JSON.parse(await template.file("communication-cache", { operation: "read", name }));
    const { sha256, ...body } = back;
    if (sha256 !== digest(body) || sha256 !== data.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
    return { revision: data.revision, sha256: data.sha256, records: data.records.length };
  };
  return { data, name, merge, save, blocked: (type, key) => data.records.some((r) => r.type === type && r.businessKey === key) };
}
const greetingDigest = digest;
var stdin_default = async ({ input, signal, template }) => {
  signal.throwIfAborted();
  const obj = (v) => !!v && typeof v === "object" && !Array.isArray(v), canonical2 = (v) => Array.isArray(v) ? v.map(canonical2) : obj(v) ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical2(v[k])])) : v, same = (a, b) => JSON.stringify(canonical2(a)) === JSON.stringify(canonical2(b));
  if (!obj(input) || Object.keys(input).sort().join(",") !== "list,plan,receipt,reread") throw Error("\u7F3A\u5C11\u5355\u9879\u4FDD\u5B58\u7684\u8BA1\u5212\u3001\u63D0\u4EA4\u56DE\u6267\u3001\u91CD\u8BFB\u72B6\u6001\u6216\u539F\u5217\u8868");
  const { plan: p, receipt: r, reread: s, list: l } = input;
  if (p?.kind === "daily-first-communication-quota-plan") {
    if (p.websiteGreetingVerified !== false || p.siteDailyLimitConfirmed !== true || !same(p.originalValue, p.value) || r?.operation !== "state.write" || r.contextId !== p.contextId || r.previousRevision !== p.expectedRevision || r.revision !== p.expectedRevision + 1 || !same(r.value, p.value) || s?.operation !== "state.read" || s.contextId !== p.contextId || s.revision !== r.revision || !same(s.value, p.value) || !same(await template.state.get(), s.value)) throw Error("\u771F\u5B9E\u4E0A\u9650\u540E\u9632\u91CD\u72B6\u6001\u8BFB\u56DE\u4E0D\u4E00\u81F4\uFF0C\u672A\u7EED\u53D1");
    const quota = JSON.parse(await template.file("communication-cache", { operation: "read", name: p.siteDailyLimitEvidenceName }));
    if (!same(quota, p.siteDailyLimitEvidence) || p.evidence?.siteDailyLimitEvidenceSha256 !== quota.sha256) throw Error("\u771F\u5B9E\u4E0A\u9650\u4FDD\u5B58\u56DE\u6267\u6765\u6E90\u53D8\u5316");
    return { version: 1, kind: "daily-first-communication-quota-blocked", siteDailyLimitConfirmed: true, websiteGreetingVerified: false, dayTaskComplete: false, newGreeting: false, returnedToList: true, stateRevision: s.revision, otherRecordsPreserved: true, reason: "\u7F51\u7AD9\u771F\u5B9E\u5F53\u5929\u4E0A\u9650\u5DF2\u4FDD\u5B58\uFF1B\u539F\u9884\u7559/unknown \u4FDD\u7559\u9632\u91CD\uFF0C\u4E0D\u8BA1\u4E3A\u62DB\u547C\u6210\u529F" };
  }
  if (p?.kind !== "daily-first-communication-confirmation-plan" || p.websiteGreetingVerified !== true || p.attachmentSent !== false || p.evidence?.kind !== "first-communication-default-greeting-acknowledgement" || p.evidence.listRestored !== true || p.evidence.jobSource !== p.jobSource || !obj(p.originalValue) || !obj(p.value) || !Array.isArray(p.originalValue.applicationIntents) || !Array.isArray(p.value.applicationIntents) || !Array.isArray(p.originalValue.queueEntries) || !Array.isArray(p.value.queueEntries) || p.intent?.status !== "reserved") throw Error("\u672C\u9879\u786E\u8BA4\u8BA1\u5212\u6216\u539F\u72B6\u6001\u6765\u6E90\u65E0\u6548");
  const queueRows = p.originalValue.queueEntries.filter((v) => v?.key === p.intent.key);
  if (queueRows.length !== 1 || queueRows[0].status !== "processing" || queueRows[0].jobSource !== p.intent.jobSource || queueRows[0].accountSourceSha256 !== p.intent.accountSourceSha256 || queueRows[0].day !== p.intent.day || queueRows[0].timeZone !== p.intent.timeZone) throw Error("\u9001\u8FBE\u5199\u56DE\u7684\u5B8C\u6574\u961F\u5217\u6765\u6E90\u4E0D\u4E00\u81F4");
  const expected = structuredClone(p.originalValue), matches = expected.applicationIntents.filter((v) => v?.key === p.intent.key);
  if (matches.length !== 1 || !same(matches[0], p.intent)) throw Error("\u5355\u9879\u8BA1\u5212\u4E0D\u5BF9\u5E94\u51C6\u786E\u539F\u9884\u7559");
  expected.applicationIntents = expected.applicationIntents.map((v) => v.key === p.intent.key ? { ...v, status: "confirmed" } : v);
  if (!same(expected, p.value) || r?.version !== 1 || r.operation !== "state.write" || r.contextId !== p.contextId || r.previousRevision !== p.expectedRevision || r.revision !== p.expectedRevision + 1 || typeof r.operationId !== "string" || !Number.isFinite(Date.parse(r.committedAt)) || !same(r.value, p.value) || s?.version !== 1 || s.operation !== "state.read" || s.contextId !== p.contextId || s.revision !== r.revision || !same(s.value, r.value)) throw Error("\u9001\u8FBE\u72B6\u6001\u63D0\u4EA4\u6216\u5199\u540E\u91CD\u8BFB\u4E0D\u4E00\u81F4\uFF1B\u4FDD\u7559\u8BB0\u5F55\u5E76\u505C\u6B62\uFF0C\u4E0D\u91CD\u590D\u53D1\u9001");
  const index = await safetyIndex(template, signal, p.intent.accountSourceSha256, p.contextId);
  const businessKey = digest(["boss-job-safety-v1", p.intent.accountSourceSha256, p.intent.jobId]), entry = index.data.records.find((v) => v.type === "first-contact" && v.businessKey === businessKey);
  if (!entry || entry.jobId !== p.intent.jobId || !entry.sightings.some((v) => v.contextId === p.contextId && v.intentKey === p.intent.key && v.status === "reserved") || entry.sightings.some((v) => v.contextId !== p.contextId || v.intentKey !== p.intent.key)) throw Error("\u672C\u9879\u5DF2\u4FDD\u5B58\u786E\u8BA4\uFF0C\u4F46\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5C11\u539F\u9884\u7559\u6216\u5B58\u5728\u5176\u4ED6\u6765\u6E90\uFF1B\u4E0D\u91CD\u653E");
  index.merge(s.value);
  const safetyReceipt = await index.save();
  const cache = communicationCache(template, signal, p.contextId, p.intent.accountSourceSha256);
  await cache.init();
  const cachedDelivery = await cache.observe({ observationType: "default-greeting-state-committed", jobId: p.intent.jobId, jobSource: p.jobSource, operationId: p.operationId, operationKey: p.operationKey, runId: p.evidence.runId || null, sourcePage: p.evidence.listSource, observedAt: (/* @__PURE__ */ new Date()).toISOString(), evidence: p.evidence, verification: p.cachedVerification, stateCommit: { contextId: p.contextId, operationId: r.operationId, revision: s.revision, committedAt: r.committedAt }, safetyReceipt, doNotReplay: true });
  if (p.evidence.actualMessageSha256 !== p.evidence.approvedMessageSha256 || p.evidence.acknowledgementSha256 !== greetingDigest(p.evidence.acknowledgement)) throw Error("\u5DF2\u786E\u8BA4\u56DE\u6267\u6B63\u6587\u6216\u6458\u8981\u53D8\u5316\uFF0C\u4E0D\u91CD\u653E");
  if (l?.kind !== "daily-selected-job-candidate" || l.evaluationMode !== directMode || l.selected !== true || l.sourceMode !== "persisted-job-link-in-list" || l.jobSource !== p.jobSource || l.jobTitle !== p.jobTitle || l.actualCity !== p.actualCity || l.configuredDay !== p.intent.day || l.timeZone !== p.intent.timeZone || l.returnUrl !== p.evidence.listSource) throw Error("\u672C\u9879\u5DF2\u786E\u8BA4\uFF0C\u539F\u5217\u8868\u6765\u6E90\u53D1\u751F\u53D8\u5316\uFF1B\u4E0D\u91CD\u653E");
  await directSelected(template, signal, { jobSource: p.jobSource, returnUrl: l.returnUrl });
  const contact = await template.browser("browser", { operation: "read", selector: PANEL.contact, timeoutMs: 3e3 });
  if (!["\u7ACB\u5373\u6C9F\u901A", "\u7EE7\u7EED\u6C9F\u901A"].includes(String(contact).trim())) throw Error("\u9001\u8FBE\u4FDD\u5B58\u540E\u5F53\u524D\u6C9F\u901A\u5165\u53E3\u53D8\u5316\uFF1B\u4FDD\u7559\u786E\u8BA4\uFF0C\u4E0D\u91CD\u653E");
  const todayRows = s.value.applicationIntents.filter((v) => v.accountSourceSha256 === p.intent.accountSourceSha256 && v.timeZone === p.intent.timeZone && v.day === p.intent.day);
  return { version: 1, kind: "daily-first-communication-confirmed", status: "\u7F51\u7AD9\u9ED8\u8BA4\u62DB\u547C\u5DF2\u786E\u8BA4\u5E76\u4FDD\u5B58\uFF1B\u5F53\u524D\u5217\u8868\u7EE7\u7EED\u4E0B\u4E00\u5C97\u4F4D", jobTitle: p.jobTitle, jobSource: p.jobSource, actualCity: p.actualCity, websiteGreetingVerified: true, stateRevision: s.revision, stateSavedAndRereadVerified: true, otherRecordsPreserved: true, confirmedGreetingsToday: todayRows.filter((v) => v.status === "confirmed").length, attachmentSent: false, extraIntroductionSent: false, applied: false, dayTaskComplete: false, siteDailyLimitConfirmed: false, returnedToList: true, evidence: p.evidence, cacheReceipt: cachedDelivery, safetyReceipt, acknowledgementSha256: p.evidence.acknowledgementSha256 };
};
export {
  stdin_default as default
};
