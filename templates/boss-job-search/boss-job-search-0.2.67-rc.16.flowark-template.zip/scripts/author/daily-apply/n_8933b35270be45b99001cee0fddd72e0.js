import "node:crypto";
const C = /* @__PURE__ */ (() => {
  var s = async ({ input: e, signal: d }) => {
    d.throwIfAborted();
    const n = e?.closing;
    if (n?.version !== 1 || n.kind !== "unread-closing-cohort" || typeof n.closingPhase != "boolean") throw Error("\u7F3A\u5C11\u672C\u6279\u6D88\u606F\u6536\u5C3E\u9636\u6BB5\u6838\u5BF9\uFF0C\u672A\u521D\u59CB\u5316\u6295\u9012");
    if (n.closingPhase) {
      const u = e.configuration;
      if (u?.operation !== "configuration" || u.contextId !== n.contextId || !Number.isSafeInteger(u.revision)) throw Error("\u6536\u5C3E\u4E0E\u4E3B\u6D41\u7A0B\u914D\u7F6E\u8EAB\u4EFD\u4E0D\u7B26");
      return { version: 1, kind: "daily-apply-configuration", configurationRevision: u.revision, closingPhase: true, configuredDay: (n.siteDailyLimitEvidence || n.testCompletionEvidence).day, timeZone: (n.siteDailyLimitEvidence || n.testCompletionEvidence).timeZone, userDailyLimit: e.dailyApplyLimit, batchSize: e.batchSize, readyForLoop: false, loopItems: [], issues: [], status: "unread-closing-priority", dayTaskComplete: false, accountVerified: false, eligibleForActions: false };
    }
    if (!e || Object.keys(e).sort().join(",") !== "approvedGreetingText,batchSize,closing,configuration,dailyApplyLimit") throw Error("\u6BCF\u65E5\u6295\u9012\u8F93\u5165\u6765\u6E90\u4E0D\u5B8C\u6574");
    const r = e.configuration;
    if (!r || r.version !== 1 || r.operation !== "configuration" || !Number.isSafeInteger(r.revision) || r.revision < 0 || !r.value || typeof r.value != "object" || Array.isArray(r.value)) throw Error("\u7F3A\u5C11\u672C\u6B21\u56FA\u5B9A\u7528\u6237\u914D\u7F6E\u4E0E\u4FEE\u8BA2");
    const E = e.dailyApplyLimit, F = e.batchSize;
    if (!Number.isSafeInteger(E) || E < 0 || E > 150 || !Number.isSafeInteger(F) || F < 1 || F > 150) throw Error("\u672C\u5165\u53E3\u6BCF\u65E5\u989D\u5EA6\u987B\u4E3A0\u81F3150\u3001\u5355\u6279\u6B21\u6570\u987B\u4E3A1\u81F3150\u7684\u6574\u6570");
    const i = r.value, o = [], a = {};
    if (!Number.isSafeInteger(i.firstContactDailyBudget) || i.firstContactDailyBudget < 0 || i.firstContactDailyBudget > 150) throw Error("\u672C\u65E5\u81EA\u52A8\u65B0\u589E\u6C9F\u901A\u9884\u7B97\u987B\u4E3A0\u81F3150\u7684\u6574\u6570");
    i.firstContactDailyBudget === 0 && o.push({ field: "firstContactDailyBudget", reason: "\u672C\u65E5\u81EA\u52A8\u65B0\u589E\u9884\u7B97\u4E3A0\uFF0C\u7981\u6B62\u65B0\u62DB\u547C\uFF1B\u5DF2\u89E6\u53D1\u7684\u7F51\u7AD9\u4E0A\u9650\u6536\u5C3E\u4ECD\u72EC\u7ACB\u7EE7\u7EED" }), (typeof e.approvedGreetingText != "string" || !e.approvedGreetingText.trim() || e.approvedGreetingText.length > 4e3) && o.push({ field: "approvedGreetingText", reason: "\u8BF7\u586B\u5199\u5DF2\u6279\u51C6\u7684\u5B8C\u6574\u4ECB\u7ECD\u6B63\u6587\uFF081\u81F34000\u5B57\uFF09\uFF0C\u4E0D\u81EA\u52A8\u8865\u5199\u4E2A\u4EBA\u4FE1\u606F" });
    const f = (u) => u.normalize("NFKC").trim().toLocaleLowerCase("en-US");
    for (const u of ["targetRoles", "titleKeywords", "cities", "excludedRoles"]) {
      const t = i[u];
      if (!Array.isArray(t) || t.length > 20 || t.some((c) => typeof c != "string" || !c.trim() || c.length > 100)) throw Error("\u6C42\u804C\u6761\u4EF6\u5217\u8868\u7ED3\u6784\u65E0\u6548\uFF1A" + u);
      a[u] = [...t], new Set(t.map(f)).size !== t.length && o.push({ field: u, reason: "\u5B58\u5728\u91CD\u590D\u6761\u4EF6\uFF0C\u8BF7\u672C\u4EBA\u6838\u5BF9" });
    }
    a.targetRoles.length || o.push({ field: "targetRoles", reason: "\u8BF7\u914D\u7F6E\u76EE\u6807\u804C\u4F4D" }), a.titleKeywords.length || o.push({ field: "titleKeywords", reason: "\u8BF7\u914D\u7F6E\u53EF\u63A5\u53D7\u5C97\u4F4D\u6807\u9898\u5173\u952E\u8BCD\uFF1B\u7F51\u7AD9\u68C0\u7D22\u8BCD\u4E0D\u80FD\u4F5C\u4E3A\u5C97\u4F4D\u5408\u683C\u8BC1\u636E" }), a.cities.length || o.push({ field: "cities", reason: "\u8BF7\u914D\u7F6E\u671F\u671B\u57CE\u5E02\uFF0C\u4E0D\u6CBF\u7528\u7F51\u5740\u3001\u5B9A\u4F4D\u6216\u5386\u53F2\u57CE\u5E02" });
    const B = new Set(a.excludedRoles.map(f));
    a.targetRoles.some((u) => B.has(f(u))) && o.push({ field: "excludedRoles", reason: "\u76EE\u6807\u4E0E\u6392\u9664\u65B9\u5411\u51B2\u7A81" });
    for (const u of ["salaryMin", "salaryMax"]) {
      if (!Number.isSafeInteger(i[u]) || i[u] < 0 || i[u] > 1e6) throw Error("\u6708\u85AA\u6761\u4EF6\u65E0\u6548\uFF1A" + u);
      a[u] = i[u];
    }
    i.salaryMax > 0 && i.salaryMin > i.salaryMax && o.push({ field: "salaryMax", reason: "\u85AA\u8D44\u4E0A\u4E0B\u9650\u51B2\u7A81" });
    const l = i.replyTimeZone;
    let y = null;
    try {
      if (typeof l != "string" || !l.trim() || l.length > 100) throw Error("\u65F6\u533A\u672A\u914D\u7F6E");
      const u = new Intl.DateTimeFormat("en-CA", { timeZone: l, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(/* @__PURE__ */ new Date()), t = (c) => u.find((D) => D.type === c).value;
      y = t("year") + "-" + t("month") + "-" + t("day");
    } catch {
      o.push({ field: "replyTimeZone", reason: "\u8BF7\u914D\u7F6E\u6709\u6548\u7684\u6BCF\u65E5\u989D\u5EA6\u65F6\u533A" });
    }
    return E === 0 && o.push({ field: "dailyApplyLimit", reason: "\u7528\u6237\u672A\u5F00\u653E\u6BCF\u65E5\u6295\u9012\u989D\u5EA6" }), d.throwIfAborted(), { version: 1, kind: "daily-apply-configuration", configurationRevision: r.revision, conditions: a, dailyTarget: 150, firstContactDailyBudget: i.firstContactDailyBudget, userDailyLimit: E, batchSize: F, timeZone: typeof l == "string" ? l : null, configuredDay: y, readyForLoop: o.length === 0, loopItems: o.length ? [] : Array.from({ length: F }, (u, t) => t), issues: o, status: o.length ? "needs-configuration" : "conditions-ready", completionEvidenceRequired: "boss-site-daily-limit-dialog", dayTaskComplete: false, accountVerified: false, eligibleForActions: false, note: "\u4EC5\u56FA\u5B9A\u7528\u6237\u6761\u4EF6\u548C\u672C\u5165\u53E3\u6709\u9650\u6279\u6B21\u8303\u56F4\uFF1B\u9010\u6B21\u6309\u914D\u7F6E\u5207\u57CE\uFF0C\u8BFB\u53D6\u5E76\u590D\u6838\u7F51\u9875\u5B9E\u9645\u57CE\u5E02\u4E0E\u5C97\u4F4D\u5730\u70B9\u540E\u624D\u53EF\u7EE7\u7EED\u3002\u4ECD\u987B\u8D26\u53F7\u3001\u7F51\u7AD9\u5F53\u5929\u8303\u56F4\u3001\u6301\u4E45\u8FDB\u5EA6\u3001\u7AD9\u70B9\u5B9A\u4F4D\u53CA\u9010\u6B21\u52A8\u4F5C\u6838\u5BF9\u3002\u6210\u529F\u6570\u3001\u8DF3\u8FC7\u548C\u672A\u77E5\u5206\u5F00\uFF1B\u672C\u5730\u989D\u5EA6\u548C\u6279\u6B21\u7ED3\u675F\u4E0D\u4EE3\u8868\u7F51\u7AD9\u5F53\u65E5\u5B8C\u6210\u3002" };
  };
  return s;
})(), g = async function({ input: e }) {
  if (!e?.closing?.unknownRecovery) throw Error("\u7F3A\u5C11unknown\u63A5\u7BA1\u8303\u56F4");
  return { version: 1, kind: "daily-apply-configuration", closingPhase: true, configuredDay: e.closing.day, timeZone: e.closing.timeZone, userDailyLimit: 0, batchSize: e.batchSize, readyForLoop: false, loopItems: [], issues: [], status: "unknown-recovery-priority", dayTaskComplete: false, accountVerified: false, eligibleForActions: false };
};
async function p(s) {
  return s.input?.closing?.unknownRecovery ? g(s) : C(s);
}
export {
  p as default
};
