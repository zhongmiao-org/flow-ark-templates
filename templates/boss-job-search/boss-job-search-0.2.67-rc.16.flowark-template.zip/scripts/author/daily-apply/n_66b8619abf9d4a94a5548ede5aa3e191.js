import { createHash as x } from "node:crypto";
const K = /* @__PURE__ */ (() => {
  function E(e) {
    return e.status === "review" && !e.operationKey && !e.modelRequestId && e.sourceReviewVersion !== "chat-list-direct-v5" && /固定成员姓名控件不唯一|固定成员定向搜索结果不唯一|关联职位没有可核对的继续沟通入口|固定成员缺少可核对的定向搜索姓名，未猜测|固定成员缺少唯一可见身份|关联职位返回后的完整消息或对象变化/u.test(String(e.reason || ""));
  }
  const p = (e) => Array.isArray(e) ? e.map(p) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((t) => [t, p(e[t])])) : e, b = (e) => B("sha256").update(JSON.stringify(p(e))).digest("hex");
  async function v(e, t, i, o, a = false) {
    const l = "account-outbound-safety-v1-" + i + ".json";
    let r, s = true, d;
    try {
      d = await e.file("communication-cache", { operation: "read", name: l }), r = JSON.parse(d);
    } catch (n) {
      if (!String(n.message || n).includes("ENOENT")) throw n;
      if (!a) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
      s = false, r = { version: 1, kind: "boss-account-outbound-safety", accountKey: i, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    }
    if (s) {
      const { sha256: n, ...u } = r;
      if (n !== b(u)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
    }
    if (r.version !== 1 || r.kind !== "boss-account-outbound-safety" || r.accountKey !== i || !Number.isSafeInteger(r.revision) || r.revision < 0 || !Array.isArray(r.records) || r.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
    const f = /* @__PURE__ */ new Set();
    for (const n of r.records) {
      if (!["first-contact", "reply"].includes(n.type) || !/^[a-f0-9]{64}$/.test(n.businessKey) || !Array.isArray(n.sightings) || !n.sightings.length || n.sightings.length > 100 || f.has(n.type + ":" + n.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
      f.add(n.type + ":" + n.businessKey);
      for (const u of n.sightings) if (typeof u.contextId != "string" || !u.contextId || !/^[a-f0-9]{64}$/.test(u.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(u.status) || !/^\d{4}-\d{2}-\d{2}$/.test(u.day) || typeof u.timeZone != "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
    }
    let g = !s;
    return { data: r, name: l, merge: (n) => {
      if (!Array.isArray(n?.applicationIntents) || !Array.isArray(n?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
      for (const [u, w] of [["first-contact", n.applicationIntents], ["reply", n.replyIntents]]) for (const c of w) {
        if ((u === "first-contact" ? c.accountSourceSha256 : c.accountKey) !== i) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
        if (!/^[a-f0-9]{64}$/.test(c.key) || !c.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(c.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
        const y = u === "first-contact" ? b(["boss-job-safety-v1", i, c.jobId]) : B("sha256").update(["boss-text-reply-v1", i, c.incomingMessageId].join(":")).digest("hex");
        let m = r.records.find((h) => h.type === u && h.businessKey === y);
        if (m || (m = { type: u, businessKey: y, jobId: c.jobId, ...u === "reply" ? { conversationKey: c.conversationKey, incomingMessageId: c.incomingMessageId } : {}, sightings: [] }, r.records.push(m), g = true), m.jobId !== c.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
        const F = { contextId: o, intentKey: c.key, status: c.status, day: c.day, timeZone: c.timeZone, contentSha256: c.contentSha256 || null, sourceSha256: c.sourceSha256 || null };
        if (m.sightings.some((h) => JSON.stringify(p(h)) === JSON.stringify(p(F))) || (m.sightings.push(F), g = true), m.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
      }
      if (r.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
    }, save: async () => {
      if (t.throwIfAborted(), g) {
        if (s && await e.file("communication-cache", { operation: "read", name: l }) !== d) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
        r.records.sort((c, y) => (c.type + ":" + c.businessKey).localeCompare(y.type + ":" + y.businessKey));
        for (const c of r.records) c.sightings.sort((y, m) => JSON.stringify(p(y)).localeCompare(JSON.stringify(p(m))));
        r.revision++, r.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete r.sha256, r.sha256 = b(r), await e.file("communication-cache", { operation: "write", name: l, content: JSON.stringify(r) }), g = false, d = JSON.stringify(r), s = true;
      }
      const n = JSON.parse(await e.file("communication-cache", { operation: "read", name: l })), { sha256: u, ...w } = n;
      if (u !== b(w) || u !== r.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
      return { revision: r.revision, sha256: r.sha256, records: r.records.length };
    }, blocked: (n, u) => r.records.some((w) => w.type === n && w.businessKey === u) };
  }
  const I = (e, t) => async (i, o, a) => (t.throwIfAborted(), e.browser("browser", { operation: i, ...o ? { selector: o } : {}, ...a === void 0 ? {} : { value: a }, timeoutMs: 3e3 })), S = (e) => {
    const { sha256: t, ...i } = e;
    return t === b(i);
  };
  async function k(e, t, i, o) {
    const a = i.progressName, l = await e.file("communication-cache", { operation: "read", name: a }), r = JSON.parse(l);
    if (!S(r) || r.accountKey !== i.accountKey || r.fixedUnreadSetSha256 !== i.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
    if (!o) return r;
    const s = o(structuredClone(r));
    if (s.revision++, s.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete s.sha256, s.sha256 = b(s), await e.file("communication-cache", { operation: "read", name: a }) !== l) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
    t.throwIfAborted(), await e.file("communication-cache", { operation: "write", name: a, content: JSON.stringify(s) });
    const d = JSON.parse(await e.file("communication-cache", { operation: "read", name: a }));
    if (!S(d) || d.sha256 !== s.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
    return d;
  }
  async function D(e) {
    const t = await e("count", "li.message-item");
    if (!Number.isSafeInteger(t) || t < 1 || t > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
    const i = [];
    for (let o = 1; o <= t; o++) {
      const a = "li.message-item:nth-child(" + o + " of li.message-item)", l = await e("attribute", a, "data-mid"), r = await e("attribute", a, "class");
      if (!/^\d{6,40}$/.test(l || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
      const s = await e("count", a + " .text-content");
      if (s > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
      const d = s === 1 ? String(await e("read", a + " .text-content")).trim() : null, f = d === null ? String(await e("read", a)).trim() : null;
      if ((d || f || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
      const g = !!d && /^您正在与Boss.+沟通$/u.test(d), n = !g && d !== null && r.split(/\s+/u).includes("item-myself") ? "outgoing" : !g && d !== null && r.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
      i.push({ mid: l, direction: n, text: d, context: f });
    }
    if (new Set(i.map((o) => o.mid)).size !== i.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
    return i;
  }
  async function A(e, t) {
    const i = new URL(await e("url"));
    if (i.origin !== "https://www.zhipin.com" || i.pathname !== "/web/geek/chat" || await e("count", ".chat-conversation .user-info") !== 1) return false;
    const o = String(await e("read", ".chat-conversation .user-info")).trim(), a = (l) => l.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
    return String(await e("read", ".chat-conversation .user-info")).trim() === t.recipientLabel && await e("count", 'li.message-item[data-mid="' + t.rows[0].mid + '"]') === 1;
  }
  async function N(e, t, i) {
    const o = I(e, t);
    return await A(o, i) ? String(await o("read", i.accountSelector)).trim() === i.accountLabel && String(await o("read", i.recipientSelector)).trim() === i.recipientLabel && JSON.stringify(await D(o)) === JSON.stringify(i.rows) : false;
  }
  var C = async ({ input: e, signal: t, template: i, artifact: o, logger: a }) => {
    if (e?.kind !== "chat-reply-dispatch") throw Error("Missing single-dispatch stage");
    const l = (n) => B("sha256").update(n).digest("hex"), r = (n) => String(n).replace(/\s+/g, ""), s = (n, u, w) => (t.throwIfAborted(), i.browser("browser", { operation: n, ...u ? { selector: u } : {}, ...w !== void 0 ? { value: w } : {}, timeoutMs: 3e3 })), d = () => D(s);
    let f = null;
    if (e.dispatched) try {
      const n = Date.now() + 1e4;
      for (; Date.now() < n; ) {
        if (new URL(await s("url")).origin !== "https://www.zhipin.com" || new URL(await s("url")).pathname !== "/web/geek/chat" || String(await s("read", e.accountSelector)).trim() !== e.accountLabel || !await A(s, e) || String(await s("read", e.recipientSelector)).trim() !== e.recipientLabel) throw Error("Conversation changed after dispatch");
        const m = await d();
        if (JSON.stringify(m.slice(0, e.rows.length)) !== JSON.stringify(e.rows)) throw Error("Original conversation history changed after dispatch");
        const F = m.slice(e.rows.length).filter((h) => h.direction === "outgoing");
        if (F.length > 1) throw Error("More than one new outbound message; no attribution");
        if (F.length === 1) {
          const h = F[0];
          if (r(h.text) !== r(e.reply)) throw Error("New outbound content differs from fixed AI reply");
          const O = 'li.message-item[data-mid="' + h.mid + '"] > div > div > i';
          if (await s("count", O) === 1) {
            const j = String(await s("read", O)).trim();
            if (["\u9001\u8FBE", "\u5DF2\u8BFB"].includes(j)) {
              f = { version: 1, kind: "existing-conversation-ai-reply-delivery", incomingMessageId: e.incomingMessageId, outgoingMessageId: h.mid, jobId: e.jobId, jobSource: e.jobSource, conversationKey: e.conversationKey, accountKey: e.accountKey, operationId: e.effect.id, operationKey: e.key, runId: e.effect.runId, sourceSha256: e.sourceSha256, approvedText: e.reply, contentSha256: e.contentSha256, observedText: h.text, observedSha256: l(h.text), receipt: j, observedAt: (/* @__PURE__ */ new Date()).toISOString(), model: e.model, profileRef: e.profile.ref, configurationRevision: e.configurationRevision, rows: m };
              break;
            }
          }
        }
        await new Promise((h) => setTimeout(h, 200));
      }
      if (!f) throw Error("Website delivery receipt did not appear within the bounded observation");
      await o("reply-delivery-proof.json", JSON.stringify(f, null, 2)), await i.effect.resolve({ id: e.effect.id, state: "confirmed", evidence: f });
      const u = await i.state.get();
      if (u.replyIntents.filter((m) => m.key === e.key && m.status === "reserved" && m.contentSha256 === e.contentSha256).length !== 1) throw Error("Reply reservation changed before receipt persistence");
      await i.state.set({ ...u, replyIntents: u.replyIntents.map((m) => m.key === e.key ? { ...m, status: "confirmed" } : m) });
      const w = await i.state.get();
      if (w.replyIntents.filter((m) => m.key === e.key && m.status === "confirmed").length !== 1) throw Error("Reply confirmation could not be read back");
      const c = await v(i, t, e.accountKey, e.contextId);
      c.merge(w);
      const y = await c.save();
      if (!c.data.records.some((m) => m.type === "reply" && m.businessKey === e.key && m.sightings.some((F) => F.contextId === e.contextId && F.intentKey === e.key && F.status === "confirmed"))) throw Error("\u9001\u8FBE\u5DF2\u6838\u5BF9\uFF0C\u4F46\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u786E\u8BA4\u672A\u8BFB\u56DE\uFF1B\u4FDD\u7559\u539F\u610F\u56FE\uFF0C\u4E0D\u91CD\u53D1");
      await o("reply-safety-confirmation.json", JSON.stringify({ operationKey: e.key, incomingMessageId: e.incomingMessageId, ...y }, null, 2)), a.info({ status: "reply-confirmed", incomingMessageId: e.incomingMessageId, outgoingMessageId: f.outgoingMessageId, receipt: f.receipt });
    } catch (n) {
      if (!f) {
        await i.effect.resolve({ id: e.effect.id, state: "unknown", evidence: { reason: String(n.message || n), incomingMessageId: e.incomingMessageId, jobSource: e.jobSource, doNotReplay: true } });
        const u = await i.state.get();
        await i.state.set({ ...u, replyIntents: u.replyIntents.map((y) => y.key === e.key ? { ...y, status: "unknown" } : y) });
        const w = await i.state.get(), c = await v(i, t, e.accountKey, e.contextId);
        c.merge(w), await c.save();
      }
      throw await i.attention({ key: "reply-unresolved:" + e.key, title: "\u672C\u6761\u56DE\u590D\u9700\u8981\u6838\u5BF9\u9001\u8FBE\uFF0C\u8BF7\u52FF\u91CD\u53D1", detail: { jobTitle: e.jobTitle, jobSource: e.jobSource, incomingMessageId: e.incomingMessageId, reason: String(n.message || n), doNotReplay: true } }), n;
    }
    const g = { kind: "chat-reply-result", accountKey: e.accountKey, status: f ? "confirmed" : e.decision === "skip" ? "skipped-no-work-question" : e.status || "skipped", jobId: e.jobId || null, jobTitle: e.jobTitle || null, jobSource: e.jobSource || null, reason: f ? "AI reply has a real website delivery receipt" : e.reason, incomingMessageId: e.incomingMessageId || null, outgoingMessageId: f?.outgoingMessageId || null, receipt: f?.receipt || null, newGreeting: false, nativeActions: e.nativeActions || [], attachmentSent: (e.nativeActions || []).some((n) => n.type === "resume" && n.status === "confirmed") };
    if (e.member) {
      const n = await k(i, t, e, (u) => {
        const w = u.completed.find((c) => c.memberKey === e.member.key);
        if (w) {
          if (w.status !== "review" || w.replyPolicyVersion === e.replyPolicyVersion && !E(w)) return u;
          u.reviewHistory = [...u.reviewHistory || [], w], u.completed = u.completed.filter((c) => c.memberKey !== e.member.key);
        }
        if (u.active && u.active.memberKey !== e.member.key) throw Error("\u9001\u8FBE\u6838\u5BF9\u540E\u7684\u6D3B\u8DC3\u4F1A\u8BDD\u5DF2\u53D8\u5316");
        return u.completed.push({ sourceReviewVersion: e.sourceReviewVersion || null, nativeActions: e.nativeActions || [], memberKey: e.member.key, identityLine: e.member.identityLine, replyPolicyVersion: e.replyPolicyVersion || null, status: f ? "confirmed" : e.decision === "review" ? "review" : e.decision === "skip" ? "skipped-no-work-question" : e.status || "skipped", reason: g.reason, incomingMessageId: e.incomingMessageId || null, outgoingMessageId: f?.outgoingMessageId || null, receipt: f?.receipt || null, operationKey: e.key || null, modelRequestId: e.model?.requestId || null, checkedAt: (/* @__PURE__ */ new Date()).toISOString() }), u.active = null, u;
      });
      g.fixedUnreadSetSha256 = e.fixedUnreadSetSha256, g.memberKey = e.member.key, g.completed = n.completed.length, g.remaining = e.memberCount - n.completed.length, g.progressSha256 = n.sha256;
    }
    return await o("fixed-unread-member-result.json", JSON.stringify(g, null, 2)), g;
  };
  return C;
})(), M = /* @__PURE__ */ (() => {
  const E = (e) => Array.isArray(e) ? e.map(E) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((t) => [t, E(e[t])])) : e, p = (e) => x("sha256").update(JSON.stringify(E(e))).digest("hex"), b = (e) => x("sha256").update(e).digest("hex"), v = (e, t) => (i, o, a) => (t.throwIfAborted(), e.browser("browser", { operation: i, ...o ? { selector: o } : {}, ...a === void 0 ? {} : { value: a }, timeoutMs: 3e3 }));
  async function I(e, t, i, o, a = null) {
    let l = null;
    try {
      l = await e.file("communication-cache", { operation: "read", name: t });
    } catch (s) {
      if (!String(s.message || s).includes("ENOENT")) throw s;
    }
    const r = l === null ? a : JSON.parse(l);
    if (!r) throw Error("\u7F3A\u5C11\u6062\u590D\u6765\u6E90 " + t);
    if (l !== null) {
      const { sha256: s, ...d } = r;
      if (s !== p(d)) throw Error("\u6062\u590D\u6765\u6E90\u6458\u8981\u4E0D\u7B26 " + t);
    }
    if (r.kind !== i || r.accountKey !== o) throw Error("\u6062\u590D\u6765\u6E90\u8D26\u53F7\u6216\u7C7B\u578B\u4E0D\u7B26");
    return { name: t, raw: l, value: r };
  }
  async function S(e, t) {
    let i = null;
    try {
      i = await e.file("communication-cache", { operation: "read", name: t.name });
    } catch (l) {
      if (!String(l.message || l).includes("ENOENT")) throw l;
    }
    if (i !== t.raw) throw Error("\u6062\u590D\u8BB0\u5F55\u5E76\u53D1\u53D8\u5316");
    const o = t.value;
    o.revision++, o.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete o.sha256, o.sha256 = p(o);
    const a = JSON.stringify(o);
    if (await e.file("communication-cache", { operation: "write", name: t.name, content: a }), await e.file("communication-cache", { operation: "read", name: t.name }) !== a) throw Error("\u6062\u590D\u8BB0\u5F55\u672A\u51C6\u786E\u8BFB\u56DE");
    t.raw = a;
  }
  async function k(e, t) {
    return I(e, "unknown-chat-reviews-v1-" + t + ".json", "boss-unknown-chat-reviews", t, { version: 1, kind: "boss-unknown-chat-reviews", accountKey: t, revision: 0, reviews: [] });
  }
  async function D(e) {
    const t = await e("count", "li.message-item");
    if (!Number.isSafeInteger(t) || t < 1 || t > 150) throw Error("\u4F1A\u8BDD\u53EF\u89C1\u6D88\u606F\u8303\u56F4\u65E0\u6548");
    const i = [];
    for (let o = 1; o <= t; o++) {
      const a = "li.message-item:nth-child(" + o + " of li.message-item)", l = await e("attribute", a, "data-mid"), r = String(await e("attribute", a, "class") || "");
      if (!/^\d{6,40}$/u.test(l || "")) throw Error("\u7F3A\u5C11\u771F\u5B9E\u670D\u52A1\u5668\u6D88\u606F\u7F16\u53F7");
      const s = await e("count", a + " .text-content");
      if (s > 1) throw Error("\u5355\u6761\u6B63\u6587\u4E0D\u552F\u4E00");
      const d = s === 1 ? String(await e("read", a + " .text-content")).trim() : null, f = s === 1 ? null : String(await e("read", a)).trim(), g = !!d && /^您正在与Boss.+沟通$/u.test(d), n = !g && d !== null && r.split(/\s/u).includes("item-myself") ? "outgoing" : !g && d !== null && r.split(/\s/u).includes("item-friend") ? "incoming" : "system", u = a + " > div > div > i", w = await e("count", u) === 1 ? String(await e("read", u)).trim() : null;
      i.push({ mid: l, direction: n, text: d, context: f, receipt: w });
    }
    if (new Set(i.map((o) => o.mid)).size !== i.length) throw Error("\u670D\u52A1\u5668\u6D88\u606F\u7F16\u53F7\u91CD\u590D");
    return i;
  }
  async function A(e, t, i = true) {
    const o = new URL(await e("url"));
    if (o.origin !== "https://www.zhipin.com" || o.pathname !== "/web/geek/chat" || String(await e("read", t.accountSelector)).trim() !== t.accountLabel || await e("count", 'li.message-item[data-mid="' + t.member.originalIncomingMid + '"]') !== 1 || await e("count", 'li.message-item[data-mid="' + t.member.firstMessageId + '"]') !== 1) throw Error("\u672A\u77E5\u6062\u590D\u7684\u8D26\u53F7\u6216\u539F\u6D88\u606F\u94FE\u53D8\u5316");
    if (i && p(await D(e)) !== t.messagesHash) throw Error("AI\u5224\u65AD\u671F\u95F4\u804A\u5929\u5185\u5BB9\u53D8\u5316\uFF0C\u672A\u5916\u53D1");
  }
  async function N(e, t) {
    const i = ".list-warp.v2 input";
    if (await e("count", i) !== 1) throw Error("\u8054\u7CFB\u4EBA\u641C\u7D22\u5165\u53E3\u4E0D\u552F\u4E00");
    await e("click", i), await e("fill", i, t.lookupQuery || t.recipientName);
    const o = ".boss-search-result .search-list";
    let a = 0;
    for (let s = 0; s < 30 && (a = await e("count", o), !(a > 0)); s++) await new Promise((d) => setTimeout(d, 150));
    if (a < 1 || a > 50) throw Error("\u672A\u627E\u5230\u539Funknown\u8054\u7CFB\u4EBA");
    const l = [];
    for (let s = 1; s <= a; s++) {
      const d = o + ":nth-child(" + s + " of .search-list)", f = [d];
      let g = 0;
      for (; f.length; ) {
        const n = f.shift();
        if (++g > 150) throw Error("\u59D3\u540D\u63A7\u4EF6\u8303\u56F4\u8FC7\u5927");
        const u = String(await e("read", n)).trim(), w = await e("count", n + " > *");
        if (u === t.recipientName && l.push({ selector: n, text: u }), w > 0 && w < 30) for (let c = 1; c <= w; c++) f.push(n + " > :nth-child(" + c + ")");
      }
    }
    const r = l.filter((s) => !l.some((d) => d !== s && d.selector.startsWith(s.selector + " > ")));
    if (r.length !== 1) throw Error("\u539Funknown\u59D3\u540D\u63A7\u4EF6\u4E0D\u552F\u4E00");
    if (String(await e("read", r[0].selector)).trim() !== r[0].text) throw Error("\u641C\u7D22\u7ED3\u679C\u53D8\u5316");
    await e("click", r[0].selector);
    for (let s = 0; s < 40; s++) {
      if (await e("count", 'li.message-item[data-mid="' + t.originalIncomingMid + '"]') === 1 && await e("count", 'li.message-item[data-mid="' + t.firstMessageId + '"]') === 1) return;
      await new Promise((d) => setTimeout(d, 150));
    }
    throw Error("\u641C\u7D22\u540E\u672A\u8BFB\u56DE\u539Funknown\u670D\u52A1\u5668\u6D88\u606F\u94FE");
  }
  return async function({ input: e, template: t, artifact: i }) {
    if (e?.kind !== "unknown-chat-review-dispatch") throw Error("\u7F3A\u5C11unknown\u5224\u65AD\u7ED3\u679C");
    const o = await k(t, e.accountKey), a = o.value.reviews.find((r) => r.key === e.member.key);
    a && e.status === "review" && (a.status = "review", a.reason = e.reason, await S(t, o));
    const l = { key: e.member.key, decision: e.decision, status: e.readOnly ? "reviewed-no-external-action" : e.status, reason: e.reason, modelRequestId: e.model?.requestId || null, reply: e.reply, newGreeting: false, readOnly: e.readOnly };
    return await i("unknown-review-result-" + e.member.key.split(":")[1] + ".json", JSON.stringify(l)), l;
  };
})();
async function R(E) {
  return E.input?.unknownRecovery ? M(E) : K(E);
}
export {
  R as default
};
