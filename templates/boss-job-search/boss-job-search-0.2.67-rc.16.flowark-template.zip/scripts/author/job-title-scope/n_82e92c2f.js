function titleScopeEvidence(title, configuration) {
  const normalize = (value) => value.normalize("NFKC").replace(/\s+/gu, " ").trim().toLocaleLowerCase("en-US");
  if (typeof title !== "string" || !title.trim() || title.length > 1e3 || /(?:\.{3}|…|⋯)/u.test(title)) throw Error("\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u7F3A\u5931\u6216\u622A\u65AD\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u8BB0\u5F55");
  const positive = configuration?.titleKeywords, negative = configuration?.excludedRoles;
  for (const [name, terms, minimum] of [["titleKeywords", positive, 1], ["excludedRoles", negative, 0]]) {
    if (!Array.isArray(terms) || terms.length < minimum || terms.length > 20 || terms.some((v) => typeof v !== "string" || !normalize(v) || v.length > 100) || new Set(terms.map(normalize)).size !== terms.length) throw Error("\u5C97\u4F4D\u8303\u56F4\u914D\u7F6E\u65E0\u6548\uFF1A" + name + "\uFF1B\u672A\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE");
  }
  const fullTitle = normalize(title), excluded = negative.filter((term) => fullTitle.includes(normalize(term))), matched = positive.filter((term) => fullTitle.includes(normalize(term)));
  return { version: 1, kind: "literal-full-job-title-scope", fullTitle: title, matched, excluded, allowed: excluded.length === 0 && matched.length > 0, source: "actual-complete-job-title", jdUsed: false, searchKeywordUsedAsEvidence: false };
}
async function stdin_default({ input, template, signal, artifact }) {
  signal.throwIfAborted();
  if (input?.operation !== "configuration" || !Number.isSafeInteger(input.revision) || !input.value) throw Error("\u7F3A\u5C11\u672C\u6B21\u56FA\u5B9A\u914D\u7F6E");
  const read = async (operation, selector, attribute) => {
    signal.throwIfAborted();
    return template.browser("browser", { operation, ...selector ? { selector } : {}, ...attribute ? { value: attribute } : {}, timeoutMs: 3e3 });
  };
  const url = await read("url"), page = new URL(url);
  if (page.origin !== "https://www.zhipin.com" || page.pathname !== "/web/geek/jobs") throw Error("\u8BF7\u5148\u5728BOSS\u804C\u4F4D\u5217\u8868\u9009\u62E9\u4E00\u4E2A\u5C97\u4F4D\uFF1B\u53EA\u8BFB\u5165\u53E3\u4E0D\u4F1A\u6253\u5F00\u6216\u9009\u62E9\u5C97\u4F4D");
  const activeCount = await read("count", ".job-card-wrap.active"), count = await read("count", "div > div:nth-of-type(1) > li");
  if (!Number.isSafeInteger(activeCount) || activeCount < 1 || activeCount > 500 || !Number.isSafeInteger(count) || count < 1 || count > 500) throw Error("\u5F53\u524D\u9009\u4E2D\u5C97\u4F4D\u6216\u5217\u8868\u8303\u56F4\u4E0D\u53EF\u6838\u5BF9");
  let selected;
  for (let n = 1; n <= count; n++) {
    const card = "div:nth-of-type(" + n + ") > div:nth-of-type(1) > li:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1)", active = ":is(" + card + "):is(.job-card-wrap.active *)";
    if (await read("count", active) !== 1) continue;
    const link = card + " > a:nth-of-type(1)";
    if (await read("count", link) !== 1) throw Error("\u9009\u4E2D\u5C97\u4F4D\u6807\u9898\u94FE\u63A5\u4E0D\u552F\u4E00");
    const title2 = String(await read("read", link)).trim(), href = new URL(await read("attribute", link, "href"), url);
    if (href.origin !== page.origin || !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(href.pathname)) throw Error("\u9009\u4E2D\u5C97\u4F4D\u6765\u6E90\u94FE\u63A5\u65E0\u6548");
    selected = { title: title2, jobSource: href.origin + href.pathname, card, link, active };
    break;
  }
  if (!selected) throw Error("\u672A\u53D6\u5F97\u5F53\u524D\u552F\u4E00\u9009\u4E2D\u5C97\u4F4D\u7684\u6807\u9898\u548C\u51C6\u786E\u94FE\u63A5");
  const path = new URL(selected.jobSource).pathname, links = [path, selected.jobSource].flatMap((v) => ['[href="' + v + '"]', '[href^="' + v + '?"]']).join(",");
  const same = ".job-card-box:has(> div:nth-of-type(1) > div > a:is(" + links + "))";
  if (await read("count", ":is(" + same + "):is(.job-card-wrap.active *)") !== activeCount) throw Error("\u9875\u9762\u5B58\u5728\u4E0D\u540C\u5C97\u4F4D\u7684\u9009\u4E2D\u72B6\u6001\uFF0C\u505C\u6B62\u53EA\u8BFB\u6838\u5BF9");
  const panel = ".job-detail-container .job-name";
  if (await read("count", panel) !== 1) throw Error("\u9009\u4E2D\u8BE6\u60C5\u6807\u9898\u4E0D\u552F\u4E00");
  const fullPanel = String(await read("read", panel)).replace(/\s+/gu, " ").trim(), title = selected.title.replace(/\s+/gu, " ").trim();
  if (fullPanel !== title && !fullPanel.startsWith(title + " ")) throw Error("\u8BE6\u60C5\u6807\u9898\u4E0E\u9009\u4E2D\u5C97\u4F4D\u94FE\u63A5\u4E0D\u4E00\u81F4");
  const scope = titleScopeEvidence(selected.title, input.value);
  if (await read("url") !== url || await read("count", selected.active) !== 1 || String(await read("read", selected.link)).trim() !== selected.title) throw Error("\u6838\u5BF9\u671F\u95F4\u5C97\u4F4D\u6765\u6E90\u53D8\u5316");
  const result = { version: 1, kind: "boss-read-only-job-title-scope", status: scope.allowed ? "title-matches-configured-scope" : "skip-outside-title-scope", readyForTitleScope: scope.allowed, configurationRevision: input.revision, scope, jobSource: selected.jobSource, sourceUrl: page.origin + page.pathname, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), aiCalled: false, websiteMessagesSent: 0, attachmentSent: false, intentCreated: false, eligibleForActions: false, note: "\u4EC5\u8BC1\u660E\u5F53\u524D\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u7684\u5B57\u9762\u8303\u56F4\uFF1B\u4E0D\u4EE3\u66FF\u57CE\u5E02\u3001\u85AA\u8D44\u3001\u8D26\u53F7\u3001\u5916\u53D1\u6388\u6743\u53CA\u7F51\u7AD9\u56DE\u6267\u6838\u9A8C\u3002" };
  await artifact("job-title-scope.json", JSON.stringify(result, null, 2));
  await template.result(result);
  return result;
}
export {
  stdin_default as default
};
