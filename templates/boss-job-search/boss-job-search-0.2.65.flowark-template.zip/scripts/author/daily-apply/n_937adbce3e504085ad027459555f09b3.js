import { createHash } from "node:crypto";
var stdin_default = async ({ input, signal, template }) => {
  signal.throwIfAborted();
  const obj = (v) => !!v && typeof v === "object" && !Array.isArray(v), hash = (v) => createHash("sha256").update(JSON.stringify(v)).digest("hex");
  if (!obj(input) || Object.keys(input).sort().join(",") !== "conditions,started,state") throw Error("\u7F3A\u5C11\u672C\u9879\u786C\u6761\u4EF6\u3001\u5904\u7406\u4E2D\u56DE\u6267\u6216\u6700\u65B0\u5B8C\u6574\u72B6\u6001");
  const { conditions: c, started: d, state: s } = input;
  if (d?.version !== 1 || d.kind !== "daily-list-panel-precheck" || d.sourceMode !== "persisted-job-link-in-list" || d.processingPersisted !== true || !/^[a-f0-9]{64}$/.test(d.queueKey) || !/^[a-f0-9]{64}$/.test(d.accountSourceSha256) || d.eligibleForActions !== false || s?.version !== 1 || s.operation !== "state.read" || s.contextId !== d.processingContextId || !Number.isSafeInteger(s.revision) || s.revision < d.processingStateRevision || !obj(s.value) || Object.keys(s.value).sort().join(",") !== "applicationIntents,conversationControls,queueEntries,replyIntents" || !Array.isArray(s.value.queueEntries) || !Array.isArray(s.value.applicationIntents)) throw Error("\u672C\u9879\u6301\u4E45\u6765\u6E90\u4E0E\u6700\u65B0\u5B8C\u6574\u72B6\u6001\u4E0D\u4E00\u81F4");
  if (c?.version !== 1 || c.kind !== "daily-job-hard-conditions" || !["hard-condition-mismatch", "hard-conditions-needs-review", "hard-conditions-ready-for-skill"].includes(c.status) || c.jobSource !== d.jobSource || c.jobTitle !== d.jobTitle || c.configurationRevision !== d.configurationRevision || c.configuredDay !== d.configuredDay || c.actualCity !== d.actualCity || c.eligibleForActions !== false || c.applied !== false) throw Error("\u672C\u9879\u5B9E\u9645\u786C\u6761\u4EF6\u4E0E\u961F\u5217\u8EAB\u4EFD\u4E0D\u4E00\u81F4");
  const day = new Intl.DateTimeFormat("sv-SE", { timeZone: d.timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
  if (day !== d.configuredDay) throw Error("\u672C\u9879\u5904\u7406\u671F\u95F4\u8DE8\u5929\uFF0C\u4FDD\u7559\u539F\u72B6\u6001\u5E76\u505C\u6B62");
  const entries = s.value.queueEntries.filter((r) => r.key === d.queueKey), intents = s.value.applicationIntents.filter((r) => r.key === d.queueKey);
  if (entries.length !== 1 || entries[0].status !== "processing" || entries[0].jobSource !== d.jobSource || entries[0].accountSourceSha256 !== d.accountSourceSha256 || entries[0].configurationRevision !== d.configurationRevision || entries[0].day !== day || entries[0].timeZone !== d.timeZone || intents.length > 1) throw Error("\u672C\u9879\u5DF2\u7ECF\u53D1\u751F\u5E76\u53D1\u53D8\u5316\u6216\u91CD\u590D\u8BB0\u5F55\uFF0C\u505C\u6B62\u5206\u7C7B");
  let status, reason;
  const intent = intents[0];
  if (intent) {
    if (intent.accountSourceSha256 !== d.accountSourceSha256 || intent.jobSource !== d.jobSource || intent.day !== day || intent.timeZone !== d.timeZone || !["reserved", "confirmed", "failed", "unknown"].includes(intent.status)) throw Error("\u672C\u9879\u62DB\u547C\u610F\u56FE\u6765\u6E90\u6216\u72B6\u6001\u65E0\u6548");
    status = intent.status === "reserved" ? "unknown" : intent.status;
    reason = status === "confirmed" ? "\u672C\u9879\u5B9E\u9645\u62DB\u547C\u9001\u8FBE\u5DF2\u7531\u4E13\u95E8\u56DE\u6267\u6B65\u9AA4\u786E\u8BA4\uFF1B\u672A\u53D1\u9001\u9644\u4EF6" : status === "failed" ? "\u62DB\u547C\u610F\u56FE\u5DF2\u8BB0\u5F55\u4E3A\u660E\u786E\u5931\u8D25\uFF1B\u4E0D\u81EA\u52A8\u91CD\u53D1" : "\u62DB\u547C\u5B58\u5728\u9884\u7559\u6216\u672A\u77E5\u7ED3\u679C\uFF0C\u505C\u6B62\u4E0B\u4E00\u9879\u5E76\u4FDD\u7559\u539F\u64CD\u4F5C";
  } else if (c.status === "hard-condition-mismatch") {
    status = "skipped";
    reason = "\u672C\u9879\u53F3\u4FA7JD\u7684\u786C\u6761\u4EF6\u660E\u786E\u4E0D\u7B26\uFF1B\u6CA1\u6709\u62DB\u547C\u610F\u56FE\u6216\u7F51\u9875\u63D0\u4EA4";
  } else if (c.status === "hard-conditions-needs-review") {
    status = "review";
    reason = "\u672C\u9879\u5C97\u4F4D\u8D44\u6599\u6216\u786C\u6761\u4EF6\u9700\u672C\u4EBA\u5224\u65AD\uFF1B\u6CA1\u6709\u62DB\u547C\u610F\u56FE";
  } else {
    status = "review";
    reason = "\u5185\u90E8\u8BC4\u4F30\u7ED3\u675F\u4F46\u672A\u5EFA\u7ACB\u53EF\u91C7\u7528\u7684\u62DB\u547C\u610F\u56FE\uFF1B\u8BF7\u6838\u5BF9\u672C\u9879\u5EFA\u8BAE\u3001\u5F85\u529E\u6216\u65E2\u6709\u6C9F\u901A\u6392\u9664\u539F\u56E0\uFF0C\u4E0D\u81EA\u52A8\u91CD\u65B0\u8BC4\u4F30\u6216\u53D1\u9001";
  }
  if (!intent && c.status === "hard-conditions-ready-for-skill" && c.evaluationMode !== "salary-and-selected-ui") {
    const name = "assessment-attempt-v1-" + hash([d.processingContextId, d.queueKey, d.processingStateRevision]) + ".json";
    let saved = null;
    try {
      const file = { content: await template.file("communication-cache", { operation: "read", name }) };
      if (typeof file.content !== "string" || Buffer.byteLength(file.content) > 524288) throw Error("\u5C97\u4F4D\u5224\u65AD\u8BB0\u5F55\u5927\u5C0F\u6216\u683C\u5F0F\u65E0\u6548");
      saved = JSON.parse(file.content);
      if (JSON.stringify(saved) !== file.content) throw Error("\u5C97\u4F4D\u5224\u65AD\u8BB0\u5F55\u4E0D\u662F\u5B8C\u6574\u89C4\u8303\u5185\u5BB9");
    } catch (error) {
      const message = String(error?.message || error);
      if (!(message.includes("ENOENT") && message.includes(name))) throw error;
    }
    if (saved) {
      const a = saved.result, source = saved.source;
      if (saved.version !== 1 || saved.kind !== "boss-ai-assessment-attempt" || saved.policy !== "boss-ai-first-advice-v2" || !/^[a-f0-9]{64}$/.test(saved.scopeSha256) || !obj(source) || source.contextId !== s.contextId || source.applicationKey !== d.queueKey || source.ledgerStateRevision !== d.processingStateRevision || source.jobSource !== d.jobSource || source.title !== d.jobTitle || source.accountSourceSha256 !== d.accountSourceSha256 || source.configurationRevision !== d.configurationRevision || source.day !== day || source.timeZone !== d.timeZone || !obj(a) || a.version !== 1 || a.kind !== "job-assessment-advice" || !["match", "mismatch", "review"].includes(a.decision) || a.memoryScopeSha256 !== saved.scopeSha256 || !Array.isArray(a.issues) || typeof a.reason !== "string" || !a.reason.trim() || a.eligibleForActions !== false || a.applied !== false || !Number.isFinite(Date.parse(saved.createdAt)) || Date.parse(saved.createdAt) > Date.now()) throw Error("\u5C97\u4F4D\u5224\u65AD\u8BB0\u5F55\u4E0E\u672C\u9879\u6700\u65B0\u5904\u7406\u6765\u6E90\u4E0D\u4E00\u81F4\uFF0C\u4FDD\u7559\u72B6\u6001\u5E76\u505C\u6B62");
      const humanRejected = a.assessmentOrigin === "human-current-run" && a.humanResolution?.version === 1 && a.humanResolution?.kind === "current-run-job-confirmation" && a.humanResolution?.accepted === false && a.humanResolution?.scopeSha256 === saved.scopeSha256 && a.humanResolution?.applicationKey === d.queueKey && a.humanResolution?.configurationRevision === d.configurationRevision && a.humanResolution?.day === day && a.humanResolution?.timeZone === d.timeZone;
      status = a.decision === "mismatch" && (a.issues.length === 0 || humanRejected) ? "skipped" : "review";
      reason = status === "skipped" ? (humanRejected ? "\u672C\u4EBA\u9009\u62E9\u8DF3\u8FC7\u672C\u5C97\u4F4D\uFF1A" : "AI \u6838\u5BF9\u540E\u4E0D\u7B26\u5408\uFF1A") + a.reason : a.decision === "match" && a.issues.length === 0 ? "AI \u5DF2\u5224\u5B9A\u7B26\u5408\uFF0C\u4F46\u540E\u7EED\u8D26\u53F7\u3001\u53BB\u91CD\u6216\u9884\u7559\u6838\u5BF9\u672A\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE\uFF1B\u8BF7\u67E5\u770B\u672C\u6B21\u5177\u4F53\u963B\u65AD\u7ED3\u679C\u3002" : "AI \u590D\u6838\u4ECD\u9700\u5224\u65AD\uFF1A" + a.reason + (a.issues.length ? "\uFF1B" + a.issues.join("\uFF1B") : "");
    } else {
      status = "review";
      reason = "\u672C\u9879\u5C1A\u672A\u5F62\u6210\u5B8C\u6574 AI \u5224\u65AD\u8BB0\u5F55\uFF1B\u8BF7\u67E5\u770B\u8D44\u6599\u51C6\u5907\u6216\u6A21\u578B\u8BF7\u6C42\u7684\u5177\u4F53\u963B\u65AD\u7ED3\u679C\u3002\u6CA1\u6709\u5916\u53D1\u610F\u56FE\uFF0C\u4E0D\u63A8\u65AD\u4E3A\u4E0D\u7B26\u5408\u3002";
    }
  }
  if (!intent && status === "skipped" && Array.isArray(c.checks) && c.checks.some((v) => v.field === "\u804C\u4F4D\u72B6\u6001" && v.state === "mismatch" && v.reason === "\u7F51\u7AD9\u660E\u786E\u663E\u793A\u804C\u4F4D\u5DF2\u5173\u95ED\uFF1B\u4E0D\u8FDB\u5165\u6A21\u578B\u6216\u5916\u53D1")) reason = "\u7F51\u7AD9\u660E\u786E\u663E\u793A\u804C\u4F4D\u5DF2\u5173\u95ED\uFF1B\u672C\u9879\u6CA1\u6709\u6A21\u578B\u5224\u65AD\u3001\u62DB\u547C\u610F\u56FE\u6216\u5916\u53D1\uFF0C\u5DF2\u8DF3\u8FC7";
  if (!intent && c.sourceUnavailable === true) {
    if (c.status !== "hard-condition-mismatch" || !c.checks.some((v) => v.field === "\u6B63\u6587\u5B8C\u6574\u6027" && v.state === "mismatch" && v.reason === "\u672C\u9879\u6B63\u6587\u65E0\u6CD5\u5B8C\u6574\u6838\u5BF9\uFF0C\u4EC5\u8DF3\u8FC7\u672C\u9879\uFF0C\u4E0D\u5224\u65AD\u5C97\u4F4D\u4E0D\u7B26\u5408\uFF0C\u4E0D\u8C03\u7528AI\u6216\u5916\u53D1")) throw Error("\u6B63\u6587\u7F3A\u53E3\u5206\u7C7B\u6765\u6E90\u4E0D\u4E00\u81F4");
    status = "skipped";
    reason = "\u672C\u9879\u53F3\u4FA7\u6B63\u6587\u88AB\u7F51\u7AD9\u5E03\u5C40\u88C1\u526A\u68C0\u67E5\u963B\u6B62\uFF0C\u65E0\u6CD5\u5B8C\u6574\u6838\u5BF9\uFF1B\u4EC5\u8DF3\u8FC7\u672C\u9879\u5E76\u7EE7\u7EED\uFF0C\u4E0D\u4EE3\u8868\u5C97\u4F4D\u4E0D\u5339\u914D\uFF0C\u6CA1\u6709\u6A21\u578B\u5224\u65AD\u3001\u5916\u53D1\u610F\u56FE\u6216\u53D1\u9001\u3002";
  }
  if (!intent && c.evaluationMode === "salary-and-selected-ui" && c.status === "hard-conditions-ready-for-skill") {
    status = "review";
    reason = "\u672C\u9879\u85AA\u8D44\u4E0E\u9009\u4E2D\u6001\u5DF2\u901A\u8FC7\uFF0C\u4F46\u672A\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE\uFF1B\u8BF7\u67E5\u770B\u539F\u8FD0\u884C\u963B\u65AD\u7ED3\u679C\uFF0C\u6CA1\u6709AI\u5224\u65AD\u6216\u53D1\u9001\u3002";
  }
  const entry = { ...entries[0], status, reason };
  if (status === "review" || status === "unknown") await template.attention({ key: "daily-queue-outcome:" + hash([s.contextId, d.queueKey, status, day]), title: status === "unknown" ? "\u672C\u9879\u62DB\u547C\u7ED3\u679C\u672A\u77E5\uFF0C\u5DF2\u505C\u6B62\u7EED\u53D1" : "\u672C\u9879\u5019\u9009\u9700\u8981\u6838\u5BF9", detail: { jobTitle: d.jobTitle, jobSource: d.jobSource, status, reason, dayTaskComplete: false } });
  signal.throwIfAborted();
  return { version: 1, kind: "daily-queue-finish-plan", contextId: s.contextId, expectedRevision: s.revision, value: { ...s.value, queueEntries: s.value.queueEntries.map((r) => r.key === entry.key ? entry : r) }, entry, continueBatch: status !== "unknown", eligibleForActions: false, dayTaskComplete: false, siteDailyLimitConfirmed: false };
};
export {
  stdin_default as default
};
