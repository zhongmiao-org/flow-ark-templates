import { createHash } from "node:crypto";
const PANEL = Object.freeze({
  title: "head > title",
  jobTitle: ".job-detail-container .job-name",
  jobCity: ".job-header-info .tag-list > :nth-child(1)",
  companyLabel: ".job-boss-info > :nth-child(2) > :nth-child(2)",
  description: ".job-detail-body > .desc",
  salary: ".job-detail-container .job-salary",
  closedStatus: ".job-detail-container .job-close",
  contact: ".job-detail-container div:nth-of-type(2) > a:nth-of-type(2)"
});
const panelClean = (v) => String(v).replace(/\s+/gu, " ").trim();
const panelCompany = (v) => String(v).trim().split(/\s+·\s+/u).slice(0, -1).join(" \xB7 ").trim();
function panelJobIdentity(source) {
  const u = new URL(source), m = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(u.pathname);
  if (u.origin !== "https://www.zhipin.com" || u.username || u.password || u.search || u.hash || !m) throw Error("\u5C97\u4F4D\u5B8C\u6574\u94FE\u63A5\u65E0\u6548");
  const hrefs = [u.pathname, u.href].flatMap((v) => ['[href="' + v + '"]', '[href^="' + v + '?"]']).join(",");
  const relative = "> div:nth-of-type(1) > div > a:is(" + hrefs + ")";
  return { jobId: m[1], cardSelector: ".job-card-box:has(" + relative + ")", linkSelector: ".job-card-box " + relative };
}
async function panelFontCodec(read) {
  const sources = ["https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/app~0.1e6caebe.css", "https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/8026.de407e2f.css"];
  for (const href of sources) {
    const selector = 'head > link[rel="stylesheet"][href="' + href + '"]';
    if (await read("count", selector) !== 1 || await read("attribute", selector, "href") !== href) throw Error("\u85AA\u8D44\u5B57\u4F53\u6765\u6E90\u53D8\u5316\uFF0C\u672A\u731C\u6D4B\u91D1\u989D");
  }
  return "kanzhun-mix-2023-digits-v1";
}
function panelSalary(raw, codec) {
  if (typeof raw !== "string" || !raw.trim() || raw.length > 256) throw Error("\u85AA\u8D44\u539F\u6587\u7F3A\u5931\u6216\u8D85\u957F");
  if (/[\uE000-\uF8FF]/u.test(raw)) {
    if (codec !== "kanzhun-mix-2023-digits-v1" || /[\uE000-\uE030\uE03B-\uF8FF]/u.test(raw)) throw Error("\u85AA\u8D44\u5305\u542B\u672A\u7ECF\u6838\u5BF9\u7684\u5B57\u4F53\u7F16\u7801");
    return raw.replace(/[\uE031-\uE03A]/gu, (c) => String(c.charCodeAt(0) - 57393)).normalize("NFKC").trim();
  }
  return raw.normalize("NFKC").trim();
}
const directMode = "salary-and-selected-ui";
const directHash = (v) => createHash("sha256").update(typeof v === "string" ? v : JSON.stringify(v)).digest("hex");
const directDay = (zone) => new Intl.DateTimeFormat("sv-SE", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
function directSalary(raw) {
  const m = /^(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)\s*[Kk](?:\s*[·•]\s*\d{1,2}薪)?$/.exec(raw);
  if (!m) return null;
  const minimumYuan = Number(m[1]) * 1e3, maximumYuan = Number(m[2]) * 1e3;
  return Number.isSafeInteger(minimumYuan) && Number.isSafeInteger(maximumYuan) && minimumYuan > 0 && maximumYuan >= minimumYuan ? { minimumYuan, maximumYuan, period: "month" } : null;
}
async function directSelected(template, signal, c, { requireImmediate = false } = {}) {
  const read = async (operation, selector, value) => {
    signal.throwIfAborted();
    return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
  };
  const id = panelJobIdentity(c.jobSource), url = await read("url");
  if (url !== c.returnUrl) throw Error("\u5F53\u524D\u68C0\u7D22\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55");
  const active = ".job-card-wrap.active " + id.cardSelector;
  if (await read("count", ".job-card-wrap.active") !== 1 || await read("count", active) !== 1 || await read("count", id.linkSelector) !== 1) throw Error("\u672C\u9879\u5C97\u4F4D\u672A\u5904\u4E8E\u552F\u4E00\u9009\u4E2D\u72B6\u6001");
  const salarySelector = id.cardSelector + " .job-salary";
  if (await read("count", salarySelector) !== 1) throw Error("\u9009\u4E2D\u5C97\u4F4D\u85AA\u8D44\u4E0D\u552F\u4E00");
  const raw = String(await read("read", salarySelector)).trim(), codec = /[\uE000-\uF8FF]/u.test(raw) ? await panelFontCodec(read) : null, salaryRaw = panelSalary(raw, codec), salary = directSalary(salaryRaw);
  const href = new URL(await read("attribute", id.linkSelector, "href"), url);
  if (href.origin + href.pathname !== c.jobSource || await read("url") !== url) throw Error("\u9009\u4E2D\u5C97\u4F4D\u6765\u6E90\u53D8\u5316");
  let contactLabel = null, closed = false;
  const count = await read("count", PANEL.contact);
  if (count === 1) contactLabel = String(await read("read", PANEL.contact)).trim();
  else if (count === 0) closed = String(await read("read", "body")).split(/\r?\n/u).some((v) => v.trim() === "\u804C\u4F4D\u5DF2\u5173\u95ED");
  if (!closed && !["\u7ACB\u5373\u6C9F\u901A", "\u7EE7\u7EED\u6C9F\u901A"].includes(contactLabel)) throw Error("\u9009\u4E2D\u5C97\u4F4D\u7684\u6C9F\u901A\u5165\u53E3\u5C1A\u672A\u5C31\u7EEA");
  if (requireImmediate && contactLabel !== "\u7ACB\u5373\u6C9F\u901A") throw Error("\u5F53\u524D\u4E0D\u662F\u7ACB\u5373\u6C9F\u901A\uFF0C\u672A\u91CD\u590D\u53D1\u9001");
  if (await read("count", active) !== 1 || await read("url") !== url) throw Error("\u6838\u5BF9\u671F\u95F4\u9009\u4E2D\u72B6\u6001\u53D8\u5316");
  return { mode: directMode, jobSource: c.jobSource, selected: true, selector: active, salaryRaw, salary, contactLabel, closed, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
}
function directIntersection(salary, conditions) {
  return !!salary && (!conditions.salaryMin || salary.maximumYuan >= conditions.salaryMin) && (!conditions.salaryMax || salary.minimumYuan <= conditions.salaryMax);
}
var stdin_default = async ({ input, signal }) => {
  signal.throwIfAborted();
  const { account: a, advice: m, prepared: p, reservation: r, approvedGreetingText: text } = input, i = r?.intent, w = r?.receipt, s = m?.source;
  if (r?.result?.kind !== "daily-application-reservation" || r.result.reservationPersisted !== true || i?.status !== "reserved" || w?.operation !== "state.write" || w.revision !== r.result.stateRevision || JSON.stringify(w.value.applicationIntents.find((v) => v.key === i.key)) !== JSON.stringify(i) || m?.kind !== "direct-salary-selection-decision" || m.aiCalled !== false || m.decision !== "match" || p?.kind !== "direct-first-contact-prepared" || p.aiCalled !== false || s?.contextId !== w.contextId || s.applicationKey !== i.key || s.accountSourceSha256 !== i.accountSourceSha256 || s.jobSource !== i.jobSource || s.day !== i.day || s.configurationRevision !== i.configurationRevision || a?.currentAccountVerified !== true || directDay(i.timeZone) !== i.day) throw Error("\u7F3A\u5C11\u672C\u9879\u76F4\u63A5\u62DB\u547C\u7684\u6301\u4E45\u9884\u7559\u4E0E\u56DE\u8BFB");
  if (typeof text !== "string" || !text.trim() || text.length > 4e3) throw Error("\u6279\u51C6\u7684App\u62DB\u547C\u6B63\u6587\u7F3A\u5931");
  const greetingSha256 = directHash(text), description = "\u5411\u5F53\u524D\u9009\u4E2D\u5C97\u4F4D\u70B9\u51FB\u4E00\u6B21\u7ACB\u5373\u6C9F\u901A\uFF1B\u7F51\u7AD9\u53D1\u9001App\u9ED8\u8BA4\u62DB\u547C\u5E76\u7559\u5728\u672C\u9875\u3002", target = s.title + " \xB7 " + s.actualCity + " \xB7 \u8D26\u53F7\uFF1A" + a.accountName;
  return { version: 1, kind: "daily-application-operation-input", evaluationMode: directMode, aiCalled: false, action: "apply", submissionMode: "first-communication-with-app-default-greeting", greetingText: text, greetingSha256, key: "application:" + i.key, description, review: { version: 1, target, content: ["\u4F7F\u7528\u8005\u89C4\u5219\uFF1A\u5217\u8868\u6708\u85AA\u6709\u4EA4\u96C6\u5E76\u4E14\u5C97\u4F4D\u5DF2\u9009\u4E2D\uFF0C\u76F4\u63A5\u9996\u6B21\u6C9F\u901A\u3002", "\u5C97\u4F4D\uFF1A" + s.title, "\u5217\u8868\u6708\u85AA\uFF1A" + p.job.salaryRaw, "\u5C97\u4F4D\u94FE\u63A5\uFF1A" + i.jobSource, "\u8D26\u53F7\uFF1A" + a.accountName + "\uFF08" + a.phoneMask + "\uFF09", "\u4E0D\u8C03\u7528AI\uFF0C\u4E0D\u4F5CJD\u6216\u516C\u53F8\u540D\u79F0\u6BD4\u5BF9\uFF1B\u4E0D\u53D1\u9001\u7B80\u5386\u9644\u4EF6\u3001\u8054\u7CFB\u65B9\u5F0F\u6216\u53E6\u4E00\u6761\u4ECB\u7ECD\u3002", "App\u6279\u51C6\u62DB\u547C\uFF1A", text, "\u70B9\u51FB\u524D\u6301\u4E45\u9884\u7559\uFF1B\u7F51\u7AD9\u9001\u8FBE\u4E0D\u660E\u4FDD\u7559unknown\u5E76\u505C\u6B62\uFF0C\u4E0D\u91CD\u653E\u3002"].join("\n") }, intent: i, stateRevision: w.revision, contextId: w.contextId, actualCity: s.actualCity, jobTitle: s.title, jobSource: i.jobSource, listSource: s.listSource, sourceMode: "persisted-job-link-in-list", websiteGreetingVerified: false, readyForWebsiteSubmission: false, applied: false };
};
export {
  stdin_default as default
};
