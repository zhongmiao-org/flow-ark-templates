import { createHash } from "node:crypto";
const PANEL = Object.freeze({
  title: "head > title",
  jobTitle: ".job-detail-container .job-name",
  jobCity: ".job-header-info .tag-list > :nth-child(1)",
  companyLabel: ".job-boss-info > :nth-child(2) > :nth-child(2)",
  description: ".job-detail-body > .desc",
  salary: ".job-detail-container .job-salary",
  closedStatus: ".job-detail-container .job-close",
  contact: ".job-detail-container div:nth-of-type(2) > a:nth-of-type(2)"
});
const panelClean = (v) => String(v).replace(/\s+/gu, " ").trim();
const panelCompany = (v) => String(v).trim().split(/\s+·\s+/u).slice(0, -1).join(" \xB7 ").trim();
function panelJobIdentity(source) {
  const u = new URL(source), m = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(u.pathname);
  if (u.origin !== "https://www.zhipin.com" || u.username || u.password || u.search || u.hash || !m) throw Error("\u5C97\u4F4D\u5B8C\u6574\u94FE\u63A5\u65E0\u6548");
  const hrefs = [u.pathname, u.href].flatMap((v) => ['[href="' + v + '"]', '[href^="' + v + '?"]']).join(",");
  const relative = "> div:nth-of-type(1) > div > a:is(" + hrefs + ")";
  return { jobId: m[1], cardSelector: ".job-card-box:has(" + relative + ")", linkSelector: ".job-card-box " + relative };
}
async function panelFontCodec(read) {
  const sources = ["https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/app~0.1e6caebe.css", "https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/8026.de407e2f.css"];
  for (const href of sources) {
    const selector = 'head > link[rel="stylesheet"][href="' + href + '"]';
    if (await read("count", selector) !== 1 || await read("attribute", selector, "href") !== href) throw Error("\u85AA\u8D44\u5B57\u4F53\u6765\u6E90\u53D8\u5316\uFF0C\u672A\u731C\u6D4B\u91D1\u989D");
  }
  return "kanzhun-mix-2023-digits-v1";
}
function panelSalary(raw, codec) {
  if (typeof raw !== "string" || !raw.trim() || raw.length > 256) throw Error("\u85AA\u8D44\u539F\u6587\u7F3A\u5931\u6216\u8D85\u957F");
  if (/[\uE000-\uF8FF]/u.test(raw)) {
    if (codec !== "kanzhun-mix-2023-digits-v1" || /[\uE000-\uE030\uE03B-\uF8FF]/u.test(raw)) throw Error("\u85AA\u8D44\u5305\u542B\u672A\u7ECF\u6838\u5BF9\u7684\u5B57\u4F53\u7F16\u7801");
    return raw.replace(/[\uE031-\uE03A]/gu, (c) => String(c.charCodeAt(0) - 57393)).normalize("NFKC").trim();
  }
  return raw.normalize("NFKC").trim();
}
const directMode = "salary-and-selected-ui";
const directHash = (v) => createHash("sha256").update(typeof v === "string" ? v : JSON.stringify(v)).digest("hex");
const directDay = (zone) => new Intl.DateTimeFormat("sv-SE", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
function directSalary(raw) {
  const m = /^(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)\s*[Kk](?:\s*[·•]\s*\d{1,2}薪)?$/.exec(raw);
  if (!m) return null;
  const minimumYuan = Number(m[1]) * 1e3, maximumYuan = Number(m[2]) * 1e3;
  return Number.isSafeInteger(minimumYuan) && Number.isSafeInteger(maximumYuan) && minimumYuan > 0 && maximumYuan >= minimumYuan ? { minimumYuan, maximumYuan, period: "month" } : null;
}
async function directSelected(template, signal, c, { requireImmediate = false } = {}) {
  const read = async (operation, selector, value) => {
    signal.throwIfAborted();
    return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
  };
  const id = panelJobIdentity(c.jobSource), url = await read("url");
  if (url !== c.returnUrl) throw Error("\u5F53\u524D\u68C0\u7D22\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55");
  const active = ".job-card-wrap.active " + id.cardSelector;
  if (await read("count", ".job-card-wrap.active") !== 1 || await read("count", active) !== 1 || await read("count", id.linkSelector) !== 1) throw Error("\u672C\u9879\u5C97\u4F4D\u672A\u5904\u4E8E\u552F\u4E00\u9009\u4E2D\u72B6\u6001");
  const salarySelector = id.cardSelector + " .job-salary";
  if (await read("count", salarySelector) !== 1) throw Error("\u9009\u4E2D\u5C97\u4F4D\u85AA\u8D44\u4E0D\u552F\u4E00");
  const raw = String(await read("read", salarySelector)).trim(), codec = /[\uE000-\uF8FF]/u.test(raw) ? await panelFontCodec(read) : null, salaryRaw = panelSalary(raw, codec), salary = directSalary(salaryRaw);
  const href = new URL(await read("attribute", id.linkSelector, "href"), url);
  if (href.origin + href.pathname !== c.jobSource || await read("url") !== url) throw Error("\u9009\u4E2D\u5C97\u4F4D\u6765\u6E90\u53D8\u5316");
  let contactLabel = null, closed = false;
  const count = await read("count", PANEL.contact);
  if (count === 1) contactLabel = String(await read("read", PANEL.contact)).trim();
  else if (count === 0) closed = String(await read("read", "body")).split(/\r?\n/u).some((v) => v.trim() === "\u804C\u4F4D\u5DF2\u5173\u95ED");
  if (!closed && !["\u7ACB\u5373\u6C9F\u901A", "\u7EE7\u7EED\u6C9F\u901A"].includes(contactLabel)) throw Error("\u9009\u4E2D\u5C97\u4F4D\u7684\u6C9F\u901A\u5165\u53E3\u5C1A\u672A\u5C31\u7EEA");
  if (requireImmediate && contactLabel !== "\u7ACB\u5373\u6C9F\u901A") throw Error("\u5F53\u524D\u4E0D\u662F\u7ACB\u5373\u6C9F\u901A\uFF0C\u672A\u91CD\u590D\u53D1\u9001");
  if (await read("count", active) !== 1 || await read("url") !== url) throw Error("\u6838\u5BF9\u671F\u95F4\u9009\u4E2D\u72B6\u6001\u53D8\u5316");
  return { mode: directMode, jobSource: c.jobSource, selected: true, selector: active, salaryRaw, salary, contactLabel, closed, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
}
function directIntersection(salary, conditions) {
  return !!salary && (!conditions.salaryMin || salary.maximumYuan >= conditions.salaryMin) && (!conditions.salaryMax || salary.minimumYuan <= conditions.salaryMax);
}
function communicationCache(template, signal, contextId, accountSourceSha256) {
  const object = (v) => !!v && typeof v === "object" && !Array.isArray(v);
  const canonical2 = (v) => Array.isArray(v) ? v.map(canonical2) : object(v) ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical2(v[k])])) : v;
  const encode = (v) => JSON.stringify(canonical2(v));
  const sha = (v) => createHash("sha256").update(v).digest("hex");
  const digest2 = (v) => typeof v === "string" && /^[a-f0-9]{64}$/.test(v);
  const timestamp = (v) => typeof v === "string" && Number.isFinite(Date.parse(v)) && new Date(v).toISOString() === v && Date.parse(v) <= Date.now();
  if (typeof contextId !== "string" || !contextId || contextId.length > 200 || !digest2(accountSourceSha256)) throw Error("\u7F13\u5B58\u6240\u5C5E\u4E0A\u4E0B\u6587\u6216\u8D26\u53F7\u6765\u6E90\u65E0\u6548");
  const scope = { version: 1, kind: "boss-communication-cache-scope", contextId, accountSourceSha256 };
  const scopeText = encode(scope), scopeName = "scope-v1-" + sha(scopeText) + ".json";
  let initialized = false;
  const guarded = (fn) => async (...args) => {
    try {
      return await fn(...args);
    } catch (error) {
      if (signal.aborted || error?.communicationCacheFailure === true) throw error;
      const failure = Error("\u6C9F\u901A\u7F13\u5B58\u6545\u969C\uFF1A" + String(error?.message || error));
      failure.communicationCacheFailure = true;
      throw failure;
    }
  };
  const controlled = (name) => typeof name === "string" && /^(?:scope|observation|positive)-v1-[a-f0-9]{64}\.json$/.test(name);
  const missingTarget = (error, name) => {
    const match = /^ENOENT: no such file or directory, realpath '([^'\r\n]+)'$/.exec(String(error?.message || ""));
    return !!match && controlled(name) && match[1].endsWith("/" + name);
  };
  const rawRead = async (name) => {
    if (!controlled(name)) throw Error("\u7F13\u5B58\u6587\u4EF6\u540D\u4E0D\u53D7\u652F\u6301");
    signal.throwIfAborted();
    const content = await template.file("communication-cache", { operation: "read", name });
    signal.throwIfAborted();
    if (typeof content !== "string" || Buffer.byteLength(content) > 10 * 1024 * 1024) throw Error("\u7F13\u5B58\u5185\u5BB9\u8D85\u51FA\u65E2\u6709\u6587\u4EF6\u8BFB\u53D6\u8303\u56F4");
    return content;
  };
  const checkScope = async () => {
    if (await rawRead(scopeName) !== scopeText) throw Error("\u7F13\u5B58\u8303\u56F4\u6807\u8BB0\u4E0E\u672C\u5B9E\u4F8B\u8D26\u53F7\u4E0D\u4E00\u81F4\uFF0C\u4FDD\u7559\u539F\u6587\u4EF6");
  };
  const init = async () => {
    try {
      if (await rawRead(scopeName) !== scopeText) throw Error("\u7F13\u5B58\u8303\u56F4\u6807\u8BB0\u635F\u574F\u6216\u4E0D\u4E00\u81F4\uFF0C\u4FDD\u7559\u539F\u6587\u4EF6");
    } catch (error) {
      if (!missingTarget(error, scopeName)) throw error;
      signal.throwIfAborted();
      await template.file("communication-cache", { operation: "write", name: scopeName, content: scopeText });
      await checkScope();
    }
    initialized = true;
  };
  const read = async (name) => {
    if (!initialized) throw Error("\u7F13\u5B58\u8303\u56F4\u5C1A\u672A\u6838\u5BF9");
    try {
      return await rawRead(name);
    } catch (error) {
      if (!missingTarget(error, name)) throw error;
      await checkScope();
      return null;
    }
  };
  const put = async (name, value) => {
    const content = encode(value);
    if (typeof content !== "string" || Buffer.byteLength(content) > 10 * 1024 * 1024) throw Error("\u7F13\u5B58\u8F93\u51FA\u8D85\u8FC7\u65E2\u6709SDK\u4E0A\u9650\uFF0C\u672A\u622A\u65AD\u5199\u5165");
    const previous = await read(name);
    if (previous !== null && previous !== content) throw Error("\u7F13\u5B58\u6587\u4EF6\u5DF2\u6709\u4E0D\u540C\u5185\u5BB9\uFF0C\u4FDD\u7559\u539F\u6587\u4EF6");
    if (previous === null) {
      signal.throwIfAborted();
      await template.file("communication-cache", { operation: "write", name, content });
    }
    if (await rawRead(name) !== content) throw Error("\u7F13\u5B58\u5199\u51FA\u4E0E\u56DE\u8BFB\u4E0D\u4E00\u81F4");
    return { name, sha256: sha(content) };
  };
  const parse = (content) => {
    let value;
    try {
      value = JSON.parse(content);
    } catch {
      throw Error("\u7F13\u5B58JSON\u635F\u574F\uFF0C\u4E0D\u80FD\u6309\u7A7A\u7F13\u5B58\u5904\u7406");
    }
    if (!object(value) || encode(value) !== content) throw Error("\u7F13\u5B58\u4E0D\u662F\u5B8C\u6574\u89C4\u8303\u5BF9\u8C61\uFF0C\u4E0D\u80FD\u6309\u7A7A\u7F13\u5B58\u5904\u7406");
    return value;
  };
  const identity = (value, jobSource, jobId) => {
    let source;
    try {
      source = new URL(jobSource);
    } catch {
      throw Error("\u7F13\u5B58\u5C97\u4F4D\u6765\u6E90\u65E0\u6548");
    }
    const match = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(source.pathname);
    if (source.origin !== "https://www.zhipin.com" || source.username || source.password || source.port || source.search || source.hash || source.href !== jobSource || match?.[1] !== jobId || value.version !== 1 || value.contextId !== contextId || value.accountSourceSha256 !== accountSourceSha256 || value.jobSource !== jobSource || value.jobId !== jobId) throw Error("\u7F13\u5B58\u4E0A\u4E0B\u6587\u3001\u8D26\u53F7\u6216\u5B8C\u6574\u5C97\u4F4D\u6765\u6E90\u4E0D\u4E00\u81F4");
  };
  const observe = async (value) => {
    const record = { ...value, version: 1, kind: "boss-communication-observation", contextId, accountSourceSha256 };
    identity(record, value.jobSource, value.jobId);
    if (!timestamp(record.observedAt) || record.doNotReplay !== true) throw Error("\u7F13\u5B58\u89C2\u5BDF\u65F6\u95F4\u6216\u672A\u77E5\u91CD\u653E\u8FB9\u754C\u65E0\u6548");
    const content = encode(record), name = "observation-v1-" + sha(content) + ".json";
    return put(name, record);
  };
  return { init: guarded(init), observe: guarded(observe) };
}
const canonical = (v) => Array.isArray(v) ? v.map(canonical) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical(v[k])])) : v;
const digest = (v) => createHash("sha256").update(JSON.stringify(canonical(v))).digest("hex");
async function safetyIndex(template, signal, accountKey, contextId, initialize = false) {
  const name = "account-outbound-safety-v1-" + accountKey + ".json";
  let data, existed = true, baseline;
  try {
    baseline = await template.file("communication-cache", { operation: "read", name });
    data = JSON.parse(baseline);
  } catch (error) {
    if (!String(error.message || error).includes("ENOENT")) throw error;
    if (!initialize) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
    existed = false;
    data = { version: 1, kind: "boss-account-outbound-safety", accountKey, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (existed) {
    const { sha256, ...body } = data;
    if (sha256 !== digest(body)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
  }
  if (data.version !== 1 || data.kind !== "boss-account-outbound-safety" || data.accountKey !== accountKey || !Number.isSafeInteger(data.revision) || data.revision < 0 || !Array.isArray(data.records) || data.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
  const records = /* @__PURE__ */ new Set();
  for (const r of data.records) {
    if (!["first-contact", "reply"].includes(r.type) || !/^[a-f0-9]{64}$/.test(r.businessKey) || !Array.isArray(r.sightings) || !r.sightings.length || r.sightings.length > 100 || records.has(r.type + ":" + r.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
    records.add(r.type + ":" + r.businessKey);
    for (const s of r.sightings) if (typeof s.contextId !== "string" || !s.contextId || !/^[a-f0-9]{64}$/.test(s.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(s.status) || !/^\d{4}-\d{2}-\d{2}$/.test(s.day) || typeof s.timeZone !== "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
  }
  let dirty = !existed;
  const merge = (state) => {
    if (!Array.isArray(state?.applicationIntents) || !Array.isArray(state?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
    for (const [type, rows] of [["first-contact", state.applicationIntents], ["reply", state.replyIntents]]) for (const i of rows) {
      if ((type === "first-contact" ? i.accountSourceSha256 : i.accountKey) !== accountKey) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
      if (!/^[a-f0-9]{64}$/.test(i.key) || !i.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(i.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
      const businessKey = type === "first-contact" ? digest(["boss-job-safety-v1", accountKey, i.jobId]) : createHash("sha256").update(["boss-text-reply-v1", accountKey, i.incomingMessageId].join(":")).digest("hex");
      let r = data.records.find((r2) => r2.type === type && r2.businessKey === businessKey);
      if (!r) {
        r = { type, businessKey, jobId: i.jobId, ...type === "reply" ? { conversationKey: i.conversationKey, incomingMessageId: i.incomingMessageId } : {}, sightings: [] };
        data.records.push(r);
        dirty = true;
      }
      if (r.jobId !== i.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
      const sight = { contextId, intentKey: i.key, status: i.status, day: i.day, timeZone: i.timeZone, contentSha256: i.contentSha256 || null, sourceSha256: i.sourceSha256 || null };
      if (!r.sightings.some((s) => JSON.stringify(canonical(s)) === JSON.stringify(canonical(sight)))) {
        r.sightings.push(sight);
        dirty = true;
      }
      if (r.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
    }
    if (data.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
  };
  const save = async () => {
    signal.throwIfAborted();
    if (dirty) {
      if (existed && await template.file("communication-cache", { operation: "read", name }) !== baseline) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
      data.records.sort((a, b) => (a.type + ":" + a.businessKey).localeCompare(b.type + ":" + b.businessKey));
      for (const r of data.records) r.sightings.sort((a, b) => JSON.stringify(canonical(a)).localeCompare(JSON.stringify(canonical(b))));
      data.revision++;
      data.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      delete data.sha256;
      data.sha256 = digest(data);
      await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(data) });
      dirty = false;
      baseline = JSON.stringify(data);
      existed = true;
    }
    const back = JSON.parse(await template.file("communication-cache", { operation: "read", name }));
    const { sha256, ...body } = back;
    if (sha256 !== digest(body) || sha256 !== data.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
    return { revision: data.revision, sha256: data.sha256, records: data.records.length };
  };
  return { data, name, merge, save, blocked: (type, key) => data.records.some((r) => r.type === type && r.businessKey === key) };
}
const greetingDigest = digest;
var stdin_default = async ({ input, signal, template }) => {
  signal.throwIfAborted();
  const obj = (v) => !!v && typeof v === "object" && !Array.isArray(v), hash = (v) => createHash("sha256").update(v).digest("hex"), same = (a, b) => greetingDigest(a) === greetingDigest(b);
  if (!obj(input) || Object.keys(input).sort().join(",") !== "chat,check,clickResult,fields,pageText,pageUrl,receipt,source,state") throw Error("\u7F3A\u5C11\u672C\u6B21\u7F51\u7AD9\u62DB\u547C\u56DE\u6267\u4E0E\u5B8C\u6574\u72B6\u6001");
  const { chat: h, fields: f, state: st, check: c, receipt: r, source: s } = input, i = s?.intent;
  if (h?.kind !== "daily-default-greeting-acknowledged" || !same(h.check, c) || !same(h.receipt, r) || !same(h.source, s) || !same(h.clickResult, input.clickResult) || r?.state !== "submitting" || r.execute !== true || r.operation !== "prepare" || r.id !== c?.operationId || r.runId !== c?.runId || r.key !== s?.key || s.key !== "application:" + i?.key || i.status !== "reserved" || h.extraIntroductionSent !== false) throw Error("\u9ED8\u8BA4\u62DB\u547C\u89C2\u5BDF\u4E0D\u5C5E\u4E8E\u672C\u6B21\u70B9\u51FB\u4E0E\u539F\u9884\u7559");
  const cache = communicationCache(template, signal, s.contextId, i.accountSourceSha256);
  await cache.init();
  let stopping = false, resolved = false;
  const fail = async (reason) => {
    stopping = true;
    const evidence = { version: 1, kind: "default-greeting-confirmation-unresolved", jobSource: i.jobSource, reason, observedAt: (/* @__PURE__ */ new Date()).toISOString() };
    if (!resolved) await template.effect.resolve({ id: r.id, state: "unknown", evidence });
    await template.attention({ key: "default-greeting-save:" + r.id, title: "\u81EA\u52A8\u62DB\u547C\u4FDD\u5B58\u524D\u9700\u6838\u5BF9", detail: { ...evidence, doNotReplay: true } });
    throw Error(reason + "\uFF1B\u4E0D\u91CD\u590D\u53D1\u9001");
  };
  try {
    if (!obj(f) || f.version !== 3 || f.operation !== "collect" || f.selector !== "body" || f.complete !== true || !Array.isArray(f.framePath) || f.framePath.length || !Array.isArray(f.fields) || f.fields.length !== 4 || f.url !== s.listSource || f.documentUrl !== s.listSource || h.listSource !== s.listSource) return await fail("\u540C\u6B21\u5217\u8868\u56DE\u6267\u91C7\u96C6\u4E0D\u5B8C\u6574\u6216\u6765\u6E90\u53D8\u5316");
    const observed = Date.parse(h.observedAt);
    if (!Number.isFinite(observed) || observed > Date.now() || Date.now() - observed > 6e4) return await fail("\u9ED8\u8BA4\u62DB\u547C\u6210\u529F\u56DE\u6267\u5DF2\u7ECF\u8FC7\u671F");
    const specs = { jobTitle: PANEL.jobTitle, contact: PANEL.contact, city: PANEL.jobCity, salary: PANEL.salary }, values = {};
    for (const [key, selector] of Object.entries(specs)) {
      const rows = f.fields.filter((v2) => v2?.key === key), v = rows[0];
      if (rows.length !== 1 || h.selectors?.[key] !== selector || v.selector !== selector || v.operation !== "text" || v.attribute !== null || v.required !== true || v.count !== 1 || v.status !== "ok" || !Array.isArray(v.issues) || v.issues.length || typeof v.value !== "string" || !v.value.trim() || v.value.trim() !== h.rendered?.[key]) return await fail("\u540C\u6B21\u9875\u9762\u5B57\u6BB5\u4E0E\u5B9E\u9645\u6210\u529F\u56DE\u6267\u4E0D\u4E00\u81F4\uFF1A" + key);
      values[key] = v.value.trim();
    }
    if (!["\u7ACB\u5373\u6C9F\u901A", "\u7EE7\u7EED\u6C9F\u901A"].includes(values.contact) || h.stayedOnList !== true || h.fullGreetingVerified !== true || h.acknowledgement?.selector !== ".greet-boss-dialog" || !String(h.acknowledgement.text).includes("\u5DF2\u5411BOSS\u53D1\u9001\u6D88\u606F") || !h.cachedAcknowledgement?.name || h.acknowledgement.actualMessage !== s.greetingText || directHash(h.acknowledgement.actualMessage) !== s.greetingSha256 || h.acknowledgement.actualMessageSha256 !== s.greetingSha256 || h.acknowledgement.approvedMessageSha256 !== s.greetingSha256) return await fail("\u7F3A\u5C11\u672C\u6B21\u7559\u9875\u53CA\u5B8C\u6574\u9ED8\u8BA4\u62DB\u547C\u6210\u529F\u56DE\u6267");
    await directSelected(template, signal, { jobSource: i.jobSource, returnUrl: s.listSource });
    const day = new Intl.DateTimeFormat("sv-SE", { timeZone: i.timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
    if (day !== i.day || !obj(st) || st.version !== 1 || st.operation !== "state.read" || st.contextId !== s.contextId || !Number.isSafeInteger(st.revision) || st.revision < s.stateRevision || !obj(st.value) || !["applicationIntents", "conversationControls", "replyIntents", "queueEntries"].every((k) => Array.isArray(st.value[k])) || st.value.applicationIntents.length > 500) return await fail("\u65E5\u671F\u6216\u6700\u65B0\u5B8C\u6574\u72B6\u6001\u4E0D\u9002\u7528");
    const q = st.value.queueEntries.filter((v) => v?.key === i.key), matches = st.value.applicationIntents.filter((v) => v?.key === i.key);
    if (q.length !== 1 || q[0].status !== "processing" || q[0].accountSourceSha256 !== i.accountSourceSha256 || q[0].jobSource !== i.jobSource || q[0].day !== i.day || q[0].timeZone !== i.timeZone || q[0].configurationRevision !== i.configurationRevision || matches.length !== 1 || !same(matches[0], i)) return await fail("\u539F\u9884\u7559\u6216\u672C\u9879\u5904\u7406\u4E2D\u72B6\u6001\u5DF2\u7ECF\u53D8\u5316");
    const evidence = { version: 1, kind: "first-communication-default-greeting-acknowledgement", jobSource: i.jobSource, jobTitle: c.jobTitle, actualCity: c.actualCity, listSource: s.listSource, acknowledgement: h.acknowledgement, acknowledgementSha256: greetingDigest(h.acknowledgement), approvedMessageSha256: s.greetingSha256, actualMessageSha256: h.acknowledgement.actualMessageSha256, currentMessageBodyInspected: true, collectedFieldsSha256: greetingDigest(f), observedAt: (/* @__PURE__ */ new Date()).toISOString(), runId: r.runId, clicked: true, websiteGreetingVerified: true, stayedOnList: true, listRestored: true, extraIntroductionSent: false, attachmentSent: false };
    const cachedVerification = await cache.observe({ observationType: "default-greeting-verification", jobId: i.jobId, jobSource: i.jobSource, operationId: r.id, operationKey: r.key, runId: r.runId, sourcePage: s.listSource, observedAt: (/* @__PURE__ */ new Date()).toISOString(), fields: f, evidence, acknowledgement: h.cachedAcknowledgement, doNotReplay: true });
    await template.effect.resolve({ id: r.id, state: "confirmed", evidence });
    resolved = true;
    signal.throwIfAborted();
    const value = structuredClone(st.value);
    value.applicationIntents = value.applicationIntents.map((v) => v.key === i.key ? { ...v, status: "confirmed" } : v);
    return { version: 1, kind: "daily-first-communication-confirmation-plan", contextId: st.contextId, expectedRevision: st.revision, originalValue: st.value, value, intent: i, evidence, cachedObservation: h.cachedAcknowledgement, cachedVerification, operationId: r.id, operationKey: r.key, jobTitle: c.jobTitle, jobSource: i.jobSource, actualCity: c.actualCity, websiteGreetingVerified: true, attachmentSent: false, dayTaskComplete: false, siteDailyLimitConfirmed: false };
  } catch (error) {
    if (signal.aborted || stopping || error?.communicationCacheFailure) throw error;
    return await fail(String(error?.message || error).slice(0, 800));
  }
};
export {
  stdin_default as default
};
