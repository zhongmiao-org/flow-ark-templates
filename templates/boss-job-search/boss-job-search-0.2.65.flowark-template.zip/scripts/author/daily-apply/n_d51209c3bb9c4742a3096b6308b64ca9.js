import { createHash } from "node:crypto";
const PANEL = Object.freeze({
  title: "head > title",
  jobTitle: ".job-detail-container .job-name",
  jobCity: ".job-header-info .tag-list > :nth-child(1)",
  companyLabel: ".job-boss-info > :nth-child(2) > :nth-child(2)",
  description: ".job-detail-body > .desc",
  salary: ".job-detail-container .job-salary",
  closedStatus: ".job-detail-container .job-close",
  contact: ".job-detail-container div:nth-of-type(2) > a:nth-of-type(2)"
});
const panelClean = (v) => String(v).replace(/\s+/gu, " ").trim();
const panelCompany = (v) => String(v).trim().split(/\s+·\s+/u).slice(0, -1).join(" \xB7 ").trim();
function panelJobIdentity(source) {
  const u = new URL(source), m = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(u.pathname);
  if (u.origin !== "https://www.zhipin.com" || u.username || u.password || u.search || u.hash || !m) throw Error("\u5C97\u4F4D\u5B8C\u6574\u94FE\u63A5\u65E0\u6548");
  const hrefs = [u.pathname, u.href].flatMap((v) => ['[href="' + v + '"]', '[href^="' + v + '?"]']).join(",");
  const relative = "> div:nth-of-type(1) > div > a:is(" + hrefs + ")";
  return { jobId: m[1], cardSelector: ".job-card-box:has(" + relative + ")", linkSelector: ".job-card-box " + relative };
}
async function panelFontCodec(read) {
  const sources = ["https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/app~0.1e6caebe.css", "https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/8026.de407e2f.css"];
  for (const href of sources) {
    const selector = 'head > link[rel="stylesheet"][href="' + href + '"]';
    if (await read("count", selector) !== 1 || await read("attribute", selector, "href") !== href) throw Error("\u85AA\u8D44\u5B57\u4F53\u6765\u6E90\u53D8\u5316\uFF0C\u672A\u731C\u6D4B\u91D1\u989D");
  }
  return "kanzhun-mix-2023-digits-v1";
}
function panelSalary(raw, codec) {
  if (typeof raw !== "string" || !raw.trim() || raw.length > 256) throw Error("\u85AA\u8D44\u539F\u6587\u7F3A\u5931\u6216\u8D85\u957F");
  if (/[\uE000-\uF8FF]/u.test(raw)) {
    if (codec !== "kanzhun-mix-2023-digits-v1" || /[\uE000-\uE030\uE03B-\uF8FF]/u.test(raw)) throw Error("\u85AA\u8D44\u5305\u542B\u672A\u7ECF\u6838\u5BF9\u7684\u5B57\u4F53\u7F16\u7801");
    return raw.replace(/[\uE031-\uE03A]/gu, (c) => String(c.charCodeAt(0) - 57393)).normalize("NFKC").trim();
  }
  return raw.normalize("NFKC").trim();
}
const directMode = "salary-and-selected-ui";
const directHash = (v) => createHash("sha256").update(typeof v === "string" ? v : JSON.stringify(v)).digest("hex");
const directDay = (zone) => new Intl.DateTimeFormat("sv-SE", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
function directSalary(raw) {
  const m = /^(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)\s*[Kk](?:\s*[·•]\s*\d{1,2}薪)?$/.exec(raw);
  if (!m) return null;
  const minimumYuan = Number(m[1]) * 1e3, maximumYuan = Number(m[2]) * 1e3;
  return Number.isSafeInteger(minimumYuan) && Number.isSafeInteger(maximumYuan) && minimumYuan > 0 && maximumYuan >= minimumYuan ? { minimumYuan, maximumYuan, period: "month" } : null;
}
async function directSelected(template, signal, c, { requireImmediate = false } = {}) {
  const read = async (operation, selector, value) => {
    signal.throwIfAborted();
    return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
  };
  const id = panelJobIdentity(c.jobSource), url = await read("url");
  if (url !== c.returnUrl) throw Error("\u5F53\u524D\u68C0\u7D22\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55");
  const active = ".job-card-wrap.active " + id.cardSelector;
  if (await read("count", ".job-card-wrap.active") !== 1 || await read("count", active) !== 1 || await read("count", id.linkSelector) !== 1) throw Error("\u672C\u9879\u5C97\u4F4D\u672A\u5904\u4E8E\u552F\u4E00\u9009\u4E2D\u72B6\u6001");
  const salarySelector = id.cardSelector + " .job-salary";
  if (await read("count", salarySelector) !== 1) throw Error("\u9009\u4E2D\u5C97\u4F4D\u85AA\u8D44\u4E0D\u552F\u4E00");
  const raw = String(await read("read", salarySelector)).trim(), codec = /[\uE000-\uF8FF]/u.test(raw) ? await panelFontCodec(read) : null, salaryRaw = panelSalary(raw, codec), salary = directSalary(salaryRaw);
  const href = new URL(await read("attribute", id.linkSelector, "href"), url);
  if (href.origin + href.pathname !== c.jobSource || await read("url") !== url) throw Error("\u9009\u4E2D\u5C97\u4F4D\u6765\u6E90\u53D8\u5316");
  let contactLabel = null, closed = false;
  const count = await read("count", PANEL.contact);
  if (count === 1) contactLabel = String(await read("read", PANEL.contact)).trim();
  else if (count === 0) closed = String(await read("read", "body")).split(/\r?\n/u).some((v) => v.trim() === "\u804C\u4F4D\u5DF2\u5173\u95ED");
  if (!closed && !["\u7ACB\u5373\u6C9F\u901A", "\u7EE7\u7EED\u6C9F\u901A"].includes(contactLabel)) throw Error("\u9009\u4E2D\u5C97\u4F4D\u7684\u6C9F\u901A\u5165\u53E3\u5C1A\u672A\u5C31\u7EEA");
  if (requireImmediate && contactLabel !== "\u7ACB\u5373\u6C9F\u901A") throw Error("\u5F53\u524D\u4E0D\u662F\u7ACB\u5373\u6C9F\u901A\uFF0C\u672A\u91CD\u590D\u53D1\u9001");
  if (await read("count", active) !== 1 || await read("url") !== url) throw Error("\u6838\u5BF9\u671F\u95F4\u9009\u4E2D\u72B6\u6001\u53D8\u5316");
  return { mode: directMode, jobSource: c.jobSource, selected: true, selector: active, salaryRaw, salary, contactLabel, closed, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
}
function directIntersection(salary, conditions) {
  return !!salary && (!conditions.salaryMin || salary.maximumYuan >= conditions.salaryMin) && (!conditions.salaryMax || salary.minimumYuan <= conditions.salaryMax);
}
var stdin_default = async ({ input, template, signal }) => {
  signal.throwIfAborted();
  const { account: a, advice: m, batch: b, candidate: h, configuration: f, fixedConfiguration: raw, ledger: l, profile: p, resume: d, state: st } = input, s = m?.source;
  if (raw?.operation !== "configuration" || st?.operation !== "state.read" || st.contextId !== raw.contextId || raw.revision !== f?.configurationRevision || h?.evaluationMode !== directMode || h.readyForFirstContact !== true || m?.kind !== "direct-salary-selection-decision" || m.aiCalled !== false || m.decision !== "match" || s?.contextId !== raw.contextId || s.configurationRevision !== raw.revision || s.jobSource !== h.jobSource || s.applicationKey !== l?.key || s.day !== directDay(f.timeZone) || s.day !== f.configuredDay) throw Error("\u76F4\u63A5\u62DB\u547C\u7684\u56FA\u5B9A\u6765\u6E90\u4E0D\u4E00\u81F4");
  if (a?.status !== "current-account-source-matched" || a.currentAccountVerified !== true || Date.now() - Date.parse(a.checkedAt) > 12e4 || Date.parse(a.checkedAt) < Date.parse(m.checkedAt)) throw Error("\u5F53\u524D\u8D26\u53F7\u590D\u9A8C\u65E0\u6548");
  const accountHash = directHash(["boss-visible-account-source-v1", a.accountName, a.phoneMask, new URL(a.jobseekerResumeHref, a.sourceUrl).origin + new URL(a.jobseekerResumeHref, a.sourceUrl).pathname]);
  if (accountHash !== s.accountSourceSha256 || l.contextId !== raw.contextId || l.stateRevision !== st.revision || l.existingIntent !== null || l.issues?.length || l.status !== "ledger-ready-for-skill" || l.readyForSkillAssessment !== true || !Number.isSafeInteger(l.quota?.remaining) || l.quota.remaining < 1 && f.userDailyLimit !== 150) throw Error("\u8D26\u53F7\u6216\u6700\u65B0\u5916\u53D1\u8D26\u672C\u4E0D\u5141\u8BB8\u65B0\u589E\u62DB\u547C");
  const selection = await directSelected(template, signal, s.selectedSource, { requireImmediate: true });
  if (!directIntersection(selection.salary, f.conditions)) throw Error("\u9009\u4E2D\u5C97\u4F4D\u6708\u85AA\u4E0E\u914D\u7F6E\u6CA1\u6709\u4EA4\u96C6");
  const id = panelJobIdentity(h.jobSource), key = directHash(["boss-application-v1", accountHash, id.jobId]), rows = st.value?.applicationIntents;
  if (!Array.isArray(rows) || rows.length >= 500 || rows.some((v) => v.key === key) || key !== s.applicationKey || typeof b?.batchId !== "string" || directDay(f.timeZone) !== s.day || !/^([a-f0-9]{64})$/.test(d?.source?.sha256) || typeof p?.ref?.versionId !== "string") throw Error("\u65E7\u5916\u53D1\u610F\u56FE\u3001\u6279\u6B21\u6216\u5BA1\u8BA1\u8D44\u6599\u6765\u6E90\u65E0\u6548");
  const intent = { key, accountSourceSha256: accountHash, jobId: id.jobId, jobSource: h.jobSource, jobSourceSha256: directHash({ jobSource: h.jobSource, jobTitle: h.jobTitle, jobCity: h.jobCity, company: null, descriptionSha256: null, salaryRaw: h.salaryRaw }), resumeSha256: d.source.sha256, profileVersionId: p.ref.versionId, configurationRevision: raw.revision, batchId: b.batchId, day: s.day, timeZone: f.timeZone, createdAt: (/* @__PURE__ */ new Date()).toISOString(), status: "reserved" };
  const result = { version: 1, kind: "daily-application-reservation-plan", evaluationMode: directMode, status: "ready-for-reservation", jobTitle: h.jobTitle, jobSource: h.jobSource, actualCity: h.actualCity, configurationRevision: raw.revision, stateRevision: st.revision, day: s.day, timeZone: f.timeZone, readyForReservation: true, quota: l.quota, reason: "\u85AA\u8D44\u4EA4\u96C6\u3001\u9009\u4E2D\u6001\u4E0E\u5916\u53D1\u8D26\u672C\u5141\u8BB8\u9996\u6B21\u62DB\u547C\uFF1B\u6CA1\u6709AI\u5224\u65AD", aiCalled: false, accountVerified: false, eligibleForActions: false, applied: false, dayTaskComplete: false, siteDailyLimitConfirmed: false };
  return { readyForReservation: true, expectedRevision: st.revision, value: { ...st.value, applicationIntents: [...rows, intent] }, intent, result };
};
export {
  stdin_default as default
};
