import { createHash } from "node:crypto";
const PANEL = Object.freeze({
  title: "head > title",
  jobTitle: ".job-detail-container .job-name",
  jobCity: ".job-header-info .tag-list > :nth-child(1)",
  companyLabel: ".job-boss-info > :nth-child(2) > :nth-child(2)",
  description: ".job-detail-body > .desc",
  salary: ".job-detail-container .job-salary",
  closedStatus: ".job-detail-container .job-close",
  contact: ".job-detail-container div:nth-of-type(2) > a:nth-of-type(2)"
});
const panelClean = (v) => String(v).replace(/\s+/gu, " ").trim();
const panelCompany = (v) => String(v).trim().split(/\s+·\s+/u).slice(0, -1).join(" \xB7 ").trim();
function panelJobIdentity(source) {
  const u = new URL(source), m = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(u.pathname);
  if (u.origin !== "https://www.zhipin.com" || u.username || u.password || u.search || u.hash || !m) throw Error("\u5C97\u4F4D\u5B8C\u6574\u94FE\u63A5\u65E0\u6548");
  const hrefs = [u.pathname, u.href].flatMap((v) => ['[href="' + v + '"]', '[href^="' + v + '?"]']).join(",");
  const relative = "> div:nth-of-type(1) > div > a:is(" + hrefs + ")";
  return { jobId: m[1], cardSelector: ".job-card-box:has(" + relative + ")", linkSelector: ".job-card-box " + relative };
}
async function panelFontCodec(read) {
  const sources = ["https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/app~0.1e6caebe.css", "https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/8026.de407e2f.css"];
  for (const href of sources) {
    const selector = 'head > link[rel="stylesheet"][href="' + href + '"]';
    if (await read("count", selector) !== 1 || await read("attribute", selector, "href") !== href) throw Error("\u85AA\u8D44\u5B57\u4F53\u6765\u6E90\u53D8\u5316\uFF0C\u672A\u731C\u6D4B\u91D1\u989D");
  }
  return "kanzhun-mix-2023-digits-v1";
}
function panelSalary(raw, codec) {
  if (typeof raw !== "string" || !raw.trim() || raw.length > 256) throw Error("\u85AA\u8D44\u539F\u6587\u7F3A\u5931\u6216\u8D85\u957F");
  if (/[\uE000-\uF8FF]/u.test(raw)) {
    if (codec !== "kanzhun-mix-2023-digits-v1" || /[\uE000-\uE030\uE03B-\uF8FF]/u.test(raw)) throw Error("\u85AA\u8D44\u5305\u542B\u672A\u7ECF\u6838\u5BF9\u7684\u5B57\u4F53\u7F16\u7801");
    return raw.replace(/[\uE031-\uE03A]/gu, (c) => String(c.charCodeAt(0) - 57393)).normalize("NFKC").trim();
  }
  return raw.normalize("NFKC").trim();
}
const directMode = "salary-and-selected-ui";
const directHash = (v) => createHash("sha256").update(typeof v === "string" ? v : JSON.stringify(v)).digest("hex");
const directDay = (zone) => new Intl.DateTimeFormat("sv-SE", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
function directSalary(raw) {
  const m = /^(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)\s*[Kk](?:\s*[·•]\s*\d{1,2}薪)?$/.exec(raw);
  if (!m) return null;
  const minimumYuan = Number(m[1]) * 1e3, maximumYuan = Number(m[2]) * 1e3;
  return Number.isSafeInteger(minimumYuan) && Number.isSafeInteger(maximumYuan) && minimumYuan > 0 && maximumYuan >= minimumYuan ? { minimumYuan, maximumYuan, period: "month" } : null;
}
async function directSelected(template, signal, c, { requireImmediate = false } = {}) {
  const read = async (operation, selector, value) => {
    signal.throwIfAborted();
    return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
  };
  const id = panelJobIdentity(c.jobSource), url = await read("url");
  if (url !== c.returnUrl) throw Error("\u5F53\u524D\u68C0\u7D22\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55");
  const active = ".job-card-wrap.active " + id.cardSelector;
  if (await read("count", ".job-card-wrap.active") !== 1 || await read("count", active) !== 1 || await read("count", id.linkSelector) !== 1) throw Error("\u672C\u9879\u5C97\u4F4D\u672A\u5904\u4E8E\u552F\u4E00\u9009\u4E2D\u72B6\u6001");
  const salarySelector = id.cardSelector + " .job-salary";
  if (await read("count", salarySelector) !== 1) throw Error("\u9009\u4E2D\u5C97\u4F4D\u85AA\u8D44\u4E0D\u552F\u4E00");
  const raw = String(await read("read", salarySelector)).trim(), codec = /[\uE000-\uF8FF]/u.test(raw) ? await panelFontCodec(read) : null, salaryRaw = panelSalary(raw, codec), salary = directSalary(salaryRaw);
  const href = new URL(await read("attribute", id.linkSelector, "href"), url);
  if (href.origin + href.pathname !== c.jobSource || await read("url") !== url) throw Error("\u9009\u4E2D\u5C97\u4F4D\u6765\u6E90\u53D8\u5316");
  let contactLabel = null, closed = false;
  const count = await read("count", PANEL.contact);
  if (count === 1) contactLabel = String(await read("read", PANEL.contact)).trim();
  else if (count === 0) closed = String(await read("read", "body")).split(/\r?\n/u).some((v) => v.trim() === "\u804C\u4F4D\u5DF2\u5173\u95ED");
  if (!closed && !["\u7ACB\u5373\u6C9F\u901A", "\u7EE7\u7EED\u6C9F\u901A"].includes(contactLabel)) throw Error("\u9009\u4E2D\u5C97\u4F4D\u7684\u6C9F\u901A\u5165\u53E3\u5C1A\u672A\u5C31\u7EEA");
  if (requireImmediate && contactLabel !== "\u7ACB\u5373\u6C9F\u901A") throw Error("\u5F53\u524D\u4E0D\u662F\u7ACB\u5373\u6C9F\u901A\uFF0C\u672A\u91CD\u590D\u53D1\u9001");
  if (await read("count", active) !== 1 || await read("url") !== url) throw Error("\u6838\u5BF9\u671F\u95F4\u9009\u4E2D\u72B6\u6001\u53D8\u5316");
  return { mode: directMode, jobSource: c.jobSource, selected: true, selector: active, salaryRaw, salary, contactLabel, closed, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
}
function directIntersection(salary, conditions) {
  return !!salary && (!conditions.salaryMin || salary.maximumYuan >= conditions.salaryMin) && (!conditions.salaryMax || salary.minimumYuan <= conditions.salaryMax);
}
const canonical = (v) => Array.isArray(v) ? v.map(canonical) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical(v[k])])) : v;
const digest = (v) => createHash("sha256").update(JSON.stringify(canonical(v))).digest("hex");
async function safetyIndex(template, signal, accountKey, contextId, initialize = false) {
  const name = "account-outbound-safety-v1-" + accountKey + ".json";
  let data, existed = true, baseline;
  try {
    baseline = await template.file("communication-cache", { operation: "read", name });
    data = JSON.parse(baseline);
  } catch (error) {
    if (!String(error.message || error).includes("ENOENT")) throw error;
    if (!initialize) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
    existed = false;
    data = { version: 1, kind: "boss-account-outbound-safety", accountKey, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (existed) {
    const { sha256, ...body } = data;
    if (sha256 !== digest(body)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
  }
  if (data.version !== 1 || data.kind !== "boss-account-outbound-safety" || data.accountKey !== accountKey || !Number.isSafeInteger(data.revision) || data.revision < 0 || !Array.isArray(data.records) || data.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
  const records = /* @__PURE__ */ new Set();
  for (const r of data.records) {
    if (!["first-contact", "reply"].includes(r.type) || !/^[a-f0-9]{64}$/.test(r.businessKey) || !Array.isArray(r.sightings) || !r.sightings.length || r.sightings.length > 100 || records.has(r.type + ":" + r.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
    records.add(r.type + ":" + r.businessKey);
    for (const s of r.sightings) if (typeof s.contextId !== "string" || !s.contextId || !/^[a-f0-9]{64}$/.test(s.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(s.status) || !/^\d{4}-\d{2}-\d{2}$/.test(s.day) || typeof s.timeZone !== "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
  }
  let dirty = !existed;
  const merge = (state) => {
    if (!Array.isArray(state?.applicationIntents) || !Array.isArray(state?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
    for (const [type, rows] of [["first-contact", state.applicationIntents], ["reply", state.replyIntents]]) for (const i of rows) {
      if ((type === "first-contact" ? i.accountSourceSha256 : i.accountKey) !== accountKey) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
      if (!/^[a-f0-9]{64}$/.test(i.key) || !i.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(i.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
      const businessKey = type === "first-contact" ? digest(["boss-job-safety-v1", accountKey, i.jobId]) : createHash("sha256").update(["boss-text-reply-v1", accountKey, i.incomingMessageId].join(":")).digest("hex");
      let r = data.records.find((r2) => r2.type === type && r2.businessKey === businessKey);
      if (!r) {
        r = { type, businessKey, jobId: i.jobId, ...type === "reply" ? { conversationKey: i.conversationKey, incomingMessageId: i.incomingMessageId } : {}, sightings: [] };
        data.records.push(r);
        dirty = true;
      }
      if (r.jobId !== i.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
      const sight = { contextId, intentKey: i.key, status: i.status, day: i.day, timeZone: i.timeZone, contentSha256: i.contentSha256 || null, sourceSha256: i.sourceSha256 || null };
      if (!r.sightings.some((s) => JSON.stringify(canonical(s)) === JSON.stringify(canonical(sight)))) {
        r.sightings.push(sight);
        dirty = true;
      }
      if (r.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
    }
    if (data.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
  };
  const save = async () => {
    signal.throwIfAborted();
    if (dirty) {
      if (existed && await template.file("communication-cache", { operation: "read", name }) !== baseline) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
      data.records.sort((a, b) => (a.type + ":" + a.businessKey).localeCompare(b.type + ":" + b.businessKey));
      for (const r of data.records) r.sightings.sort((a, b) => JSON.stringify(canonical(a)).localeCompare(JSON.stringify(canonical(b))));
      data.revision++;
      data.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      delete data.sha256;
      data.sha256 = digest(data);
      await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(data) });
      dirty = false;
      baseline = JSON.stringify(data);
      existed = true;
    }
    const back = JSON.parse(await template.file("communication-cache", { operation: "read", name }));
    const { sha256, ...body } = back;
    if (sha256 !== digest(body) || sha256 !== data.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
    return { revision: data.revision, sha256: data.sha256, records: data.records.length };
  };
  return { data, name, merge, save, blocked: (type, key) => data.records.some((r) => r.type === type && r.businessKey === key) };
}
const greetingCanonical = (v) => Array.isArray(v) ? v.map(greetingCanonical) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, greetingCanonical(v[k])])) : v;
const greetingDigest = (v) => createHash("sha256").update(JSON.stringify(greetingCanonical(v))).digest("hex");
function greetingPreparationName(accountKey, day) {
  if (!/^[a-f0-9]{64}$/.test(accountKey) || !/^\d{4}-\d{2}-\d{2}$/.test(day)) throw Error("\u62DB\u547C\u521D\u59CB\u5316\u8303\u56F4\u65E0\u6548");
  return "default-greeting-preparation-v1-" + accountKey + "-" + day + ".json";
}
async function readGreetingPreparation(template, signal, accountKey, day, approvedSha256) {
  const name = greetingPreparationName(accountKey, day);
  let content;
  signal.throwIfAborted();
  try {
    content = await template.file("communication-cache", { operation: "read", name });
  } catch (error) {
    const m = /^ENOENT: no such file or directory, realpath '([^'\r\n]+)'$/.exec(String(error?.message || ""));
    if (m && m[1].endsWith("/" + name)) return null;
    throw error;
  }
  if (typeof content !== "string" || Buffer.byteLength(content) > 65536) throw Error("\u9ED8\u8BA4\u62DB\u547C\u521D\u59CB\u5316\u56DE\u6267\u8D85\u51FA\u8303\u56F4");
  const value = JSON.parse(content), { sha256, ...body } = value;
  if (sha256 !== greetingDigest(body) || value.version !== 1 || value.kind !== "boss-default-greeting-preparation" || value.accountKey !== accountKey || value.day !== day || value.approvedSha256 !== approvedSha256 || value.actualMessageSha256 !== approvedSha256 || !/^\d{6,40}$/.test(value.websiteMessageId) || !["\u9001\u8FBE", "\u5DF2\u8BFB"].includes(value.receipt) || value.linkedJobVerified !== true || value.sourcePage !== "https://www.zhipin.com/web/geek/chat" || !Number.isFinite(Date.parse(value.observedAt)) || Date.parse(value.observedAt) > Date.now()) throw Error("\u9ED8\u8BA4\u62DB\u547C\u521D\u59CB\u5316\u56DE\u6267\u8EAB\u4EFD\u3001\u6B63\u6587\u6216\u9001\u8FBE\u8BC1\u636E\u4E0D\u7B26");
  return value;
}
async function saveGreetingPreparation(template, signal, value) {
  const name = greetingPreparationName(value.accountKey, value.day), prior = await readGreetingPreparation(template, signal, value.accountKey, value.day, value.approvedSha256);
  if (prior) {
    if (prior.sha256 !== value.sha256) throw Error("\u5DF2\u6709\u53E6\u4E00\u6761\u9ED8\u8BA4\u62DB\u547C\u521D\u59CB\u5316\u56DE\u6267\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55");
    return prior;
  }
  const { sha256, ...body } = value;
  if (sha256 !== greetingDigest(body)) throw Error("\u9ED8\u8BA4\u62DB\u547C\u521D\u59CB\u5316\u6458\u8981\u4E0D\u7B26");
  signal.throwIfAborted();
  await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(value) });
  const back = await readGreetingPreparation(template, signal, value.accountKey, value.day, value.approvedSha256);
  if (back?.sha256 !== sha256) throw Error("\u9ED8\u8BA4\u62DB\u547C\u521D\u59CB\u5316\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
  return back;
}
var stdin_default = async ({ input, template, signal }) => {
  signal.throwIfAborted();
  const { account: a, buttonText: label, prepared: p, receipt: r, source: s } = input, i = s?.intent;
  if (s?.kind !== "daily-application-operation-input" || s.evaluationMode !== directMode || s.aiCalled !== false || i?.status !== "reserved" || r?.operation !== "prepare" || r.state !== "submitting" || r.execute !== true || r.key !== s.key || s.key !== "application:" + i.key || typeof r.id !== "string" || typeof r.runId !== "string" || directHash(s.greetingText) !== s.greetingSha256 || p?.kind !== "direct-first-contact-prepared" || p.source.applicationKey !== i.key || p.source.contextId !== s.contextId || p.source.configurationRevision !== i.configurationRevision || p.source.day !== i.day || p.source.jobSource !== i.jobSource || directDay(i.timeZone) !== i.day) throw Error("\u5F53\u524D\u64CD\u4F5C\u4E0D\u5C5E\u4E8E\u672C\u9879\u6301\u4E45\u9884\u7559");
  if (a?.currentAccountVerified !== true || a.status !== "current-account-source-matched" || Date.now() - Date.parse(a.checkedAt) > 12e4 || directHash(["boss-visible-account-source-v1", a.accountName, a.phoneMask, new URL(a.jobseekerResumeHref, a.sourceUrl).origin + new URL(a.jobseekerResumeHref, a.sourceUrl).pathname]) !== i.accountSourceSha256) throw Error("\u5F53\u524D\u8D26\u53F7\u6216\u5F53\u5929\u6765\u6E90\u53D8\u5316");
  if (String(label).trim() !== "\u7ACB\u5373\u6C9F\u901A") throw Error("\u5F53\u524D\u5DF2\u4E0D\u662F\u7ACB\u5373\u6C9F\u901A\uFF0C\u4E0D\u91CD\u653E");
  let selection = await directSelected(template, signal, p.source.selectedSource, { requireImmediate: true });
  if (!directIntersection(selection.salary, p.configuration)) throw Error("\u5F53\u524D\u9009\u4E2D\u5C97\u4F4D\u6708\u85AA\u6CA1\u6709\u4EA4\u96C6");
  const state = await template.state.get();
  if (!Array.isArray(state?.applicationIntents) || state.applicationIntents.filter((v) => v.key === i.key).length !== 1 || JSON.stringify(state.applicationIntents.find((v) => v.key === i.key)) !== JSON.stringify(i)) throw Error("\u5F53\u524D\u9884\u7559\u5DF2\u53D8\u5316");
  const greetingPreparation = null, safety = await safetyIndex(template, signal, i.accountSourceSha256, s.contextId), businessKey = digest(["boss-job-safety-v1", i.accountSourceSha256, i.jobId]);
  if (safety.blocked("first-contact", businessKey)) throw Error("\u8BE5\u5C97\u4F4D\u5DF2\u6709\u5916\u53D1\u610F\u56FE\uFF0C\u4E0D\u518D\u6B21\u70B9\u51FB");
  safety.merge(state);
  const safetyReceipt = await safety.save();
  selection = await directSelected(template, signal, p.source.selectedSource, { requireImmediate: true });
  if (!directIntersection(selection.salary, p.configuration)) throw Error("\u7D22\u5F15\u4FDD\u5B58\u540E\u9009\u4E2D\u5C97\u4F4D\u85AA\u8D44\u4E0D\u518D\u6709\u4EA4\u96C6\uFF0C\u4FDD\u7559\u9884\u7559\u5E76\u505C\u6B62");
  return { version: 1, kind: "daily-first-communication-submit-check", evaluationMode: directMode, aiCalled: false, readyForWebsiteSubmission: true, safetyReceipt, greetingPreparation, selection, operationId: r.id, operationKey: r.key, runId: r.runId, jobTitle: s.jobTitle, jobSource: i.jobSource, listSource: s.listSource, sourceMode: "persisted-job-link-in-list", actualCity: s.actualCity, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), greetingText: s.greetingText, greetingSha256: s.greetingSha256, selector: PANEL.contact, websiteGreetingVerified: false, applied: false, attachmentSent: false };
};
export {
  stdin_default as default
};
