import { createHash } from "node:crypto";
var validateAccountSource = async ({ input, signal }) => {
  signal.throwIfAborted();
  const read = input, account = read?.value;
  if (!read || read.version !== 1 || read.operation !== "read" || read.binding !== "account-source-result" || read.schemaValidation !== "passed" || read.dataChanged !== false || read.ref?.version !== 1 || read.ref.policy !== "credential-redacted-v1" || read.ref.source?.entryId !== "account-source") throw new Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u5DF2\u9009\u62E9\u4E14\u5B8C\u6574\u53EF\u590D\u7528\u7684\u8D26\u53F7\u6765\u6E90\uFF0C\u8BF7\u5230\u8D44\u6E90\u9875\u91CD\u65B0\u6838\u5BF9\u5E76\u4FDD\u5B58");
  if (!account || account.version !== 1 || account.kind !== "boss-account-source" || account.status !== "account-source-confirmed" || account.accountVerified !== true || account.platformUniqueIdVerified !== false || account.eligibleForActions !== false || account.role !== "jobseeker") throw new Error("\u6240\u9009\u8BB0\u5F55\u5C1A\u672A\u5B8C\u6210\u672C\u4EBA\u786E\u8BA4\u548C\u6765\u6E90\u590D\u9A8C\uFF1B\u8BF7\u5728\u5F53\u524D\u5B9E\u4F8B\u5B8C\u6210\u8D26\u53F7\u6838\u5BF9\uFF0C\u518D\u9009\u62E9\u8BE5\u6B21\u5DF2\u4FDD\u5B58\u7ED3\u679C");
  const keys = ["version", "kind", "status", "accountAlias", "accountName", "phoneMask", "jobseekerResumeHref", "role", "sourceUrl", "accountVerified", "platformUniqueIdVerified", "eligibleForActions", "confirmedAt", "checkedAt", "reason"];
  if (Object.keys(account).length !== keys.length || keys.some((k) => !Object.prototype.hasOwnProperty.call(account, k))) throw new Error("\u6240\u9009\u8D26\u53F7\u7ED3\u679C\u7ED3\u6784\u4E0D\u7B26\uFF0C\u505C\u6B62\u91C7\u7528");
  for (const key of ["accountAlias", "accountName", "phoneMask"]) if (typeof account[key] !== "string" || !account[key].trim() || account[key] !== account[key].trim() || account[key].length > 100 || /[\r\n]/.test(account[key])) throw new Error("\u8D26\u53F7\u5FC5\u8981\u5B57\u6BB5\u7F3A\u5931\u6216\u683C\u5F0F\u65E0\u6548\uFF0C\u505C\u6B62\u91C7\u7528");
  if (!/^[+\d ()-]*\*{2,}[\d ()-]+$/.test(account.phoneMask) || /登录|注册|验证码/.test(account.accountName)) throw new Error("\u8D26\u53F7\u6765\u6E90\u7F3A\u5C11\u6709\u6548\u7684\u53EF\u89C1\u59D3\u540D\u6216\u624B\u673A\u53F7\u63A9\u7801");
  if (typeof account.reason !== "string" || !account.reason.trim()) throw new Error("\u8D26\u53F7\u7ED3\u679C\u7F3A\u5C11\u660E\u786E\u6838\u5BF9\u8BF4\u660E");
  const confirmedAt = Date.parse(account.confirmedAt), checkedAt = Date.parse(account.checkedAt);
  if (typeof account.confirmedAt !== "string" || typeof account.checkedAt !== "string" || !Number.isFinite(confirmedAt) || !Number.isFinite(checkedAt) || confirmedAt <= 0 || checkedAt < confirmedAt || checkedAt > Date.now() + 6e4) throw new Error("\u8D26\u53F7\u786E\u8BA4\u6216\u590D\u9A8C\u65F6\u95F4\u65E0\u6CD5\u6838\u5BF9\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4");
  if (typeof account.sourceUrl !== "string" || typeof account.jobseekerResumeHref !== "string" || !account.sourceUrl.trim() || !account.jobseekerResumeHref.trim() || account.sourceUrl.length > 16384 || account.jobseekerResumeHref.length > 16384) throw new Error("\u8D26\u53F7\u9875\u9762\u6216\u7B80\u5386\u5165\u53E3\u5730\u5740\u65E0\u6548");
  const page = new URL(account.sourceUrl), resume = new URL(account.jobseekerResumeHref, account.sourceUrl);
  if (page.origin !== "https://www.zhipin.com" || page.pathname !== "/web/geek/account" || page.searchParams.get("type") !== "accountSet" || page.username || page.password || page.hash || resume.origin !== page.origin || resume.pathname !== "/web/geek/resume" || resume.username || resume.password) throw new Error("\u8D26\u53F7\u8BB0\u5F55\u7684\u9875\u9762\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u4E0D\u7B26");
  signal.throwIfAborted();
  return { version: 1, accountSourceValid: true, currentAccountVerified: false, account };
};
async function verifyCurrentAccount({ input, signal, template }) {
  signal.throwIfAborted();
  const a = input?.expected?.account;
  if (input?.expected?.accountSourceValid !== true || a?.kind !== "boss-account-source" || a.status !== "account-source-confirmed" || a.accountVerified !== true) throw Error("\u7F3A\u5C11\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\u6765\u6E90");
  const call = async (operation, selector, value) => {
    signal.throwIfAborted();
    const r2 = await template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
    signal.throwIfAborted();
    return r2;
  };
  const before = await call("url"), p = new URL(before);
  if (p.origin !== "https://www.zhipin.com" || p.username || p.password || !p.pathname.startsWith("/web/") && !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(p.pathname)) throw Error("\u5F53\u524D\u9875\u9762\u4E0D\u662FBOSS\u6C42\u804C\u9875\u9762\uFF0C\u8BF7\u5148\u767B\u5F55");
  const n = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", r = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)";
  const nameCount = await call("count", n), resumeCount = await call("count", r);
  if (nameCount !== 1 || resumeCount !== 1) throw Error("\u5F53\u524D\u9875\u9762\u8D26\u53F7\u5165\u53E3\u6570\u91CF\u5F02\u5E38\uFF1A" + JSON.stringify({ nameCount, resumeCount }));
  const name = await call("read", n), href = await call("attribute", r, "href");
  if (typeof name !== "string" || name.normalize("NFKC").trim() !== a.accountName.normalize("NFKC").trim() || typeof href !== "string" || new URL(href, before).href !== new URL(a.jobseekerResumeHref, a.sourceUrl).href || await call("url") !== before) throw Error("\u5F53\u524D\u767B\u5F55\u8EAB\u4EFD\u3001\u6C42\u804C\u5165\u53E3\u6216\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
  return { version: 1, status: "current-account-source-matched", accountAlias: a.accountAlias, accountName: a.accountName, phoneMask: a.phoneMask, jobseekerResumeHref: a.jobseekerResumeHref, sourceUrl: a.sourceUrl, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), currentPageUrl: before, currentAccountVerified: true, platformUniqueIdVerified: false, eligibleForActions: false, accountCheckMode: "confirmed-initial-account-and-visible-header", phoneMaskRechecked: false, reason: "\u4F7F\u7528\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\uFF1B\u53EA\u8BFB\u6838\u5BF9\u5F53\u524D\u767B\u5F55\u59D3\u540D\u3001\u6C42\u804C\u5165\u53E3\u53CA\u9875\u9762\u8FDE\u7EED\u6027\uFF0C\u624B\u673A\u53F7\u63A9\u7801\u6CBF\u7528\u786E\u8BA4\u6765\u6E90\uFF0C\u6CA1\u6709\u91CD\u65B0\u8BFB\u53D6\u3002" };
}
var canonical = (v) => Array.isArray(v) ? v.map(canonical) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical(v[k])])) : v;
var digest = (v) => createHash("sha256").update(JSON.stringify(canonical(v))).digest("hex");
var stdin_default = async ({ input, template, signal }) => {
  signal.throwIfAborted();
  const expected = await validateAccountSource({ input, signal });
  const account = await verifyCurrentAccount({ input: { expected }, template, signal });
  const resume = new URL(account.jobseekerResumeHref, account.sourceUrl), accountKey = digest(["boss-visible-account-source-v1", account.accountName, account.phoneMask, resume.origin + resume.pathname]);
  const name = "account-outbound-safety-v1-" + accountKey + ".json";
  const read = async (file) => {
    signal.throwIfAborted();
    try {
      return await template.file("communication-cache", { operation: "read", name: file });
    } catch (error) {
      const m = /^ENOENT: no such file or directory, realpath '([^'\r\n]+)'$/.exec(String(error?.message || ""));
      if (m && m[1].endsWith("/" + file)) return null;
      throw error;
    }
  };
  const validate = (text) => {
    if (typeof text !== "string" || Buffer.byteLength(text) > 10 * 1024 * 1024) throw Error("\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\u6216\u8D85\u51FA\u8303\u56F4\uFF0C\u4E0D\u6309\u7A7A\u5386\u53F2\u5904\u7406");
    const value = JSON.parse(text), { sha256, ...body } = value;
    if (value.version !== 1 || value.kind !== "boss-account-outbound-safety" || value.accountKey !== accountKey || !Number.isSafeInteger(value.revision) || value.revision < 0 || !Array.isArray(value.records) || value.records.length > 2e3 || sha256 !== digest(body)) throw Error("\u5DF2\u6709\u7D22\u5F15\u8EAB\u4EFD\u3001\u7ED3\u6784\u6216\u6458\u8981\u4E0D\u7B26\uFF1B\u4E0D\u8986\u76D6");
    const keys = /* @__PURE__ */ new Set();
    for (const r of value.records) {
      if (!["first-contact", "reply"].includes(r.type) || !/^[a-f0-9]{64}$/.test(r.businessKey) || typeof r.jobId !== "string" || !r.jobId || !Array.isArray(r.sightings) || !r.sightings.length || r.sightings.length > 100 || keys.has(r.type + ":" + r.businessKey)) throw Error("\u5DF2\u6709\u7D22\u5F15\u8BB0\u5F55\u635F\u574F\uFF0C\u4E0D\u8986\u76D6");
      keys.add(r.type + ":" + r.businessKey);
      for (const s of r.sightings) if (typeof s.contextId !== "string" || !s.contextId || !/^[a-f0-9]{64}$/.test(s.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(s.status) || !/^\d{4}-\d{2}-\d{2}$/.test(s.day) || typeof s.timeZone !== "string") throw Error("\u5DF2\u6709\u5916\u53D1\u5386\u53F2\u635F\u574F\uFF0C\u4E0D\u6E05\u9664\u6216\u91CD\u5EFA");
    }
    return value;
  };
  const result = async (value, created) => {
    const out = { version: 1, kind: "boss-account-safety-index-check", status: created ? "\u9996\u6B21\u4F7F\u7528\u7D22\u5F15\u5DF2\u521B\u5EFA\u5E76\u8BFB\u56DE" : "\u5DF2\u6709\u5B89\u5168\u7D22\u5F15\u5DF2\u6838\u5BF9\uFF0C\u5185\u5BB9\u672A\u6539\u5199", accountKey, records: value.records.length, sha256: value.sha256, newIndexCreated: created, historyPreserved: true, accountVerified: false, eligibleForActions: false, dayTaskComplete: false };
    await template.result(out);
    return out;
  };
  let previous = await read(name);
  if (previous !== null) return result(validate(previous), false);
  const state = await template.state.get();
  const empty = (st) => st && typeof st === "object" && Object.keys(st).sort().join(",") === "applicationIntents,conversationControls,queueEntries,replyIntents" && ["applicationIntents", "replyIntents", "queueEntries", "conversationControls"].every((k) => Array.isArray(st[k])) && st.applicationIntents.length === 0 && st.replyIntents.length === 0 && st.queueEntries.length === 0 && st.conversationControls.length === 0;
  if (!empty(state)) throw Error("\u7D22\u5F15\u7F3A\u5931\u4F46\u5F53\u524D\u5B9E\u4F8B\u5DF2\u6709\u5386\u53F2\uFF1B\u8BF7\u6062\u590D\u539F\u76EE\u5F55\u548C\u5B89\u5168\u7D22\u5F15\uFF0C\u4E0D\u5141\u8BB8\u521B\u5EFA\u7A7A\u5386\u53F2");
  const history = "daily-candidate-history-v1-" + accountKey + ".json";
  if (await read(history) !== null) throw Error("\u76EE\u5F55\u5185\u5DF2\u6709\u5386\u53F2\u6765\u6E90\uFF0C\u7F3A\u5931\u7D22\u5F15\u5FC5\u987B\u6062\u590D\uFF0C\u4E0D\u5EFA\u7ACB\u7A7A\u7D22\u5F15");
  const accept = "\u786E\u8BA4\u5F53\u524D\u5DE5\u4F5C\u533A\u9996\u6B21\u4F7F\u7528\uFF0C\u5EFA\u7ACB\u672C\u5730\u7D22\u5F15";
  const answer = await template.human({ title: "\u786E\u8BA4\u5F53\u524D\u5DE5\u4F5C\u533A\u9996\u6B21\u4F7F\u7528", description: "\u5DF2\u786E\u8BA4\u8D26\u53F7\uFF1A" + account.accountName + "\uFF08" + account.phoneMask + "\uFF09\u3002\u5F53\u524D\u5B9E\u4F8B\u548C\u7ED1\u5B9A\u7F13\u5B58\u5747\u672A\u53D1\u73B0\u672C\u5730\u4E1A\u52A1\u5386\u53F2\uFF0C\u53EF\u4E3A\u8FD9\u4E2A\u65B0\u5DE5\u4F5C\u533A\u5EFA\u7ACB\u7A7A\u7684\u672C\u5730\u9632\u91CD\u7D22\u5F15\u3002\u8D26\u53F7\u53EF\u4EE5\u6709\u7F51\u7AD9\u65E2\u5F80\u6C9F\u901A\uFF1B\u672C\u5730\u7A7A\u7D22\u5F15\u4E0D\u4EE3\u8868\u7F51\u7AD9\u65E0\u5386\u53F2\uFF0C\u4E5F\u4E0D\u8BC1\u660E\u5386\u53F2unknown\u5DF2\u5B8C\u6210\u3002\u4E0D\u4F1A\u5BFC\u5165\u65E7\u8BB0\u5F55\u3001\u6062\u590D\u65E7\u6D41\u7A0B\u6216\u53D1\u9001\u6D88\u606F\u3002\u540E\u7EED\u4ECD\u8DF3\u8FC7\u7F51\u7AD9\u5DF2\u6C9F\u901A\u9879\uFF0C\u5916\u53D1\u5FC5\u987B\u9884\u7559\u5E76\u6838\u5BF9\u56DE\u6267\uFF1B\u672C\u673A\u5DF2\u6709\u5386\u53F2\u5374\u7F3A\u7D22\u5F15\u65F6\u4ECD\u505C\u6B62\uFF0C\u4E0D\u80FD\u501F\u6B64\u6E05\u9664\u6216\u8986\u76D6\u3002", schema: { type: "object", additionalProperties: false, required: ["decision"], properties: { decision: { type: "string", title: "\u5F53\u524D\u5DE5\u4F5C\u533A\u9996\u6B21\u4F7F\u7528\u786E\u8BA4", enum: ["\u4FDD\u7559\u5386\u53F2\u5E76\u505C\u6B62", accept], default: "\u4FDD\u7559\u5386\u53F2\u5E76\u505C\u6B62" } } } });
  signal.throwIfAborted();
  if (answer?.decision !== accept) throw Error("\u5C1A\u672A\u786E\u8BA4\u5F53\u524D\u5DE5\u4F5C\u533A\u521D\u59CB\u5316\uFF0C\u672A\u521B\u5EFA\u6216\u6539\u5199\u7D22\u5F15");
  await verifyCurrentAccount({ input: { expected }, template, signal });
  if (!empty(await template.state.get()) || await read(history) !== null || await read(name) !== null) throw Error("\u786E\u8BA4\u671F\u95F4\u51FA\u73B0\u5386\u53F2\u6216\u7D22\u5F15\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
  const operation = await template.effect.prepare({ action: "workflow-write-1", key: "first-account-safety-index:" + accountKey, description: "\u4EC5\u5728\u786E\u8BA4\u5F53\u524D\u5B9E\u4F8B\u53CA\u7F13\u5B58\u65E0\u672C\u5730\u5386\u53F2\u540E\uFF0C\u4E3A\u5F53\u524D\u8D26\u53F7\u5EFA\u7ACB\u672C\u5DE5\u4F5C\u533A\u7684\u672C\u5730\u9632\u91CD\u7D22\u5F15\uFF1B\u4E0D\u8BC1\u660E\u7F51\u7AD9\u6CA1\u6709\u5386\u53F2\uFF0C\u4E0D\u8986\u76D6\u6216\u5BFC\u5165\u4EFB\u4F55\u65E7\u8BB0\u5F55\uFF0C\u4E0D\u53D1\u9001\u7F51\u7AD9\u6D88\u606F\u3002" });
  if (operation?.execute !== true || operation.state !== "submitting") throw Error("\u5DF2\u6709\u521D\u59CB\u5316\u64CD\u4F5C\u8BB0\u5F55\uFF0C\u672A\u81EA\u52A8\u91CD\u653E");
  try {
    signal.throwIfAborted();
    if (await read(name) !== null || !empty(await template.state.get())) throw Error("\u5199\u5165\u524D\u5386\u53F2\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
    const value = { version: 1, kind: "boss-account-outbound-safety", accountKey, revision: 1, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    value.sha256 = digest(value);
    const content = JSON.stringify(value);
    await template.file("communication-cache", { operation: "write", name, content });
    const back = await read(name);
    if (back !== content) throw Error("\u65B0\u5EFA\u7D22\u5F15\u5199\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4\uFF0C\u4FDD\u7559\u6587\u4EF6\u53CA\u672A\u77E5\u8BB0\u5F55");
    const verified = validate(back);
    await template.effect.resolve({ id: operation.id, state: "confirmed", evidence: { kind: "new-account-index-readback", accountKey, sha256: verified.sha256, records: 0, websiteMessagesSent: 0 } });
    return result(verified, true);
  } catch (error) {
    if (!signal.aborted) await template.effect.resolve({ id: operation.id, state: "unknown", evidence: { reason: String(error?.message || error).slice(0, 600), doNotReplay: true } });
    throw error;
  }
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default2 = (ctx) => stdin_default(Object.freeze({ ...ctx, constants }));
export {
  stdin_default2 as default
};
