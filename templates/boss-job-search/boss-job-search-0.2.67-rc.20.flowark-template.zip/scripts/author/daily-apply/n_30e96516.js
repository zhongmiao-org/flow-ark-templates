import { createHash as Y } from "node:crypto";
var G = /* @__PURE__ */ (() => {
  const B = Y;
  function x(u) {
    return u.status === "review" && !u.operationKey && !u.modelRequestId && u.sourceReviewVersion !== "chat-list-direct-v5" && /固定成员姓名控件不唯一|固定成员定向搜索结果不唯一|关联职位没有可核对的继续沟通入口|固定成员缺少可核对的定向搜索姓名，未猜测|固定成员缺少唯一可见身份|关联职位返回后的完整消息或对象变化/u.test(String(u.reason || ""));
  }
  async function M(u, t) {
    const n = ".user-list-content", c = (i) => i.replace(/[\s\uE000-\uF8FF]/gu, ""), e = ".list-warp.v2 input";
    await u("count", e) === 1 && String(await u("inputValue", e, null)) !== "" && await u("fill", e, "");
    const o = ".list-warp.v2 ul:has(> .selected)", r = o + " > :nth-child(2)";
    await u("count", r) === 1 && /^未读(?:\s*\(\d+\))?$/u.test(String(await u("read", r)).trim()) && !/^未读/u.test(String(await u("read", o + " .selected")).trim()) && await u("click", r);
    for (let i = 0; i < 30 && await u("count", n) !== 1; i++) await new Promise((F) => setTimeout(F, 150));
    if (await u("count", n) !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u6765\u6E90\u4E0D\u552F\u4E00");
    const l = [{ selector: n, depth: 0 }], a = [];
    let f = 0;
    for (; l.length; ) {
      const i = l.shift();
      if (++f > 400) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
      const F = await u("count", i.selector + ".friend-content") === 1, p = F ? 1 : await u("count", i.selector + " .friend-content");
      if (p === 1) {
        const m = F ? i.selector : i.selector + " .friend-content", w = String(await u("read", i.selector)).trim();
        c(w).includes(c(String(t.member.text).split(/\r?\n/u).slice(3).join(`
`).trim())) && a.push({ sel: i.selector, label: m, text: w });
        continue;
      }
      if (p > 1 && i.depth < 4) {
        const m = await u("count", i.selector + " > *");
        if (!Number.isSafeInteger(m) || m > 200) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
        for (let w = 1; w <= m; w++) l.push({ selector: i.selector + " > :nth-child(" + w + ")", depth: i.depth + 1 });
      }
    }
    if (a.length === 0 && t.member.lookupName) {
      await u("fill", e, t.member.lookupName);
      const i = ".boss-search-result .search-list";
      for (let h = 0; h < 30 && !(await u("count", i) > 0); h++) await new Promise((D) => setTimeout(D, 150));
      if (await u("count", i) !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u5B9A\u5411\u641C\u7D22\u7ED3\u679C\u4E0D\u552F\u4E00");
      const F = [i], p = [];
      let m = 0;
      for (; F.length; ) {
        const h = F.shift();
        if (++m > 100) throw Error("\u8054\u7CFB\u4EBA\u59D3\u540D\u63A7\u4EF6\u8303\u56F4\u8FC7\u5927");
        const D = await u("count", h + " > *"), E = String(await u("read", h)).trim();
        if (E === t.member.lookupName && p.push({ label: h, text: E }), D > 0 && D < 30) for (let b = 1; b <= D; b++) F.push(h + " > :nth-child(" + b + ")");
      }
      const w = p.filter((h) => !p.some((D) => D !== h && D.label.startsWith(h.label + " > ")));
      if (w.length !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u59D3\u540D\u63A7\u4EF6\u4E0D\u552F\u4E00");
      a.push(w[0]);
    }
    if (a.length !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u7F3A\u5C11\u552F\u4E00\u53EF\u89C1\u8EAB\u4EFD\uFF0C\u672A\u731C\u6D4B\u59D3\u540D");
    const s = a[0];
    if (String(await u("read", s.label)).trim() !== s.text) throw Error("\u56FA\u5B9A\u6210\u5458\u53EF\u89C1\u8EAB\u4EFD\u53D8\u5316");
    await u("click", s.label);
    for (let i = 0; i < 30; i++) {
      if (await u("count", ".chat-conversation .user-info") === 1 && await u("count", "li.message-item") > 0) {
        const F = String(await u("read", ".chat-conversation .user-info")).trim(), p = await j(u), m = c(String(t.member.text).split(/\r?\n/u).slice(3).join(`
`).trim());
        if (F && p.some((w) => w.direction === "incoming" && c(w.text || "") === m)) {
          t.recipientLabel = F, t.rows = [{ mid: p[0].mid }];
          return;
        }
      }
      await new Promise((F) => setTimeout(F, 150));
    }
    throw Error("\u56FA\u5B9A\u6210\u5458\u53EF\u89C1\u8EAB\u4EFD\u672A\u5B8C\u6574\u8BFB\u56DE");
  }
  async function uu(u, t, n) {
    if (typeof n != "string" || !n.trim()) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u539F\u59D3\u540D\u6765\u6E90\u7F3A\u5931");
    await u("navigate", void 0, "https://www.zhipin.com/web/geek/chat"), await M(u, t);
  }
  function eu(u, t) {
    const n = (a) => a.normalize("NFKC").replace(/\s+/gu, " ").trim().toLocaleLowerCase("en-US");
    if (typeof u != "string" || !u.trim() || u.length > 1e3 || /(?:\.{3}|…|⋯)/u.test(u)) throw Error("\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u7F3A\u5931\u6216\u622A\u65AD\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u8BB0\u5F55");
    const c = t?.titleKeywords, e = t?.excludedRoles;
    for (const [a, f, s] of [["titleKeywords", c, 1], ["excludedRoles", e, 0]]) if (!Array.isArray(f) || f.length < s || f.length > 20 || f.some((i) => typeof i != "string" || !n(i) || i.length > 100) || new Set(f.map(n)).size !== f.length) throw Error("\u5C97\u4F4D\u8303\u56F4\u914D\u7F6E\u65E0\u6548\uFF1A" + a + "\uFF1B\u672A\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE");
    const o = n(u), r = e.filter((a) => o.includes(n(a))), l = c.filter((a) => o.includes(n(a)));
    return { version: 1, kind: "literal-full-job-title-scope", fullTitle: u, matched: l, excluded: r, allowed: r.length === 0 && l.length > 0, source: "actual-complete-job-title", jdUsed: false, searchKeywordUsedAsEvidence: false };
  }
  const tu = /* @__PURE__ */ (() => {
    var u = async ({ input: t, signal: n }) => {
      n.throwIfAborted();
      const c = t, e = c?.value;
      if (!c || c.version !== 1 || c.operation !== "read" || c.binding !== "account-source-result" || c.schemaValidation !== "passed" || c.dataChanged !== false || c.ref?.version !== 1 || c.ref.policy !== "credential-redacted-v1" || c.ref.source?.entryId !== "account-source") throw new Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u5DF2\u9009\u62E9\u4E14\u5B8C\u6574\u53EF\u590D\u7528\u7684\u8D26\u53F7\u6765\u6E90\uFF0C\u8BF7\u5230\u8D44\u6E90\u9875\u91CD\u65B0\u6838\u5BF9\u5E76\u4FDD\u5B58");
      if (!e || e.version !== 1 || e.kind !== "boss-account-source" || e.status !== "account-source-confirmed" || e.accountVerified !== true || e.platformUniqueIdVerified !== false || e.eligibleForActions !== false || e.role !== "jobseeker") throw new Error("\u6240\u9009\u8BB0\u5F55\u5C1A\u672A\u5B8C\u6210\u672C\u4EBA\u786E\u8BA4\u548C\u6765\u6E90\u590D\u9A8C\uFF1B\u8BF7\u5728\u5F53\u524D\u5B9E\u4F8B\u5B8C\u6210\u8D26\u53F7\u6838\u5BF9\uFF0C\u518D\u9009\u62E9\u8BE5\u6B21\u5DF2\u4FDD\u5B58\u7ED3\u679C");
      const o = ["version", "kind", "status", "accountAlias", "accountName", "phoneMask", "jobseekerResumeHref", "role", "sourceUrl", "accountVerified", "platformUniqueIdVerified", "eligibleForActions", "confirmedAt", "checkedAt", "reason"];
      if (Object.keys(e).length !== o.length || o.some((s) => !Object.prototype.hasOwnProperty.call(e, s))) throw new Error("\u6240\u9009\u8D26\u53F7\u7ED3\u679C\u7ED3\u6784\u4E0D\u7B26\uFF0C\u505C\u6B62\u91C7\u7528");
      for (const s of ["accountAlias", "accountName", "phoneMask"]) if (typeof e[s] != "string" || !e[s].trim() || e[s] !== e[s].trim() || e[s].length > 100 || /[\r\n]/.test(e[s])) throw new Error("\u8D26\u53F7\u5FC5\u8981\u5B57\u6BB5\u7F3A\u5931\u6216\u683C\u5F0F\u65E0\u6548\uFF0C\u505C\u6B62\u91C7\u7528");
      if (!/^[+\d ()-]*\*{2,}[\d ()-]+$/.test(e.phoneMask) || /登录|注册|验证码/.test(e.accountName)) throw new Error("\u8D26\u53F7\u6765\u6E90\u7F3A\u5C11\u6709\u6548\u7684\u53EF\u89C1\u59D3\u540D\u6216\u624B\u673A\u53F7\u63A9\u7801");
      if (typeof e.reason != "string" || !e.reason.trim()) throw new Error("\u8D26\u53F7\u7ED3\u679C\u7F3A\u5C11\u660E\u786E\u6838\u5BF9\u8BF4\u660E");
      const r = Date.parse(e.confirmedAt), l = Date.parse(e.checkedAt);
      if (typeof e.confirmedAt != "string" || typeof e.checkedAt != "string" || !Number.isFinite(r) || !Number.isFinite(l) || r <= 0 || l < r || l > Date.now() + 6e4) throw new Error("\u8D26\u53F7\u786E\u8BA4\u6216\u590D\u9A8C\u65F6\u95F4\u65E0\u6CD5\u6838\u5BF9\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4");
      if (typeof e.sourceUrl != "string" || typeof e.jobseekerResumeHref != "string" || !e.sourceUrl.trim() || !e.jobseekerResumeHref.trim() || e.sourceUrl.length > 16384 || e.jobseekerResumeHref.length > 16384) throw new Error("\u8D26\u53F7\u9875\u9762\u6216\u7B80\u5386\u5165\u53E3\u5730\u5740\u65E0\u6548");
      const a = new URL(e.sourceUrl), f = new URL(e.jobseekerResumeHref, e.sourceUrl);
      if (a.origin !== "https://www.zhipin.com" || a.pathname !== "/web/geek/account" || a.searchParams.get("type") !== "accountSet" || a.username || a.password || a.hash || f.origin !== a.origin || f.pathname !== "/web/geek/resume" || f.username || f.password) throw new Error("\u8D26\u53F7\u8BB0\u5F55\u7684\u9875\u9762\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u4E0D\u7B26");
      return n.throwIfAborted(), { version: 1, accountSourceValid: true, currentAccountVerified: false, account: e };
    };
    return u;
  })(), P = /* @__PURE__ */ (() => {
    async function u({ input: t, signal: n, template: c }) {
      n.throwIfAborted();
      const e = t?.expected?.account;
      if (t?.expected?.accountSourceValid !== true || e?.kind !== "boss-account-source" || e.status !== "account-source-confirmed" || e.accountVerified !== true) throw Error("\u7F3A\u5C11\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\u6765\u6E90");
      const o = async (m, w, h) => {
        n.throwIfAborted();
        const D = await c.browser("browser", { operation: m, ...w ? { selector: w } : {}, ...h === void 0 ? {} : { value: h }, timeoutMs: 3e3 });
        return n.throwIfAborted(), D;
      }, r = await o("url"), l = new URL(r);
      if (l.origin !== "https://www.zhipin.com" || l.username || l.password || !l.pathname.startsWith("/web/") && !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(l.pathname)) throw Error("\u5F53\u524D\u9875\u9762\u4E0D\u662FBOSS\u6C42\u804C\u9875\u9762\uFF0C\u8BF7\u5148\u767B\u5F55");
      const a = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", f = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)", s = await o("count", a), i = await o("count", f);
      if (s !== 1 || i !== 1) throw Error("\u5F53\u524D\u9875\u9762\u8D26\u53F7\u5165\u53E3\u6570\u91CF\u5F02\u5E38\uFF1A" + JSON.stringify({ nameCount: s, resumeCount: i }));
      const F = await o("read", a), p = await o("attribute", f, "href");
      if (typeof F != "string" || F.normalize("NFKC").trim() !== e.accountName.normalize("NFKC").trim() || typeof p != "string" || new URL(p, r).href !== new URL(e.jobseekerResumeHref, e.sourceUrl).href || await o("url") !== r) throw Error("\u5F53\u524D\u767B\u5F55\u8EAB\u4EFD\u3001\u6C42\u804C\u5165\u53E3\u6216\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
      return { version: 1, status: "current-account-source-matched", accountAlias: e.accountAlias, accountName: e.accountName, phoneMask: e.phoneMask, jobseekerResumeHref: e.jobseekerResumeHref, sourceUrl: e.sourceUrl, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), currentPageUrl: r, currentAccountVerified: true, platformUniqueIdVerified: false, eligibleForActions: false, accountCheckMode: "confirmed-initial-account-and-visible-header", phoneMaskRechecked: false, reason: "\u4F7F\u7528\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\uFF1B\u53EA\u8BFB\u6838\u5BF9\u5F53\u524D\u767B\u5F55\u59D3\u540D\u3001\u6C42\u804C\u5165\u53E3\u53CA\u9875\u9762\u8FDE\u7EED\u6027\uFF0C\u624B\u673A\u53F7\u63A9\u7801\u6CBF\u7528\u786E\u8BA4\u6765\u6E90\uFF0C\u6CA1\u6709\u91CD\u65B0\u8BFB\u53D6\u3002" };
    }
    return u;
  })(), O = (u) => Array.isArray(u) ? u.map(O) : u && typeof u == "object" ? Object.fromEntries(Object.keys(u).sort().map((t) => [t, O(u[t])])) : u, Z = (u) => B("sha256").update(JSON.stringify(O(u))).digest("hex"), A = (u) => Array.isArray(u) ? u.map(A) : u && typeof u == "object" ? Object.fromEntries(Object.keys(u).sort().map((t) => [t, A(u[t])])) : u, C = (u) => B("sha256").update(JSON.stringify(A(u))).digest("hex");
  async function $(u, t, n, c, e = false) {
    const o = "account-outbound-safety-v1-" + n + ".json";
    let r, l = true, a;
    try {
      a = await u.file("communication-cache", { operation: "read", name: o }), r = JSON.parse(a);
    } catch (i) {
      if (!String(i.message || i).includes("ENOENT")) throw i;
      if (!e) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
      l = false, r = { version: 1, kind: "boss-account-outbound-safety", accountKey: n, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    }
    if (l) {
      const { sha256: i, ...F } = r;
      if (i !== C(F)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
    }
    if (r.version !== 1 || r.kind !== "boss-account-outbound-safety" || r.accountKey !== n || !Number.isSafeInteger(r.revision) || r.revision < 0 || !Array.isArray(r.records) || r.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
    const f = /* @__PURE__ */ new Set();
    for (const i of r.records) {
      if (!["first-contact", "reply"].includes(i.type) || !/^[a-f0-9]{64}$/.test(i.businessKey) || !Array.isArray(i.sightings) || !i.sightings.length || i.sightings.length > 100 || f.has(i.type + ":" + i.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
      f.add(i.type + ":" + i.businessKey);
      for (const F of i.sightings) if (typeof F.contextId != "string" || !F.contextId || !/^[a-f0-9]{64}$/.test(F.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(F.status) || !/^\d{4}-\d{2}-\d{2}$/.test(F.day) || typeof F.timeZone != "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
    }
    let s = !l;
    return { data: r, name: o, merge: (i) => {
      if (!Array.isArray(i?.applicationIntents) || !Array.isArray(i?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
      for (const [F, p] of [["first-contact", i.applicationIntents], ["reply", i.replyIntents]]) for (const m of p) {
        if ((F === "first-contact" ? m.accountSourceSha256 : m.accountKey) !== n) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
        if (!/^[a-f0-9]{64}$/.test(m.key) || !m.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(m.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
        const w = F === "first-contact" ? C(["boss-job-safety-v1", n, m.jobId]) : B("sha256").update(["boss-text-reply-v1", n, m.incomingMessageId].join(":")).digest("hex");
        let h = r.records.find((E) => E.type === F && E.businessKey === w);
        if (h || (h = { type: F, businessKey: w, jobId: m.jobId, ...F === "reply" ? { conversationKey: m.conversationKey, incomingMessageId: m.incomingMessageId } : {}, sightings: [] }, r.records.push(h), s = true), h.jobId !== m.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
        const D = { contextId: c, intentKey: m.key, status: m.status, day: m.day, timeZone: m.timeZone, contentSha256: m.contentSha256 || null, sourceSha256: m.sourceSha256 || null };
        if (h.sightings.some((E) => JSON.stringify(A(E)) === JSON.stringify(A(D))) || (h.sightings.push(D), s = true), h.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
      }
      if (r.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
    }, save: async () => {
      if (t.throwIfAborted(), s) {
        if (l && await u.file("communication-cache", { operation: "read", name: o }) !== a) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
        r.records.sort((m, w) => (m.type + ":" + m.businessKey).localeCompare(w.type + ":" + w.businessKey));
        for (const m of r.records) m.sightings.sort((w, h) => JSON.stringify(A(w)).localeCompare(JSON.stringify(A(h))));
        r.revision++, r.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete r.sha256, r.sha256 = C(r), await u.file("communication-cache", { operation: "write", name: o, content: JSON.stringify(r) }), s = false, a = JSON.stringify(r), l = true;
      }
      const i = JSON.parse(await u.file("communication-cache", { operation: "read", name: o })), { sha256: F, ...p } = i;
      if (F !== C(p) || F !== r.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
      return { revision: r.revision, sha256: r.sha256, records: r.records.length };
    }, blocked: (i, F) => r.records.some((p) => p.type === i && p.businessKey === F) };
  }
  const R = (u, t) => async (n, c, e) => {
    t.throwIfAborted();
    try {
      return await u.browser("browser", { operation: n, ...c ? { selector: c } : {}, ...e === void 0 ? {} : { value: e }, timeoutMs: 3e3 });
    } catch (o) {
      const r = String(o.message || o);
      if (!/^\(-3\) loading /u.test(r)) throw o;
      let l = null;
      if (n === "navigate" && e === "https://www.zhipin.com/web/geek/chat" && (l = new URL(e)), n === "click" && c === ".chat-position-content .right-content > :first-child") {
        const a = /^\(-3\) loading '([^']+)'/u.exec(r);
        if (a) {
          const f = new URL(a[1]);
          f.origin === "https://www.zhipin.com" && /^\/job_detail\/[A-Za-z0-9_~-]+\.html$/u.test(f.pathname) && !f.username && !f.password && (l = f);
        }
      }
      if (!l) throw o;
      for (let a = 0; a < 30; a++) {
        t.throwIfAborted();
        const f = await u.browser("browser", { operation: "url", timeoutMs: 3e3 }), s = new URL(f);
        if (s.origin === l.origin && s.pathname === l.pathname) return { navigationObserved: true, url: f, originalClickRepeated: false };
        await new Promise((i) => setTimeout(i, 150));
      }
      throw o;
    }
  }, L = (u) => {
    const { sha256: t, ...n } = u;
    return t === C(n);
  };
  async function V(u, t, n, c) {
    const e = n.progressName, o = await u.file("communication-cache", { operation: "read", name: e }), r = JSON.parse(o);
    if (!L(r) || r.accountKey !== n.accountKey || r.fixedUnreadSetSha256 !== n.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
    if (!c) return r;
    const l = c(structuredClone(r));
    if (l.revision++, l.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete l.sha256, l.sha256 = C(l), await u.file("communication-cache", { operation: "read", name: e }) !== o) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
    t.throwIfAborted(), await u.file("communication-cache", { operation: "write", name: e, content: JSON.stringify(l) });
    const a = JSON.parse(await u.file("communication-cache", { operation: "read", name: e }));
    if (!L(a) || a.sha256 !== l.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
    return a;
  }
  async function j(u) {
    const t = await u("count", "li.message-item");
    if (!Number.isSafeInteger(t) || t < 1 || t > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
    const n = [];
    for (let c = 1; c <= t; c++) {
      const e = "li.message-item:nth-child(" + c + " of li.message-item)", o = await u("attribute", e, "data-mid"), r = await u("attribute", e, "class");
      if (!/^\d{6,40}$/.test(o || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
      const l = await u("count", e + " .text-content");
      if (l > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
      const a = l === 1 ? String(await u("read", e + " .text-content")).trim() : null, f = a === null ? String(await u("read", e)).trim() : null;
      if ((a || f || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
      const s = !!a && /^您正在与Boss.+沟通$/u.test(a), i = !s && a !== null && r.split(/\s+/u).includes("item-myself") ? "outgoing" : !s && a !== null && r.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
      n.push({ mid: o, direction: i, text: a, context: f });
    }
    if (new Set(n.map((c) => c.mid)).size !== n.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
    return n;
  }
  async function J(u, t) {
    const n = new URL(await u("url"));
    if (n.origin !== "https://www.zhipin.com" || n.pathname !== "/web/geek/chat" || await u("count", ".chat-conversation .user-info") !== 1) return false;
    const c = String(await u("read", ".chat-conversation .user-info")).trim(), e = (o) => o.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
    return t.recipientLabel ? String(await u("read", ".chat-conversation .user-info")).trim() === t.recipientLabel && (!t.rows?.length || await u("count", 'li.message-item[data-mid="' + t.rows[0].mid + '"]') === 1) : await u("count", ".friend-content.selected") === 1 && e(String(await u("read", ".friend-content.selected"))).includes(e(t.member.identityLine));
  }
  async function q(u, t, n) {
    const c = R(u, t);
    return await J(c, n) ? String(await c("read", n.accountSelector)).trim() === n.accountLabel && String(await c("read", n.recipientSelector)).trim() === n.recipientLabel && JSON.stringify(await j(c)) === JSON.stringify(n.rows) : false;
  }
  var H = async ({ input: u, template: t, signal: n, artifact: c, onAccountVerified: e }) => {
    const o = u?.cohort, r = u?.profile;
    if (o?.kind !== "unread-closing-cohort" || o.closingPhase !== true || r?.version !== 1 || !r.ref?.versionId || !r.markdown?.trim()) throw Error("\u7F3A\u5C11\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u6216\u672C\u6B21\u786E\u8BA4Skill");
    const l = { ...o, sourceReviewVersion: "chat-list-direct-v5", kind: "chat-reply-source", fixedUnreadMember: true, profile: r, returnToJobs: false };
    if (!o.ready) return { ...l, ready: false, status: "fixed-unread-complete", reason: "\u56FA\u5B9A\u96C6\u5408\u5DF2\u5904\u7406\u5B8C\u6BD5\uFF0C\u4E0D\u91CD\u65B0\u626B\u63CF" };
    await P({ input: { expected: o.accountSource }, template: t, signal: n }), e?.();
    const a = String(o.member?.text || "").split(/\r?\n/u).slice(3).join(`
`).trim();
    if (/背景不完全相符|需要其他资质|不太符合|不太?合适|不[是太]*特别契合|不[完全]*符合|不[完全]*匹配|后续有机会再合作|未能通过|暂不考虑/u.test(a) && !/[?？]|(?:是否|有没有|会不会|能否|请问|什么时候|多少|怎么|哪些)/u.test(a)) return { ...l, member: o.member, ready: false, jobId: null, jobSource: null, status: "rejected-no-reply", reason: "\u56FA\u5B9A\u672A\u8BFB\u5FEB\u7167\u4E2D\u5BF9\u65B9\u5DF2\u660E\u786E\u62D2\u7EDD\uFF0C\u4E0D\u56DE\u590D\u3001\u4E0D\u6267\u884C\u539F\u751F\u8BF7\u6C42", previewSource: true };
    const f = R(t, n), s = o.member;
    let i = await V(t, n, o);
    if (i.completed.some((d) => d.memberKey === s.key && !x(d) && !(d.status === "review" && d.replyPolicyVersion !== "work-questions-partial-known-v2"))) return { ...l, ready: false, status: "already-completed", reason: "\u8BE5\u56FA\u5B9A\u6210\u5458\u5DF2\u5904\u7406\uFF0C\u672A\u91CD\u590D\u6253\u5F00" };
    if (i.active && i.active.memberKey !== s.key) throw Error("\u6D3B\u8DC3\u4F1A\u8BDD\u4E0E\u56FA\u5B9A\u6210\u5458\u4E0D\u7B26");
    if (!await J(f, o)) {
      const d = new URL(await f("url"));
      (d.origin !== "https://www.zhipin.com" || d.pathname !== "/web/geek/chat") && await f("navigate", void 0, "https://www.zhipin.com/web/geek/chat"), await M(f, o);
    }
    const F = ".chat-conversation .user-info", p = String(await f("read", F)).trim(), m = ".chat-position-content", w = String(await f("read", m)).trim(), h = w.split(/\r?\n/u)[0], D = await j(f);
    if (!h || !p) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u7684\u62DB\u8058\u8005\u6216\u804C\u4F4D\u4E0A\u4E0B\u6587\u7F3A\u5931");
    if (/校招|校园|应届/u.test(h)) return { ...l, member: s, ready: false, status: "campus-no-reply", reason: "\u804A\u5929\u4E2D\u660E\u786E\u6821\u62DB\uFF0C\u7EE7\u7EED\u6392\u9664" };
    if (i.active?.firstMessageId && i.active.firstMessageId !== D[0].mid) throw Error("\u91CD\u5F00\u540E\u7684\u4F1A\u8BDD\u539F\u59CB\u6D88\u606F\u94FE\u5DF2\u53D8\u5316\uFF0C\u672A\u8986\u76D6\u65E7\u8FDB\u5EA6");
    i = await V(t, n, o, (d) => {
      if (d.active && d.active.memberKey !== s.key) throw Error("\u6D3B\u8DC3\u6210\u5458\u53D8\u5316");
      return d.active = { ...d.active, memberKey: s.key, identityLine: s.identityLine, recipientName: p.split(/\r?\n/u)[0], contextId: o.contextId, openedAt: d.active?.openedAt || (/* @__PURE__ */ new Date()).toISOString(), firstMessageId: D[0].mid }, d;
    });
    const E = "https://www.zhipin.com/web/geek/chat", b = "chat-" + D[0].mid, v = await j(f), S = v.filter((d) => d.direction !== "system" && d.text), y = S.at(-1), X = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", z = o.accountSource.account.accountName, g = { ...l, ownedConversation: S[0]?.direction === "outgoing", member: s, jobId: b, jobSource: E, jobTitle: h, chatJobTitle: w, jobSelector: m, recipientSelector: F, recipientLabel: p, accountSelector: X, accountLabel: z, conversationKey: "boss-chat:" + v[0].mid, rows: v };
    if (S[0]?.direction === "incoming") return { ...g, ready: false, status: "inbound-first-no-reply", reason: "\u53EF\u89C1\u4F1A\u8BDD\u7531\u5BF9\u65B9\u53D1\u8D77\uFF0C\u6309\u672C\u4EBA\u89C4\u5219\u8DF3\u8FC7" };
    if (!y || y.direction !== "incoming") return { ...g, ready: false, status: "already-replied-or-system-only", reason: "\u6CA1\u6709\u5C1A\u672A\u56DE\u590D\u7684\u771F\u4EBA\u6587\u5B57\u6765\u4FE1\uFF1B\u7CFB\u7EDF\u5361\u7247\u4E0D\u89E6\u53D1\u56DE\u590D" };
    if (/背景不完全相符|需要其他资质|不太符合|不太?合适|不[是太]*特别契合|不[完全]*符合|不[完全]*匹配|后续有机会再合作|未能通过|暂不考虑/u.test(y.text) && !/[?？]|(?:是否|有没有|会不会|能否|请问|什么时候|多少|怎么|哪些)/u.test(y.text)) return { ...g, ready: false, status: "rejected-no-reply", incomingMessageId: y.mid, reason: "\u5BF9\u65B9\u660E\u786E\u8868\u793A\u4E0D\u5408\u9002\uFF0C\u6309\u672C\u4EBA\u6700\u65B0\u8981\u6C42\u4E0D\u56DE\u590D\uFF1B\u4FDD\u7559\u6240\u6709\u539F\u5916\u53D1\u610F\u56FE" };
    const K = B("sha256").update(["boss-text-reply-v1", o.accountKey, y.mid].join(":")).digest("hex"), N = await t.state.get(), k = await $(t, n, o.accountKey, o.contextId);
    if (k.merge(N), await k.save(), N.replyIntents.some((d) => d.accountKey === o.accountKey && d.incomingMessageId === y.mid && ["reserved", "unknown", "failed"].includes(d.status)) || k.data.records.some((d) => d.type === "reply" && d.businessKey === K && d.sightings.some((I) => ["reserved", "unknown", "failed"].includes(I.status)))) {
      const d = "\u539F\u6765\u4FE1\u5DF2\u6709\u9884\u7559\u3001\u672A\u77E5\u6216\u5931\u8D25\u8BB0\u5F55\uFF0C\u4FDD\u7559\u5F85\u529E\u5E76\u7981\u6B62\u91CD\u53D1";
      return await t.attention({ key: "reply-existing-uncertain:" + o.accountKey + ":" + y.mid, title: "\u539F\u56DE\u590D\u7ED3\u679C\u5F85\u6838\u5BF9\uFF0C\u8BF7\u52FF\u91CD\u53D1", detail: { contact: s.identityLine, jobSource: E, incomingMessageId: y.mid, reason: d, externalAction: false } }), { ...g, ready: false, status: "existing-uncertain-reply", decision: "review", replyPolicyVersion: "work-questions-partial-known-v2", incomingMessageId: y.mid, key: K, reason: d };
    }
    if (N.replyIntents.some((d) => d.accountKey === o.accountKey && d.incomingMessageId === y.mid) || k.blocked("reply", K)) return { ...g, ready: false, status: "existing-reply-intent", incomingMessageId: y.mid, reason: "\u8BE5\u539F\u6765\u4FE1\u5DF2\u6709\u5916\u53D1\u610F\u56FE\uFF0C\u9884\u7559\u3001\u672A\u77E5\u53CA\u786E\u8BA4\u5747\u7981\u6B62\u91CD\u653E" };
    if ((N.conversationControls || []).some((d) => d.accountKey === o.accountKey && [g.conversationKey, "boss-chat:" + v[0].mid].includes(d.conversationKey) && d.mode === "paused")) return { ...g, ready: false, status: "manual-control", reason: "\u672C\u4EBA\u5DF2\u63A5\u7BA1\u672C\u4F1A\u8BDD\uFF0C\u81EA\u52A8\u56DE\u590D\u8DF3\u8FC7" };
    const T = new Intl.DateTimeFormat("sv-SE", { timeZone: o.configuration.replyTimeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
    if (new Set(k.data.records.filter((d) => d.type === "reply" && d.sightings.some((I) => I.day === T && I.timeZone === o.configuration.replyTimeZone && I.status !== "failed")).map((d) => d.businessKey)).size >= o.configuration.replyDailyLimit) throw Error("\u5DF2\u4FDD\u5B58\u7684\u672C\u4EBA\u56DE\u590D\u989D\u5EA6\u5DF2\u6EE1\uFF0C\u4FDD\u7559\u672A\u5B8C\u6210\u6536\u5C3E");
    const U = { ...g, ready: true, key: K, incomingMessageId: y.mid, incomingMessage: y.text, pendingMessages: S.slice(S.map((d) => d.direction).lastIndexOf("outgoing") + 1).filter((d) => d.direction === "incoming"), sourceSha256: B("sha256").update(JSON.stringify({ rows: v, jobSource: E, accountLabel: z })).digest("hex"), day: T, timeZone: o.configuration.replyTimeZone };
    if (!await q(t, n, U)) throw Error("\u5B8C\u6574\u6765\u6E90\u4FDD\u5B58\u524D\u4F1A\u8BDD\u5DF2\u53D8\u5316");
    return await c("fixed-unread-reply-source.json", JSON.stringify(U, null, 2)), U;
  };
  async function _(u) {
    let t = false;
    try {
      return await H({ ...u, onAccountVerified: () => {
        t = true;
      } });
    } catch (n) {
      const c = String(n.message || n), e = u.input?.cohort, o = /关联职位返回后的完整消息或对象变化|完整岗位标题缺失或截断|固定姓名搜索未取得唯一的姓名、公司和角色组合|固定成员缺少可核对的定向搜索姓名，未猜测|未读会话的实际职位链接未核对|关联职位没有可核对的继续沟通入口|固定成员当前列表|固定成员缺少唯一可见身份|固定成员可见身份|固定会话返回|关联职位完整标题与固定会话不符/u.test(c), r = t && !/账号|安全索引|账本|摘要|配置|状态|进度|Skill|预留/u.test(c) && /固定成员|固定会话|关联职位|网页操作超时|元素|目标不可见|点击目标|点击期间|\(-3\) loading/u.test(c);
      if (!(o || r) || e?.kind !== "unread-closing-cohort" || !e.member?.key) throw n;
      return await u.template.attention({ key: "fixed-member-source-review:" + e.accountKey + ":" + e.member.key, title: "\u8BE5\u672A\u8BFB\u4F1A\u8BDD\u6765\u6E90\u5F85\u6838\u5BF9\uFF0C\u672A\u6267\u884C\u5916\u53D1", detail: { contact: e.member.identityLine, fixedUnreadSetSha256: e.fixedUnreadSetSha256, memberKey: e.member.key, reason: c, externalAction: false } }), { ...e, sourceReviewVersion: "chat-list-direct-v5", kind: "chat-reply-source", fixedUnreadMember: true, profile: u.input.profile, ready: false, jobId: null, jobSource: null, status: "member-needs-review", decision: "review", replyPolicyVersion: "work-questions-partial-known-v2", reason: c };
    }
  }
  async function W(u) {
    const t = u.input;
    if (t?.kind !== "chat-reply-source" || t.fixedUnreadMember !== true) throw Error("\u7F3A\u5C11\u539F\u56FA\u5B9A\u6210\u5458\u4E0A\u4E0B\u6587");
    const n = [];
    if (t.jobId) for (const [c, e, o] of [["native-contact-index-v1-" + t.accountKey + ".json", "boss-native-contact-index", "actions"], ["resume-delivery-index-v1-" + t.accountKey + ".json", "boss-resume-delivery-index", "deliveries"]]) {
      let r;
      try {
        r = await u.template.file("communication-cache", { operation: "read", name: c });
      } catch (s) {
        if (String(s.message || s).includes("ENOENT")) continue;
        throw s;
      }
      const l = JSON.parse(r), { sha256: a, ...f } = l;
      if (a !== Z(f) || l.kind !== e || l.accountKey !== t.accountKey || !Array.isArray(l[o])) throw Error("\u539F\u751F\u52A8\u4F5C\u8D26\u672C\u6765\u6E90\u4E0D\u7B26");
      for (const s of l[o]) s.jobSource === t.jobSource && (s.memberKey === t.member.key || s.firstMessageId === t.rows?.[0]?.mid) && n.push({ type: s.contactType || "resume", requestMid: s.requestMid, status: s.status, key: s.key, receipt: s.receipt || null, agreementConfirmed: s.agreementConfirmed === true, contactValueObserved: s.contactValueObserved === true });
    }
    return { ...t.ready ? await _({ ...u, input: { cohort: { ...t, kind: "unread-closing-cohort" }, profile: t.profile } }) : t, nativeActions: n };
  }
  return W;
})();
var Q = async function({ input: x }) {
  if (!x?.unknownRecovery) throw Error("\u7F3A\u5C11unknown\u804A\u5929\u6765\u6E90");
  return x;
};
async function ou(B) {
  return B.input?.unknownRecovery ? Q(B) : G(B);
}
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default = (ctx) => ou(Object.freeze({ ...ctx, constants }));
export {
  stdin_default as default
};
