import { createHash } from "node:crypto";
var PANEL = Object.freeze({ title: "head > title", jobTitle: ".job-detail-container .job-name", jobCity: ".job-header-info .tag-list > :nth-child(1)", companyLabel: ".job-boss-info > :nth-child(2) > :nth-child(2)", description: ".job-detail-body > .desc", salary: ".job-detail-container .job-salary", closedStatus: ".job-detail-container .job-close", contact: ".job-detail-container div:nth-of-type(2) > a:nth-of-type(2)" });
var directMode = "salary-and-selected-ui";
var directHash = (v) => createHash("sha256").update(typeof v === "string" ? v : JSON.stringify(v)).digest("hex");
var directDay = (zone) => new Intl.DateTimeFormat("sv-SE", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
var stdin_default = async ({ input, signal }) => {
  signal.throwIfAborted();
  const { account: a, advice: m, prepared: p, reservation: r, approvedGreetingText: text } = input, i = r?.intent, w = r?.receipt, s = m?.source;
  if (r?.result?.kind !== "daily-application-reservation" || r.result.reservationPersisted !== true || i?.status !== "reserved" || w?.operation !== "state.write" || w.revision !== r.result.stateRevision || JSON.stringify(w.value.applicationIntents.find((v) => v.key === i.key)) !== JSON.stringify(i) || m?.kind !== "direct-salary-selection-decision" || m.aiCalled !== false || m.decision !== "match" || p?.kind !== "direct-first-contact-prepared" || p.aiCalled !== false || s?.contextId !== w.contextId || s.applicationKey !== i.key || s.accountSourceSha256 !== i.accountSourceSha256 || s.jobSource !== i.jobSource || s.day !== i.day || s.configurationRevision !== i.configurationRevision || a?.currentAccountVerified !== true || directDay(i.timeZone) !== i.day) throw Error("\u7F3A\u5C11\u672C\u9879\u76F4\u63A5\u62DB\u547C\u7684\u6301\u4E45\u9884\u7559\u4E0E\u56DE\u8BFB");
  if (typeof text !== "string" || !text.trim() || text.length > 4e3) throw Error("\u6279\u51C6\u7684App\u62DB\u547C\u6B63\u6587\u7F3A\u5931");
  const greetingSha256 = directHash(text), description = "\u5411\u5F53\u524D\u9009\u4E2D\u5C97\u4F4D\u70B9\u51FB\u4E00\u6B21\u7ACB\u5373\u6C9F\u901A\uFF1B\u7F51\u7AD9\u53D1\u9001App\u9ED8\u8BA4\u62DB\u547C\u5E76\u7559\u5728\u672C\u9875\u3002", target = s.title + " \xB7 " + s.actualCity + " \xB7 \u8D26\u53F7\uFF1A" + a.accountName;
  return { version: 1, kind: "daily-application-operation-input", evaluationMode: directMode, aiCalled: false, action: "apply", submissionMode: "first-communication-with-app-default-greeting", greetingText: text, greetingSha256, key: "application:" + i.key, description, review: { version: 1, target, content: ["\u4F7F\u7528\u8005\u89C4\u5219\uFF1A\u5217\u8868\u6708\u85AA\u6709\u4EA4\u96C6\u5E76\u4E14\u5C97\u4F4D\u5DF2\u9009\u4E2D\uFF0C\u76F4\u63A5\u9996\u6B21\u6C9F\u901A\u3002", "\u5C97\u4F4D\uFF1A" + s.title, "\u5217\u8868\u6708\u85AA\uFF1A" + p.job.salaryRaw, "\u5C97\u4F4D\u94FE\u63A5\uFF1A" + i.jobSource, "\u8D26\u53F7\uFF1A" + a.accountName + "\uFF08" + a.phoneMask + "\uFF09", "\u4E0D\u8C03\u7528AI\uFF0C\u4E0D\u4F5CJD\u6216\u516C\u53F8\u540D\u79F0\u6BD4\u5BF9\uFF1B\u4E0D\u53D1\u9001\u7B80\u5386\u9644\u4EF6\u3001\u8054\u7CFB\u65B9\u5F0F\u6216\u53E6\u4E00\u6761\u4ECB\u7ECD\u3002", "App\u6279\u51C6\u62DB\u547C\uFF1A", text, "\u70B9\u51FB\u524D\u6301\u4E45\u9884\u7559\uFF1B\u7F51\u7AD9\u9001\u8FBE\u4E0D\u660E\u4FDD\u7559unknown\u5E76\u505C\u6B62\uFF0C\u4E0D\u91CD\u653E\u3002"].join("\n") }, intent: i, stateRevision: w.revision, contextId: w.contextId, actualCity: s.actualCity, jobTitle: s.title, jobSource: i.jobSource, listSource: s.listSource, sourceMode: "persisted-job-link-in-list", websiteGreetingVerified: false, readyForWebsiteSubmission: false, applied: false };
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default2 = (ctx) => stdin_default(Object.freeze({ ...ctx, constants }));
export {
  stdin_default2 as default
};
