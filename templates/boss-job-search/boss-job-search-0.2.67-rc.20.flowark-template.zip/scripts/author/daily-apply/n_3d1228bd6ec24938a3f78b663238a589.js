import { createHash as j } from "node:crypto";
var U = /* @__PURE__ */ (() => {
  const D = (t) => Array.isArray(t) ? t.map(D) : t && typeof t == "object" ? Object.fromEntries(Object.keys(t).sort().map((e) => [e, D(t[e])])) : t, k = (t) => j("sha256").update(JSON.stringify(D(t))).digest("hex");
  async function A(t, e, r, d, u = false) {
    const n = "account-outbound-safety-v1-" + r + ".json";
    let o, s = true, i;
    try {
      i = await t.file("communication-cache", { operation: "read", name: n }), o = JSON.parse(i);
    } catch (y) {
      if (!String(y.message || y).includes("ENOENT")) throw y;
      if (!u) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
      s = false, o = { version: 1, kind: "boss-account-outbound-safety", accountKey: r, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    }
    if (s) {
      const { sha256: y, ...h } = o;
      if (y !== k(h)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
    }
    if (o.version !== 1 || o.kind !== "boss-account-outbound-safety" || o.accountKey !== r || !Number.isSafeInteger(o.revision) || o.revision < 0 || !Array.isArray(o.records) || o.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
    const w = /* @__PURE__ */ new Set();
    for (const y of o.records) {
      if (!["first-contact", "reply"].includes(y.type) || !/^[a-f0-9]{64}$/.test(y.businessKey) || !Array.isArray(y.sightings) || !y.sightings.length || y.sightings.length > 100 || w.has(y.type + ":" + y.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
      w.add(y.type + ":" + y.businessKey);
      for (const h of y.sightings) if (typeof h.contextId != "string" || !h.contextId || !/^[a-f0-9]{64}$/.test(h.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(h.status) || !/^\d{4}-\d{2}-\d{2}$/.test(h.day) || typeof h.timeZone != "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
    }
    let f = !s;
    return { data: o, name: n, merge: (y) => {
      if (!Array.isArray(y?.applicationIntents) || !Array.isArray(y?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
      for (const [h, g] of [["first-contact", y.applicationIntents], ["reply", y.replyIntents]]) for (const a of g) {
        if ((h === "first-contact" ? a.accountSourceSha256 : a.accountKey) !== r) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
        if (!/^[a-f0-9]{64}$/.test(a.key) || !a.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(a.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
        const S = h === "first-contact" ? k(["boss-job-safety-v1", r, a.jobId]) : j("sha256").update(["boss-text-reply-v1", r, a.incomingMessageId].join(":")).digest("hex");
        let l = o.records.find((I) => I.type === h && I.businessKey === S);
        if (l || (l = { type: h, businessKey: S, jobId: a.jobId, ...h === "reply" ? { conversationKey: a.conversationKey, incomingMessageId: a.incomingMessageId } : {}, sightings: [] }, o.records.push(l), f = true), l.jobId !== a.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
        const m = { contextId: d, intentKey: a.key, status: a.status, day: a.day, timeZone: a.timeZone, contentSha256: a.contentSha256 || null, sourceSha256: a.sourceSha256 || null };
        if (l.sightings.some((I) => JSON.stringify(D(I)) === JSON.stringify(D(m))) || (l.sightings.push(m), f = true), l.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
      }
      if (o.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
    }, save: async () => {
      if (e.throwIfAborted(), f) {
        if (s && await t.file("communication-cache", { operation: "read", name: n }) !== i) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
        o.records.sort((a, S) => (a.type + ":" + a.businessKey).localeCompare(S.type + ":" + S.businessKey));
        for (const a of o.records) a.sightings.sort((S, l) => JSON.stringify(D(S)).localeCompare(JSON.stringify(D(l))));
        o.revision++, o.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete o.sha256, o.sha256 = k(o), await t.file("communication-cache", { operation: "write", name: n, content: JSON.stringify(o) }), f = false, i = JSON.stringify(o), s = true;
      }
      const y = JSON.parse(await t.file("communication-cache", { operation: "read", name: n })), { sha256: h, ...g } = y;
      if (h !== k(g) || h !== o.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
      return { revision: o.revision, sha256: o.sha256, records: o.records.length };
    }, blocked: (y, h) => o.records.some((g) => g.type === y && g.businessKey === h) };
  }
  const L = (t, e) => async (r, d, u) => (e.throwIfAborted(), t.browser("browser", { operation: r, ...d ? { selector: d } : {}, ...u === void 0 ? {} : { value: u }, timeoutMs: 3e3 })), O = (t) => {
    const { sha256: e, ...r } = t;
    return e === k(r);
  };
  async function C(t, e, r, d) {
    const u = r.progressName, n = await t.file("communication-cache", { operation: "read", name: u }), o = JSON.parse(n);
    if (!O(o) || o.accountKey !== r.accountKey || o.fixedUnreadSetSha256 !== r.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
    if (!d) return o;
    const s = d(structuredClone(o));
    if (s.revision++, s.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete s.sha256, s.sha256 = k(s), await t.file("communication-cache", { operation: "read", name: u }) !== n) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
    e.throwIfAborted(), await t.file("communication-cache", { operation: "write", name: u, content: JSON.stringify(s) });
    const i = JSON.parse(await t.file("communication-cache", { operation: "read", name: u }));
    if (!O(i) || i.sha256 !== s.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
    return i;
  }
  async function M(t) {
    const e = await t("count", "li.message-item");
    if (!Number.isSafeInteger(e) || e < 1 || e > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
    const r = [];
    for (let d = 1; d <= e; d++) {
      const u = "li.message-item:nth-child(" + d + " of li.message-item)", n = await t("attribute", u, "data-mid"), o = await t("attribute", u, "class");
      if (!/^\d{6,40}$/.test(n || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
      const s = await t("count", u + " .text-content");
      if (s > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
      const i = s === 1 ? String(await t("read", u + " .text-content")).trim() : null, w = i === null ? String(await t("read", u)).trim() : null;
      if ((i || w || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
      const f = !!i && /^您正在与Boss.+沟通$/u.test(i), p = !f && i !== null && o.split(/\s+/u).includes("item-myself") ? "outgoing" : !f && i !== null && o.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
      r.push({ mid: n, direction: p, text: i, context: w });
    }
    if (new Set(r.map((d) => d.mid)).size !== r.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
    return r;
  }
  async function J(t, e) {
    const r = new URL(await t("url"));
    if (r.origin !== "https://www.zhipin.com" || r.pathname !== "/web/geek/chat" || await t("count", ".chat-conversation .user-info") !== 1) return false;
    const d = String(await t("read", ".chat-conversation .user-info")).trim(), u = (n) => n.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
    return String(await t("read", ".chat-conversation .user-info")).trim() === e.recipientLabel && await t("count", 'li.message-item[data-mid="' + e.rows[0].mid + '"]') === 1;
  }
  async function R(t, e, r) {
    const d = L(t, e);
    return await J(d, r) ? String(await d("read", r.accountSelector)).trim() === r.accountLabel && String(await d("read", r.recipientSelector)).trim() === r.recipientLabel && JSON.stringify(await M(d)) === JSON.stringify(r.rows) : false;
  }
  async function z(t, e, r) {
    const d = ".chat-conversation .btn-send";
    let u = 0;
    const n = Date.now() + 5e3;
    for (; Date.now() < n; ) {
      if (!await r() || String(await t("read", "#chat-input")).trim() !== e) throw Error("\u7B49\u5F85\u53D1\u9001\u5C31\u7EEA\u65F6\u4F1A\u8BDD\u6216\u6B63\u6587\u53D8\u5316\uFF0C\u672A\u6309\u56DE\u8F66");
      if (await t("count", d) !== 1 || String(await t("read", d)).trim() !== "\u53D1\u9001") throw Error("\u53D1\u9001\u72B6\u6001\u6765\u6E90\u4E0D\u552F\u4E00");
      const o = String(await t("attribute", d, "class") || ""), s = await t("attribute", d, "disabled"), i = await t("attribute", d, "aria-disabled");
      if (u = s === null && i !== "true" && !o.split(/\s+/u).includes("disabled") ? u + 1 : 0, u === 2) return { kind: "boss-composer-ready", stableSamples: 2, readinessOnly: true, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
      await new Promise((f) => setTimeout(f, 100));
    }
    throw Error("\u7F51\u7AD9\u8F93\u5165\u6846\u5C1A\u672A\u8FDB\u5165\u53EF\u53D1\u9001\u72B6\u6001\uFF0C\u672A\u6309\u56DE\u8F66");
  }
  var Z = async ({ input: t, signal: e, template: r, artifact: d }) => {
    if (t?.kind !== "chat-reply-draft") throw Error("Missing AI reply stage");
    if (t.send && (typeof t.reply != "string" || Array.from(t.reply).length < 1 || Array.from(t.reply).length > 50)) throw Error("\u53D1\u9001\u524D\u56DE\u590D\u987B\u4E3A1\u81F350\u5B57\uFF0C\u672A\u5EFA\u7ACB\u53D1\u9001\u610F\u56FE");
    if (!t.send) return { ...t, kind: "chat-reply-dispatch", dispatched: false };
    const u = (a) => j("sha256").update(a).digest("hex");
    if (u(t.reply) !== t.contentSha256 || !t.model?.requestId || t.decision !== "reply" || t.closingPhase !== true || t.fixedUnreadMember !== true || t.siteDailyLimitEvidence?.confirmed !== true && !(t.closingTrigger === "two-new-greetings-test" && t.testCompletionEvidence?.kind === "boss-test-new-greeting-completion" && t.testCompletionEvidence.confirmed === true && t.testCompletionEvidence.newConfirmed === 2) || !t.fixedUnreadSetSha256 || t.key !== u(["boss-text-reply-v1", t.accountKey, t.incomingMessageId].join(":"))) throw Error("Reply text or model source changed");
    const n = (a, S, l) => (e.throwIfAborted(), r.browser("browser", { operation: a, ...S ? { selector: S } : {}, ...l !== void 0 ? { value: l } : {}, timeoutMs: 3e3 })), o = () => R(r, e, t);
    if (!await o()) throw Error("Conversation changed while AI was thinking; no send");
    let s = await r.state.get();
    const i = await A(r, e, t.accountKey, t.contextId);
    if (i.merge(s), await i.save(), (s.replyIntents || []).some((a) => a.accountKey === t.accountKey && a.incomingMessageId === t.incomingMessageId) || i.data.records.some((a) => a.type === "reply" && (a.businessKey === t.key || a.incomingMessageId === t.incomingMessageId))) return { ...t, kind: "chat-reply-dispatch", dispatched: false, reason: "Persistent reply intent already exists; no replay" };
    const w = (s.conversationControls || []).filter((a) => a.accountKey === t.accountKey && a.conversationKey === t.conversationKey);
    if (w.some((a) => a.mode === "paused")) throw Error("Conversation is under manual control");
    const f = w.length ? Math.max(...w.map((a) => a.controlEpoch)) : 1;
    let p = s.replyIntents || [];
    if (p.length >= 500 || p.filter((a) => a.accountKey === t.accountKey && a.day === t.day && a.timeZone === t.timeZone && a.status !== "failed").length >= t.configuration.replyDailyLimit) throw Error("Reply quota or ledger capacity reached");
    if (await n("count", "#chat-input") !== 1 || String(await n("read", "#chat-input")).trim() !== "") throw Error("Composer contains an existing draft; no overwrite");
    if (await n("count", ".chat-conversation .btn-send") !== 1 || String(await n("read", ".chat-conversation .btn-send")).trim() !== "\u53D1\u9001") throw Error("Send target is ambiguous");
    const F = await r.effect.prepare({ action: "reply", key: t.key, description: "\u5411\u5F53\u524D\u51C6\u786E\u5DF2\u6709\u4F1A\u8BDD\u56DE\u590D\u539F\u6765\u4FE1 " + t.incomingMessageId + "\uFF1B\u4EC5\u6B64\u6587\u672C\uFF0C\u4E0D\u53D1\u9001\u9644\u4EF6\u6216\u65B0\u7684\u9996\u6B21\u62DB\u547C\u3002", review: { version: 1, target: t.jobTitle + `
` + t.jobSource + `
\u539F\u6765\u4FE1 ` + t.incomingMessageId, content: t.reply } });
    if (!F.execute) return { ...t, kind: "chat-reply-dispatch", dispatched: false, reason: "Existing effect blocks repeated reply" };
    const y = { key: t.key, accountKey: t.accountKey, conversationKey: t.conversationKey, incomingMessageId: t.incomingMessageId, jobId: t.jobId, contentSha256: t.contentSha256, sourceSha256: t.sourceSha256, profileVersionId: t.profile.ref.versionId, configurationRevision: t.configurationRevision, controlEpoch: f, day: t.day, timeZone: t.timeZone, createdAt: (/* @__PURE__ */ new Date()).toISOString(), status: "reserved" };
    let h = false, g = false;
    try {
      s = await r.state.get(), p = s.replyIntents || [];
      const a = await A(r, e, t.accountKey, t.contextId);
      if (a.merge(s), await a.save(), p.some((c) => c.accountKey === t.accountKey && c.incomingMessageId === t.incomingMessageId) || a.data.records.some((c) => c.type === "reply" && (c.businessKey === t.key || c.incomingMessageId === t.incomingMessageId))) throw Error("\u786E\u8BA4\u671F\u95F4\u539F\u6765\u4FE1\u5DF2\u5EFA\u7ACB\u56DE\u590D\u610F\u56FE\uFF0C\u505C\u6B62\u65E7\u8349\u7A3F");
      if ((s.conversationControls || []).some((c) => c.accountKey === t.accountKey && [t.conversationKey, "boss-chat:" + t.rows[0].mid].includes(c.conversationKey) && c.mode === "paused")) throw Error("\u786E\u8BA4\u671F\u95F4\u672C\u4EBA\u5DF2\u63A5\u7BA1\u4F1A\u8BDD");
      if (new Set(a.data.records.filter((c) => c.type === "reply" && c.sightings.some((E) => E.day === t.day && E.timeZone === t.timeZone && E.status !== "failed")).map((c) => c.businessKey)).size >= t.configuration.replyDailyLimit || p.length >= 500) throw Error("\u786E\u8BA4\u671F\u95F4\u56DE\u590D\u989D\u5EA6\u6216\u8D26\u672C\u5BB9\u91CF\u5DF2\u6EE1");
      if (await r.state.set({ ...s, replyIntents: [...p, y] }), g = true, s = await r.state.get(), s.replyIntents.filter((c) => c.key === t.key && c.status === "reserved").length !== 1 || !await o()) throw Error("Reservation or exact conversation changed");
      const l = await A(r, e, t.accountKey, t.contextId);
      l.merge(s);
      const m = await l.save();
      if (!l.data.records.some((c) => c.type === "reply" && c.businessKey === t.key && c.sightings.some((E) => E.contextId === t.contextId && E.intentKey === t.key && E.status === "reserved"))) throw Error("\u56DE\u590D\u5B89\u5168\u7D22\u5F15\u9884\u7559\u672A\u8BFB\u56DE");
      const I = "unknown-chat-sources-v1-" + t.accountKey + ".json";
      let v = null;
      try {
        v = await r.file("communication-cache", { operation: "read", name: I });
      } catch (c) {
        if (!String(c.message || c).includes("ENOENT")) throw c;
      }
      const b = v ? JSON.parse(v) : { version: 1, kind: "boss-unknown-chat-sources", accountKey: t.accountKey, revision: 0, items: [] };
      if (v) {
        const { sha256: c, ...E } = b;
        if (c !== k(E)) throw Error("\u6062\u590D\u6765\u6E90\u76EE\u5F55\u6458\u8981\u4E0D\u7B26");
      }
      if (b.kind !== "boss-unknown-chat-sources" || b.accountKey !== t.accountKey || !Array.isArray(b.items) || b.items.length >= 2e3) throw Error("\u6062\u590D\u6765\u6E90\u76EE\u5F55\u8EAB\u4EFD\u6216\u5BB9\u91CF\u4E0D\u7B26");
      const N = { key: "reply:" + t.key, parentKind: "reply", parentKey: t.key, recipientLabel: t.recipientLabel, recipientName: t.recipientLabel.split(/\r?\n/u)[0].trim(), firstMessageId: t.rows[0].mid, originalIncomingMid: t.incomingMessageId, originalApprovedText: t.reply, originalTextSha256: t.contentSha256, originalSourceSha256: t.sourceSha256 }, K = b.items.find((c) => c.key === N.key);
      if (K && k(K) !== k(N)) throw Error("\u539F\u6062\u590D\u6765\u6E90\u4E0D\u5141\u8BB8\u8986\u76D6");
      if (!K) {
        b.items.push(N), b.revision++, b.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete b.sha256, b.sha256 = k(b);
        let c = null;
        try {
          c = await r.file("communication-cache", { operation: "read", name: I });
        } catch ($) {
          if (!String($.message || $).includes("ENOENT")) throw $;
        }
        if (c !== v) throw Error("\u6062\u590D\u6765\u6E90\u76EE\u5F55\u5E76\u53D1\u53D8\u5316");
        const E = JSON.stringify(b);
        if (await r.file("communication-cache", { operation: "write", name: I, content: E }), await r.file("communication-cache", { operation: "read", name: I }) !== E) throw Error("\u6062\u590D\u6765\u6E90\u76EE\u5F55\u672A\u51C6\u786E\u8BFB\u56DE");
      }
      await d("reply-reservation.json", JSON.stringify({ intent: y, effect: F, safety: m, sourceSha256: t.sourceSha256, reply: t.reply, model: t.model }, null, 2)), await n("fill", "#chat-input", t.reply);
      let T = false;
      for (let c = 0; c < 12; c++) {
        if (String(await n("read", "#chat-input")).trim() === t.reply) {
          T = true;
          break;
        }
        await new Promise((E) => setTimeout(E, 100));
      }
      if (!T || !await o() || String(await n("read", "#chat-input")).trim() !== t.reply) throw Error("Draft or recipient changed before send");
      const x = await r.state.get(), B = await A(r, e, t.accountKey, t.contextId);
      if (B.data.records.some((c) => c.type === "reply" && c.incomingMessageId === t.incomingMessageId && c.businessKey !== t.key) || x.replyIntents.filter((c) => c.accountKey === t.accountKey && c.incomingMessageId === t.incomingMessageId).length !== 1 || x.replyIntents.filter((c) => c.key === t.key && c.status === "reserved").length !== 1 || !B.data.records.some((c) => c.type === "reply" && c.businessKey === t.key && c.sightings.some((E) => E.contextId === t.contextId && E.intentKey === t.key && E.status === "reserved")) || B.data.records.some((c) => c.type === "reply" && c.businessKey === t.key && c.sightings.some((E) => E.contextId !== t.contextId || E.intentKey !== t.key || E.status !== "reserved")) || (x.conversationControls || []).some((c) => c.accountKey === t.accountKey && [t.conversationKey, "boss-chat:" + t.rows[0].mid].includes(c.conversationKey) && c.mode === "paused") || !await o() || String(await n("read", "#chat-input")).trim() !== t.reply) throw Error("\u53D1\u9001\u524D\u5BF9\u8C61\u3001\u6765\u4FE1\u3001\u9884\u7559\u6216\u63A5\u7BA1\u72B6\u6001\u53D8\u5316");
      if (!/按\s*Enter\s*键发送/u.test(String(await n("read", ".chat-conversation")))) throw Error("\u7F51\u7AD9\u672A\u786E\u8BA4Enter\u53D1\u9001\u6A21\u5F0F\uFF1B\u4E0D\u6267\u884C\u53D1\u9001");
      const P = await z(n, t.reply, o);
      if (await d("reply-composer-ready.json", JSON.stringify(P)), h = true, await n("click", "#chat-input"), !await o() || String(await n("read", "#chat-input")).trim() !== t.reply) throw Error("\u56DE\u8F66\u524D\u5F53\u524D\u804A\u5929\u6216\u8349\u7A3F\u53D8\u5316\uFF0C\u4E0D\u53D1\u9001");
      return await n("press", "#chat-input", "Enter"), { ...t, kind: "chat-reply-dispatch", dispatched: true, effect: F, intent: y, websiteConfirmed: false };
    } catch (a) {
      const S = h ? "unknown" : "failed";
      if (await r.effect.resolve({ id: F.id, state: S, evidence: { kind: "reply-not-confirmed", incomingMessageId: t.incomingMessageId, jobSource: t.jobSource, attempted: h, reason: String(a.message || a) } }), s = await r.state.get(), g) {
        await r.state.set({ ...s, replyIntents: s.replyIntents.map((m) => m.key === t.key ? { ...m, status: S } : m) }), s = await r.state.get();
        const l = await A(r, e, t.accountKey, t.contextId);
        l.merge(s), await l.save();
      }
      throw a;
    }
  };
  return Z;
})();
var H = /* @__PURE__ */ (() => {
  const D = (e) => Array.isArray(e) ? e.map(D) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((r) => [r, D(e[r])])) : e, k = (e) => j("sha256").update(JSON.stringify(D(e))).digest("hex"), A = (e) => j("sha256").update(e).digest("hex"), L = (e, r) => (d, u, n) => (r.throwIfAborted(), e.browser("browser", { operation: d, ...u ? { selector: u } : {}, ...n === void 0 ? {} : { value: n }, timeoutMs: 3e3 }));
  async function O(e, r, d, u, n = null) {
    let o = null;
    try {
      o = await e.file("communication-cache", { operation: "read", name: r });
    } catch (i) {
      if (!String(i.message || i).includes("ENOENT")) throw i;
    }
    const s = o === null ? n : JSON.parse(o);
    if (!s) throw Error("\u7F3A\u5C11\u6062\u590D\u6765\u6E90 " + r);
    if (o !== null) {
      const { sha256: i, ...w } = s;
      if (i !== k(w)) throw Error("\u6062\u590D\u6765\u6E90\u6458\u8981\u4E0D\u7B26 " + r);
    }
    if (s.kind !== d || s.accountKey !== u) throw Error("\u6062\u590D\u6765\u6E90\u8D26\u53F7\u6216\u7C7B\u578B\u4E0D\u7B26");
    return { name: r, raw: o, value: s };
  }
  async function C(e, r) {
    let d = null;
    try {
      d = await e.file("communication-cache", { operation: "read", name: r.name });
    } catch (o) {
      if (!String(o.message || o).includes("ENOENT")) throw o;
    }
    if (d !== r.raw) throw Error("\u6062\u590D\u8BB0\u5F55\u5E76\u53D1\u53D8\u5316");
    const u = r.value;
    u.revision++, u.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete u.sha256, u.sha256 = k(u);
    const n = JSON.stringify(u);
    if (await e.file("communication-cache", { operation: "write", name: r.name, content: n }), await e.file("communication-cache", { operation: "read", name: r.name }) !== n) throw Error("\u6062\u590D\u8BB0\u5F55\u672A\u51C6\u786E\u8BFB\u56DE");
    r.raw = n;
  }
  async function M(e, r) {
    return O(e, "unknown-chat-reviews-v1-" + r + ".json", "boss-unknown-chat-reviews", r, { version: 1, kind: "boss-unknown-chat-reviews", accountKey: r, revision: 0, reviews: [] });
  }
  async function J(e) {
    const r = await e("count", "li.message-item");
    if (!Number.isSafeInteger(r) || r < 1 || r > 150) throw Error("\u4F1A\u8BDD\u53EF\u89C1\u6D88\u606F\u8303\u56F4\u65E0\u6548");
    const d = [];
    for (let u = 1; u <= r; u++) {
      const n = "li.message-item:nth-child(" + u + " of li.message-item)", o = await e("attribute", n, "data-mid"), s = String(await e("attribute", n, "class") || "");
      if (!/^\d{6,40}$/u.test(o || "")) throw Error("\u7F3A\u5C11\u771F\u5B9E\u670D\u52A1\u5668\u6D88\u606F\u7F16\u53F7");
      const i = await e("count", n + " .text-content");
      if (i > 1) throw Error("\u5355\u6761\u6B63\u6587\u4E0D\u552F\u4E00");
      const w = i === 1 ? String(await e("read", n + " .text-content")).trim() : null, f = i === 1 ? null : String(await e("read", n)).trim(), p = !!w && /^您正在与Boss.+沟通$/u.test(w), F = !p && w !== null && s.split(/\s/u).includes("item-myself") ? "outgoing" : !p && w !== null && s.split(/\s/u).includes("item-friend") ? "incoming" : "system", y = n + " > div > div > i", h = await e("count", y) === 1 ? String(await e("read", y)).trim() : null;
      d.push({ mid: o, direction: F, text: w, context: f, receipt: h });
    }
    if (new Set(d.map((u) => u.mid)).size !== d.length) throw Error("\u670D\u52A1\u5668\u6D88\u606F\u7F16\u53F7\u91CD\u590D");
    return d;
  }
  async function R(e, r, d = true) {
    const u = new URL(await e("url"));
    if (u.origin !== "https://www.zhipin.com" || u.pathname !== "/web/geek/chat" || String(await e("read", r.accountSelector)).trim() !== r.accountLabel || await e("count", 'li.message-item[data-mid="' + r.member.originalIncomingMid + '"]') !== 1 || await e("count", 'li.message-item[data-mid="' + r.member.firstMessageId + '"]') !== 1) throw Error("\u672A\u77E5\u6062\u590D\u7684\u8D26\u53F7\u6216\u539F\u6D88\u606F\u94FE\u53D8\u5316");
    if (d && k(await J(e)) !== r.messagesHash) throw Error("AI\u5224\u65AD\u671F\u95F4\u804A\u5929\u5185\u5BB9\u53D8\u5316\uFF0C\u672A\u5916\u53D1");
  }
  async function z(e, r) {
    const d = ".list-warp.v2 input";
    if (await e("count", d) !== 1) throw Error("\u8054\u7CFB\u4EBA\u641C\u7D22\u5165\u53E3\u4E0D\u552F\u4E00");
    await e("click", d), await e("fill", d, r.lookupQuery || r.recipientName);
    const u = ".boss-search-result .search-list";
    let n = 0;
    for (let i = 0; i < 30 && (n = await e("count", u), !(n > 0)); i++) await new Promise((w) => setTimeout(w, 150));
    if (n < 1 || n > 50) throw Error("\u672A\u627E\u5230\u539Funknown\u8054\u7CFB\u4EBA");
    const o = [];
    for (let i = 1; i <= n; i++) {
      const w = u + ":nth-child(" + i + " of .search-list)", f = [w];
      let p = 0;
      for (; f.length; ) {
        const F = f.shift();
        if (++p > 150) throw Error("\u59D3\u540D\u63A7\u4EF6\u8303\u56F4\u8FC7\u5927");
        const y = String(await e("read", F)).trim(), h = await e("count", F + " > *");
        if (y === r.recipientName && o.push({ selector: F, text: y }), h > 0 && h < 30) for (let g = 1; g <= h; g++) f.push(F + " > :nth-child(" + g + ")");
      }
    }
    const s = o.filter((i) => !o.some((w) => w !== i && w.selector.startsWith(i.selector + " > ")));
    if (s.length !== 1) throw Error("\u539Funknown\u59D3\u540D\u63A7\u4EF6\u4E0D\u552F\u4E00");
    if (String(await e("read", s[0].selector)).trim() !== s[0].text) throw Error("\u641C\u7D22\u7ED3\u679C\u53D8\u5316");
    await e("click", s[0].selector);
    for (let i = 0; i < 40; i++) {
      if (await e("count", 'li.message-item[data-mid="' + r.originalIncomingMid + '"]') === 1 && await e("count", 'li.message-item[data-mid="' + r.firstMessageId + '"]') === 1) return;
      await new Promise((w) => setTimeout(w, 150));
    }
    throw Error("\u641C\u7D22\u540E\u672A\u8BFB\u56DE\u539Funknown\u670D\u52A1\u5668\u6D88\u606F\u94FE");
  }
  async function Z(e, r, d) {
    const u = ".chat-conversation .btn-send";
    let n = 0;
    const o = Date.now() + 5e3;
    for (; Date.now() < o; ) {
      if (!await d() || String(await e("read", "#chat-input")).trim() !== r) throw Error("\u7B49\u5F85\u53D1\u9001\u5C31\u7EEA\u65F6\u4F1A\u8BDD\u6216\u6B63\u6587\u53D8\u5316\uFF0C\u672A\u6309\u56DE\u8F66");
      if (await e("count", u) !== 1 || String(await e("read", u)).trim() !== "\u53D1\u9001") throw Error("\u53D1\u9001\u72B6\u6001\u6765\u6E90\u4E0D\u552F\u4E00");
      const s = String(await e("attribute", u, "class") || ""), i = await e("attribute", u, "disabled"), w = await e("attribute", u, "aria-disabled");
      if (n = i === null && w !== "true" && !s.split(/\s+/u).includes("disabled") ? n + 1 : 0, n === 2) return { kind: "boss-composer-ready", stableSamples: 2, readinessOnly: true, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
      await new Promise((p) => setTimeout(p, 100));
    }
    throw Error("\u7F51\u7AD9\u8F93\u5165\u6846\u5C1A\u672A\u8FDB\u5165\u53EF\u53D1\u9001\u72B6\u6001\uFF0C\u672A\u6309\u56DE\u8F66");
  }
  return async function({ input: e, template: r, signal: d, artifact: u }) {
    if (e?.kind !== "unknown-chat-review-draft" || !e.unknownRecovery) throw Error("\u7F3A\u5C11AI\u63A5\u7BA1\u6765\u6E90");
    if (e.decision !== "reply") return { ...e, kind: "unknown-chat-review-dispatch", dispatched: false, readOnly: false, status: e.decision === "skip" ? "skipped" : "review" };
    if (e.readOnly || !e.model?.requestId || e.member.parentKind !== "reply" || !e.latestIncomingMid || e.lastRealDirection !== "incoming" || e.campus || !e.initiatedByUs || e.unsupportedFacts.length || A(e.reply) !== e.contentSha256 || Array.from(e.reply).length < 1 || Array.from(e.reply).length > 50) throw Error("\u63A5\u7BA1\u53D1\u9001\u6761\u4EF6\u4E0D\u6EE1\u8DB3");
    const n = L(r, d), o = () => new Intl.DateTimeFormat("sv-SE", { timeZone: e.timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date()), s = async () => {
      if (o() !== e.day) throw Error("\u63A5\u7BA1\u8DE8\u65E5\u505C\u6B62");
      if (await R(n, e), ((await r.state.get()).conversationControls || []).some((m) => m.accountKey === e.accountKey && m.mode === "paused" && [e.member.conversationKey, "boss-chat:" + e.member.firstMessageId].includes(m.conversationKey))) throw Error("\u672C\u4EBA\u5DF2\u624B\u52A8\u63A5\u7BA1");
    };
    await s();
    const i = await O(r, "account-outbound-safety-v1-" + e.accountKey + ".json", "boss-account-outbound-safety", e.accountKey), w = i.value.records.find((l) => l.type === "reply" && l.businessKey === e.member.parentKey);
    if (i.value.records.length >= 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u5BB9\u91CF\u5DF2\u6EE1");
    if (!w || k(w) !== e.member.parentRecordHash || !w.sightings.some((l) => l.status === "unknown")) throw Error("\u539Funknown\u6765\u6E90\u53D8\u5316");
    const f = A(["boss-unknown-reply-recovery-v1", e.accountKey, e.member.parentKey, e.member.originalIncomingMid].join(":"));
    if (i.value.records.some((l) => l.type === "reply" && (l.businessKey === f || l.parentBusinessKey === e.member.parentKey || l.incomingMessageId === e.latestIncomingMid && l.businessKey !== e.member.parentKey))) return { ...e, kind: "unknown-chat-review-dispatch", dispatched: false, readOnly: false, status: "review", reason: "\u5DF2\u6709\u5173\u8054\u63A5\u7BA1\u610F\u56FE\uFF0C\u4E0D\u91CD\u590D\u5916\u53D1" };
    const p = new Set(i.value.records.filter((l) => l.type === "reply" && l.sightings.some((m) => m.day === e.day && m.timeZone === e.timeZone && m.status !== "failed")).map((l) => l.businessKey));
    if (!Number.isSafeInteger(e.configuration.replyDailyLimit) || p.size >= e.configuration.replyDailyLimit) throw Error("\u5F53\u65E5\u56DE\u590D\u9884\u7B97\u4E0D\u8DB3");
    if (await n("count", "#chat-input") !== 1) throw Error("\u56DE\u590D\u8F93\u5165\u6846\u4E0D\u552F\u4E00");
    const F = String(await n("read", "#chat-input")).trim();
    if (F && F !== e.member.originalApprovedText && F !== e.reply) throw Error("\u5B58\u5728\u4E0D\u5C5E\u4E8E\u672C\u6B21\u6062\u590D\u7684\u624B\u5DE5\u8349\u7A3F\uFF0C\u4E0D\u8986\u76D6");
    if (!/按\s*Enter\s*键发送/u.test(String(await n("read", ".chat-conversation")))) throw Error("\u7F51\u7AD9\u672A\u786E\u8BA4Enter\u53D1\u9001\u6A21\u5F0F");
    await u("unknown-recovery-before-send-" + e.member.parentKey + ".json", JSON.stringify({ source: e, oldDraft: F, recoveryKey: f, authorization: e.authorization }));
    const y = await r.effect.prepare({ action: "reply", key: f, description: "\u8BFB\u53D6\u539Funknown\u5B8C\u6574\u804A\u5929\u540E\u7684AI\u63A5\u7BA1\uFF0C\u4EC5\u56DE\u590D\u4ECD\u672A\u56DE\u7B54\u7684\u95EE\u9898\u4E00\u6B21\uFF0C\u539Funknown\u4FDD\u7559\u3002", review: { version: 1, target: e.recipientLabel + `
\u6765\u4FE1 ` + e.latestIncomingMid + `
\u539Funknown ` + e.member.parentKey, content: e.reply } });
    if (!y.execute) return { ...e, kind: "unknown-chat-review-dispatch", dispatched: false, readOnly: false, status: "review", reason: "\u5173\u8054\u63A5\u7BA1\u526F\u4F5C\u7528\u5DF2\u5B58\u5728\uFF0C\u4E0D\u91CD\u53D1" };
    let h = false, g, a = null;
    const S = (l) => ({ contextId: e.contextId, intentKey: f, status: l, day: e.day, timeZone: e.timeZone, contentSha256: e.contentSha256, sourceSha256: e.messagesHash });
    try {
      if (await s(), await r.file("communication-cache", { operation: "read", name: i.name }) !== i.raw) throw Error("\u9884\u7559\u524D\u5B89\u5168\u7D22\u5F15\u53D8\u5316");
      g = { type: "reply", businessKey: f, jobId: w.jobId, conversationKey: w.conversationKey, incomingMessageId: e.latestIncomingMid, parentBusinessKey: e.member.parentKey, recoveryKind: "unknown-chat-ai-takeover", firstMessageId: e.member.firstMessageId, sightings: [S("reserved")] }, i.value.records.push(g), await C(r, i);
      const l = await M(r, e.accountKey), m = l.value.reviews.find((K) => K.key === e.member.key);
      if (!m || m.messagesHash !== e.messagesHash || m.contentSha256 !== e.contentSha256) throw Error("\u63A5\u7BA1\u8349\u7A3F\u6765\u6E90\u53D8\u5316");
      if (Object.assign(m, { status: "reserved", recoveryKey: f, effectId: y.id }), await C(r, l), await s(), await n("fill", "#chat-input", e.reply), await n("click", "#chat-input"), await s(), String(await n("read", "#chat-input")).trim() !== e.reply || await r.file("communication-cache", { operation: "read", name: i.name }) !== i.raw) throw Error("\u56DE\u8F66\u524D\u6B63\u6587\u6216\u9884\u7559\u53D8\u5316");
      const I = await Z(n, e.reply, async () => (await s(), true));
      if (await u("unknown-recovery-composer-ready.json", JSON.stringify(I)), await s(), String(await n("read", "#chat-input")).trim() !== e.reply || await r.file("communication-cache", { operation: "read", name: i.name }) !== i.raw) throw Error("\u56DE\u8F66\u524D\u6B63\u6587\u6216\u9884\u7559\u53D8\u5316");
      h = true, await n("press", "#chat-input", "Enter");
      let v;
      for (let K = 0; K < 18; K++) {
        await new Promise((B) => setTimeout(B, 250)), await R(n, e, false);
        const T = await J(n), x = T.filter((B) => !e.rows.some((P) => P.mid === B.mid) && B.direction === "outgoing" && B.text === e.reply);
        if (x.length > 1) throw Error("\u65B0\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
        if (x.length === 1 && /送达|已读/u.test(x[0].receipt || "") && String(await n("read", "#chat-input")).trim() === "") {
          v = x[0];
          break;
        }
      }
      if (!v) throw Error("\u6CA1\u6709\u53D6\u5F97\u540C\u4F1A\u8BDD\u65B0\u6D88\u606F\u9001\u8FBE\u56DE\u6267");
      a = v, await u("unknown-recovery-delivery-" + e.member.parentKey + ".json", JSON.stringify({ recoveryKey: f, parentKey: e.member.parentKey, receipt: v, model: e.model, contentSha256: e.contentSha256, originalUnknownPreserved: true })), await r.effect.resolve({ id: y.id, state: "confirmed", evidence: { kind: "boss-unknown-recovery-delivery", parentKey: e.member.parentKey, messageId: v.mid, receipt: v.receipt, contentSha256: e.contentSha256 } }), g.sightings.push(S("confirmed")), g.recoveryReceipt = { mid: v.mid, receipt: v.receipt }, await C(r, i);
      const b = await M(r, e.accountKey), N = b.value.reviews.find((K) => K.key === e.member.key);
      return Object.assign(N, { status: "confirmed-reply", recoveryKey: f, effectId: y.id, receipt: v, completedAt: (/* @__PURE__ */ new Date()).toISOString() }), await C(r, b), { ...e, kind: "unknown-chat-review-dispatch", dispatched: true, readOnly: false, status: "confirmed-reply", recoveryKey: f, receipt: v };
    } catch (l) {
      const m = a ? "confirmed" : h ? "unknown" : "failed";
      try {
        await r.effect.resolve({ id: y.id, state: m, evidence: { kind: a ? "boss-unknown-recovery-delivery" : "boss-unknown-recovery-not-confirmed", receipt: a, parentKey: e.member.parentKey, attempted: h, reason: String(l.message || l) } });
      } catch {
      }
      g && (g.sightings.some((b) => b.status === m) || g.sightings.push(S(m)), a && (g.recoveryReceipt = a), await C(r, i));
      const I = await M(r, e.accountKey), v = I.value.reviews.find((b) => b.key === e.member.key);
      throw Object.assign(v, { status: a ? "confirmed-reply" : h ? "unknown-recovery" : "failed-recovery", recoveryKey: f, reason: String(l.message || l) }), await C(r, I), l;
    }
  };
})();
async function V(D) {
  return D.input?.unknownRecovery ? H(D) : U(D);
}
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default = (ctx) => V(Object.freeze({ ...ctx, constants }));
export {
  stdin_default as default
};
