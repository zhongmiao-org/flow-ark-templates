import { createHash } from "node:crypto";
var cursorCanonical = (value) => Array.isArray(value) ? value.map(cursorCanonical) : value && typeof value === "object" ? Object.fromEntries(Object.keys(value).sort().map((key) => [key, cursorCanonical(value[key])])) : value;
var cursorDigest = (value) => createHash("sha256").update(JSON.stringify(cursorCanonical(value))).digest("hex");
async function openIncrementalCursor(template, signal, scope) {
  const fields = ["accountKey", "contextId", "configurationRevision", "day", "timeZone", "searchUrl"];
  if (!scope || fields.some((key) => scope[key] === void 0) || !/^[a-f0-9]{64}$/.test(scope.accountKey) || !scope.contextId || !Number.isSafeInteger(scope.configurationRevision) || !/^\d{4}-\d{2}-\d{2}$/.test(scope.day)) throw Error("\u589E\u91CF\u4F4D\u7F6E\u7F3A\u5C11\u56FA\u5B9A\u8303\u56F4");
  const u = new URL(scope.searchUrl);
  if (u.origin !== "https://www.zhipin.com" || u.pathname !== "/web/geek/jobs" || u.username || u.password || u.hash || !u.searchParams.get("query")) throw Error("\u589E\u91CF\u68C0\u7D22\u6765\u6E90\u65E0\u6548");
  const name = "single-job-list-v1-" + scope.accountKey + "-" + cursorDigest(scope).slice(0, 32) + ".json";
  let original = null, data;
  try {
    original = await template.file("communication-cache", { operation: "read", name });
  } catch (error) {
    if (!String(error.message || error).includes("ENOENT")) throw error;
  }
  if (original !== null) {
    data = JSON.parse(original);
    const { sha256, ...body } = data;
    if (sha256 !== cursorDigest(body) || data.version !== 1 || data.kind !== "boss-single-job-list-cursor" || fields.some((key) => data[key] !== scope[key]) || !Number.isSafeInteger(data.revision) || data.revision < 0 || !Number.isSafeInteger(data.through) || data.through < 0 || !Number.isSafeInteger(data.listCount) || data.listCount < data.through || data.listCount > 500 || data.through > 0 && typeof data.throughId !== "string" || typeof data.exhausted !== "boolean") throw Error("\u5DF2\u4FDD\u5B58\u7684\u589E\u91CF\u4F4D\u7F6E\u8EAB\u4EFD\u3001\u6458\u8981\u6216\u7ED3\u6784\u65E0\u6548\uFF1B\u672A\u6E05\u7A7A\u91CD\u5EFA");
  } else data = { version: 1, kind: "boss-single-job-list-cursor", ...scope, revision: 0, through: 0, throughId: null, listCount: 0, firstId: null, tailId: null, exhausted: false, lastLoad: null };
  const plan = (patch) => {
    const next = { ...data, ...patch, revision: data.revision + 1 };
    delete next.sha256;
    next.sha256 = cursorDigest(next);
    return { version: 1, name, scope, beforeSha256: original === null ? null : createHash("sha256").update(original).digest("hex"), value: next };
  };
  const save = async (update) => {
    signal.throwIfAborted();
    if (!update || update.name !== name || cursorDigest(update.scope) !== cursorDigest(scope) || update.beforeSha256 !== (original === null ? null : createHash("sha256").update(original).digest("hex"))) throw Error("\u589E\u91CF\u4F4D\u7F6E\u5199\u5165\u8BA1\u5212\u6765\u6E90\u4E0D\u7B26");
    const { sha256, ...body } = update.value;
    if (sha256 !== cursorDigest(body) || body.revision !== data.revision + 1) throw Error("\u589E\u91CF\u4F4D\u7F6E\u5199\u5165\u8BA1\u5212\u6458\u8981\u6216\u4FEE\u8BA2\u4E0D\u7B26");
    let before = null;
    try {
      before = await template.file("communication-cache", { operation: "read", name });
    } catch (error) {
      if (!String(error.message || error).includes("ENOENT")) throw error;
    }
    if (before !== original) throw Error("\u589E\u91CF\u4F4D\u7F6E\u5DF2\u88AB\u5176\u4ED6\u64CD\u4F5C\u4FEE\u6539\uFF0C\u505C\u6B62\u8986\u76D6");
    const content = JSON.stringify(update.value);
    await template.file("communication-cache", { operation: "write", name, content });
    if (await template.file("communication-cache", { operation: "read", name }) !== content) throw Error("\u589E\u91CF\u4F4D\u7F6E\u4FDD\u5B58\u540E\u672A\u5B8C\u6574\u8BFB\u56DE");
    data = update.value;
    original = content;
    return { name, revision: data.revision, through: data.through, listCount: data.listCount, sha256: data.sha256 };
  };
  return { name, get data() {
    return data;
  }, plan, save };
}
var stdin_default = async ({ input, signal, template }) => {
  signal.throwIfAborted();
  const obj = (v) => !!v && typeof v === "object" && !Array.isArray(v), hash = (v) => createHash("sha256").update(JSON.stringify(v)).digest("hex");
  if (!obj(input) || Object.keys(input).sort().join(",") !== "plan,receipt,state") throw Error("\u7F3A\u5C11\u961F\u5217\u8BA1\u5212\u3001\u5199\u5165\u56DE\u6267\u6216\u5199\u540E\u6700\u65B0\u72B6\u6001");
  const { plan: p, receipt: w, state: s } = input;
  if (!obj(p) || p.version !== 1 || p.kind !== "daily-candidate-queue-plan" || p.eligibleForActions !== false || p.dayTaskComplete !== false || p.siteDailyLimitConfirmed !== false || !Number.isSafeInteger(p.expectedRevision) || p.expectedRevision < 0 || !obj(p.value) || !Array.isArray(p.value.queueEntries) || !Array.isArray(p.items) || p.items.length > 150) throw Error("\u5B8C\u6574\u961F\u5217\u8BA1\u5212\u6765\u6E90\u65E0\u6548");
  if (!obj(w) || w.version !== 1 || w.operation !== "state.write" || w.contextId !== p.contextId || w.previousRevision !== p.expectedRevision || w.revision !== p.expectedRevision + 1 || typeof w.operationId !== "string" || !/^[a-f0-9]{64}$/.test(w.operationId) || typeof w.committedAt !== "string" || !Number.isFinite(Date.parse(w.committedAt)) || Date.parse(w.committedAt) > Date.now() || hash(w.value) !== hash(p.value)) throw Error("\u961F\u5217\u5199\u5165\u56DE\u6267\u672A\u8BC1\u660E\u51C6\u786E\u5B8C\u6574\u503C\u4E0E\u9884\u671F\u4FEE\u8BA2\u5DF2\u63D0\u4EA4");
  if (!obj(s) || s.version !== 1 || s.operation !== "state.read" || s.contextId !== p.contextId || s.revision !== w.revision || hash(s.value) !== hash(w.value)) throw Error("\u961F\u5217\u5199\u540E\u91CD\u8BFB\u4E0E\u5199\u5165\u56DE\u6267\u4E0D\u4E00\u81F4\uFF0C\u505C\u6B62\u6D88\u8D39");
  const day = new Intl.DateTimeFormat("sv-SE", { timeZone: p.timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
  if (day !== p.configuredDay) throw Error("\u961F\u5217\u4FDD\u5B58\u671F\u95F4\u65E5\u671F\u5DF2\u7ECF\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
  const seen = /* @__PURE__ */ new Set();
  for (const item of p.items) {
    const stored = s.value.queueEntries.find((r) => r.key === item.key);
    if (!stored || stored.status !== "queued" || stored.accountSourceSha256 !== p.accountSourceSha256 || stored.configurationRevision !== p.configurationRevision || stored.day !== day || stored.timeZone !== p.timeZone || hash(stored) !== hash(item) || seen.has(item.key)) throw Error("\u6240\u9009\u6709\u9650\u5019\u9009\u4E0E\u5B9E\u9645\u6301\u4E45\u961F\u5217\u4E0D\u4E00\u81F4");
    seen.add(item.key);
  }
  signal.throwIfAborted();
  if (typeof p.currentSearchUrl !== "string") throw Error("\u672C\u6279\u5B9E\u9645\u5217\u8868\u5730\u5740\u7F3A\u5931");
  const currentList = new URL(p.currentSearchUrl);
  if (currentList.origin !== "https://www.zhipin.com" || currentList.pathname !== "/web/geek/jobs" || currentList.username || currentList.password || currentList.hash) throw Error("\u672C\u6279\u5B9E\u9645\u5217\u8868\u5730\u5740\u65E0\u6548");
  if (!p.cursorUpdate) throw Error("\u7F3A\u5C11\u4E0E\u5DF2\u63D0\u4EA4\u961F\u5217\u5BF9\u5E94\u7684\u589E\u91CF\u4F4D\u7F6E\u8BA1\u5212");
  const cursor = await openIncrementalCursor(template, signal, p.cursorUpdate.scope);
  const cursorReceipt = await cursor.save(p.cursorUpdate);
  return { version: 1, kind: "daily-candidate-queue-range", contextId: p.contextId, configurationRevision: p.configurationRevision, configuredDay: day, timeZone: p.timeZone, actualCity: p.actualCity, currentSearchUrl: p.currentSearchUrl, accountSourceSha256: p.accountSourceSha256, stateRevision: s.revision, operationId: w.operationId, items: p.items, newlyAdded: p.newlyAdded, cursorReceipt, scanned: p.scanned, pending: p.pending, knownGreetingsUsedToday: p.knownGreetingsUsedToday, identityVerified: false, descriptionVerified: false, accountVerified: false, eligibleForActions: false, dayTaskComplete: false, siteDailyLimitConfirmed: false };
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default2 = (ctx) => stdin_default(Object.freeze({ ...ctx, constants }));
export {
  stdin_default2 as default
};
