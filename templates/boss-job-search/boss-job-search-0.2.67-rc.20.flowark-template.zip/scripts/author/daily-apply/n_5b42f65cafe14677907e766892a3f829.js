import { createHash } from "node:crypto";
import { setTimeout as pause } from "node:timers/promises";
var PANEL = Object.freeze({ title: "head > title", jobTitle: ".job-detail-container .job-name", jobCity: ".job-header-info .tag-list > :nth-child(1)", companyLabel: ".job-boss-info > :nth-child(2) > :nth-child(2)", description: ".job-detail-body > .desc", salary: ".job-detail-container .job-salary", closedStatus: ".job-detail-container .job-close", contact: ".job-detail-container div:nth-of-type(2) > a:nth-of-type(2)" });
var stdin_default = async ({ template, signal }) => {
  await pause(300, void 0, { signal });
  let lastObserved = null;
  for (let sample = 1; sample <= 40; sample++) {
    signal.throwIfAborted();
    const count = await template.browser("browser", { operation: "count", selector: ".job-card-wrap.active", timeoutMs: 2e3 });
    const button = await template.browser("browser", { operation: "count", selector: PANEL.contact, timeoutMs: 2e3 });
    lastObserved = { selectedCards: count, contactButtons: button };
    if (sample >= 2 && Number.isSafeInteger(count) && count >= 1 && count <= 500 && button === 1) return { kind: "selected-card-contact-ready", aiCalled: false, eligibleForActions: false };
    const body = String(await template.browser("browser", { operation: "read", selector: "body", timeoutMs: 2e3 }));
    if (body.split(/\r?\n/u).some((v) => v.trim() === "\u804C\u4F4D\u5DF2\u5173\u95ED")) return { kind: "selected-card-closed", aiCalled: false, eligibleForActions: false };
    await pause(250, void 0, { signal });
  }
  throw Error("\u9009\u4E2D\u6001\u6216\u6C9F\u901A\u5165\u53E3\u5728\u6709\u9650\u7B49\u5F85\u5185\u672A\u5C31\u7EEA: " + JSON.stringify(lastObserved));
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default2 = (ctx) => stdin_default(Object.freeze({ ...ctx, constants }));
export {
  stdin_default2 as default
};
