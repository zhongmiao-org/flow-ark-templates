import { createHash } from "node:crypto";
var PANEL = Object.freeze({ title: "head > title", jobTitle: ".job-detail-container .job-name", jobCity: ".job-header-info .tag-list > :nth-child(1)", companyLabel: ".job-boss-info > :nth-child(2) > :nth-child(2)", description: ".job-detail-body > .desc", salary: ".job-detail-container .job-salary", closedStatus: ".job-detail-container .job-close", contact: ".job-detail-container div:nth-of-type(2) > a:nth-of-type(2)" });
var directMode = "salary-and-selected-ui";
var stdin_default = async ({ input, signal }) => {
  signal.throwIfAborted();
  const p = input;
  if (p?.kind !== "direct-first-contact-prepared" || p.ready !== true || p.evaluationMode !== directMode || p.aiCalled !== false || p.source?.kind !== "selected-card-salary-source" || p.source.selectedSource?.selected !== true) throw Error("\u7F3A\u5C11\u76F4\u63A5\u62DB\u547C\u7684\u85AA\u8D44\u53CA\u9009\u4E2D\u6765\u6E90");
  return { version: 1, kind: "direct-contact-rule-result", aiCalled: false, result: { version: 1, kind: "direct-salary-selection-decision", evaluationMode: directMode, decision: "match", source: p.source, issues: [], aiCalled: false, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), reason: "\u4F7F\u7528\u8005\u5DF2\u9009\u62E9\uFF1A\u5217\u8868\u85AA\u8D44\u6709\u4EA4\u96C6\u4E14\u5C97\u4F4D\u9009\u4E2D\u5373\u9996\u6B21\u6C9F\u901A\uFF0C\u4E0D\u4F5CJD\u3001\u516C\u53F8\u6216AI\u5339\u914D", accountVerified: false, eligibleForActions: false } };
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default2 = (ctx) => stdin_default(Object.freeze({ ...ctx, constants }));
export {
  stdin_default2 as default
};
