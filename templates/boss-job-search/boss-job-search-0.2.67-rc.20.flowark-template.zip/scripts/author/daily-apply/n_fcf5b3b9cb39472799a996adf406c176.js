import { createHash } from "node:crypto";
var PANEL = Object.freeze({ title: "head > title", jobTitle: ".job-detail-container .job-name", jobCity: ".job-header-info .tag-list > :nth-child(1)", companyLabel: ".job-boss-info > :nth-child(2) > :nth-child(2)", description: ".job-detail-body > .desc", salary: ".job-detail-container .job-salary", closedStatus: ".job-detail-container .job-close", contact: ".job-detail-container div:nth-of-type(2) > a:nth-of-type(2)" });
var directMode = "salary-and-selected-ui";
var directDay = (zone) => new Intl.DateTimeFormat("sv-SE", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
var stdin_default = async ({ input, signal }) => {
  signal.throwIfAborted();
  const c = input?.candidate, h = input?.hardConditions, l = input?.ledger, raw = input?.configuration, q = raw?.value;
  if (c?.kind !== "daily-verified-selected-candidate" || h?.evaluationMode !== directMode || h.readyForFirstContact !== true || l?.status !== "ledger-ready-for-skill" || l.readyForSkillAssessment !== true || l.existingIntent !== null || l.issues?.length || raw?.operation !== "configuration" || raw.contextId !== l.contextId || raw.revision !== h.configurationRevision || c.jobSource !== h.jobSource || h.jobSource !== l.jobSource || directDay(c.timeZone) !== c.configuredDay) throw Error("\u85AA\u8D44\u3001\u9009\u4E2D\u6001\u6216\u5916\u53D1\u53BB\u91CD\u672A\u901A\u8FC7");
  const source = { kind: "selected-card-salary-source", mode: directMode, contextId: raw.contextId, configurationRevision: raw.revision, applicationKey: l.key, accountSourceSha256: l.accountSourceSha256, jobSource: c.jobSource, title: c.jobTitle, actualCity: c.actualCity, listSource: c.returnUrl, sourceMode: "persisted-job-link-in-list", day: c.configuredDay, timeZone: c.timeZone, salaryRaw: c.salaryRaw, salaryMin: q.salaryMin, salaryMax: q.salaryMax, selectedSource: c };
  return { version: 1, kind: "direct-first-contact-prepared", ready: true, evaluationMode: directMode, aiCalled: false, source, job: { title: c.jobTitle, city: c.actualCity, sourceLabel: c.jobSource, salaryRaw: c.salaryRaw, company: null, description: null }, configuration: q, resume: { status: input.resume?.status, source: input.resume?.source }, eligibleForActions: false };
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default2 = (ctx) => stdin_default(Object.freeze({ ...ctx, constants }));
export {
  stdin_default2 as default
};
