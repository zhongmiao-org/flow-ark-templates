import { createHash } from "node:crypto";
var PANEL = Object.freeze({ title: "head > title", jobTitle: ".job-detail-container .job-name", jobCity: ".job-header-info .tag-list > :nth-child(1)", companyLabel: ".job-boss-info > :nth-child(2) > :nth-child(2)", description: ".job-detail-body > .desc", salary: ".job-detail-container .job-salary", closedStatus: ".job-detail-container", contact: ".job-detail-container div:nth-of-type(2) > a:nth-of-type(2)" });
var panelClean = (v) => String(v).replace(/\s+/gu, " ").trim();
function panelJobIdentity(source) {
  const u = new URL(source), m = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(u.pathname);
  if (u.origin !== "https://www.zhipin.com" || u.username || u.password || u.search || u.hash || !m) throw Error("\u5C97\u4F4D\u5B8C\u6574\u94FE\u63A5\u65E0\u6548");
  const hrefs = [u.pathname, u.href].flatMap((v) => ['[href="' + v + '"]', '[href^="' + v + '?"]']).join(",");
  const relative = "> div:nth-of-type(1) > div > a:is(" + hrefs + ")";
  return { jobId: m[1], cardSelector: ".job-card-box:has(" + relative + ")", linkSelector: ".job-card-box " + relative };
}
var stdin_default = async ({ input, signal, template }) => {
  signal.throwIfAborted();
  const obj = (v) => !!v && typeof v === "object" && !Array.isArray(v), hash = (v) => createHash("sha256").update(JSON.stringify(v)).digest("hex");
  if (!obj(input) || Object.keys(input).sort().join(",") !== "plan,receipt,state") throw Error("\u7F3A\u5C11\u672C\u9879\u5904\u7406\u8BA1\u5212\u3001\u5199\u56DE\u6267\u6216\u5199\u540E\u72B6\u6001");
  const { plan: p, receipt: w, state: s } = input;
  if (p?.version !== 1 || p.kind !== "daily-queue-start-plan" || p.eligibleForActions !== false || p.dayTaskComplete !== false || !obj(p.value) || !obj(p.entry) || p.entry.status !== "processing" || !obj(p.detail) || p.detail.queueKey !== p.entry.key || p.detail.jobSource !== p.entry.jobSource || !Number.isSafeInteger(p.expectedRevision)) throw Error("\u672C\u9879\u5F00\u59CB\u8BA1\u5212\u6765\u6E90\u4E0D\u4E00\u81F4");
  if (w?.version !== 1 || w.operation !== "state.write" || w.contextId !== p.contextId || w.previousRevision !== p.expectedRevision || w.revision !== p.expectedRevision + 1 || typeof w.operationId !== "string" || !/^[a-f0-9]{64}$/.test(w.operationId) || typeof w.committedAt !== "string" || !Number.isFinite(Date.parse(w.committedAt)) || Date.parse(w.committedAt) > Date.now() || hash(w.value) !== hash(p.value)) throw Error("\u672C\u9879\u5904\u7406\u4E2D\u72B6\u6001\u6CA1\u6709\u51C6\u786E\u5199\u5165\u56DE\u6267\uFF0C\u4E0D\u80FD\u6253\u5F00\u540E\u7EED\u8BE6\u60C5");
  if (s?.version !== 1 || s.operation !== "state.read" || s.contextId !== p.contextId || s.revision !== w.revision || hash(s.value) !== hash(w.value) || s.value.queueEntries.filter((v) => v.key === p.entry.key).length !== 1 || hash(s.value.queueEntries.find((v) => v.key === p.entry.key)) !== hash(p.entry)) throw Error("\u5904\u7406\u72B6\u6001\u5199\u540E\u91CD\u8BFB\u4E0D\u4E00\u81F4");
  const day = new Intl.DateTimeFormat("sv-SE", { timeZone: p.entry.timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
  if (day !== p.entry.day) throw Error("\u4FDD\u5B58\u671F\u95F4\u5DF2\u8DE8\u5929\uFF0C\u505C\u6B62\u672C\u9879");
  signal.throwIfAborted();
  const identity = panelJobIdentity(p.entry.jobSource);
  const read = async (operation, selector, value) => {
    signal.throwIfAborted();
    return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
  };
  const page = await read("url");
  if (page !== p.detail.returnUrl) throw Error("\u70B9\u51FB\u524D\u5217\u8868\u9875\u9762\u53D8\u5316\uFF0C\u672A\u5916\u53D1");
  const matchingCards = await read("count", identity.cardSelector), matchingLinks = await read("count", identity.linkSelector);
  if (matchingCards !== 1 || matchingLinks !== 1) {
    const cards = "div > div:nth-of-type(1) > li", count = await read("count", cards);
    if (!Number.isSafeInteger(count) || count < 1 || count > 500) throw Error("\u5C97\u4F4D\u5217\u8868\u6570\u91CF\u65E0\u6548");
    let chosen = null;
    for (let position = 1; position <= count; position++) {
      const card = "div:nth-of-type(" + position + ") > div:nth-of-type(1) > li:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1)";
      const link = card + " > a:nth-of-type(1)";
      const href2 = new URL(await read("attribute", link, "href"), page);
      if (href2.origin + href2.pathname === p.entry.jobSource) {
        chosen = { card, link };
        break;
      }
    }
    if (!chosen || await read("count", chosen.card) !== 1 || await read("count", chosen.link) !== 1 || await read("url") !== page) throw Error("\u672C\u9879\u5C97\u4F4D\u4E0D\u5728\u5F53\u524D\u5DF2\u52A0\u8F7D\u5217\u8868\u4E2D\uFF0C\u672A\u5916\u53D1");
    identity.cardSelector = chosen.card;
    identity.linkSelector = chosen.link;
  }
  const href = await read("attribute", identity.linkSelector, "href"), title = await read("read", identity.linkSelector), cardText = await read("read", identity.cardSelector);
  const salarySelector = identity.cardSelector + " .job-salary";
  if (await read("count", salarySelector) !== 1) throw Error("\u5DE6\u4FA7\u85AA\u8D44\u76EE\u6807\u4E0D\u552F\u4E00");
  const leftSalaryRaw = String(await read("read", salarySelector)).trim();
  const actual = new URL(href, page);
  if (actual.origin + actual.pathname !== p.entry.jobSource || panelClean(title) !== panelClean(p.entry.jobTitle) || typeof cardText !== "string" || !cardText.trim() || cardText.length > 4e3 || await read("url") !== page || await read("attribute", identity.linkSelector, "href") !== href) throw Error("\u70B9\u51FB\u524D\u5361\u7247\u6765\u6E90\u53D8\u5316");
  return { ...p.detail, kind: "daily-list-panel-precheck", readyToNavigate: false, selector: identity.cardSelector, leftLinkSelector: identity.linkSelector, leftCardText: cardText, leftSalaryRaw, leftLinkHref: href, leftCheckedAt: (/* @__PURE__ */ new Date()).toISOString(), sourceMode: "persisted-job-link-in-list", processingContextId: p.contextId, processingStateRevision: s.revision, processingOperationId: w.operationId, processingPersisted: true };
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default2 = (ctx) => stdin_default(Object.freeze({ ...ctx, constants }));
export {
  stdin_default2 as default
};
