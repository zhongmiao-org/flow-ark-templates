import { randomUUID } from "node:crypto";
var stdin_default = async ({ signal }) => {
  signal.throwIfAborted();
  return { version: 1, batchId: randomUUID(), createdAt: (/* @__PURE__ */ new Date()).toISOString() };
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default2 = (ctx) => stdin_default(Object.freeze({ ...ctx, constants }));
export {
  stdin_default2 as default
};
