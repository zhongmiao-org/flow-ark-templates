import { createHash as n } from "node:crypto";
var l = async ({ input: e, signal: r, template: a }) => {
  if (r.throwIfAborted(), e?.version === 1 && e.kind === "daily-apply-configuration" && e.closingPhase === true && e.readyForLoop === false) return { version: 1, kind: "daily-apply", status: "unread-closing-priority", newGreeting: false, dayTaskComplete: false, siteDailyLimitConfirmed: e.siteDailyLimitConfirmed === true && e.closingTrigger === "real-site-daily-limit", testCompletionConfirmed: e.testCompletionConfirmed === true, unknownRecovery: e.unknownRecovery === true, reason: "\u672C\u6279\u4F18\u5148\u6062\u590D\u56FA\u5B9A\u6D88\u606F\u6536\u5C3E\uFF0C\u6CA1\u6709\u91CD\u65B0\u51C6\u5907\u6295\u9012" };
  if (!e || e.version !== 1 || e.kind !== "daily-apply-configuration" || e.readyForLoop !== false || !Number.isSafeInteger(e.configurationRevision) || !Array.isArray(e.issues) || !e.issues.length || e.dayTaskComplete !== false) throw Error("\u7F3A\u5C11\u672C\u6B21\u672A\u51C6\u5907\u7684\u56FA\u5B9A\u914D\u7F6E\u7ED3\u679C");
  const o = e.issues.map((u) => {
    if (!u || typeof u.field != "string" || typeof u.reason != "string") throw Error("\u672A\u51C6\u5907\u539F\u56E0\u65E0\u6548");
    return { field: u.field, reason: u.reason };
  }), i = { version: 1, kind: "daily-apply", status: "needs-configuration", dayTaskComplete: false, siteDailyLimitConfirmed: false, configurationRevision: e.configurationRevision, dailyTarget: 150, userDailyLimit: e.userDailyLimit, reasons: o, accountVerified: false, eligibleForActions: false, nextAction: "configure-and-review", note: "\u5F53\u5929\u6295\u9012\u672A\u5B8C\u6210\uFF1B\u5148\u8865\u9F50\u7528\u6237\u914D\u7F6E\u53CA\u7AD9\u70B9\u6821\u51C6\u3002\u6CA1\u6709\u6295\u9012\u3001\u6A21\u578B\u8BF7\u6C42\u6216\u7F51\u7AD9\u4E0A\u9650\u5B8C\u6210\u8BC1\u660E\u3002", checkedAt: (/* @__PURE__ */ new Date()).toISOString() }, s = "daily-apply-preparation:" + n("sha256").update(JSON.stringify({ revision: e.configurationRevision, reasons: o })).digest("hex"), t = await a.attention({ key: s, title: "\u6BCF\u65E5\u6295\u9012\u5C1A\u672A\u5F00\u59CB\uFF0C\u9700\u8981\u8865\u9F50\u914D\u7F6E", detail: i });
  return r.throwIfAborted(), await Promise.resolve(i), { result: i, attention: t };
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default = (ctx) => l(Object.freeze({ ...ctx, constants }));
export {
  stdin_default as default
};
