import { createHash as b } from "node:crypto";
var N = /* @__PURE__ */ (() => {
  const m = (r) => Array.isArray(r) ? r.map(m) : r && typeof r == "object" ? Object.fromEntries(Object.keys(r).sort().map((e) => [e, m(r[e])])) : r, h = (r) => b("sha256").update(JSON.stringify(m(r))).digest("hex");
  async function O(r, e, t, s, i = false) {
    const u = "account-outbound-safety-v1-" + t + ".json";
    let n, o = true, a;
    try {
      a = await r.file("communication-cache", { operation: "read", name: u }), n = JSON.parse(a);
    } catch (c) {
      if (!String(c.message || c).includes("ENOENT")) throw c;
      if (!i) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
      o = false, n = { version: 1, kind: "boss-account-outbound-safety", accountKey: t, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    }
    if (o) {
      const { sha256: c, ...f } = n;
      if (c !== h(f)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
    }
    if (n.version !== 1 || n.kind !== "boss-account-outbound-safety" || n.accountKey !== t || !Number.isSafeInteger(n.revision) || n.revision < 0 || !Array.isArray(n.records) || n.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
    const l = /* @__PURE__ */ new Set();
    for (const c of n.records) {
      if (!["first-contact", "reply"].includes(c.type) || !/^[a-f0-9]{64}$/.test(c.businessKey) || !Array.isArray(c.sightings) || !c.sightings.length || c.sightings.length > 100 || l.has(c.type + ":" + c.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
      l.add(c.type + ":" + c.businessKey);
      for (const f of c.sightings) if (typeof f.contextId != "string" || !f.contextId || !/^[a-f0-9]{64}$/.test(f.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(f.status) || !/^\d{4}-\d{2}-\d{2}$/.test(f.day) || typeof f.timeZone != "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
    }
    let w = !o;
    return { data: n, name: u, merge: (c) => {
      if (!Array.isArray(c?.applicationIntents) || !Array.isArray(c?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
      for (const [f, g] of [["first-contact", c.applicationIntents], ["reply", c.replyIntents]]) for (const d of g) {
        if ((f === "first-contact" ? d.accountSourceSha256 : d.accountKey) !== t) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
        if (!/^[a-f0-9]{64}$/.test(d.key) || !d.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(d.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
        const p = f === "first-contact" ? h(["boss-job-safety-v1", t, d.jobId]) : b("sha256").update(["boss-text-reply-v1", t, d.incomingMessageId].join(":")).digest("hex");
        let y = n.records.find((B) => B.type === f && B.businessKey === p);
        if (y || (y = { type: f, businessKey: p, jobId: d.jobId, ...f === "reply" ? { conversationKey: d.conversationKey, incomingMessageId: d.incomingMessageId } : {}, sightings: [] }, n.records.push(y), w = true), y.jobId !== d.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
        const I = { contextId: s, intentKey: d.key, status: d.status, day: d.day, timeZone: d.timeZone, contentSha256: d.contentSha256 || null, sourceSha256: d.sourceSha256 || null };
        if (y.sightings.some((B) => JSON.stringify(m(B)) === JSON.stringify(m(I))) || (y.sightings.push(I), w = true), y.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
      }
      if (n.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
    }, save: async () => {
      if (e.throwIfAborted(), w) {
        if (o && await r.file("communication-cache", { operation: "read", name: u }) !== a) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
        n.records.sort((d, p) => (d.type + ":" + d.businessKey).localeCompare(p.type + ":" + p.businessKey));
        for (const d of n.records) d.sightings.sort((p, y) => JSON.stringify(m(p)).localeCompare(JSON.stringify(m(y))));
        n.revision++, n.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete n.sha256, n.sha256 = h(n), await r.file("communication-cache", { operation: "write", name: u, content: JSON.stringify(n) }), w = false, a = JSON.stringify(n), o = true;
      }
      const c = JSON.parse(await r.file("communication-cache", { operation: "read", name: u })), { sha256: f, ...g } = c;
      if (f !== h(g) || f !== n.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
      return { revision: n.revision, sha256: n.sha256, records: n.records.length };
    }, blocked: (c, f) => n.records.some((g) => g.type === c && g.businessKey === f) };
  }
  const C = (r, e) => async (t, s, i) => (e.throwIfAborted(), r.browser("browser", { operation: t, ...s ? { selector: s } : {}, ...i === void 0 ? {} : { value: i }, timeoutMs: 3e3 })), D = (r) => {
    const { sha256: e, ...t } = r;
    return e === h(t);
  };
  async function v(r, e, t, s) {
    const i = t.progressName, u = await r.file("communication-cache", { operation: "read", name: i }), n = JSON.parse(u);
    if (!D(n) || n.accountKey !== t.accountKey || n.fixedUnreadSetSha256 !== t.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
    if (!s) return n;
    const o = s(structuredClone(n));
    if (o.revision++, o.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete o.sha256, o.sha256 = h(o), await r.file("communication-cache", { operation: "read", name: i }) !== u) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
    e.throwIfAborted(), await r.file("communication-cache", { operation: "write", name: i, content: JSON.stringify(o) });
    const a = JSON.parse(await r.file("communication-cache", { operation: "read", name: i }));
    if (!D(a) || a.sha256 !== o.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
    return a;
  }
  async function A(r) {
    const e = await r("count", "li.message-item");
    if (!Number.isSafeInteger(e) || e < 1 || e > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
    const t = [];
    for (let s = 1; s <= e; s++) {
      const i = "li.message-item:nth-child(" + s + " of li.message-item)", u = await r("attribute", i, "data-mid"), n = await r("attribute", i, "class");
      if (!/^\d{6,40}$/.test(u || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
      const o = await r("count", i + " .text-content");
      if (o > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
      const a = o === 1 ? String(await r("read", i + " .text-content")).trim() : null, l = a === null ? String(await r("read", i)).trim() : null;
      if ((a || l || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
      const w = !!a && /^您正在与Boss.+沟通$/u.test(a), F = !w && a !== null && n.split(/\s+/u).includes("item-myself") ? "outgoing" : !w && a !== null && n.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
      t.push({ mid: u, direction: F, text: a, context: l });
    }
    if (new Set(t.map((s) => s.mid)).size !== t.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
    return t;
  }
  async function S(r, e) {
    const t = new URL(await r("url"));
    if (t.origin !== "https://www.zhipin.com" || t.pathname !== "/web/geek/chat" || await r("count", ".chat-conversation .user-info") !== 1 || await r("count", ".friend-content.selected") !== 1) return false;
    const s = String(await r("read", ".chat-conversation .user-info")).trim(), i = String(await r("read", ".friend-content.selected")).trim(), u = (n) => n.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
    return u(s) === u(e.member.identityLine) && i.split(/\r?\n/u).map((n) => n.trim()).includes(e.member.identityLine);
  }
  async function x(r, e, t) {
    const s = C(r, e);
    return await S(s, t) ? String(await s("read", t.accountSelector)).trim() === t.accountLabel && String(await s("read", t.recipientSelector)).trim() === t.recipientLabel && String(await s("read", t.jobSelector)).trim() === t.chatJobTitle && JSON.stringify(await A(s)) === JSON.stringify(t.rows) : false;
  }
  var k = async ({ input: r, template: e, signal: t, artifact: s }) => {
    if (r?.kind !== "unread-closing-cohort") throw Error("\u7F3A\u5C11\u56FA\u5B9A\u6536\u5C3E\u6765\u6E90");
    if (r.closingPhase === false) return { version: 1, kind: "fixed-unread-closing-summary", closingPhase: false, siteDailyLimitConfirmed: false, newGreeting: false, memberCount: 0, remaining: 0, dayTaskComplete: false, decision: "continue", reason: "\u5C1A\u65E0\u771F\u5B9E\u7F51\u7AD9\u4E0A\u9650\u8BC1\u636E\uFF0C\u672C\u6279\u4E0D\u8BFB\u53D6\u4F1A\u8BDD" };
    const i = await v(e, t, r), u = i.completed.filter((l) => l.status === "confirmed"), n = i.completed.filter((l) => l.status === "review"), o = r.memberCount - i.completed.length, a = { version: 1, kind: "fixed-unread-closing-summary", siteDailyLimitConfirmed: r.siteDailyLimitEvidence?.confirmed === true, testCompletionConfirmed: r.testCompletionEvidence?.confirmed === true, newGreeting: false, newMembersAdded: 0, fixedUnreadSetSha256: r.fixedUnreadSetSha256, memberCount: r.memberCount, originalUnreadMessageCount: r.unreadMessageCount, confirmedReplies: u.length, skipped: i.completed.length - u.length - n.length, needsReview: n.length, remaining: o, activeMember: i.active?.memberKey || null, completed: i.completed, progressSha256: i.sha256, dayTaskComplete: o === 0, decision: o ? "review" : "complete", progress: r.fixedUnreadSetSha256 + ":" + i.completed.length, reason: o ? "\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u5C1A\u6709\u672A\u5B8C\u6210\u6210\u5458\uFF0C\u91CD\u5F00\u540E\u4ECE\u6D3B\u8DC3\u4F1A\u8BDD\u6062\u590D" : "\u56FA\u5B9A\u672A\u8BFB\u4F1A\u8BDD\u96C6\u5408\u5904\u7406\u5B8C\u6BD5\uFF1B\u4E4B\u540E\u65B0\u5230\u7684\u5176\u4ED6\u4F1A\u8BDD\u672A\u52A0\u5165\u672C\u8F6E" };
    return await s("fixed-unread-closing-summary.json", JSON.stringify(a, null, 2)), await e.result(a), a;
  };
  return k;
})();
var j = /* @__PURE__ */ (() => {
  const m = (e) => Array.isArray(e) ? e.map(m) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((t) => [t, m(e[t])])) : e, h = (e) => b("sha256").update(JSON.stringify(m(e))).digest("hex"), O = (e) => b("sha256").update(e).digest("hex"), C = (e, t) => (s, i, u) => (t.throwIfAborted(), e.browser("browser", { operation: s, ...i ? { selector: i } : {}, ...u === void 0 ? {} : { value: u }, timeoutMs: 3e3 }));
  async function D(e, t, s, i, u = null) {
    let n = null;
    try {
      n = await e.file("communication-cache", { operation: "read", name: t });
    } catch (a) {
      if (!String(a.message || a).includes("ENOENT")) throw a;
    }
    const o = n === null ? u : JSON.parse(n);
    if (!o) throw Error("\u7F3A\u5C11\u6062\u590D\u6765\u6E90 " + t);
    if (n !== null) {
      const { sha256: a, ...l } = o;
      if (a !== h(l)) throw Error("\u6062\u590D\u6765\u6E90\u6458\u8981\u4E0D\u7B26 " + t);
    }
    if (o.kind !== s || o.accountKey !== i) throw Error("\u6062\u590D\u6765\u6E90\u8D26\u53F7\u6216\u7C7B\u578B\u4E0D\u7B26");
    return { name: t, raw: n, value: o };
  }
  async function v(e, t) {
    let s = null;
    try {
      s = await e.file("communication-cache", { operation: "read", name: t.name });
    } catch (n) {
      if (!String(n.message || n).includes("ENOENT")) throw n;
    }
    if (s !== t.raw) throw Error("\u6062\u590D\u8BB0\u5F55\u5E76\u53D1\u53D8\u5316");
    const i = t.value;
    i.revision++, i.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete i.sha256, i.sha256 = h(i);
    const u = JSON.stringify(i);
    if (await e.file("communication-cache", { operation: "write", name: t.name, content: u }), await e.file("communication-cache", { operation: "read", name: t.name }) !== u) throw Error("\u6062\u590D\u8BB0\u5F55\u672A\u51C6\u786E\u8BFB\u56DE");
    t.raw = u;
  }
  async function A(e, t) {
    return D(e, "unknown-chat-reviews-v1-" + t + ".json", "boss-unknown-chat-reviews", t, { version: 1, kind: "boss-unknown-chat-reviews", accountKey: t, revision: 0, reviews: [] });
  }
  async function S(e) {
    const t = await e("count", "li.message-item");
    if (!Number.isSafeInteger(t) || t < 1 || t > 150) throw Error("\u4F1A\u8BDD\u53EF\u89C1\u6D88\u606F\u8303\u56F4\u65E0\u6548");
    const s = [];
    for (let i = 1; i <= t; i++) {
      const u = "li.message-item:nth-child(" + i + " of li.message-item)", n = await e("attribute", u, "data-mid"), o = String(await e("attribute", u, "class") || "");
      if (!/^\d{6,40}$/u.test(n || "")) throw Error("\u7F3A\u5C11\u771F\u5B9E\u670D\u52A1\u5668\u6D88\u606F\u7F16\u53F7");
      const a = await e("count", u + " .text-content");
      if (a > 1) throw Error("\u5355\u6761\u6B63\u6587\u4E0D\u552F\u4E00");
      const l = a === 1 ? String(await e("read", u + " .text-content")).trim() : null, w = a === 1 ? null : String(await e("read", u)).trim(), F = !!l && /^您正在与Boss.+沟通$/u.test(l), E = !F && l !== null && o.split(/\s/u).includes("item-myself") ? "outgoing" : !F && l !== null && o.split(/\s/u).includes("item-friend") ? "incoming" : "system", c = u + " > div > div > i", f = await e("count", c) === 1 ? String(await e("read", c)).trim() : null;
      s.push({ mid: n, direction: E, text: l, context: w, receipt: f });
    }
    if (new Set(s.map((i) => i.mid)).size !== s.length) throw Error("\u670D\u52A1\u5668\u6D88\u606F\u7F16\u53F7\u91CD\u590D");
    return s;
  }
  async function x(e, t, s = true) {
    const i = new URL(await e("url"));
    if (i.origin !== "https://www.zhipin.com" || i.pathname !== "/web/geek/chat" || String(await e("read", t.accountSelector)).trim() !== t.accountLabel || await e("count", 'li.message-item[data-mid="' + t.member.originalIncomingMid + '"]') !== 1 || await e("count", 'li.message-item[data-mid="' + t.member.firstMessageId + '"]') !== 1) throw Error("\u672A\u77E5\u6062\u590D\u7684\u8D26\u53F7\u6216\u539F\u6D88\u606F\u94FE\u53D8\u5316");
    if (s && h(await S(e)) !== t.messagesHash) throw Error("AI\u5224\u65AD\u671F\u95F4\u804A\u5929\u5185\u5BB9\u53D8\u5316\uFF0C\u672A\u5916\u53D1");
  }
  async function k(e, t) {
    const s = ".list-warp.v2 input";
    if (await e("count", s) !== 1) throw Error("\u8054\u7CFB\u4EBA\u641C\u7D22\u5165\u53E3\u4E0D\u552F\u4E00");
    await e("click", s), await e("fill", s, t.lookupQuery || t.recipientName);
    const i = ".boss-search-result .search-list";
    let u = 0;
    for (let a = 0; a < 30 && (u = await e("count", i), !(u > 0)); a++) await new Promise((l) => setTimeout(l, 150));
    if (u < 1 || u > 50) throw Error("\u672A\u627E\u5230\u539Funknown\u8054\u7CFB\u4EBA");
    const n = [];
    for (let a = 1; a <= u; a++) {
      const l = i + ":nth-child(" + a + " of .search-list)", w = [l];
      let F = 0;
      for (; w.length; ) {
        const E = w.shift();
        if (++F > 150) throw Error("\u59D3\u540D\u63A7\u4EF6\u8303\u56F4\u8FC7\u5927");
        const c = String(await e("read", E)).trim(), f = await e("count", E + " > *");
        if (c === t.recipientName && n.push({ selector: E, text: c }), f > 0 && f < 30) for (let g = 1; g <= f; g++) w.push(E + " > :nth-child(" + g + ")");
      }
    }
    const o = n.filter((a) => !n.some((l) => l !== a && l.selector.startsWith(a.selector + " > ")));
    if (o.length !== 1) throw Error("\u539Funknown\u59D3\u540D\u63A7\u4EF6\u4E0D\u552F\u4E00");
    if (String(await e("read", o[0].selector)).trim() !== o[0].text) throw Error("\u641C\u7D22\u7ED3\u679C\u53D8\u5316");
    await e("click", o[0].selector);
    for (let a = 0; a < 40; a++) {
      if (await e("count", 'li.message-item[data-mid="' + t.originalIncomingMid + '"]') === 1 && await e("count", 'li.message-item[data-mid="' + t.firstMessageId + '"]') === 1) return;
      await new Promise((l) => setTimeout(l, 150));
    }
    throw Error("\u641C\u7D22\u540E\u672A\u8BFB\u56DE\u539Funknown\u670D\u52A1\u5668\u6D88\u606F\u94FE");
  }
  return async function({ input: e, template: t, artifact: s }) {
    if (!e?.unknownRecovery) throw Error("\u7F3A\u5C11unknown\u96C6\u5408");
    const i = await A(t, e.accountKey), u = i.value.reviews.filter((o) => e.metadataKeys.includes(o.key)), n = { version: 1, kind: "unknown-chat-review-summary", closingPhase: true, unknownRecovery: true, siteDailyLimitConfirmed: false, testCompletionConfirmed: false, newGreeting: false, newMembersAdded: 0, memberCount: e.memberCount, reviewed: u.length, plannedReplies: u.filter((o) => o.decision === "reply").length, plannedNative: u.filter((o) => o.decision === "resume").length, skipped: u.filter((o) => o.decision === "skip").length, needsReview: u.filter((o) => o.decision === "review").length, readOnly: e.readOnly, reviews: u, decision: u.length === e.memberCount && u.every((o) => ["skipped", "existing-answer", "confirmed-reply", "confirmed-native"].includes(o.status)) ? "complete" : "review", progress: e.reviewSetHash + ":" + u.length, reason: "unknown\u5148\u8BFB\u771F\u5B9E\u804A\u5929\u5E76\u7531\u672C\u4EBAAPI\u7ED3\u5408\u786E\u8BA4Skill\u5224\u65AD\uFF1B\u672C\u6279\u4E0D\u65B0\u589E\u62DB\u547C\uFF0C\u4E0D\u76F2\u91CD\u53D1" };
    return await s("unknown-review-summary.json", JSON.stringify(n)), await t.result(n), n;
  };
})();
async function M(m) {
  return m.input?.unknownRecovery ? j(m) : N(m);
}
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default = (ctx) => M(Object.freeze({ ...ctx, constants }));
export {
  stdin_default as default
};
