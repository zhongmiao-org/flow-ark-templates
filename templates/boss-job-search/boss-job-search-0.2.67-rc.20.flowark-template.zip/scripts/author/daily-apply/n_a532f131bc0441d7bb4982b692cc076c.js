import { createHash } from "node:crypto";
var cursorCanonical = (value) => Array.isArray(value) ? value.map(cursorCanonical) : value && typeof value === "object" ? Object.fromEntries(Object.keys(value).sort().map((key) => [key, cursorCanonical(value[key])])) : value;
var cursorDigest = (value) => createHash("sha256").update(JSON.stringify(cursorCanonical(value))).digest("hex");
var cursorCard = (position) => "div:nth-of-type(" + position + ") > div:nth-of-type(1) > li:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1)";
function cursorJob(href, base) {
  const u = new URL(href, base), match = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(u.pathname);
  if (u.origin !== "https://www.zhipin.com" || u.username || u.password || u.hash || !match) throw Error("\u589E\u91CF\u4F4D\u7F6E\u7F3A\u5C11\u51C6\u786E\u5C97\u4F4D\u94FE\u63A5");
  return { jobId: match[1], jobSource: u.origin + u.pathname };
}
async function openIncrementalCursor(template, signal, scope) {
  const fields = ["accountKey", "contextId", "configurationRevision", "day", "timeZone", "searchUrl"];
  if (!scope || fields.some((key) => scope[key] === void 0) || !/^[a-f0-9]{64}$/.test(scope.accountKey) || !scope.contextId || !Number.isSafeInteger(scope.configurationRevision) || !/^\d{4}-\d{2}-\d{2}$/.test(scope.day)) throw Error("\u589E\u91CF\u4F4D\u7F6E\u7F3A\u5C11\u56FA\u5B9A\u8303\u56F4");
  const u = new URL(scope.searchUrl);
  if (u.origin !== "https://www.zhipin.com" || u.pathname !== "/web/geek/jobs" || u.username || u.password || u.hash || !u.searchParams.get("query")) throw Error("\u589E\u91CF\u68C0\u7D22\u6765\u6E90\u65E0\u6548");
  const name = "single-job-list-v1-" + scope.accountKey + "-" + cursorDigest(scope).slice(0, 32) + ".json";
  let original = null, data;
  try {
    original = await template.file("communication-cache", { operation: "read", name });
  } catch (error) {
    if (!String(error.message || error).includes("ENOENT")) throw error;
  }
  if (original !== null) {
    data = JSON.parse(original);
    const { sha256, ...body } = data;
    if (sha256 !== cursorDigest(body) || data.version !== 1 || data.kind !== "boss-single-job-list-cursor" || fields.some((key) => data[key] !== scope[key]) || !Number.isSafeInteger(data.revision) || data.revision < 0 || !Number.isSafeInteger(data.through) || data.through < 0 || !Number.isSafeInteger(data.listCount) || data.listCount < data.through || data.listCount > 500 || data.through > 0 && typeof data.throughId !== "string" || typeof data.exhausted !== "boolean") throw Error("\u5DF2\u4FDD\u5B58\u7684\u589E\u91CF\u4F4D\u7F6E\u8EAB\u4EFD\u3001\u6458\u8981\u6216\u7ED3\u6784\u65E0\u6548\uFF1B\u672A\u6E05\u7A7A\u91CD\u5EFA");
  } else data = { version: 1, kind: "boss-single-job-list-cursor", ...scope, revision: 0, through: 0, throughId: null, listCount: 0, firstId: null, tailId: null, exhausted: false, lastLoad: null };
  const plan = (patch) => {
    const next = { ...data, ...patch, revision: data.revision + 1 };
    delete next.sha256;
    next.sha256 = cursorDigest(next);
    return { version: 1, name, scope, beforeSha256: original === null ? null : createHash("sha256").update(original).digest("hex"), value: next };
  };
  const save = async (update) => {
    signal.throwIfAborted();
    if (!update || update.name !== name || cursorDigest(update.scope) !== cursorDigest(scope) || update.beforeSha256 !== (original === null ? null : createHash("sha256").update(original).digest("hex"))) throw Error("\u589E\u91CF\u4F4D\u7F6E\u5199\u5165\u8BA1\u5212\u6765\u6E90\u4E0D\u7B26");
    const { sha256, ...body } = update.value;
    if (sha256 !== cursorDigest(body) || body.revision !== data.revision + 1) throw Error("\u589E\u91CF\u4F4D\u7F6E\u5199\u5165\u8BA1\u5212\u6458\u8981\u6216\u4FEE\u8BA2\u4E0D\u7B26");
    let before = null;
    try {
      before = await template.file("communication-cache", { operation: "read", name });
    } catch (error) {
      if (!String(error.message || error).includes("ENOENT")) throw error;
    }
    if (before !== original) throw Error("\u589E\u91CF\u4F4D\u7F6E\u5DF2\u88AB\u5176\u4ED6\u64CD\u4F5C\u4FEE\u6539\uFF0C\u505C\u6B62\u8986\u76D6");
    const content = JSON.stringify(update.value);
    await template.file("communication-cache", { operation: "write", name, content });
    if (await template.file("communication-cache", { operation: "read", name }) !== content) throw Error("\u589E\u91CF\u4F4D\u7F6E\u4FDD\u5B58\u540E\u672A\u5B8C\u6574\u8BFB\u56DE");
    data = update.value;
    original = content;
    return { name, revision: data.revision, through: data.through, listCount: data.listCount, sha256: data.sha256 };
  };
  return { name, get data() {
    return data;
  }, plan, save };
}
async function observeIncrementalPosition(read, cursor, count, searchUrl) {
  if (!Number.isSafeInteger(count) || count < 1 || count > 500) throw Error("\u589E\u91CF\u5217\u8868\u5C1A\u672A\u5C31\u7EEA\u6216\u8D85\u51FA\u8BFB\u53D6\u8303\u56F4");
  const idAt = async (position) => cursorJob(await read({ operation: "attribute", selector: cursorCard(position) + " > a:nth-of-type(1)", value: "href" }), searchUrl).jobId;
  const firstId = await idAt(1), tailId = await idAt(count), old = cursor.data;
  let through = old.through, restored = false;
  const anchorMatches = through === 0 || through <= count && await idAt(through) === old.throughId;
  const appendMatches = old.listCount === 0 || count >= old.listCount && firstId === old.firstId && await idAt(old.listCount) === old.tailId;
  if (!anchorMatches || !appendMatches) {
    if (!old.throughId) throw Error("\u5217\u8868\u5237\u65B0\u540E\u6CA1\u6709\u53EF\u6838\u5BF9\u7684\u5DF2\u5904\u7406\u951A\u70B9\uFF1B\u672A\u6309\u65E7\u5E8F\u53F7\u7EE7\u7EED");
    const matches = [];
    for (let position = 1; position <= count; position++) if (await idAt(position) === old.throughId) matches.push(position);
    if (matches.length !== 1) throw Error("\u5217\u8868\u5237\u65B0\u6216\u91CD\u6392\u540E\u6062\u590D\u4F4D\u7F6E\u4E0D\u660E\u786E\uFF0C\u672A\u6E05\u7A7A\u8FDB\u5EA6\u6216\u731C\u6D4B\u4F4D\u7F6E");
    through = matches[0];
    restored = true;
  }
  if (await read({ operation: "url" }) !== searchUrl || await read({ operation: "count", selector: "div > div:nth-of-type(1) > li" }) !== count || await idAt(1) !== firstId || await idAt(count) !== tailId) throw Error("\u8BFB\u53D6\u589E\u91CF\u4F4D\u7F6E\u671F\u95F4\u5217\u8868\u53D8\u5316");
  return { through, throughId: through > 0 ? await idAt(through) : null, listCount: count, firstId, tailId, restored };
}
async function listSalaryCodec(read) {
  const sources = ["https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/app~0.1e6caebe.css", "https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/8026.de407e2f.css"];
  for (const href of sources) {
    const selector = 'head > link[rel="stylesheet"][href="' + href + '"]';
    if (await read({ operation: "count", selector }) !== 1 || await read({ operation: "attribute", selector, value: "href" }) !== href) return null;
  }
  return { version: "kanzhun-mix-2023-digits-v1", sources };
}
function listMonthlySalary(raw, codec) {
  if (typeof raw !== "string" || raw.length > 160) return null;
  const encoded = /[\uE000-\uF8FF]/.test(raw);
  if (encoded && (!codec || /[\uE000-\uE030\uE03B-\uF8FF]/.test(raw))) return null;
  const decoded = encoded ? raw.replace(/[\uE031-\uE03A]/g, (c) => String(c.charCodeAt(0) - 57393)) : raw;
  const value = decoded.normalize("NFKC").trim().replace(/\s+/g, "");
  const m = /^(\d+(?:\.\d+)?)[-–—~至](\d+(?:\.\d+)?)(K|k|千|万)(?:元)?(?:\/月)?(?:[·•]\d{1,2}薪)?$/.exec(value);
  if (!m) return null;
  const unit = m[3] === "\u4E07" ? 1e4 : 1e3, min = Number(m[1]) * unit, max = Number(m[2]) * unit;
  return Number.isFinite(min) && Number.isFinite(max) && min > 0 && max >= min && max <= 1e6 ? { min, max, decoded: value, codec: encoded ? codec.version : "plain-monthly-v1" } : null;
}
var stdin_default = async ({ input, signal, template }) => {
  signal.throwIfAborted();
  const obj = (v) => !!v && typeof v === "object" && !Array.isArray(v);
  const text = (v, n) => typeof v === "string" && v.length > 0 && v.length <= n && v.trim() === v && !/[\u0000-\u001f\u007f]/.test(v);
  const hash = (v) => createHash("sha256").update(JSON.stringify(v)).digest("hex");
  const fail = async (message) => {
    await template.attention({ key: "daily-queue-source:" + hash([input?.fixedConfiguration?.contextId, input?.configuration?.configuredDay, message]), title: "\u5019\u9009\u961F\u5217\u5DF2\u505C\u6B62\uFF0C\u8BF7\u6838\u5BF9\u6765\u6E90", detail: { message, dayTaskComplete: false, siteDailyLimitConfirmed: false } });
    throw Error(message);
  };
  if (!obj(input) || Object.keys(input).sort().join(",") !== "account,cardCount,configuration,fixedConfiguration,state") return fail("\u7F3A\u5C11\u961F\u5217\u56FA\u5B9A\u914D\u7F6E\u3001\u5B9E\u9645\u8D26\u53F7\u3001\u5361\u7247\u6570\u91CF\u6216\u6700\u65B0\u72B6\u6001");
  const { account: a, cardCount: count, configuration: c, fixedConfiguration: raw, state: st } = input;
  if (!obj(raw) || raw.version !== 1 || raw.operation !== "configuration" || !text(raw.contextId, 200) || !Number.isSafeInteger(raw.revision) || raw.revision < 0 || !obj(raw.value) || !obj(st) || st.version !== 1 || st.operation !== "state.read" || st.contextId !== raw.contextId || !Number.isSafeInteger(st.revision) || st.revision < 0 || !obj(st.value)) return fail("\u961F\u5217\u72B6\u6001\u4E0E\u672C\u6B21\u56FA\u5B9A\u914D\u7F6E\u4E0D\u5C5E\u4E8E\u540C\u4E00\u6709\u6548\u4E0A\u4E0B\u6587");
  if (c?.kind !== "daily-apply-configuration" || c.version !== 1 || c.readyForLoop !== true || c.configurationRevision !== raw.revision || c.eligibleForActions !== false || c.timeZone !== raw.value.replyTimeZone || !Number.isSafeInteger(c.batchSize) || c.batchSize < 1 || c.batchSize > 150) return fail("\u672C\u6B21\u6761\u4EF6\u4E0E\u6709\u9650\u6279\u6B21\u5C1A\u672A\u6838\u5BF9");
  for (const k of ["cities", "targetRoles", "excludedRoles", "salaryMin", "salaryMax"]) if (JSON.stringify(c.conditions?.[k]) !== JSON.stringify(raw.value[k])) return fail("\u6574\u7406\u6761\u4EF6\u4E0E\u7528\u6237\u56FA\u5B9A\u914D\u7F6E\u4E0D\u4E00\u81F4");
  const dayOf = (d) => new Intl.DateTimeFormat("sv-SE", { timeZone: c.timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(d), now = /* @__PURE__ */ new Date(), day = dayOf(now);
  if (day !== c.configuredDay || !Array.isArray(c.conditions.cities) || !c.conditions.cities.length) return fail("\u65E5\u671F\u6216\u914D\u7F6E\u57CE\u5E02\u8303\u56F4\u5DF2\u53D8\u5316");
  if (a?.version !== 1 || a.status !== "current-account-source-matched" || a.currentAccountVerified !== true || a.platformUniqueIdVerified !== false || a.eligibleForActions !== false || !text(a.accountAlias, 100) || !text(a.accountName, 100) || !text(a.phoneMask, 100) || !text(a.checkedAt, 64) || !Number.isFinite(Date.parse(a.checkedAt)) || Date.parse(a.checkedAt) > now.getTime() || dayOf(new Date(a.checkedAt)) !== day) return fail("\u7F3A\u5C11\u672C\u6B21\u771F\u5B9E\u590D\u9A8C\u7684\u8D26\u53F7\u6765\u6E90");
  const accountPage = new URL(a.sourceUrl), resume = new URL(a.jobseekerResumeHref, a.sourceUrl);
  if (accountPage.origin !== "https://www.zhipin.com" || accountPage.pathname !== "/web/geek/account" || accountPage.searchParams.get("type") !== "accountSet" || accountPage.username || accountPage.password || accountPage.hash || resume.origin !== accountPage.origin || resume.pathname !== "/web/geek/resume" || resume.username || resume.password) return fail("\u8D26\u53F7\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u65E0\u6548");
  const accountHash = hash(["boss-visible-account-source-v1", a.accountName, a.phoneMask, resume.origin + resume.pathname]);
  const identity = (value, base) => {
    if (!text(value, 4096) || /[……]/.test(value)) throw Error("\u5C97\u4F4D\u7F51\u5740\u7F3A\u5931\u6216\u88AB\u7F29\u7565");
    const u2 = new URL(value, base), m = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(u2.pathname);
    if (u2.origin !== "https://www.zhipin.com" || u2.username || u2.password || u2.hash || !m || !text(m[1], 200)) throw Error("\u5C97\u4F4D\u7F51\u5740\u4E0D\u662F\u5B8C\u6574\u5B89\u5168\u7684\u72EC\u7ACB\u8BE6\u60C5");
    return { jobSource: u2.origin + u2.pathname, jobId: m[1], key: hash(["boss-application-v1", accountHash, m[1]]) };
  };
  const validateExistingIntents = (rows2) => {
    const fields2 = ["accountSourceSha256", "batchId", "configurationRevision", "createdAt", "day", "jobId", "jobSource", "jobSourceSha256", "key", "profileVersionId", "resumeSha256", "status", "timeZone"].sort().join(",");
    if (!Array.isArray(rows2) || rows2.length > 500) throw Error("\u62DB\u547C\u610F\u56FE\u7F3A\u5931\u6216\u8D85\u8FC7\u5BB9\u91CF\uFF0C\u4E0D\u80FD\u6309\u7A7A\u8D26\u672C\u5904\u7406");
    const keys = /* @__PURE__ */ new Set();
    for (const r of rows2) {
      signal.throwIfAborted();
      if (!obj(r) || Object.keys(r).sort().join(",") !== fields2 || r.accountSourceSha256 !== accountHash || r.timeZone !== c.timeZone || !["reserved", "confirmed", "failed", "unknown"].includes(r.status) || keys.has(r.key) || !["key", "jobSourceSha256", "resumeSha256"].every((k) => typeof r[k] === "string" && /^[a-f0-9]{64}$/.test(r[k])) || !Number.isSafeInteger(r.configurationRevision) || r.configurationRevision < 0 || typeof r.batchId !== "string" || !/^[a-f0-9-]{36}$/.test(r.batchId) || typeof r.profileVersionId !== "string" || !r.profileVersionId.trim() || r.profileVersionId.length > 200 || typeof r.createdAt !== "string" || typeof r.day !== "string") throw Error("\u62DB\u547C\u610F\u56FE\u635F\u574F\u3001\u8D26\u53F7\u6216\u65F6\u533A\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u6279");
      const id = identity(r.jobSource), at = new Date(r.createdAt), jobId = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(new URL(r.jobSource).pathname)?.[1];
      if (r.key !== id.key || r.jobSource !== id.jobSource || r.jobId !== jobId || !Number.isFinite(at.getTime()) || at.toISOString() !== r.createdAt || at.getTime() > Date.now() || dayOf(at) !== r.day || r.day > day) throw Error("\u62DB\u547C\u610F\u56FE\u65E5\u671F\u6216\u5B8C\u6574\u5C97\u4F4D\u8EAB\u4EFD\u4E0D\u4E00\u81F4\uFF0C\u505C\u6B62\u7EED\u6279");
      keys.add(r.key);
    }
    return rows2.filter((r) => r.status === "reserved" || r.status === "unknown");
  };
  const rootKeys = Object.keys(st.value).sort().join(",");
  if (rootKeys !== "applicationIntents,conversationControls,queueEntries,replyIntents" || !Array.isArray(st.value.applicationIntents) || st.value.applicationIntents.length > 500 || !Array.isArray(st.value.replyIntents) || !Array.isArray(st.value.conversationControls) || !Array.isArray(st.value.queueEntries) || st.value.queueEntries.length > 1e3) return fail("\u6700\u65B0\u5B8C\u6574\u72B6\u6001\u7ED3\u6784\u4E0D\u7B26\uFF0C\u4E0D\u80FD\u5F53\u4F5C\u7A7A\u961F\u5217\u6216\u8986\u76D6\u5176\u4ED6\u8BB0\u5F55");
  const quarantined = validateExistingIntents(st.value.applicationIntents);
  const rows = st.value.applicationIntents, intents = /* @__PURE__ */ new Map();
  for (const r of rows) {
    if (!obj(r) || r.accountSourceSha256 !== accountHash || !["reserved", "confirmed", "failed", "unknown"].includes(r.status) || intents.has(r.key) || identity(r.jobSource).key !== r.key) return fail("\u65E2\u6709\u62DB\u547C\u610F\u56FE\u635F\u574F\u3001\u8D26\u53F7\u53D8\u5316\u6216\u8EAB\u4EFD\u91CD\u590D");
    intents.set(r.key, r);
  }
  for (const r of quarantined) await template.attention({ key: "daily-quarantined-job:" + hash([raw.contextId, r.key]), title: "\u672C\u5C97\u4F4D\u7ED3\u679C\u5F85\u6838\u5BF9\uFF0C\u5DF2\u9694\u79BB\u5E76\u4FDD\u7559\u5360\u989D", detail: { jobSource: r.jobSource, intentStatus: r.status, originalDay: r.day, sameJobWillNotRetry: true, otherJobsMayContinue: true, dayTaskComplete: false } });
  const known = raw.value.knownContactedJobs ?? [], alias = raw.value.knownContactAccountAlias ?? "", mask = raw.value.knownContactPhoneMask ?? "", used = raw.value.knownGreetingsUsed ?? 0, usedDay = raw.value.knownGreetingDate ?? "";
  if (!Array.isArray(known) || known.length > 500 || !Number.isSafeInteger(used) || used < 0 || used > 150 || typeof usedDay !== "string" || usedDay.length > 10 || typeof alias !== "string" || typeof mask !== "string") return fail("\u65E2\u6709\u6C9F\u901A\u6392\u9664\u9879\u6216\u4FDD\u5B88\u5360\u989D\u683C\u5F0F\u65E0\u6548");
  if ((known.length || used > 0) && (alias !== a.accountAlias || mask !== a.phoneMask)) return fail("\u65E2\u6709\u6C9F\u901A\u6240\u5C5E\u8D26\u53F7\u4E0E\u672C\u6B21\u771F\u5B9E\u8D26\u53F7\u4E0D\u4E00\u81F4");
  if (used > 0 && (!/^\d{4}-\d{2}-\d{2}$/.test(usedDay) || usedDay > day)) return fail("\u4FDD\u5B88\u5360\u989D\u6240\u5C5E\u65E5\u671F\u7F3A\u5931\u6216\u5904\u4E8E\u672A\u6765");
  const excluded = /* @__PURE__ */ new Set();
  for (const x of known) {
    const id = identity(x);
    if (id.jobSource !== x || excluded.has(id.key)) return fail("\u65E2\u6709\u6C9F\u901A\u5FC5\u987B\u662F\u53BB\u91CD\u540E\u7684\u5B8C\u6574\u5C97\u4F4D\u7F51\u5740");
    excluded.add(id.key);
  }
  const fields = ["key", "accountSourceSha256", "configurationRevision", "day", "timeZone", "searchUrl", "jobSource", "jobId", "jobTitle", "discoveredAt", "status", "reason"].sort().join(","), seen = /* @__PURE__ */ new Set(), queue = [];
  for (const r of st.value.queueEntries) {
    signal.throwIfAborted();
    if (!obj(r) || Object.keys(r).sort().join(",") !== fields || r.accountSourceSha256 !== accountHash || !Number.isSafeInteger(r.configurationRevision) || r.configurationRevision < 0 || !/^\d{4}-\d{2}-\d{2}$/.test(r.day) || r.day > day || r.timeZone !== c.timeZone || !text(r.jobTitle, 300) || !text(r.discoveredAt, 64) || !Number.isFinite(Date.parse(r.discoveredAt)) || Date.parse(r.discoveredAt) > now.getTime() || dayOf(new Date(r.discoveredAt)) !== r.day || typeof r.reason !== "string" || r.reason.length > 2e3 || !["queued", "processing", "skipped", "review", "confirmed", "failed", "unknown"].includes(r.status) || seen.has(r.key)) return fail("\u65E2\u6709\u961F\u5217\u635F\u574F\u3001\u91CD\u590D\u6216\u8D26\u53F7\u65E5\u671F\u8303\u56F4\u4E0D\u4E00\u81F4");
    const id = identity(r.jobSource), su = new URL(r.searchUrl);
    if (id.key !== r.key || id.jobId !== r.jobId || id.jobSource !== r.jobSource || su.origin !== "https://www.zhipin.com" || su.pathname !== "/web/geek/jobs" || su.username || su.password || su.hash || !text(r.searchUrl, 4096)) return fail("\u961F\u5217\u5B8C\u6574\u804C\u4F4D\u6216\u68C0\u7D22\u6765\u6E90\u4E0D\u4E00\u81F4");
    seen.add(r.key);
    let next = { ...r };
    const intent = intents.get(r.key);
    if (intent) {
      next.status = intent.status === "reserved" ? "unknown" : intent.status;
      next.reason = "\u6309\u5DF2\u4FDD\u5B58\u62DB\u547C\u610F\u56FE\u4FDD\u7559\u7ED3\u679C\uFF0C\u4E0D\u518D\u6B21\u53D1\u9001";
    } else if (excluded.has(r.key)) {
      next.status = "skipped";
      next.reason = "\u7528\u6237\u914D\u7F6E\u4E3A\u5DF2\u6709\u6C9F\u901A\uFF0C\u4EC5\u4F5C\u6392\u9664\uFF0C\u4E0D\u751F\u6210\u62DB\u547C\u56DE\u6267";
    } else if (["queued", "processing"].includes(r.status)) {
      if (r.configurationRevision !== raw.revision || r.day !== day) {
        next.status = "review";
        next.reason = "\u56FA\u5B9A\u914D\u7F6E\u6216\u65E5\u671F\u5DF2\u7ECF\u53D8\u5316\uFF0C\u65E7\u5019\u9009\u505C\u6B62\u81EA\u52A8\u6D88\u8D39";
      } else if (r.status === "processing") {
        next.status = "review";
        next.reason = "\u4E0A\u6B21\u53EA\u8BFB\u6838\u5BF9\u4E2D\u65AD\u4E14\u672A\u5EFA\u7ACB\u53D1\u9001\u610F\u56FE\uFF1B\u4FDD\u7559\u539F\u8FD0\u884C\u4F9B\u6838\u5BF9\uFF0C\u672C\u9879\u4E0D\u81EA\u52A8\u91CD\u8BD5\uFF0C\u5176\u4F59\u5019\u9009\u7EE7\u7EED";
      }
    }
    if (next.status === "unknown" && !intent) return fail("\u672A\u77E5\u961F\u5217\u7F3A\u5C11\u540C\u5C97\u4F4D\u6709\u6548\u610F\u56FE\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55\u5E76\u6574\u4F53\u505C\u6B62");
    queue.push(next);
  }
  if (!Number.isSafeInteger(count) || count < 0 || count > 500) return fail("\u7F51\u9875\u5B9E\u9645\u5019\u9009\u6570\u91CF\u65E0\u6548");
  const citySelector = "body > div:nth-of-type(1) > div:nth-of-type(2) > div:nth-of-type(2) > div > div:nth-of-type(1) > span", cardSelector = "div > div:nth-of-type(1) > li";
  const read = (command) => {
    signal.throwIfAborted();
    return template.browser("browser", { ...command, timeoutMs: 1e4 });
  };
  const searchUrl = await read({ operation: "url" }), u = new URL(searchUrl), city = await read({ operation: "read", selector: citySelector });
  if (u.origin !== "https://www.zhipin.com" || u.pathname !== "/web/geek/jobs" || u.username || u.password || u.hash || !text(searchUrl, 4096) || !c.conditions.targetRoles.some((role) => role.trim() === u.searchParams.get("query")) || typeof city !== "string" || !c.conditions.cities.includes(city.trim()) || await read({ operation: "count", selector: cardSelector }) !== count) return fail("\u53D1\u73B0\u5019\u9009\u524D\u7684\u5B9E\u9645\u57CE\u5E02\u3001\u68C0\u7D22\u9875\u9762\u6216\u6570\u91CF\u4E0D\u7B26");
  const cursorScope = { accountKey: accountHash, contextId: raw.contextId, configurationRevision: raw.revision, day, timeZone: c.timeZone, searchUrl };
  const cursor = await openIncrementalCursor(template, signal, cursorScope);
  const positionProof = await observeIncrementalPosition(read, cursor, count, searchUrl);
  const indexName = "account-outbound-safety-v1-" + accountHash + ".json";
  const safety = JSON.parse(await template.file("communication-cache", { operation: "read", name: indexName }));
  const { sha256: indexSha, ...indexBody } = safety;
  if (safety.version !== 1 || safety.kind !== "boss-account-outbound-safety" || safety.accountKey !== accountHash || indexSha !== cursorDigest(indexBody) || !Array.isArray(safety.records) || safety.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\u6216\u4E0D\u7B26\uFF0C\u672A\u6309\u7A7A\u5386\u53F2\u7EED\u53D1");
  for (const record of safety.records) {
    if (!["first-contact", "reply"].includes(record.type) || !record.jobId || !Array.isArray(record.sightings) || !record.sightings.length || record.sightings.some((x) => !["reserved", "confirmed", "failed", "unknown"].includes(x.status))) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8BB0\u5F55\u65E0\u6548");
    if (record.type === "first-contact") seen.add(identity("https://www.zhipin.com/job_detail/" + record.jobId + ".html").key);
  }
  const directBlockedJobs = new Set(safety.records.filter((v) => v.type === "first-contact").map((v) => v.jobId));
  const interruptedReadOnlyReason = "\u4E0A\u6B21\u53EA\u8BFB\u6838\u5BF9\u4E2D\u65AD\u4E14\u672A\u5EFA\u7ACB\u53D1\u9001\u610F\u56FE\uFF1B\u4FDD\u7559\u539F\u8FD0\u884C\u4F9B\u6838\u5BF9\uFF0C\u672C\u9879\u4E0D\u81EA\u52A8\u91CD\u8BD5\uFF0C\u5176\u4F59\u5019\u9009\u7EE7\u7EED";
  for (const row of queue) {
    const sameScope = row.configurationRevision === raw.revision && row.day === day && row.searchUrl === searchUrl;
    const noOutboundIntent = !st.value.applicationIntents.some((v) => v.key === row.key) && !directBlockedJobs.has(row.jobId);
    if (!sameScope || !noOutboundIntent || !(row.status === "queued" || row.status === "review" && row.reason === interruptedReadOnlyReason)) continue;
    const path = new URL(row.jobSource).pathname;
    const hrefs = [path, row.jobSource].flatMap((href) => ['[href="' + href + '"]', '[href^="' + href + '?"]']).join(",");
    const selector = cardSelector + " > div:nth-of-type(1) > div:nth-of-type(1) > a:is(" + hrefs + ")";
    const available = await read({ operation: "count", selector });
    if (!Number.isSafeInteger(available) || available < 0 || available > 1) throw Error("\u65E7\u5019\u9009\u7684\u5F53\u524D\u5361\u7247\u6765\u6E90\u4E0D\u552F\u4E00\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55\u4E14\u4E0D\u5916\u53D1");
    if (available === 0) {
      row.status = "review";
      row.reason = "\u539F\u5C97\u4F4D\u5DF2\u4E0D\u5728\u5F53\u524D\u5DF2\u52A0\u8F7D\u5217\u8868\uFF1B\u4FDD\u7559\u539F\u6765\u6E90\u5F85\u6838\u5BF9\uFF0C\u4E0D\u5EFA\u7ACB\u53D1\u9001\u610F\u56FE\uFF0C\u5176\u4F59\u5F53\u524D\u5019\u9009\u7EE7\u7EED";
    }
    if (await read({ operation: "url" }) !== searchUrl) throw Error("\u6838\u5BF9\u65E7\u5019\u9009\u671F\u95F4\u9875\u9762\u6765\u6E90\u53D8\u5316\uFF0C\u672A\u91C7\u7528\u961F\u5217\u8BA1\u5212");
  }
  for (const row of queue) {
    if (row.status === "review" && row.reason === "\u4E0A\u6B21\u53EA\u8BFB\u6838\u5BF9\u4E2D\u65AD\u4E14\u672A\u5EFA\u7ACB\u53D1\u9001\u610F\u56FE\uFF1B\u4FDD\u7559\u539F\u8FD0\u884C\u4F9B\u6838\u5BF9\uFF0C\u672C\u9879\u4E0D\u81EA\u52A8\u91CD\u8BD5\uFF0C\u5176\u4F59\u5019\u9009\u7EE7\u7EED" && row.configurationRevision === raw.revision && row.day === day && row.searchUrl === searchUrl && !st.value.applicationIntents.some((v) => v.key === row.key) && !directBlockedJobs.has(row.jobId)) {
      row.status = "queued";
      row.reason = "\u4F7F\u7528\u8005\u5DF2\u6539\u4E3A\u85AA\u8D44\u4EA4\u96C6\u53CA\u9009\u4E2D\u6001\u76F4\u63A5\u62DB\u547C\uFF1B\u672C\u9879\u53EA\u6709\u65E7\u53EA\u8BFB\u4E2D\u65AD\u3001\u6CA1\u6709\u5916\u53D1\u610F\u56FE\uFF0C\u6309\u65B0\u89C4\u5219\u91CD\u65B0\u6838\u5BF9";
    }
  }
  let added = 0, scanned = 0, through = positionProof.through, throughId = positionProof.throughId;
  const discovered = /* @__PURE__ */ new Set();
  const hasPending = queue.some((r) => r.status === "queued" && r.configurationRevision === raw.revision && r.day === day && r.searchUrl === searchUrl);
  const salaryCodec = !hasPending ? await listSalaryCodec(read) : null;
  for (let position = through + 1; !hasPending && position <= count; position++) {
    signal.throwIfAborted();
    const card = cursorCard(position), selector = card + " > a:nth-of-type(1)";
    const href = await read({ operation: "attribute", selector, value: "href" }), title = await read({ operation: "read", selector });
    if (!text(title, 300) || await read({ operation: "attribute", selector, value: "href" }) !== href) throw Error("\u589E\u91CF\u5C97\u4F4D\u8EAB\u4EFD\u6216\u6807\u9898\u53D8\u5316");
    const id = identity(href, searchUrl);
    through = position;
    throughId = id.jobId;
    scanned++;
    discovered.add(id.key);
    if (seen.has(id.key)) continue;
    if (queue.length >= 1e3) throw Error("\u5019\u9009\u8BB0\u5F55\u5BB9\u91CF\u5DF2\u6EE1\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55\u505C\u6B62");
    const salarySelector = card + " > span", salaryCount = await read({ operation: "count", selector: salarySelector });
    const salaryText = salaryCount === 1 ? String(await read({ operation: "read", selector: salarySelector })).trim() : null;
    const verifiedStyle = salaryCount === 1 && await read({ operation: "count", selector: salarySelector + ".job-salary[data-v-6460f456]" }) === 1;
    const salary = listMonthlySalary(salaryText, verifiedStyle ? salaryCodec : null);
    const outside = !!salary && (c.conditions.salaryMin && salary.max < c.conditions.salaryMin || c.conditions.salaryMax && salary.min > c.conditions.salaryMax);
    if (await read({ operation: "attribute", selector, value: "href" }) !== href || salaryText !== null && String(await read({ operation: "read", selector: salarySelector })).trim() !== salaryText) throw Error("\u589E\u91CF\u85AA\u8D44\u9884\u7B5B\u671F\u95F4\u76EE\u6807\u53D8\u5316");
    const status = outside ? "skipped" : "queued";
    queue.push({ ...id, accountSourceSha256: accountHash, configurationRevision: raw.revision, day, timeZone: c.timeZone, searchUrl, jobTitle: title, discoveredAt: now.toISOString(), status, reason: outside ? "\u5217\u8868\u6708\u85AA " + salary.decoded + " \u4E0E\u914D\u7F6E\u6CA1\u6709\u4EA4\u96C6\uFF1B\u672A\u6253\u5F00\u8BE6\u60C5" : "\u5F53\u524D\u5217\u8868\u65B0\u589E\u533A\u6BB5\uFF1B\u5C1A\u672A\u8BFB\u53D6\u8BE6\u60C5\u6216\u5916\u53D1" });
    seen.add(id.key);
    added++;
    if (!outside && queue.filter((r) => r.status === "queued" && r.configurationRevision === raw.revision && r.day === day && r.searchUrl === searchUrl).length >= c.batchSize) break;
  }
  const cursorUpdate = cursor.plan({ ...positionProof, through, throughId, exhausted: cursor.data.exhausted && count <= cursor.data.listCount });
  if (dayOf(/* @__PURE__ */ new Date()) !== day || await read({ operation: "url" }) !== searchUrl || (await read({ operation: "read", selector: citySelector })).trim() !== city.trim() || await read({ operation: "count", selector: cardSelector }) !== count) return fail("\u53D1\u73B0\u671F\u95F4\u68C0\u7D22\u9875\u9762\u3001\u57CE\u5E02\u6216\u5217\u8868\u6570\u91CF\u53D8\u5316\uFF0C\u8BA1\u5212\u672A\u91C7\u7528");
  const items = queue.filter((r) => r.status === "queued" && r.configurationRevision === raw.revision && r.day === day && r.accountSourceSha256 === accountHash && r.searchUrl === searchUrl).slice(0, c.batchSize);
  signal.throwIfAborted();
  return { version: 1, kind: "daily-candidate-queue-plan", contextId: raw.contextId, configurationRevision: raw.revision, configuredDay: day, timeZone: c.timeZone, actualCity: city.trim(), currentSearchUrl: searchUrl, accountSourceSha256: accountHash, expectedRevision: st.revision, value: { ...st.value, queueEntries: queue }, items, newlyAdded: added, scanned, pending: queue.filter((r) => r.status === "queued").length, knownGreetingsUsedToday: usedDay === day ? used : 0, quarantinedCount: quarantined.length, cursorUpdate, eligibleForActions: false, dayTaskComplete: false, siteDailyLimitConfirmed: false };
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default2 = (ctx) => stdin_default(Object.freeze({ ...ctx, constants }));
export {
  stdin_default2 as default
};
