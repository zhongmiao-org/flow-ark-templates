import { createHash } from "node:crypto";
var PANEL = Object.freeze({ title: "head > title", jobTitle: ".job-detail-container .job-name", jobCity: ".job-header-info .tag-list > :nth-child(1)", companyLabel: ".job-boss-info > :nth-child(2) > :nth-child(2)", description: ".job-detail-body > .desc", salary: ".job-detail-container .job-salary", closedStatus: ".job-detail-container .job-close", contact: ".job-detail-container div:nth-of-type(2) > a:nth-of-type(2)" });
function panelJobIdentity(source) {
  const u = new URL(source), m = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(u.pathname);
  if (u.origin !== "https://www.zhipin.com" || u.username || u.password || u.search || u.hash || !m) throw Error("\u5C97\u4F4D\u5B8C\u6574\u94FE\u63A5\u65E0\u6548");
  const hrefs = [u.pathname, u.href].flatMap((v) => ['[href="' + v + '"]', '[href^="' + v + '?"]']).join(",");
  const relative = "> div:nth-of-type(1) > div > a:is(" + hrefs + ")";
  return { jobId: m[1], cardSelector: ".job-card-box:has(" + relative + ")", linkSelector: ".job-card-box " + relative };
}
async function panelFontCodec(read) {
  const sources = ["https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/app~0.1e6caebe.css", "https://static.zhipin.com/zhipin-geek-spa/web/v6789/static/css/8026.de407e2f.css"];
  for (const href of sources) {
    const selector = 'head > link[rel="stylesheet"][href="' + href + '"]';
    if (await read("count", selector) !== 1 || await read("attribute", selector, "href") !== href) throw Error("\u85AA\u8D44\u5B57\u4F53\u6765\u6E90\u53D8\u5316\uFF0C\u672A\u731C\u6D4B\u91D1\u989D");
  }
  return "kanzhun-mix-2023-digits-v1";
}
function panelSalary(raw, codec) {
  if (typeof raw !== "string" || !raw.trim() || raw.length > 256) throw Error("\u85AA\u8D44\u539F\u6587\u7F3A\u5931\u6216\u8D85\u957F");
  if (/[\uE000-\uF8FF]/u.test(raw)) {
    if (codec !== "kanzhun-mix-2023-digits-v1" || /[\uE000-\uE030\uE03B-\uF8FF]/u.test(raw)) throw Error("\u85AA\u8D44\u5305\u542B\u672A\u7ECF\u6838\u5BF9\u7684\u5B57\u4F53\u7F16\u7801");
    return raw.replace(/[\uE031-\uE03A]/gu, (c) => String(c.charCodeAt(0) - 57393)).normalize("NFKC").trim();
  }
  return raw.normalize("NFKC").trim();
}
var directMode = "salary-and-selected-ui";
var directHash = (v) => createHash("sha256").update(typeof v === "string" ? v : JSON.stringify(v)).digest("hex");
var directDay = (zone) => new Intl.DateTimeFormat("sv-SE", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
function directSalary(raw) {
  const m = /^(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)\s*[Kk](?:\s*[·•]\s*\d{1,2}薪)?$/.exec(raw);
  if (!m) return null;
  const minimumYuan = Number(m[1]) * 1e3, maximumYuan = Number(m[2]) * 1e3;
  return Number.isSafeInteger(minimumYuan) && Number.isSafeInteger(maximumYuan) && minimumYuan > 0 && maximumYuan >= minimumYuan ? { minimumYuan, maximumYuan, period: "month" } : null;
}
async function directSelected(template, signal, c, { requireImmediate = false } = {}) {
  const read = async (operation, selector, value) => {
    signal.throwIfAborted();
    return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
  };
  const id = panelJobIdentity(c.jobSource), url = await read("url");
  if (url !== c.returnUrl) throw Error("\u5F53\u524D\u68C0\u7D22\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55");
  const activeTotal = await read("count", ".job-card-wrap.active");
  const matchingActive = await read("count", ":is(" + id.cardSelector + "):is(.job-card-wrap.active *)");
  if (!Number.isSafeInteger(activeTotal) || activeTotal < 1 || activeTotal > 500 || matchingActive !== activeTotal) throw Error("\u5F53\u524D\u9009\u4E2D\u72B6\u6001\u5305\u542B\u5176\u4ED6\u5C97\u4F4D\u6216\u6CA1\u6709\u76EE\u6807\u5C97\u4F4D\uFF1B\u672A\u5916\u53D1");
  if (matchingActive > 1) {
    const count2 = await read("count", "div > div:nth-of-type(1) > li");
    if (!Number.isSafeInteger(count2) || count2 < 1 || count2 > 500) throw Error("\u5F53\u524D\u5217\u8868\u8303\u56F4\u65E0\u6548");
    let chosen = null;
    for (let position = 1; position <= count2; position++) {
      const card = "div:nth-of-type(" + position + ") > div:nth-of-type(1) > li:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1)";
      if (await read("count", ":is(" + card + "):is(.job-card-wrap.active *)") !== 1) continue;
      const link = card + " > a:nth-of-type(1)", href2 = new URL(await read("attribute", link, "href"), url);
      if (href2.origin + href2.pathname === c.jobSource) {
        chosen = { card, link };
        break;
      }
    }
    if (!chosen) throw Error("\u91CD\u590D\u9009\u4E2D\u5C55\u793A\u6CA1\u6709\u53EF\u6838\u5BF9\u7684\u5177\u4F53\u5C97\u4F4D\u5361\u7247");
    id.cardSelector = chosen.card;
    id.linkSelector = chosen.link;
  }
  id.linkSelector = ":is(" + id.linkSelector + "):is(.job-card-wrap.active *)";
  const active = ":is(" + id.cardSelector + "):is(.job-card-wrap.active *)";
  if (await read("count", active) !== 1 || await read("count", id.linkSelector) !== 1) throw Error("\u672C\u9879\u5C97\u4F4D\u672A\u5904\u4E8E\u552F\u4E00\u9009\u4E2D\u72B6\u6001");
  const salarySelector = active + " .job-salary";
  if (await read("count", salarySelector) !== 1) throw Error("\u9009\u4E2D\u5C97\u4F4D\u85AA\u8D44\u4E0D\u552F\u4E00");
  const raw = String(await read("read", salarySelector)).trim(), codec = /[\uE000-\uF8FF]/u.test(raw) ? await panelFontCodec(read) : null, salaryRaw = panelSalary(raw, codec), salary = directSalary(salaryRaw);
  const href = new URL(await read("attribute", id.linkSelector, "href"), url);
  if (href.origin + href.pathname !== c.jobSource || await read("url") !== url) throw Error("\u9009\u4E2D\u5C97\u4F4D\u6765\u6E90\u53D8\u5316");
  let contactLabel = null, closed = false;
  const count = await read("count", PANEL.contact);
  if (count === 1) contactLabel = String(await read("read", PANEL.contact)).trim();
  else if (count === 0) closed = String(await read("read", "body")).split(/\r?\n/u).some((v) => v.trim() === "\u804C\u4F4D\u5DF2\u5173\u95ED");
  if (!closed && !["\u7ACB\u5373\u6C9F\u901A", "\u7EE7\u7EED\u6C9F\u901A"].includes(contactLabel)) throw Error("\u9009\u4E2D\u5C97\u4F4D\u7684\u6C9F\u901A\u5165\u53E3\u5C1A\u672A\u5C31\u7EEA");
  if (requireImmediate && contactLabel !== "\u7ACB\u5373\u6C9F\u901A") throw Error("\u5F53\u524D\u4E0D\u662F\u7ACB\u5373\u6C9F\u901A\uFF0C\u672A\u91CD\u590D\u53D1\u9001");
  if (await read("count", active) !== 1 || await read("url") !== url) throw Error("\u6838\u5BF9\u671F\u95F4\u9009\u4E2D\u72B6\u6001\u53D8\u5316");
  return { mode: directMode, jobSource: c.jobSource, selected: true, selector: active, salaryRaw, salary, contactLabel, closed, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
}
function communicationCache(template, signal, contextId, accountSourceSha256) {
  const object = (v) => !!v && typeof v === "object" && !Array.isArray(v);
  const canonical2 = (v) => Array.isArray(v) ? v.map(canonical2) : object(v) ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical2(v[k])])) : v;
  const encode = (v) => JSON.stringify(canonical2(v));
  const sha = (v) => createHash("sha256").update(v).digest("hex");
  const digest2 = (v) => typeof v === "string" && /^[a-f0-9]{64}$/.test(v);
  const timestamp = (v) => typeof v === "string" && Number.isFinite(Date.parse(v)) && new Date(v).toISOString() === v && Date.parse(v) <= Date.now();
  if (typeof contextId !== "string" || !contextId || contextId.length > 200 || !digest2(accountSourceSha256)) throw Error("\u7F13\u5B58\u6240\u5C5E\u4E0A\u4E0B\u6587\u6216\u8D26\u53F7\u6765\u6E90\u65E0\u6548");
  const scope = { version: 1, kind: "boss-communication-cache-scope", contextId, accountSourceSha256 };
  const scopeText = encode(scope), scopeName = "scope-v1-" + sha(scopeText) + ".json";
  let initialized = false;
  const guarded = (fn) => async (...args) => {
    try {
      return await fn(...args);
    } catch (error) {
      if (signal.aborted || error?.communicationCacheFailure === true) throw error;
      const failure = Error("\u6C9F\u901A\u7F13\u5B58\u6545\u969C\uFF1A" + String(error?.message || error));
      failure.communicationCacheFailure = true;
      throw failure;
    }
  };
  const controlled = (name) => typeof name === "string" && /^(?:scope|observation|positive)-v1-[a-f0-9]{64}\.json$/.test(name);
  const missingTarget = (error, name) => {
    const match = /^ENOENT: no such file or directory, realpath '([^'\r\n]+)'$/.exec(String(error?.message || ""));
    return !!match && controlled(name) && match[1].endsWith("/" + name);
  };
  const rawRead = async (name) => {
    if (!controlled(name)) throw Error("\u7F13\u5B58\u6587\u4EF6\u540D\u4E0D\u53D7\u652F\u6301");
    signal.throwIfAborted();
    const content = await template.file("communication-cache", { operation: "read", name });
    signal.throwIfAborted();
    if (typeof content !== "string" || Buffer.byteLength(content) > 10 * 1024 * 1024) throw Error("\u7F13\u5B58\u5185\u5BB9\u8D85\u51FA\u65E2\u6709\u6587\u4EF6\u8BFB\u53D6\u8303\u56F4");
    return content;
  };
  const checkScope = async () => {
    if (await rawRead(scopeName) !== scopeText) throw Error("\u7F13\u5B58\u8303\u56F4\u6807\u8BB0\u4E0E\u672C\u5B9E\u4F8B\u8D26\u53F7\u4E0D\u4E00\u81F4\uFF0C\u4FDD\u7559\u539F\u6587\u4EF6");
  };
  const init = async () => {
    try {
      if (await rawRead(scopeName) !== scopeText) throw Error("\u7F13\u5B58\u8303\u56F4\u6807\u8BB0\u635F\u574F\u6216\u4E0D\u4E00\u81F4\uFF0C\u4FDD\u7559\u539F\u6587\u4EF6");
    } catch (error) {
      if (!missingTarget(error, scopeName)) throw error;
      signal.throwIfAborted();
      await template.file("communication-cache", { operation: "write", name: scopeName, content: scopeText });
      await checkScope();
    }
    initialized = true;
  };
  const read = async (name) => {
    if (!initialized) throw Error("\u7F13\u5B58\u8303\u56F4\u5C1A\u672A\u6838\u5BF9");
    try {
      return await rawRead(name);
    } catch (error) {
      if (!missingTarget(error, name)) throw error;
      await checkScope();
      return null;
    }
  };
  const put = async (name, value) => {
    const content = encode(value);
    if (typeof content !== "string" || Buffer.byteLength(content) > 10 * 1024 * 1024) throw Error("\u7F13\u5B58\u8F93\u51FA\u8D85\u8FC7\u65E2\u6709SDK\u4E0A\u9650\uFF0C\u672A\u622A\u65AD\u5199\u5165");
    const previous = await read(name);
    if (previous !== null && previous !== content) throw Error("\u7F13\u5B58\u6587\u4EF6\u5DF2\u6709\u4E0D\u540C\u5185\u5BB9\uFF0C\u4FDD\u7559\u539F\u6587\u4EF6");
    if (previous === null) {
      signal.throwIfAborted();
      await template.file("communication-cache", { operation: "write", name, content });
    }
    if (await rawRead(name) !== content) throw Error("\u7F13\u5B58\u5199\u51FA\u4E0E\u56DE\u8BFB\u4E0D\u4E00\u81F4");
    return { name, sha256: sha(content) };
  };
  const parse = (content) => {
    let value;
    try {
      value = JSON.parse(content);
    } catch {
      throw Error("\u7F13\u5B58JSON\u635F\u574F\uFF0C\u4E0D\u80FD\u6309\u7A7A\u7F13\u5B58\u5904\u7406");
    }
    if (!object(value) || encode(value) !== content) throw Error("\u7F13\u5B58\u4E0D\u662F\u5B8C\u6574\u89C4\u8303\u5BF9\u8C61\uFF0C\u4E0D\u80FD\u6309\u7A7A\u7F13\u5B58\u5904\u7406");
    return value;
  };
  const identity = (value, jobSource, jobId) => {
    let source;
    try {
      source = new URL(jobSource);
    } catch {
      throw Error("\u7F13\u5B58\u5C97\u4F4D\u6765\u6E90\u65E0\u6548");
    }
    const match = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(source.pathname);
    if (source.origin !== "https://www.zhipin.com" || source.username || source.password || source.port || source.search || source.hash || source.href !== jobSource || match?.[1] !== jobId || value.version !== 1 || value.contextId !== contextId || value.accountSourceSha256 !== accountSourceSha256 || value.jobSource !== jobSource || value.jobId !== jobId) throw Error("\u7F13\u5B58\u4E0A\u4E0B\u6587\u3001\u8D26\u53F7\u6216\u5B8C\u6574\u5C97\u4F4D\u6765\u6E90\u4E0D\u4E00\u81F4");
  };
  const observe = async (value) => {
    const record = { ...value, version: 1, kind: "boss-communication-observation", contextId, accountSourceSha256 };
    identity(record, value.jobSource, value.jobId);
    if (!timestamp(record.observedAt) || record.doNotReplay !== true) throw Error("\u7F13\u5B58\u89C2\u5BDF\u65F6\u95F4\u6216\u672A\u77E5\u91CD\u653E\u8FB9\u754C\u65E0\u6548");
    const content = encode(record), name = "observation-v1-" + sha(content) + ".json";
    return put(name, record);
  };
  return { init: guarded(init), observe: guarded(observe) };
}
var stdin_default = async ({ input, template, signal }) => {
  signal.throwIfAborted();
  const { check: c, clickResult: k, pageText: text, pageUrl: url, receipt: r, source: s } = input || {}, i = s?.intent;
  if (c?.kind !== "daily-first-communication-submit-check" || c.readyForWebsiteSubmission !== true || k?.kind !== "daily-first-communication-click-returned" || k.clicked !== true || k.businessResultVerified !== false || k.operationId !== c.operationId || k.operationKey !== c.operationKey || k.jobSource !== c.jobSource || r?.operation !== "prepare" || r.execute !== true || r.state !== "submitting" || r.id !== c.operationId || r.key !== c.operationKey || r.runId !== c.runId || s?.key !== r.key || s.jobSource !== c.jobSource || i?.status !== "reserved" || s.submissionMode !== "first-communication-with-app-default-greeting" || typeof text !== "string" || typeof url !== "string" || directHash(s.greetingText) !== c.greetingSha256 || s.greetingSha256 !== c.greetingSha256) throw Error("\u672C\u6B21\u70B9\u51FB\u4E0E\u539F\u9884\u7559\u4E0D\u4E00\u81F4\uFF0C\u4E0D\u7EE7\u7EED\u64CD\u4F5C");
  const cache = communicationCache(template, signal, s.contextId, i.accountSourceSha256);
  await cache.init();
  const read = async (operation, selector) => {
    signal.throwIfAborted();
    return template.browser("browser", { operation, ...selector ? { selector } : {}, timeoutMs: 3e3 });
  };
  const delay = (ms) => new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, ms);
    signal.addEventListener("abort", () => {
      clearTimeout(timer);
      reject(signal.reason);
    }, { once: true });
  });
  let stopping = false;
  const observe = (observationType, data) => cache.observe({ observationType, jobId: i.jobId, jobSource: i.jobSource, operationId: r.id, operationKey: r.key, runId: r.runId, sourcePage: s.listSource, observedAt: (/* @__PURE__ */ new Date()).toISOString(), ...data, doNotReplay: true });
  const fail = async (reason) => {
    stopping = true;
    const evidence = { version: 1, kind: "default-greeting-unresolved", jobSource: i.jobSource, reason, observedAt: (/* @__PURE__ */ new Date()).toISOString() };
    await observe("default-greeting-unresolved", { evidence });
    await template.effect.resolve({ id: r.id, state: "unknown", evidence });
    await template.attention({ key: "default-greeting:" + r.id, title: "\u672C\u9879\u81EA\u52A8\u62DB\u547C\u7ED3\u679C\u5F85\u6838\u5BF9", detail: { ...evidence, doNotReplay: true } });
    throw Error(reason + "\uFF1B\u4FDD\u7559\u672A\u77E5\uFF0C\u4E0D\u91CD\u653E");
  };
  try {
    if (url !== s.listSource || await read("url") !== s.listSource || !Number.isFinite(Date.parse(c.checkedAt)) || Date.now() - Date.parse(c.checkedAt) > 12e4) return await fail("\u70B9\u51FB\u540E\u5217\u8868\u6765\u6E90\u53D8\u5316\u6216\u56DE\u6267\u8D85\u65F6");
    await directSelected(template, signal, { jobSource: i.jobSource, returnUrl: s.listSource });
    const dialog = ".greet-boss-dialog";
    let modalText = null, remainingReminderHandled = false;
    for (let n = 0; n < 12; n++) {
      const body = String(await read("read", "body"));
      if (Buffer.byteLength(body) > 262144) return await fail("\u70B9\u51FB\u540E\u9875\u9762\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
      if (/您的账户存在异常行为|暂时被限制访问|访问受限|登录失效/u.test(body)) return await fail("\u7F51\u7AD9\u8BBF\u95EE\u53D7\u9650\u6216\u767B\u5F55\u5931\u6548");
      const reminder = ".chat-block-dialog";
      const reminderCount = await read("count", reminder);
      if (reminderCount > 1) return await fail("\u6C9F\u901A\u63D0\u793A\u4E0D\u552F\u4E00\uFF0C\u672A\u786E\u8BA4\u6216\u91CD\u8BD5\u6C9F\u901A");
      if (reminderCount === 1) {
        const reminderText = String(await read("read", reminder)).trim();
        const lines = reminderText.split(/\r?\n/u).map((v) => v.trim()).filter(Boolean);
        const upper = lines.length === 3 && lines[0] === "\u60A8\u5DF2\u8FBE\u5230\u6C9F\u901A\u4E0A\u9650" && lines[2] === "\u786E\u5B9A" ? /^您今天已与([1-9]\d{0,3})位BOSS沟通，休息一下，明天再来吧～$/u.exec(lines[1]) : null;
        if (upper) {
          const button2 = reminder + " .chat-block-footer a.default-btn.sure-btn";
          if (await read("count", button2) !== 1 || String(await read("read", button2)).trim() !== "\u786E\u5B9A") return await fail("\u771F\u5B9E\u4E0A\u9650\u5F39\u7A97\u7F3A\u5C11\u552F\u4E00\u786E\u8BA4\u6309\u94AE");
          const canonical2 = (v) => Array.isArray(v) ? v.map(canonical2) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k2) => [k2, canonical2(v[k2])])) : v;
          const sha = (v) => createHash("sha256").update(JSON.stringify(canonical2(v))).digest("hex");
          const accountKey = i.accountSourceSha256, day = directDay(i.timeZone), name = "site-daily-limit-v1-" + accountKey + "-" + day + ".json", indexName = "account-outbound-safety-v1-" + accountKey + ".json";
          if (day !== i.day) return await fail("\u4E0A\u9650\u63D0\u793A\u671F\u95F4\u8DE8\u5929\uFF0C\u672A\u63A8\u5B9A\u5F53\u524D\u65E5\u671F");
          const indexText = await template.file("communication-cache", { operation: "read", name: indexName }), index = JSON.parse(indexText), { sha256, ...indexBody } = index;
          if (index.kind !== "boss-account-outbound-safety" || index.accountKey !== accountKey || sha256 !== sha(indexBody) || !Array.isArray(index.records) || !index.records.some((v) => v.type === "first-contact" && v.jobId === i.jobId && v.sightings.some((v2) => v2.contextId === s.contextId && v2.intentKey === i.key && v2.status === "reserved"))) return await fail("\u771F\u5B9E\u4E0A\u9650\u7F3A\u5C11\u539F\u8D26\u53F7\u4E0E\u672C\u6B21\u9884\u7559\u7D22\u5F15");
          const configuration = await template.configuration(), page = new URL(s.listSource);
          if (!Array.isArray(configuration.targetRoles) || !configuration.targetRoles.includes(page.searchParams.get("query")) || configuration.replyTimeZone !== i.timeZone) return await fail("\u771F\u5B9E\u4E0A\u9650\u4E0E\u56FA\u5B9A\u68C0\u7D22\u914D\u7F6E\u4E0D\u7B26");
          const value = { version: 1, kind: "boss-site-daily-limit", accountKey, day, timeZone: i.timeZone, sourceContextId: s.contextId, configurationRevision: i.configurationRevision, sourceUrl: s.listSource, dialogSelector: reminder, dialogText: reminderText, dialogTextSha256: createHash("sha256").update(reminderText).digest("hex"), siteCommunicatedCount: Number(upper[1]), confirmed: true, observedAt: (/* @__PURE__ */ new Date()).toISOString(), stoppedIntentKey: i.key, stoppedJobId: i.jobId, accountSafetySha256: index.sha256, outboundHistoryReset: false, unreadClosingComplete: false };
          value.sha256 = sha(value);
          let prior = null;
          try {
            prior = await template.file("communication-cache", { operation: "read", name });
          } catch (e) {
            if (!String(e?.message || e).includes("ENOENT") || !String(e?.message || e).includes(name)) throw e;
          }
          let saved = value;
          if (prior !== null) {
            saved = JSON.parse(prior);
            const { sha256: sha2562, ...body2 } = saved;
            if (sha2562 !== sha(body2) || saved.kind !== value.kind || saved.accountKey !== accountKey || saved.day !== day || saved.timeZone !== i.timeZone || saved.dialogTextSha256 !== value.dialogTextSha256 || saved.confirmed !== true) return await fail("\u5DF2\u6709\u4E0D\u540C\u4E0A\u9650\u8BC1\u636E\uFF0C\u672A\u8986\u76D6");
          }
          if (await read("url") !== s.listSource || String(await read("read", reminder)).trim() !== reminderText || await template.file("communication-cache", { operation: "read", name: indexName }) !== indexText) return await fail("\u4FDD\u5B58\u771F\u5B9E\u4E0A\u9650\u524D\u6765\u6E90\u6216\u5B89\u5168\u7D22\u5F15\u53D8\u5316");
          if (prior === null) await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(value) });
          const back = JSON.parse(await template.file("communication-cache", { operation: "read", name }));
          if (sha(back) !== sha(saved) || await template.file("communication-cache", { operation: "read", name: indexName }) !== indexText) return await fail("\u771F\u5B9E\u4E0A\u9650\u8BC1\u636E\u672A\u5B8C\u6574\u8BFB\u56DE");
          const evidence = { version: 1, kind: "default-greeting-blocked-by-site-daily-limit", jobSource: i.jobSource, siteDailyLimitEvidenceSha256: saved.sha256, siteCommunicatedCount: saved.siteCommunicatedCount, websiteGreetingVerified: false, doNotReplay: true, observedAt: (/* @__PURE__ */ new Date()).toISOString() };
          await observe("site-daily-limit-confirmed", { evidence });
          await template.effect.resolve({ id: r.id, state: "unknown", evidence });
          if (await read("url") !== s.listSource || String(await read("read", reminder)).trim() !== reminderText || String(await read("read", button2)).trim() !== "\u786E\u5B9A") throw Error("\u4E0A\u9650\u5DF2\u4FDD\u5B58\uFF0C\u4F46\u786E\u8BA4\u524D\u9875\u9762\u53D8\u5316\uFF1B\u4FDD\u6301\u9632\u91CD\u8BB0\u5F55\u5E76\u505C\u6B62");
          await read("click", button2);
          return { version: 1, kind: "daily-default-greeting-quota-blocked", check: c, clickResult: k, receipt: r, source: s, siteDailyLimitEvidence: saved, siteDailyLimitEvidenceName: name, evidence, listSource: s.listSource, extraIntroductionSent: false, attachmentSent: false, websiteGreetingVerified: false, dayTaskComplete: false, siteDailyLimitConfirmed: true };
        }
        const remaining = lines.length === 3 && lines[0] === "\u6E29\u99A8\u63D0\u793A" && lines[2] === "\u597D" ? /^您今天已与([1-9]\d{0,3})位BOSS沟通，还剩([1-9]\d{0,3})次沟通机会哦$/u.exec(lines[1]) : null;
        if (!remaining || remainingReminderHandled) return await fail("\u7F51\u7AD9\u63D0\u793A\u5C1A\u672A\u6821\u51C6\u6216\u540C\u6B21\u63D0\u9192\u91CD\u590D\uFF1B\u4E0D\u786E\u8BA4\u672A\u77E5\u63D0\u793A\uFF0C\u4E0D\u91CD\u8BD5\u6C9F\u901A");
        const button = reminder + " .chat-block-footer a.default-btn.sure-btn";
        if (await read("count", button) !== 1 || String(await read("read", button)).trim() !== "\u597D") return await fail("\u5269\u4F59\u989D\u5EA6\u63D0\u9192\u7F3A\u5C11\u552F\u4E00\u786E\u8BA4\u6309\u94AE");
        await observe("default-greeting-remaining-quota-reminder", { reminder: { selector: reminder, text: reminderText, communicatedCount: Number(remaining[1]), remainingCount: Number(remaining[2]), buttonSelector: button, confirmedDailyLimit: false }, greetingButtonRetried: false });
        await directSelected(template, signal, { jobSource: i.jobSource, returnUrl: s.listSource });
        if (String(await read("read", reminder)).trim() !== reminderText || String(await read("read", button)).trim() !== "\u597D" || await read("url") !== s.listSource) return await fail("\u5269\u4F59\u989D\u5EA6\u63D0\u9192\u786E\u8BA4\u524D\u6765\u6E90\u5DF2\u53D8\u5316");
        remainingReminderHandled = true;
        await read("click", button);
        await delay(250);
        continue;
      }
      if (await read("count", dialog) === 1 && body.includes("\u5DF2\u5411BOSS\u53D1\u9001\u6D88\u606F")) {
        modalText = String(await read("read", dialog));
        break;
      }
      await delay(250);
    }
    if (!modalText || !modalText.includes("\u5DF2\u5411BOSS\u53D1\u9001\u6D88\u606F") || modalText.length > 5e3) return await fail("\u7F3A\u5C11\u672C\u6B21\u7F51\u7AD9\u6210\u529F\u5F39\u7A97");
    const matches = modalText.split(/\r?\n/u).map((v) => v.trim()).filter((v) => v === s.greetingText);
    if (matches.length !== 1 || directHash(matches[0]) !== s.greetingSha256) return await fail("\u7F51\u7AD9\u6210\u529F\u5F39\u7A97\u4E2D\u7684\u5B8C\u6574\u62DB\u547C\u8BED\u4E0E\u6279\u51C6\u6B63\u6587\u4E0D\u540C\uFF1B\u4E0D\u7F29\u5199\u6216\u8865\u53D1");
    let footer = dialog + " .greet-boss-footer", buttons = [];
    if (await read("count", footer) !== 1) return await fail("\u7F51\u7AD9\u6210\u529F\u5F39\u7A97\u7F3A\u5C11\u552F\u4E00\u7559\u9875\u64CD\u4F5C\u533A");
    for (let depth = 0; depth < 4; depth++) {
      const count = await read("count", footer + " > *");
      if (count < 1 || count > 8) return await fail("\u7559\u9875\u64CD\u4F5C\u533A\u7ED3\u6784\u53D8\u5316");
      const children = [];
      for (let n = 1; n <= count; n++) {
        const selector = footer + " > :nth-child(" + n + ")";
        if (await read("count", selector) !== 1) return await fail("\u7559\u9875\u64CD\u4F5C\u4E0D\u552F\u4E00");
        children.push({ selector, label: String(await read("read", selector)).trim() });
      }
      buttons = children.filter((v) => ["\u7559\u5728\u6B64\u9875", "\u7559\u5728\u672C\u9875", "\u7EE7\u7EED\u6C9F\u901A"].includes(v.label));
      if (buttons.length === 2 && buttons.some((v) => v.label === "\u7EE7\u7EED\u6C9F\u901A")) break;
      if (children.length !== 1) return await fail("\u672A\u627E\u5230\u51C6\u786E\u7684\u7559\u9875\u4E0E\u7EE7\u7EED\u6C9F\u901A\u6309\u94AE");
      footer = children[0].selector;
    }
    const stay = buttons.filter((v) => ["\u7559\u5728\u6B64\u9875", "\u7559\u5728\u672C\u9875"].includes(v.label));
    if (stay.length !== 1) return await fail("\u7F3A\u5C11\u552F\u4E00\u7684\u7559\u5728\u672C\u9875\u6309\u94AE");
    const acknowledgement = { version: 1, selector: dialog, text: modalText, actualMessage: matches[0], actualMessageSha256: directHash(matches[0]), approvedMessageSha256: s.greetingSha256, buttons, observedAt: (/* @__PURE__ */ new Date()).toISOString() };
    const cachedAcknowledgement = await observe("default-greeting-website-acknowledgement", { acknowledgement, check: c, clickResult: k });
    await directSelected(template, signal, { jobSource: i.jobSource, returnUrl: s.listSource });
    if (String(await read("read", stay[0].selector)).trim() !== stay[0].label) return await fail("\u7559\u9875\u6309\u94AE\u53D8\u5316");
    await read("click", stay[0].selector);
    let dismissed = false;
    for (let n = 0; n < 15; n++) {
      if (await read("url") !== s.listSource) return await fail("\u7559\u9875\u540E\u5730\u5740\u53D8\u5316");
      if (!String(await read("read", "body")).includes("\u5DF2\u5411BOSS\u53D1\u9001\u6D88\u606F")) {
        dismissed = true;
        break;
      }
      await delay(200);
    }
    if (!dismissed) return await fail("\u7559\u5728\u672C\u9875\u5C1A\u672A\u5B8C\u6210\uFF0C\u4E0D\u518D\u6B21\u70B9\u51FB");
    await directSelected(template, signal, { jobSource: i.jobSource, returnUrl: s.listSource });
    const selectors = { jobTitle: PANEL.jobTitle, contact: PANEL.contact, city: PANEL.jobCity, salary: PANEL.salary }, rendered = {};
    for (const [key, selector] of Object.entries(selectors)) {
      if (await read("count", selector) !== 1) return await fail("\u7559\u9875\u5B57\u6BB5\u4E0D\u552F\u4E00\uFF1A" + key);
      rendered[key] = String(await read("read", selector)).trim();
    }
    return { version: 1, kind: "daily-default-greeting-acknowledged", check: c, clickResult: k, receipt: r, source: s, acknowledgement, cachedAcknowledgement, selectors, rendered, observedAt: (/* @__PURE__ */ new Date()).toISOString(), listSource: s.listSource, stayedOnList: true, fullGreetingVerified: true, websiteGreetingVerified: false, attachmentSent: false, extraIntroductionSent: false, dayTaskComplete: false };
  } catch (error) {
    if (signal.aborted || stopping || error?.communicationCacheFailure) throw error;
    return await fail(String(error?.message || error).slice(0, 800));
  }
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default2 = (ctx) => stdin_default(Object.freeze({ ...ctx, constants }));
export {
  stdin_default2 as default
};
