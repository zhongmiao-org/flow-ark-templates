import { createHash } from "node:crypto";
var canonical = (v) => Array.isArray(v) ? v.map(canonical) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical(v[k])])) : v;
var digest = (v) => createHash("sha256").update(JSON.stringify(canonical(v))).digest("hex");
var closingValid = (v) => {
  const { sha256, ...body } = v;
  return sha256 === digest(body);
};
async function closingProgress(template, signal, c, change) {
  const name = c.progressName, raw = await template.file("communication-cache", { operation: "read", name }), p = JSON.parse(raw);
  if (!closingValid(p) || p.accountKey !== c.accountKey || p.fixedUnreadSetSha256 !== c.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
  if (!change) return p;
  const next = change(structuredClone(p));
  next.revision++;
  next.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  delete next.sha256;
  next.sha256 = digest(next);
  if (await template.file("communication-cache", { operation: "read", name }) !== raw) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  signal.throwIfAborted();
  await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(next) });
  const back = JSON.parse(await template.file("communication-cache", { operation: "read", name }));
  if (!closingValid(back) || back.sha256 !== next.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
  return back;
}
var stdin_default = async ({ input, template, signal, artifact }) => {
  if (input?.kind !== "unread-closing-cohort") throw Error("\u7F3A\u5C11\u56FA\u5B9A\u6536\u5C3E\u6765\u6E90");
  const p = await closingProgress(template, signal, input), confirmed = p.completed.filter((x) => x.status === "confirmed"), review = p.completed.filter((x) => x.status === "review"), remaining = input.memberCount - p.completed.length;
  const result = { version: 1, kind: "fixed-unread-closing-summary", siteDailyLimitConfirmed: true, newGreeting: false, newMembersAdded: 0, fixedUnreadSetSha256: input.fixedUnreadSetSha256, memberCount: input.memberCount, originalUnreadMessageCount: input.unreadMessageCount, confirmedReplies: confirmed.length, skipped: p.completed.length - confirmed.length - review.length, needsReview: review.length, remaining, activeMember: p.active?.memberKey || null, completed: p.completed, progressSha256: p.sha256, dayTaskComplete: remaining === 0, decision: remaining ? "review" : "complete", progress: input.fixedUnreadSetSha256 + ":" + p.completed.length, reason: remaining ? "\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u5C1A\u6709\u672A\u5B8C\u6210\u6210\u5458\uFF0C\u91CD\u5F00\u540E\u4ECE\u6D3B\u8DC3\u4F1A\u8BDD\u6062\u590D" : "\u56FA\u5B9A\u672A\u8BFB\u4F1A\u8BDD\u96C6\u5408\u5904\u7406\u5B8C\u6BD5\uFF1B\u4E4B\u540E\u65B0\u5230\u7684\u5176\u4ED6\u4F1A\u8BDD\u672A\u52A0\u5165\u672C\u8F6E" };
  await artifact("fixed-unread-closing-summary.json", JSON.stringify(result, null, 2));
  await template.result(result);
  return result;
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default2 = (ctx) => stdin_default(Object.freeze({ ...ctx, constants }));
export {
  stdin_default2 as default
};
