import { createHash } from "node:crypto";
var canonical = (v) => Array.isArray(v) ? v.map(canonical) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical(v[k])])) : v;
var digest = (v) => createHash("sha256").update(JSON.stringify(canonical(v))).digest("hex");
async function safetyIndex(template, signal, accountKey, contextId, initialize = false) {
  const name = "account-outbound-safety-v1-" + accountKey + ".json";
  let data, existed = true, baseline;
  try {
    baseline = await template.file("communication-cache", { operation: "read", name });
    data = JSON.parse(baseline);
  } catch (error) {
    if (!String(error.message || error).includes("ENOENT")) throw error;
    if (!initialize) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
    existed = false;
    data = { version: 1, kind: "boss-account-outbound-safety", accountKey, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (existed) {
    const { sha256, ...body } = data;
    if (sha256 !== digest(body)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
  }
  if (data.version !== 1 || data.kind !== "boss-account-outbound-safety" || data.accountKey !== accountKey || !Number.isSafeInteger(data.revision) || data.revision < 0 || !Array.isArray(data.records) || data.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
  const records = /* @__PURE__ */ new Set();
  for (const r of data.records) {
    if (!["first-contact", "reply"].includes(r.type) || !/^[a-f0-9]{64}$/.test(r.businessKey) || !Array.isArray(r.sightings) || !r.sightings.length || r.sightings.length > 100 || records.has(r.type + ":" + r.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
    records.add(r.type + ":" + r.businessKey);
    for (const s of r.sightings) if (typeof s.contextId !== "string" || !s.contextId || !/^[a-f0-9]{64}$/.test(s.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(s.status) || !/^\d{4}-\d{2}-\d{2}$/.test(s.day) || typeof s.timeZone !== "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
  }
  let dirty = !existed;
  const merge = (state) => {
    if (!Array.isArray(state?.applicationIntents) || !Array.isArray(state?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
    for (const [type, rows] of [["first-contact", state.applicationIntents], ["reply", state.replyIntents]]) for (const i of rows) {
      if ((type === "first-contact" ? i.accountSourceSha256 : i.accountKey) !== accountKey) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
      if (!/^[a-f0-9]{64}$/.test(i.key) || !i.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(i.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
      const businessKey = type === "first-contact" ? digest(["boss-job-safety-v1", accountKey, i.jobId]) : createHash("sha256").update(["boss-text-reply-v1", accountKey, i.incomingMessageId].join(":")).digest("hex");
      let r = data.records.find((r2) => r2.type === type && r2.businessKey === businessKey);
      if (!r) {
        r = { type, businessKey, jobId: i.jobId, ...type === "reply" ? { conversationKey: i.conversationKey, incomingMessageId: i.incomingMessageId } : {}, sightings: [] };
        data.records.push(r);
        dirty = true;
      }
      if (r.jobId !== i.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
      const sight = { contextId, intentKey: i.key, status: i.status, day: i.day, timeZone: i.timeZone, contentSha256: i.contentSha256 || null, sourceSha256: i.sourceSha256 || null };
      if (!r.sightings.some((s) => JSON.stringify(canonical(s)) === JSON.stringify(canonical(sight)))) {
        r.sightings.push(sight);
        dirty = true;
      }
      if (r.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
    }
    if (data.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
  };
  const save = async () => {
    signal.throwIfAborted();
    if (dirty) {
      if (existed && await template.file("communication-cache", { operation: "read", name }) !== baseline) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
      data.records.sort((a, b) => (a.type + ":" + a.businessKey).localeCompare(b.type + ":" + b.businessKey));
      for (const r of data.records) r.sightings.sort((a, b) => JSON.stringify(canonical(a)).localeCompare(JSON.stringify(canonical(b))));
      data.revision++;
      data.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      delete data.sha256;
      data.sha256 = digest(data);
      await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(data) });
      dirty = false;
      baseline = JSON.stringify(data);
      existed = true;
    }
    const back = JSON.parse(await template.file("communication-cache", { operation: "read", name }));
    const { sha256, ...body } = back;
    if (sha256 !== digest(body) || sha256 !== data.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
    return { revision: data.revision, sha256: data.sha256, records: data.records.length };
  };
  return { data, name, merge, save, blocked: (type, key) => data.records.some((r) => r.type === type && r.businessKey === key) };
}
var closingValid = (v) => {
  const { sha256, ...body } = v;
  return sha256 === digest(body);
};
async function closingProgress(template, signal, c, change) {
  const name = c.progressName, raw = await template.file("communication-cache", { operation: "read", name }), p = JSON.parse(raw);
  if (!closingValid(p) || p.accountKey !== c.accountKey || p.fixedUnreadSetSha256 !== c.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
  if (!change) return p;
  const next = change(structuredClone(p));
  next.revision++;
  next.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  delete next.sha256;
  next.sha256 = digest(next);
  if (await template.file("communication-cache", { operation: "read", name }) !== raw) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  signal.throwIfAborted();
  await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(next) });
  const back = JSON.parse(await template.file("communication-cache", { operation: "read", name }));
  if (!closingValid(back) || back.sha256 !== next.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
  return back;
}
async function closingMessages(read) {
  const count = await read("count", "li.message-item");
  if (!Number.isSafeInteger(count) || count < 1 || count > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
  const rows = [];
  for (let n = 1; n <= count; n++) {
    const selector = "li.message-item:nth-child(" + n + " of li.message-item)", mid = await read("attribute", selector, "data-mid"), cls = await read("attribute", selector, "class");
    if (!/^\d{6,40}$/.test(mid || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
    const texts = await read("count", selector + " .text-content");
    if (texts > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
    const text = texts === 1 ? String(await read("read", selector + " .text-content")).trim() : null, context = text === null ? String(await read("read", selector)).trim() : null;
    if ((text || context || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
    const systemText = !!text && /^您正在与Boss.+沟通$/u.test(text), direction = !systemText && text !== null && cls.split(/\s+/u).includes("item-myself") ? "outgoing" : !systemText && text !== null && cls.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
    rows.push({ mid, direction, text, context });
  }
  if (new Set(rows.map((r) => r.mid)).size !== rows.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
  return rows;
}
async function closingRecipient(read, c) {
  const url = new URL(await read("url"));
  if (url.origin !== "https://www.zhipin.com" || url.pathname !== "/web/geek/chat" || await read("count", ".chat-conversation .user-info") !== 1) return false;
  const header = String(await read("read", ".chat-conversation .user-info")).trim(), compact = (v) => v.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
  const expected = compact(c.member.identityLine), observed = compact(header), count = await read("count", ".friend-content.selected");
  if (count > 1) return false;
  const selected = count === 1 ? compact(String(await read("read", ".friend-content.selected"))) : null;
  if (observed === expected) return selected === null || selected.includes(expected);
  const name = /^(.{1,20}?(?:先生|女士))/u.exec(expected)?.[1];
  return !!name && expected.endsWith("\u730E\u5934\u987E\u95EE") && observed === name + "\u730E\u5934\u987E\u95EE" && (selected !== null ? selected.includes(expected) : c.member.searchIdentityProof?.identityLine === c.member.identityLine && compact(c.member.searchIdentityProof.targetText).includes(expected));
}
var stdin_default = async ({ input, signal, template, artifact, logger }) => {
  if (input?.kind !== "chat-reply-dispatch") throw Error("Missing single-dispatch stage");
  const sha = (v) => createHash("sha256").update(v).digest("hex");
  const clean = (v) => String(v).replace(/\s+/g, "");
  const read = (operation, selector, value) => {
    signal.throwIfAborted();
    return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value !== void 0 ? { value } : {}, timeoutMs: 3e3 });
  };
  const messages = () => closingMessages(read);
  let proof = null;
  if (input.dispatched) {
    try {
      const until = Date.now() + 1e4;
      while (Date.now() < until) {
        if (new URL(await read("url")).origin !== "https://www.zhipin.com" || new URL(await read("url")).pathname !== "/web/geek/chat" || String(await read("read", input.accountSelector)).trim() !== input.accountLabel || String(await read("read", input.jobSelector)).trim() !== input.chatJobTitle || !await closingRecipient(read, input) || String(await read("read", input.recipientSelector)).trim() !== input.recipientLabel) throw Error("Conversation changed after dispatch");
        const rows = await messages();
        if (JSON.stringify(rows.slice(0, input.rows.length)) !== JSON.stringify(input.rows)) throw Error("Original conversation history changed after dispatch");
        const newOutgoing = rows.slice(input.rows.length).filter((r) => r.direction === "outgoing");
        if (newOutgoing.length > 1) throw Error("More than one new outbound message; no attribution");
        if (newOutgoing.length === 1) {
          const sent = newOutgoing[0];
          if (clean(sent.text) !== clean(input.reply)) throw Error("New outbound content differs from fixed AI reply");
          const selector = 'li.message-item[data-mid="' + sent.mid + '"] > div > div > i';
          if (await read("count", selector) === 1) {
            const receipt = String(await read("read", selector)).trim();
            if (["\u9001\u8FBE", "\u5DF2\u8BFB"].includes(receipt)) {
              proof = { version: 1, kind: "existing-conversation-ai-reply-delivery", incomingMessageId: input.incomingMessageId, outgoingMessageId: sent.mid, jobId: input.jobId, jobSource: input.jobSource, conversationKey: input.conversationKey, accountKey: input.accountKey, operationId: input.effect.id, operationKey: input.key, runId: input.effect.runId, sourceSha256: input.sourceSha256, approvedText: input.reply, contentSha256: input.contentSha256, observedText: sent.text, observedSha256: sha(sent.text), receipt, observedAt: (/* @__PURE__ */ new Date()).toISOString(), model: input.model, profileRef: input.profile.ref, configurationRevision: input.configurationRevision, rows };
              break;
            }
          }
        }
        await new Promise((r) => setTimeout(r, 200));
      }
      if (!proof) throw Error("Website delivery receipt did not appear within the bounded observation");
      await artifact("reply-delivery-proof.json", JSON.stringify(proof, null, 2));
      await template.effect.resolve({ id: input.effect.id, state: "confirmed", evidence: proof });
      const state = await template.state.get();
      if (state.replyIntents.filter((i) => i.key === input.key && i.status === "reserved" && i.contentSha256 === input.contentSha256).length !== 1) throw Error("Reply reservation changed before receipt persistence");
      await template.state.set({ ...state, replyIntents: state.replyIntents.map((i) => i.key === input.key ? { ...i, status: "confirmed" } : i) });
      const saved = await template.state.get();
      if (saved.replyIntents.filter((i) => i.key === input.key && i.status === "confirmed").length !== 1) throw Error("Reply confirmation could not be read back");
      const index = await safetyIndex(template, signal, input.accountKey, input.contextId);
      index.merge(saved);
      const safety = await index.save();
      if (!index.data.records.some((r) => r.type === "reply" && r.businessKey === input.key && r.sightings.some((s) => s.contextId === input.contextId && s.intentKey === input.key && s.status === "confirmed"))) throw Error("\u9001\u8FBE\u5DF2\u6838\u5BF9\uFF0C\u4F46\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u786E\u8BA4\u672A\u8BFB\u56DE\uFF1B\u4FDD\u7559\u539F\u610F\u56FE\uFF0C\u4E0D\u91CD\u53D1");
      await artifact("reply-safety-confirmation.json", JSON.stringify({ operationKey: input.key, incomingMessageId: input.incomingMessageId, ...safety }, null, 2));
      logger.info({ status: "reply-confirmed", incomingMessageId: input.incomingMessageId, outgoingMessageId: proof.outgoingMessageId, receipt: proof.receipt });
    } catch (error) {
      if (!proof) {
        await template.effect.resolve({ id: input.effect.id, state: "unknown", evidence: { reason: String(error.message || error), incomingMessageId: input.incomingMessageId, jobSource: input.jobSource, doNotReplay: true } });
        const state = await template.state.get();
        await template.state.set({ ...state, replyIntents: state.replyIntents.map((i) => i.key === input.key ? { ...i, status: "unknown" } : i) });
        const unknownState = await template.state.get(), index = await safetyIndex(template, signal, input.accountKey, input.contextId);
        index.merge(unknownState);
        await index.save();
      }
      await template.attention({ key: "reply-unresolved:" + input.key, title: "\u672C\u6761\u56DE\u590D\u9700\u8981\u6838\u5BF9\u9001\u8FBE\uFF0C\u8BF7\u52FF\u91CD\u53D1", detail: { jobTitle: input.jobTitle, jobSource: input.jobSource, incomingMessageId: input.incomingMessageId, reason: String(error.message || error), doNotReplay: true } });
      throw error;
    }
  }
  const result = { kind: "chat-reply-result", accountKey: input.accountKey, status: proof ? "confirmed" : input.decision === "skip" ? "skipped-no-work-question" : input.status || "skipped", jobId: input.jobId || null, jobTitle: input.jobTitle || null, jobSource: input.jobSource || null, reason: proof ? "AI reply has a real website delivery receipt" : input.reason, incomingMessageId: input.incomingMessageId || null, outgoingMessageId: proof?.outgoingMessageId || null, receipt: proof?.receipt || null, newGreeting: false, attachmentSent: false };
  if (input.member) {
    const p = await closingProgress(template, signal, input, (q) => {
      const prior = q.completed.find((c) => c.memberKey === input.member.key);
      if (prior) {
        if (prior.status !== "review" || prior.replyPolicyVersion === input.replyPolicyVersion) return q;
        q.reviewHistory = [...q.reviewHistory || [], prior];
        q.completed = q.completed.filter((c) => c.memberKey !== input.member.key);
      }
      if (q.active && q.active.memberKey !== input.member.key) throw Error("\u9001\u8FBE\u6838\u5BF9\u540E\u7684\u6D3B\u8DC3\u4F1A\u8BDD\u5DF2\u53D8\u5316");
      q.completed.push({ memberKey: input.member.key, identityLine: input.member.identityLine, replyPolicyVersion: input.replyPolicyVersion || null, status: proof ? "confirmed" : input.decision === "review" ? "review" : input.decision === "skip" ? "skipped-no-work-question" : input.status || "skipped", reason: result.reason, incomingMessageId: input.incomingMessageId || null, outgoingMessageId: proof?.outgoingMessageId || null, receipt: proof?.receipt || null, operationKey: input.key || null, modelRequestId: input.model?.requestId || null, checkedAt: (/* @__PURE__ */ new Date()).toISOString() });
      q.active = null;
      return q;
    });
    result.fixedUnreadSetSha256 = input.fixedUnreadSetSha256;
    result.memberKey = input.member.key;
    result.completed = p.completed.length;
    result.remaining = input.memberCount - p.completed.length;
    result.progressSha256 = p.sha256;
  }
  await artifact("fixed-unread-member-result.json", JSON.stringify(result, null, 2));
  return result;
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default2 = (ctx) => stdin_default(Object.freeze({ ...ctx, constants }));
export {
  stdin_default2 as default
};
