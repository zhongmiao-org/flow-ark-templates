var stdin_default = async ({ input, template, signal }) => {
  signal.throwIfAborted();
  if (!input || input.version !== 1 || input.ready !== true || input.status !== "sources-ready" || input.resume?.status !== "ready" || input.accountVerified !== false || input.eligibleForActions !== false) throw new Error("\u8D44\u6599\u6765\u6E90\u5C31\u7EEA\u7ED3\u679C\u4E0D\u4E00\u81F4");
  return template.result(input);
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default2 = (ctx) => stdin_default(Object.freeze({ ...ctx, constants }));
export {
  stdin_default2 as default
};
