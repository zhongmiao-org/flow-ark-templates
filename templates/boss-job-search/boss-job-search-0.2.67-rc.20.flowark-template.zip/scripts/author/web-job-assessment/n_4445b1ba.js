import { createHash as v } from "node:crypto";
var J = async ({ input: d, signal: F }) => {
  F.throwIfAborted();
  const r = d?.preflight, e = d?.collection;
  if (r?.readyForBody !== true || r.result?.version !== 1 || r.result?.kind !== "web-jd-body" || r.result?.status !== "body-candidate-required" || !r.metadata || r.metadata.sourceSha256 !== r.result.sourceSha256 || r.result.accountVerified !== false || r.result.eligibleForActions !== false || r.result.modelInputAllowed !== false) throw Error("\u7F3A\u5C11\u672C\u6B21\u5141\u8BB8\u8BFB\u53D6\u6B63\u6587\u5019\u9009\u7684\u9884\u68C0\u6765\u6E90");
  if (!e || e.version !== 2 || e.operation !== "collect" || e.renderPolicy !== "bounded-rendered-text-v1" || e.selector !== "html" || !Array.isArray(e.framePath) || e.framePath.length || typeof e.url != "string" || e.url !== e.documentUrl || typeof e.complete != "boolean" || !Array.isArray(e.fields) || e.fields.length !== 5 || Buffer.byteLength(e.url) > 16384 || Buffer.byteLength(JSON.stringify(e)) > 131072) throw Error("\u7F3A\u5C11\u672C\u6B21\u540C\u6B21\u5143\u6570\u636E\u4E0E\u5DF2\u6392\u7248\u6B63\u6587\u91C7\u96C6");
  const l = [["description", "div:nth-of-type(1) > div:nth-of-type(2) > div:nth-of-type(1) > div:nth-of-type(3)", "rendered-text", true], ["title", "head > title", "text", true], ["loginGate", "div:nth-of-type(3) > div:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1) > span:nth-of-type(1)", "text", false], ["jobTitle", "h1", "text", false], ["companyLabel", "div:nth-of-type(1) > div:nth-of-type(2) > div:nth-of-type(2) > div > div:nth-of-type(3) > div:nth-of-type(2)", "text", false]], c = ["hidden-target", "hidden-descendant", "line-clamp", "overflow-clip", "unsupported-layout", "embedded-content", "generated-content"];
  let f = true;
  for (let i = 0; i < l.length; i++) {
    const u = e.fields[i], [I, T, b, q] = l[i];
    if (!u || u.key !== I || u.selector !== T || u.operation !== b || u.attribute !== null || u.required !== q || !Number.isSafeInteger(u.count) || u.count < 0 || !Array.isArray(u.issues) || !(u.value === null || typeof u.value == "string")) throw Error("\u6B63\u6587\u6765\u6E90\u5B57\u6BB5\u4E0E\u5F53\u524D\u7F16\u6392\u4E0D\u7B26");
    if (JSON.stringify(u.issues) !== JSON.stringify(c.filter((w) => u.issues.includes(w))) || b !== "rendered-text" && u.issues.length || u.count !== 1 && (u.value !== null || u.issues.length)) throw Error("\u6B63\u6587\u6765\u6E90\u5B57\u6BB5\u539F\u56E0\u65E0\u6548");
    let S = u.count === 0 ? "missing" : u.count > 1 ? "ambiguous" : u.issues.some((w) => w.startsWith("hidden-")) ? "hidden" : u.issues.some((w) => ["line-clamp", "overflow-clip"].includes(w)) ? "clipped" : u.issues.length ? "unsupported" : u.value === null ? "missing-attribute" : u.value.trim() ? "ok" : "empty";
    if (u.status !== S || u.issues.length && u.value !== null || u.count === 1 && !u.issues.length && u.value === null || typeof u.value == "string" && Buffer.byteLength(u.value) > (b === "rendered-text" ? 65536 : 8192)) throw Error("\u6B63\u6587\u6765\u6E90\u5B57\u6BB5\u72B6\u6001\u6216\u957F\u5EA6\u65E0\u6548");
    (["ambiguous", "hidden", "clipped", "unsupported"].includes(S) || u.required && S !== "ok") && (f = false);
  }
  if (f !== e.complete) throw Error("\u6B63\u6587\u91C7\u96C6\u5B8C\u6574\u6027\u4E0E\u5B57\u6BB5\u72B6\u6001\u4E0D\u7B26");
  const n = new URL(e.url), [p, D, t, A, s] = e.fields, a = (i, u) => i.status === "ok" && i.count === 1 && typeof i.value == "string" && i.value.trim().length <= u ? i.value.trim() : null, g = a(D, 4096), C = a(A, 200), o = a(s, 500), m = a(t, 500), E = { origin: n.origin, pathname: n.pathname, title: g }, h = r.metadata, L = n.protocol === "https:" && ["www.zhipin.com", "zhipin.com"].includes(n.hostname) && !n.username && !n.password && (!n.port || n.port === "443") && /^\/job_detail\/[^/]+\.html$/.test(n.pathname) && JSON.stringify(E) === JSON.stringify(h.page) && C === h.jobTitle && o === h.companyLabel, B = p.status === "ok" && typeof p.value == "string" ? p.value : null, N = m === "\u767B\u5F55\u67E5\u770B\u5B8C\u6574\u5185\u5BB9" || B !== null && /登录查看完整内容|立即登录|登录\s*\/\s*注册|短信验证码/.test(B);
  let y = L ? N ? "login-required" : !f || !g || !C || !o || t.status === "ok" && m !== "\u767B\u5F55\u67E5\u770B\u5B8C\u6574\u5185\u5BB9" || !B?.trim() ? "body-incomplete" : "body-review-required" : "source-changed";
  const k = B === null ? null : v("sha256").update(B).digest("hex"), x = `BOSS\u7F51\u9875JD\u6765\u6E90
\u9875\u9762\uFF1A${n.origin}${n.pathname}
\u5C97\u4F4D\uFF1A${C}
\u516C\u53F8\u5019\u9009\uFF08\u672A\u6838\u9A8C\uFF09\uFF1A${o}
\u6B63\u6587SHA-256\uFF1A${k}`;
  y === "body-review-required" && (x.length > 4096 || B.length > 1e5) && (y = "review-too-large");
  const O = { "source-changed": "\u6B63\u6587\u91C7\u96C6\u7684\u9875\u9762\u3001\u5C97\u4F4D\u6216\u516C\u53F8\u5019\u9009\u4E0E\u672C\u6B21\u9884\u68C0\u4E0D\u4E00\u81F4\uFF0C\u505C\u6B62\u91C7\u7528\u3002", "login-required": "\u518D\u6B21\u91C7\u96C6\u53D1\u73B0\u767B\u5F55\u906E\u6321\u6216\u6B63\u6587\u4ECD\u542B\u767B\u5F55\u754C\u9762\u63D0\u793A\uFF0C\u4E0D\u91C7\u7528\u6B63\u6587\u3002", "body-incomplete": "\u6B63\u6587\u4E3A\u7A7A\u3001\u9690\u85CF\u3001\u88C1\u5207\u3001\u65E0\u6CD5\u5224\u5B9A\uFF0C\u6216\u5143\u6570\u636E\u4E0D\u5B8C\u6574\uFF0C\u8BF7\u672C\u4EBA\u6838\u5BF9\u3002", "body-review-required": "\u6709\u9650\u7B56\u7565\u5DF2\u53D6\u5F97\u6B63\u6587\u5019\u9009\uFF1B\u4ECD\u987B\u672C\u4EBA\u5B8C\u6574\u9605\u8BFB\uFF0C\u4E0D\u80FD\u636E\u6B64\u8BA4\u5B9A\u672A\u5220\u8282\u3002", "review-too-large": "\u5B8C\u6574\u76EE\u6807\u6216\u6B63\u6587\u8D85\u8FC7\u4EBA\u5DE5\u6838\u5BF9\u4E0A\u9650\uFF0C\u6574\u6B21\u505C\u6B62\uFF0C\u4E0D\u622A\u65AD\u3002" }, j = { kind: "associated-web-jd-body-source", page: E, jobTitle: C, companyLabel: o, companyVerified: false, preflight: { page: h.page, jobTitle: h.jobTitle, companyLabel: h.companyLabel, sourceSha256: h.sourceSha256 }, fields: e.fields.map((i) => ({ key: i.key, count: i.count, status: i.status, issues: i.issues })), collectionComplete: f, renderPolicy: e.renderPolicy, descriptionRead: B !== null, descriptionSha256: k, descriptionComplete: false, humanCompletenessDeclaration: false }, R = v("sha256").update(JSON.stringify({ source: j, status: y })).digest("hex");
  return F.throwIfAborted(), { readyForReview: y === "body-review-required", review: y === "body-review-required" ? { version: 1, target: x, content: B } : null, attentionKey: "web-jd-body:" + R, result: { version: 1, kind: "web-jd-body", status: y, reason: O[y], source: j, sourceSha256: R, accountVerified: false, eligibleForActions: false, modelInputAllowed: false, nextAction: "ask-user", checkedAt: (/* @__PURE__ */ new Date()).toISOString() } };
};
var M = async ({ input: d, signal: F }) => {
  F.throwIfAborted();
  const r = d?.candidate, e = d?.human?.result, l = d?.configuration;
  if (r?.readyForReview !== true || r.result?.status !== "body-review-required" || r.result?.kind !== "web-jd-body" || typeof r.review?.content != "string" || typeof r.review?.target != "string") throw Error("\u7F3A\u5C11\u672C\u6B21\u56FA\u5B9A\u539F\u6587\u6838\u5BF9\u5019\u9009");
  const c = r.result, f = (o) => v("sha256").update(JSON.stringify(o)).digest("hex");
  if (v("sha256").update(r.review.content).digest("hex") !== c.source?.descriptionSha256 || e?.version !== 1 || e.kind !== "web-jd-body" || e.status !== "body-source-confirmed" || e.assessmentRequested !== true || e.accountVerified !== false || e.eligibleForActions !== false || e.modelInputAllowed !== false || e.sourceSha256 !== f({ parent: c.sourceSha256, status: "body-source-confirmed" })) throw Error("\u7F3A\u5C11\u672C\u6B21\u660E\u786E\u8BF7\u6C42\u8BC4\u4F30\u7684\u4EBA\u5DE5\u56DE\u6267");
  const p = e.source?.humanReviewedAt;
  if (typeof p != "string" || !Number.isFinite(Date.parse(p))) throw Error("\u672C\u4EBA\u6838\u5BF9\u65F6\u95F4\u65E0\u6548");
  const D = { ...c.source, descriptionComplete: true, humanCompletenessDeclaration: true, humanDecision: "\u786E\u8BA4\u672C\u6B21\u6B63\u6587\u5E76\u8BC4\u4F30", humanReviewedAt: p };
  if (JSON.stringify(e.source) !== JSON.stringify(D)) throw Error("\u4EBA\u5DE5\u56DE\u6267\u4E0E\u672C\u6B21\u539F\u6587\u6765\u6E90\u4E0D\u7B26");
  if (l?.version !== 1 || l.operation !== "configuration" || !Number.isSafeInteger(l.revision) || l.revision < 0) throw Error("\u7F3A\u5C11\u672C\u6B21\u56FA\u5B9A\u6C42\u804C\u914D\u7F6E\u4E0E\u4FEE\u8BA2");
  const t = l.value;
  if (!t || !["cities", "excludedRoles", "replyDailyLimit", "replyTimeZone", "salaryMax", "salaryMin", "targetRoles", "titleKeywords", "firstContactDailyBudget"].every((o) => Object.hasOwn(t, o)) || Object.keys(t).some((o) => !["cities", "excludedRoles", "replyDailyLimit", "replyTimeZone", "salaryMax", "salaryMin", "targetRoles", "titleKeywords", "firstContactDailyBudget", "knownContactedJobs", "knownContactAccountAlias", "knownContactPhoneMask", "knownGreetingDate", "knownGreetingsUsed", "acceptanceNewGreetings", "confirmedPersonalFacts", "recoveryEvidenceName"].includes(o))) throw Error("\u6C42\u804C\u6761\u4EF6\u7ED3\u6784\u65E0\u6548");
  if (!Number.isSafeInteger(t.replyDailyLimit) || t.replyDailyLimit < 0 || t.replyDailyLimit > 100 || typeof t.replyTimeZone != "string" || !t.replyTimeZone.trim() || t.replyTimeZone.length > 100) throw Error("\u56DE\u590D\u989D\u5EA6\u914D\u7F6E\u7ED3\u6784\u65E0\u6548");
  const A = (o) => o.normalize("NFKC").trim().toLocaleLowerCase("en-US"), s = [];
  if (!Number.isSafeInteger(t.firstContactDailyBudget) || t.firstContactDailyBudget < 0 || t.firstContactDailyBudget > 150) throw Error("\u672C\u65E5\u81EA\u52A8\u65B0\u589E\u9884\u7B97\u683C\u5F0F\u65E0\u6548\uFF1B\u987B\u4E3A0\u81F3150\u7684\u6574\u6570");
  for (const o of ["targetRoles", "titleKeywords", "excludedRoles", "cities"]) {
    if (!Array.isArray(t[o]) || t[o].length > 20 || t[o].some((E) => typeof E != "string" || E.length > 100)) throw Error("\u6761\u4EF6\u5217\u8868\u7ED3\u6784\u65E0\u6548");
    const m = t[o].map(A);
    (m.some((E) => !E) || new Set(m).size !== m.length) && s.push("\u6761\u4EF6\u5B58\u5728\u7A7A\u767D\u6216\u91CD\u590D\u9879\uFF1A" + o);
  }
  t.titleKeywords.length || s.push("\u5C1A\u672A\u914D\u7F6E\u53EF\u63A5\u53D7\u5C97\u4F4D\u6807\u9898\u5173\u952E\u8BCD"), t.targetRoles.length || s.push("\u5C1A\u672A\u660E\u786E\u76EE\u6807\u804C\u4F4D"), t.targetRoles.some((o) => t.excludedRoles.map(A).includes(A(o))) && s.push("\u76EE\u6807\u4E0E\u6392\u9664\u65B9\u5411\u51B2\u7A81");
  for (const o of ["salaryMin", "salaryMax"]) if (!Number.isSafeInteger(t[o]) || t[o] < 0 || t[o] > 1e6) throw Error("\u85AA\u8D44\u6761\u4EF6\u7ED3\u6784\u65E0\u6548");
  t.salaryMax > 0 && t.salaryMin > t.salaryMax && s.push("\u6708\u85AA\u4E0A\u9650\u4F4E\u4E8E\u4E0B\u9650");
  const a = await J({ input: { preflight: d.preflight, collection: d.collection }, signal: F });
  (!a.readyForReview || a.result.sourceSha256 !== c.sourceSha256 || a.review?.content !== r.review.content || a.review?.target !== r.review.target) && s.push("\u786E\u8BA4\u540E\u7684\u7F51\u9875\u6765\u6E90\u3001\u5B57\u6BB5\u72B6\u6001\u6216\u7CBE\u786E\u6B63\u6587\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u91C7\u7528\uFF0C\u8BF7\u91CD\u65B0\u91C7\u96C6\u6838\u5BF9"), (r.review.content.length > 2e4 || Buffer.byteLength(r.review.content) > 65536) && s.push("\u5B8C\u6574\u6B63\u6587\u8D85\u8FC7\u672C\u5165\u53E3\u8BC4\u4F30\u8F93\u5165\u9884\u7B97\uFF0C\u6574\u6B21\u505C\u6B62\uFF0C\u4E0D\u622A\u65AD\u6216\u81EA\u52A8\u6458\u8981");
  const g = { ...D, kind: "reviewed-web-jd-assessment-source", confirmationSha256: e.sourceSha256, configurationRevision: l.revision, recheck: { sourceSha256: a.result.sourceSha256, status: a.result.status, source: a.result.source } }, C = { version: 1, kind: "web-job-assessment-advice", decision: "review", nextAction: "ask-user", reason: s.join("\uFF1B"), issues: s, source: g, accountVerified: false, eligibleForActions: false, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), note: "\u4EC5\u5185\u90E8\u5EFA\u8BAE\uFF1B\u672A\u6838\u9A8C\u8D26\u53F7/\u516C\u53F8\uFF0C\u4E0D\u8C03\u7528\u7AD9\u70B9\u52A8\u4F5C\uFF0C\u4E0D\u81EA\u52A8\u91CD\u8BD5\u3002" };
  return F.throwIfAborted(), { ready: s.length === 0, job: { title: c.source.jobTitle, description: r.review.content, completeDeclared: true, sourceLabel: c.source.page.origin + c.source.page.pathname }, configuration: t, source: g, reviewRecord: { reviewKey: "web-jd-input:" + f({ source: g, issues: s }), result: C } };
};
var freeze = (v2) => {
  if (v2 && typeof v2 === "object") {
    Object.values(v2).forEach(freeze);
    Object.freeze(v2);
  }
  return v2;
};
var constants = freeze({});
var stdin_default = (ctx) => M(Object.freeze({ ...ctx, constants }));
export {
  stdin_default as default
};
