import { createHash as A } from "node:crypto";
var d = (u) => typeof u == "string" && u.length > 0 && u.length <= 200 && u === u.trim() && !/[\u0000-\u001f\u007f]/.test(u);
var D = (u) => A("sha256").update(JSON.stringify(u)).digest("hex");
var B = (u) => {
  if (u?.version !== 1 || u.operation !== "state.read" || typeof u.contextId != "string" || !Number.isSafeInteger(u.revision) || u.revision < 0 || !u.value || typeof u.value != "object" || Array.isArray(u.value)) throw Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u6700\u65B0\u72B6\u6001");
  const s = u.value.conversationControls === void 0 ? [] : u.value.conversationControls;
  if (!Array.isArray(s) || s.length > 100) throw Error("\u4F1A\u8BDD\u63A7\u5236\u8BB0\u5F55\u7ED3\u6784\u6216\u6570\u91CF\u65E0\u6548");
  const t = /* @__PURE__ */ new Set();
  for (const e of s) {
    if (!e || Object.keys(e).sort().join(",") !== "accountKey,configurationRevision,controlEpoch,conversationKey,descriptionSha256,key,messageSha256,mode,updatedAt" || !d(e.accountKey) || !d(e.conversationKey) || e.key !== D([e.accountKey, e.conversationKey]) || t.has(e.key) || !["paused", "draft"].includes(e.mode) || !Number.isSafeInteger(e.controlEpoch) || e.controlEpoch < 1 || typeof e.updatedAt != "string" || Number.isNaN(Date.parse(e.updatedAt))) throw Error("\u4F1A\u8BDD\u63A7\u5236\u8BB0\u5F55\u8EAB\u4EFD\u6216\u4EE3\u6B21\u65E0\u6548");
    if (e.mode === "paused" ? e.configurationRevision !== null || e.descriptionSha256 !== null || e.messageSha256 !== null : !Number.isSafeInteger(e.configurationRevision) || e.configurationRevision < 0 || !/^[a-f0-9]{64}$/.test(e.descriptionSha256) || !/^[a-f0-9]{64}$/.test(e.messageSha256)) throw Error("\u4F1A\u8BDD\u6062\u590D\u8303\u56F4\u65E0\u6548");
    t.add(e.key);
  }
  return s;
};
var C = async ({ input: u, signal: s }) => {
  s.throwIfAborted();
  const t = u?.configuration;
  if (t?.version !== 1 || t.operation !== "configuration" || !Number.isSafeInteger(t.revision) || t.revision < 0) throw Error("\u7F3A\u5C11\u672C\u6B21\u56FA\u5B9A\u6C42\u804C\u914D\u7F6E\u4E0E\u4FEE\u8BA2");
  const e = t.value;
  if (!e || !["cities", "excludedRoles", "replyDailyLimit", "replyTimeZone", "salaryMax", "salaryMin", "targetRoles", "titleKeywords", "firstContactDailyBudget"].every((o) => Object.hasOwn(e, o)) || Object.keys(e).some((o) => !["cities", "excludedRoles", "replyDailyLimit", "replyTimeZone", "salaryMax", "salaryMin", "targetRoles", "titleKeywords", "firstContactDailyBudget", "knownContactedJobs", "knownContactAccountAlias", "knownContactPhoneMask", "knownGreetingDate", "knownGreetingsUsed", "acceptanceNewGreetings", "confirmedPersonalFacts", "recoveryEvidenceName"].includes(o))) throw Error("\u6C42\u804C\u6761\u4EF6\u7ED3\u6784\u65E0\u6548");
  if (!Number.isSafeInteger(e.replyDailyLimit) || e.replyDailyLimit < 0 || e.replyDailyLimit > 100 || typeof e.replyTimeZone != "string" || !e.replyTimeZone.trim() || e.replyTimeZone.length > 100) throw Error("\u56DE\u590D\u989D\u5EA6\u914D\u7F6E\u7ED3\u6784\u65E0\u6548");
  const y = (o) => o.normalize("NFKC").trim().toLocaleLowerCase("en-US"), r = [];
  if (!Number.isSafeInteger(e.firstContactDailyBudget) || e.firstContactDailyBudget < 0 || e.firstContactDailyBudget > 150) throw Error("\u672C\u65E5\u81EA\u52A8\u65B0\u589E\u9884\u7B97\u683C\u5F0F\u65E0\u6548\uFF1B\u987B\u4E3A0\u81F3150\u7684\u6574\u6570");
  for (const o of ["targetRoles", "titleKeywords", "excludedRoles", "cities"]) {
    if (!Array.isArray(e[o]) || e[o].length > 20 || e[o].some((f) => typeof f != "string" || f.length > 100)) throw Error("\u6761\u4EF6\u5217\u8868\u7ED3\u6784\u65E0\u6548");
    const h = e[o].map(y);
    (h.some((f) => !f) || new Set(h).size !== h.length) && r.push("\u6761\u4EF6\u5B58\u5728\u7A7A\u767D\u6216\u91CD\u590D\u9879\uFF1A" + o);
  }
  e.titleKeywords.length || r.push("\u5C1A\u672A\u914D\u7F6E\u53EF\u63A5\u53D7\u5C97\u4F4D\u6807\u9898\u5173\u952E\u8BCD"), e.targetRoles.length || r.push("\u5C1A\u672A\u660E\u786E\u76EE\u6807\u804C\u4F4D"), e.targetRoles.some((o) => e.excludedRoles.map(y).includes(y(o))) && r.push("\u76EE\u6807\u4E0E\u6392\u9664\u65B9\u5411\u51B2\u7A81");
  for (const o of ["salaryMin", "salaryMax"]) if (!Number.isSafeInteger(e[o]) || e[o] < 0 || e[o] > 1e6) throw Error("\u85AA\u8D44\u6761\u4EF6\u7ED3\u6784\u65E0\u6548");
  e.salaryMax > 0 && e.salaryMin > e.salaryMax && r.push("\u6708\u85AA\u4E0A\u9650\u4F4E\u4E8E\u4E0B\u9650");
  const c = u.jobTitle, n = u.jobDescription, E = u.sourceLabel ?? "";
  if (typeof c != "string" || c.length > 200 || typeof n != "string" || n.length > 2e4 || typeof E != "string" || E.length > 500 || typeof u.descriptionComplete != "boolean") throw Error("JD\u8F93\u5165\u7ED3\u6784\u65E0\u6548");
  (!c.trim() || !n.trim()) && r.push("\u5C97\u4F4D\u540D\u79F0\u6216JD\u6B63\u6587\u7F3A\u5931"), u.descriptionComplete || r.push("\u5C1A\u672A\u58F0\u660EJD\u6B63\u6587\u5B8C\u6574");
  const a = u.incomingMessage;
  if (typeof a != "string" || a.length > 4e3 || typeof u.messageComplete != "boolean" || typeof u.manualTakeover != "boolean") throw Error("\u6765\u4FE1\u6216\u63A5\u7BA1\u8F93\u5165\u7ED3\u6784\u65E0\u6548");
  a.trim() || r.push("\u672C\u6B21\u6765\u4FE1\u6B63\u6587\u7F3A\u5931"), u.messageComplete || r.push("\u5C1A\u672A\u58F0\u660E\u6765\u4FE1\u5B8C\u6574"), u.manualTakeover && r.push("\u672C\u4EBA\u63A5\u7BA1\u4E2D\u6216\u5C1A\u672A\u786E\u8BA4\u81EA\u52A8\u5904\u7406");
  const l = (o) => A("sha256").update(JSON.stringify(o)).digest("hex"), p = B(u.controlState);
  if (!d(u.accountKey) || !d(u.conversationKey)) throw Error("\u8D26\u53F7\u4E0E\u4F1A\u8BDD\u6765\u6E90\u952E\u65E0\u6548");
  const m = D([u.accountKey, u.conversationKey]), i = p.find((o) => o.key === m);
  !i || i.mode !== "draft" ? r.push("\u4F1A\u8BDD\u672A\u5EFA\u7ACB\u6062\u590D\u8303\u56F4\u6216\u672C\u4EBA\u63A5\u7BA1\u4E2D") : (i.configurationRevision !== t.revision || i.descriptionSha256 !== l(n) || i.messageSha256 !== l(a)) && r.push("\u6062\u590D\u8303\u56F4\u4E0E\u5F53\u524DJD\u3001\u6765\u4FE1\u6216\u914D\u7F6E\u4FEE\u8BA2\u4E0D\u540C\uFF0C\u8BF7\u672C\u4EBA\u91CD\u65B0\u6838\u5BF9");
  const g = { kind: "explicit-input", control: { key: m, controlEpoch: i?.controlEpoch ?? 0, mode: i?.mode ?? "paused", configurationRevision: i?.configurationRevision ?? null, descriptionSha256: i?.descriptionSha256 ?? null, messageSha256: i?.messageSha256 ?? null }, title: c, descriptionSha256: l(n), sourceLabel: E, completeDeclared: u.descriptionComplete, configurationRevision: t.revision, messageSha256: l(a), messageCompleteDeclared: u.messageComplete, manualTakeoverDeclared: u.manualTakeover }, F = { version: 1, kind: "message-draft-advice", decision: "review", nextAction: "ask-user", reason: r.join("\uFF1B"), issues: r, source: g, accountVerified: false, eligibleForActions: false, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
  return s.throwIfAborted(), { ready: r.length === 0, incomingMessage: a, job: { title: c, description: n, completeDeclared: u.descriptionComplete, sourceLabel: E }, configuration: e, source: g, reviewRecord: { reviewKey: "message-input:" + l({ source: g, issues: r }), result: F } };
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default = (ctx) => C(Object.freeze({ ...ctx, constants }));
export {
  stdin_default as default
};
