import { createHash as g } from "node:crypto";
var p = async ({ input: r, signal: d }) => {
  d.throwIfAborted();
  const i = r?.configuration;
  if (i?.version !== 1 || i.operation !== "configuration" || !Number.isSafeInteger(i.revision) || i.revision < 0) throw Error("\u7F3A\u5C11\u672C\u6B21\u56FA\u5B9A\u6C42\u804C\u914D\u7F6E\u4E0E\u4FEE\u8BA2");
  const e = i.value;
  if (!e || !["cities", "excludedRoles", "replyDailyLimit", "replyTimeZone", "salaryMax", "salaryMin", "targetRoles", "titleKeywords", "firstContactDailyBudget"].every((u) => Object.hasOwn(e, u)) || Object.keys(e).some((u) => !["cities", "excludedRoles", "replyDailyLimit", "replyTimeZone", "salaryMax", "salaryMin", "targetRoles", "titleKeywords", "firstContactDailyBudget", "knownContactedJobs", "knownContactAccountAlias", "knownContactPhoneMask", "knownGreetingDate", "knownGreetingsUsed", "acceptanceNewGreetings", "confirmedPersonalFacts", "recoveryEvidenceName"].includes(u))) throw Error("\u6C42\u804C\u6761\u4EF6\u7ED3\u6784\u65E0\u6548");
  if (!Number.isSafeInteger(e.replyDailyLimit) || e.replyDailyLimit < 0 || e.replyDailyLimit > 100 || typeof e.replyTimeZone != "string" || !e.replyTimeZone.trim() || e.replyTimeZone.length > 100) throw Error("\u56DE\u590D\u989D\u5EA6\u914D\u7F6E\u7ED3\u6784\u65E0\u6548");
  const l = (u) => u.normalize("NFKC").trim().toLocaleLowerCase("en-US"), t = [];
  if (!Number.isSafeInteger(e.firstContactDailyBudget) || e.firstContactDailyBudget < 0 || e.firstContactDailyBudget > 150) throw Error("\u672C\u65E5\u81EA\u52A8\u65B0\u589E\u9884\u7B97\u683C\u5F0F\u65E0\u6548\uFF1B\u987B\u4E3A0\u81F3150\u7684\u6574\u6570");
  for (const u of ["targetRoles", "titleKeywords", "excludedRoles", "cities"]) {
    if (!Array.isArray(e[u]) || e[u].length > 20 || e[u].some((a) => typeof a != "string" || a.length > 100)) throw Error("\u6761\u4EF6\u5217\u8868\u7ED3\u6784\u65E0\u6548");
    const E = e[u].map(l);
    (E.some((a) => !a) || new Set(E).size !== E.length) && t.push("\u6761\u4EF6\u5B58\u5728\u7A7A\u767D\u6216\u91CD\u590D\u9879\uFF1A" + u);
  }
  e.titleKeywords.length || t.push("\u5C1A\u672A\u914D\u7F6E\u53EF\u63A5\u53D7\u5C97\u4F4D\u6807\u9898\u5173\u952E\u8BCD"), e.targetRoles.length || t.push("\u5C1A\u672A\u660E\u786E\u76EE\u6807\u804C\u4F4D"), e.targetRoles.some((u) => e.excludedRoles.map(l).includes(l(u))) && t.push("\u76EE\u6807\u4E0E\u6392\u9664\u65B9\u5411\u51B2\u7A81");
  for (const u of ["salaryMin", "salaryMax"]) if (!Number.isSafeInteger(e[u]) || e[u] < 0 || e[u] > 1e6) throw Error("\u85AA\u8D44\u6761\u4EF6\u7ED3\u6784\u65E0\u6548");
  e.salaryMax > 0 && e.salaryMin > e.salaryMax && t.push("\u6708\u85AA\u4E0A\u9650\u4F4E\u4E8E\u4E0B\u9650");
  const o = r.jobTitle, s = r.jobDescription, n = r.sourceLabel ?? "";
  if (typeof o != "string" || o.length > 200 || typeof s != "string" || s.length > 2e4 || typeof n != "string" || n.length > 500 || typeof r.descriptionComplete != "boolean") throw Error("JD\u8F93\u5165\u7ED3\u6784\u65E0\u6548");
  (!o.trim() || !s.trim()) && t.push("\u5C97\u4F4D\u540D\u79F0\u6216JD\u6B63\u6587\u7F3A\u5931"), r.descriptionComplete || t.push("\u5C1A\u672A\u58F0\u660EJD\u6B63\u6587\u5B8C\u6574");
  const f = (u) => g("sha256").update(JSON.stringify(u)).digest("hex"), c = { kind: "explicit-input", title: o, descriptionSha256: f(s), sourceLabel: n, completeDeclared: r.descriptionComplete, configurationRevision: i.revision }, y = { version: 1, kind: "job-assessment-advice", decision: "review", nextAction: "ask-user", reason: t.join("\uFF1B"), issues: t, source: c, accountVerified: false, eligibleForActions: false, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
  return d.throwIfAborted(), { ready: t.length === 0, job: { title: o, description: s, completeDeclared: r.descriptionComplete, sourceLabel: n }, configuration: e, source: c, reviewRecord: { reviewKey: "jd-input:" + f({ source: c, issues: t }), result: y } };
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default = (ctx) => p(Object.freeze({ ...ctx, constants }));
export {
  stdin_default as default
};
