var stdin_default = async ({ input, template, signal }) => {
  signal.throwIfAborted();
  if (!input?.result || input.result.accountVerified !== false || input.result.eligibleForActions !== false) throw Error("\u7F3A\u5C11\u6709\u6548\u7684\u5185\u90E8\u5EFA\u8BAE\u7ED3\u679C");
  await template.result(input.result);
  return input.result;
};
var freeze = (v) => {
  if (v && typeof v === "object") {
    Object.values(v).forEach(freeze);
    Object.freeze(v);
  }
  return v;
};
var constants = freeze({});
var stdin_default2 = (ctx) => stdin_default(Object.freeze({ ...ctx, constants }));
export {
  stdin_default2 as default
};
