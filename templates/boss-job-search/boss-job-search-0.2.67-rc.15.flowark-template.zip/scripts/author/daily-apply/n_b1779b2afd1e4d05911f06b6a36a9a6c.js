function P(e) {
  return e.status === "review" && !e.operationKey && !e.modelRequestId && e.sourceReviewVersion !== "chat-list-direct-v5" && /固定成员姓名控件不唯一|固定成员定向搜索结果不唯一|关联职位没有可核对的继续沟通入口|固定成员缺少可核对的定向搜索姓名，未猜测|固定成员缺少唯一可见身份|关联职位返回后的完整消息或对象变化/u.test(String(e.reason || ""));
}
async function M(e, o) {
  const r = ".user-list-content", s = (f) => f.replace(/[\s\uE000-\uF8FF]/gu, ""), t = ".list-warp.v2 input";
  await e("count", t) === 1 && String(await e("inputValue", t, null)) !== "" && await e("fill", t, "");
  const n = ".list-warp.v2 ul:has(> .selected)", u = n + " > :nth-child(2)";
  await e("count", u) === 1 && /^未读(?:\s*\(\d+\))?$/u.test(String(await e("read", u)).trim()) && !/^未读/u.test(String(await e("read", n + " .selected")).trim()) && await e("click", u);
  for (let f = 0; f < 30 && await e("count", r) !== 1; f++) await new Promise((y) => setTimeout(y, 150));
  if (await e("count", r) !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u6765\u6E90\u4E0D\u552F\u4E00");
  const a = [{ selector: r, depth: 0 }], i = [];
  let d = 0;
  for (; a.length; ) {
    const f = a.shift();
    if (++d > 400) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
    const y = await e("count", f.selector + ".friend-content") === 1, l = y ? 1 : await e("count", f.selector + " .friend-content");
    if (l === 1) {
      const w = y ? f.selector : f.selector + " .friend-content", F = String(await e("read", f.selector)).trim();
      s(F).includes(s(String(o.member.text).split(/\r?\n/u).slice(3).join(`
`).trim())) && i.push({ sel: f.selector, label: w, text: F });
      continue;
    }
    if (l > 1 && f.depth < 4) {
      const w = await e("count", f.selector + " > *");
      if (!Number.isSafeInteger(w) || w > 200) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
      for (let F = 1; F <= w; F++) a.push({ selector: f.selector + " > :nth-child(" + F + ")", depth: f.depth + 1 });
    }
  }
  if (i.length === 0 && o.member.lookupName) {
    await e("fill", t, o.member.lookupName);
    const f = ".boss-search-result .search-list";
    for (let h = 0; h < 30 && !(await e("count", f) > 0); h++) await new Promise((p) => setTimeout(p, 150));
    if (await e("count", f) !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u5B9A\u5411\u641C\u7D22\u7ED3\u679C\u4E0D\u552F\u4E00");
    const y = [f], l = [];
    let w = 0;
    for (; y.length; ) {
      const h = y.shift();
      if (++w > 100) throw Error("\u8054\u7CFB\u4EBA\u59D3\u540D\u63A7\u4EF6\u8303\u56F4\u8FC7\u5927");
      const p = await e("count", h + " > *"), g = String(await e("read", h)).trim();
      if (g === o.member.lookupName && l.push({ label: h, text: g }), p > 0 && p < 30) for (let B = 1; B <= p; B++) y.push(h + " > :nth-child(" + B + ")");
    }
    const F = l.filter((h) => !l.some((p) => p !== h && p.label.startsWith(h.label + " > ")));
    if (F.length !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u59D3\u540D\u63A7\u4EF6\u4E0D\u552F\u4E00");
    i.push(F[0]);
  }
  if (i.length !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u7F3A\u5C11\u552F\u4E00\u53EF\u89C1\u8EAB\u4EFD\uFF0C\u672A\u731C\u6D4B\u59D3\u540D");
  const m = i[0];
  if (String(await e("read", m.label)).trim() !== m.text) throw Error("\u56FA\u5B9A\u6210\u5458\u53EF\u89C1\u8EAB\u4EFD\u53D8\u5316");
  await e("click", m.label);
  for (let f = 0; f < 30; f++) {
    if (await e("count", ".chat-conversation .user-info") === 1 && await e("count", "li.message-item") > 0) {
      const y = String(await e("read", ".chat-conversation .user-info")).trim(), l = await N(e), w = s(String(o.member.text).split(/\r?\n/u).slice(3).join(`
`).trim());
      if (y && l.some((F) => F.direction === "incoming" && s(F.text || "") === w)) {
        o.recipientLabel = y, o.rows = [{ mid: l[0].mid }];
        return;
      }
    }
    await new Promise((y) => setTimeout(y, 150));
  }
  throw Error("\u56FA\u5B9A\u6210\u5458\u53EF\u89C1\u8EAB\u4EFD\u672A\u5B8C\u6574\u8BFB\u56DE");
}
async function Q(e, o, r) {
  if (typeof r != "string" || !r.trim()) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u539F\u59D3\u540D\u6765\u6E90\u7F3A\u5931");
  await e("navigate", void 0, "https://www.zhipin.com/web/geek/chat"), await M(e, o);
}
function X(e, o) {
  const r = (i) => i.normalize("NFKC").replace(/\s+/gu, " ").trim().toLocaleLowerCase("en-US");
  if (typeof e != "string" || !e.trim() || e.length > 1e3 || /(?:\.{3}|…|⋯)/u.test(e)) throw Error("\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u7F3A\u5931\u6216\u622A\u65AD\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u8BB0\u5F55");
  const s = o?.titleKeywords, t = o?.excludedRoles;
  for (const [i, d, m] of [["titleKeywords", s, 1], ["excludedRoles", t, 0]]) if (!Array.isArray(d) || d.length < m || d.length > 20 || d.some((f) => typeof f != "string" || !r(f) || f.length > 100) || new Set(d.map(r)).size !== d.length) throw Error("\u5C97\u4F4D\u8303\u56F4\u914D\u7F6E\u65E0\u6548\uFF1A" + i + "\uFF1B\u672A\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE");
  const n = r(e), u = t.filter((i) => n.includes(r(i))), a = s.filter((i) => n.includes(r(i)));
  return { version: 1, kind: "literal-full-job-title-scope", fullTitle: e, matched: a, excluded: u, allowed: u.length === 0 && a.length > 0, source: "actual-complete-job-title", jdUsed: false, searchKeywordUsedAsEvidence: false };
}
import { createHash as I } from "node:crypto";
const ee = /* @__PURE__ */ (() => {
  var e = async ({ input: o, signal: r }) => {
    r.throwIfAborted();
    const s = o, t = s?.value;
    if (!s || s.version !== 1 || s.operation !== "read" || s.binding !== "account-source-result" || s.schemaValidation !== "passed" || s.dataChanged !== false || s.ref?.version !== 1 || s.ref.policy !== "credential-redacted-v1" || s.ref.source?.entryId !== "account-source") throw new Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u5DF2\u9009\u62E9\u4E14\u5B8C\u6574\u53EF\u590D\u7528\u7684\u8D26\u53F7\u6765\u6E90\uFF0C\u8BF7\u5230\u8D44\u6E90\u9875\u91CD\u65B0\u6838\u5BF9\u5E76\u4FDD\u5B58");
    if (!t || t.version !== 1 || t.kind !== "boss-account-source" || t.status !== "account-source-confirmed" || t.accountVerified !== true || t.platformUniqueIdVerified !== false || t.eligibleForActions !== false || t.role !== "jobseeker") throw new Error("\u6240\u9009\u8BB0\u5F55\u5C1A\u672A\u5B8C\u6210\u672C\u4EBA\u786E\u8BA4\u548C\u6765\u6E90\u590D\u9A8C\uFF1B\u8BF7\u5728\u5F53\u524D\u5B9E\u4F8B\u5B8C\u6210\u8D26\u53F7\u6838\u5BF9\uFF0C\u518D\u9009\u62E9\u8BE5\u6B21\u5DF2\u4FDD\u5B58\u7ED3\u679C");
    const n = ["version", "kind", "status", "accountAlias", "accountName", "phoneMask", "jobseekerResumeHref", "role", "sourceUrl", "accountVerified", "platformUniqueIdVerified", "eligibleForActions", "confirmedAt", "checkedAt", "reason"];
    if (Object.keys(t).length !== n.length || n.some((m) => !Object.prototype.hasOwnProperty.call(t, m))) throw new Error("\u6240\u9009\u8D26\u53F7\u7ED3\u679C\u7ED3\u6784\u4E0D\u7B26\uFF0C\u505C\u6B62\u91C7\u7528");
    for (const m of ["accountAlias", "accountName", "phoneMask"]) if (typeof t[m] != "string" || !t[m].trim() || t[m] !== t[m].trim() || t[m].length > 100 || /[\r\n]/.test(t[m])) throw new Error("\u8D26\u53F7\u5FC5\u8981\u5B57\u6BB5\u7F3A\u5931\u6216\u683C\u5F0F\u65E0\u6548\uFF0C\u505C\u6B62\u91C7\u7528");
    if (!/^[+\d ()-]*\*{2,}[\d ()-]+$/.test(t.phoneMask) || /登录|注册|验证码/.test(t.accountName)) throw new Error("\u8D26\u53F7\u6765\u6E90\u7F3A\u5C11\u6709\u6548\u7684\u53EF\u89C1\u59D3\u540D\u6216\u624B\u673A\u53F7\u63A9\u7801");
    if (typeof t.reason != "string" || !t.reason.trim()) throw new Error("\u8D26\u53F7\u7ED3\u679C\u7F3A\u5C11\u660E\u786E\u6838\u5BF9\u8BF4\u660E");
    const u = Date.parse(t.confirmedAt), a = Date.parse(t.checkedAt);
    if (typeof t.confirmedAt != "string" || typeof t.checkedAt != "string" || !Number.isFinite(u) || !Number.isFinite(a) || u <= 0 || a < u || a > Date.now() + 6e4) throw new Error("\u8D26\u53F7\u786E\u8BA4\u6216\u590D\u9A8C\u65F6\u95F4\u65E0\u6CD5\u6838\u5BF9\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4");
    if (typeof t.sourceUrl != "string" || typeof t.jobseekerResumeHref != "string" || !t.sourceUrl.trim() || !t.jobseekerResumeHref.trim() || t.sourceUrl.length > 16384 || t.jobseekerResumeHref.length > 16384) throw new Error("\u8D26\u53F7\u9875\u9762\u6216\u7B80\u5386\u5165\u53E3\u5730\u5740\u65E0\u6548");
    const i = new URL(t.sourceUrl), d = new URL(t.jobseekerResumeHref, t.sourceUrl);
    if (i.origin !== "https://www.zhipin.com" || i.pathname !== "/web/geek/account" || i.searchParams.get("type") !== "accountSet" || i.username || i.password || i.hash || d.origin !== i.origin || d.pathname !== "/web/geek/resume" || d.username || d.password) throw new Error("\u8D26\u53F7\u8BB0\u5F55\u7684\u9875\u9762\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u4E0D\u7B26");
    return r.throwIfAborted(), { version: 1, accountSourceValid: true, currentAccountVerified: false, account: t };
  };
  return e;
})(), Z = /* @__PURE__ */ (() => {
  async function e({ input: o, signal: r, template: s }) {
    r.throwIfAborted();
    const t = o?.expected?.account;
    if (o?.expected?.accountSourceValid !== true || t?.kind !== "boss-account-source" || t.status !== "account-source-confirmed" || t.accountVerified !== true) throw Error("\u7F3A\u5C11\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\u6765\u6E90");
    const n = async (w, F, h) => {
      r.throwIfAborted();
      const p = await s.browser("browser", { operation: w, ...F ? { selector: F } : {}, ...h === void 0 ? {} : { value: h }, timeoutMs: 3e3 });
      return r.throwIfAborted(), p;
    }, u = await n("url"), a = new URL(u);
    if (a.origin !== "https://www.zhipin.com" || a.username || a.password || !a.pathname.startsWith("/web/") && !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(a.pathname)) throw Error("\u5F53\u524D\u9875\u9762\u4E0D\u662FBOSS\u6C42\u804C\u9875\u9762\uFF0C\u8BF7\u5148\u767B\u5F55");
    const i = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", d = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)", m = await n("count", i), f = await n("count", d);
    if (m !== 1 || f !== 1) throw Error("\u5F53\u524D\u9875\u9762\u8D26\u53F7\u5165\u53E3\u6570\u91CF\u5F02\u5E38\uFF1A" + JSON.stringify({ nameCount: m, resumeCount: f }));
    const y = await n("read", i), l = await n("attribute", d, "href");
    if (typeof y != "string" || y.normalize("NFKC").trim() !== t.accountName.normalize("NFKC").trim() || typeof l != "string" || new URL(l, u).href !== new URL(t.jobseekerResumeHref, t.sourceUrl).href || await n("url") !== u) throw Error("\u5F53\u524D\u767B\u5F55\u8EAB\u4EFD\u3001\u6C42\u804C\u5165\u53E3\u6216\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
    return { version: 1, status: "current-account-source-matched", accountAlias: t.accountAlias, accountName: t.accountName, phoneMask: t.phoneMask, jobseekerResumeHref: t.jobseekerResumeHref, sourceUrl: t.sourceUrl, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), currentPageUrl: u, currentAccountVerified: true, platformUniqueIdVerified: false, eligibleForActions: false, accountCheckMode: "confirmed-initial-account-and-visible-header", phoneMaskRechecked: false, reason: "\u4F7F\u7528\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\uFF1B\u53EA\u8BFB\u6838\u5BF9\u5F53\u524D\u767B\u5F55\u59D3\u540D\u3001\u6C42\u804C\u5165\u53E3\u53CA\u9875\u9762\u8FDE\u7EED\u6027\uFF0C\u624B\u673A\u53F7\u63A9\u7801\u6CBF\u7528\u786E\u8BA4\u6765\u6E90\uFF0C\u6CA1\u6709\u91CD\u65B0\u8BFB\u53D6\u3002" };
  }
  return e;
})(), U = (e) => Array.isArray(e) ? e.map(U) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((o) => [o, U(e[o])])) : e, te = (e) => I("sha256").update(JSON.stringify(U(e))).digest("hex"), b = (e) => Array.isArray(e) ? e.map(b) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((o) => [o, b(e[o])])) : e, C = (e) => I("sha256").update(JSON.stringify(b(e))).digest("hex");
async function $(e, o, r, s, t = false) {
  const n = "account-outbound-safety-v1-" + r + ".json";
  let u, a = true, i;
  try {
    i = await e.file("communication-cache", { operation: "read", name: n }), u = JSON.parse(i);
  } catch (l) {
    if (!String(l.message || l).includes("ENOENT")) throw l;
    if (!t) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
    a = false, u = { version: 1, kind: "boss-account-outbound-safety", accountKey: r, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (a) {
    const { sha256: l, ...w } = u;
    if (l !== C(w)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
  }
  if (u.version !== 1 || u.kind !== "boss-account-outbound-safety" || u.accountKey !== r || !Number.isSafeInteger(u.revision) || u.revision < 0 || !Array.isArray(u.records) || u.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
  const d = /* @__PURE__ */ new Set();
  for (const l of u.records) {
    if (!["first-contact", "reply"].includes(l.type) || !/^[a-f0-9]{64}$/.test(l.businessKey) || !Array.isArray(l.sightings) || !l.sightings.length || l.sightings.length > 100 || d.has(l.type + ":" + l.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
    d.add(l.type + ":" + l.businessKey);
    for (const w of l.sightings) if (typeof w.contextId != "string" || !w.contextId || !/^[a-f0-9]{64}$/.test(w.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(w.status) || !/^\d{4}-\d{2}-\d{2}$/.test(w.day) || typeof w.timeZone != "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
  }
  let m = !a;
  return { data: u, name: n, merge: (l) => {
    if (!Array.isArray(l?.applicationIntents) || !Array.isArray(l?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
    for (const [w, F] of [["first-contact", l.applicationIntents], ["reply", l.replyIntents]]) for (const h of F) {
      if ((w === "first-contact" ? h.accountSourceSha256 : h.accountKey) !== r) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
      if (!/^[a-f0-9]{64}$/.test(h.key) || !h.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(h.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
      const p = w === "first-contact" ? C(["boss-job-safety-v1", r, h.jobId]) : I("sha256").update(["boss-text-reply-v1", r, h.incomingMessageId].join(":")).digest("hex");
      let g = u.records.find((E) => E.type === w && E.businessKey === p);
      if (g || (g = { type: w, businessKey: p, jobId: h.jobId, ...w === "reply" ? { conversationKey: h.conversationKey, incomingMessageId: h.incomingMessageId } : {}, sightings: [] }, u.records.push(g), m = true), g.jobId !== h.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
      const B = { contextId: s, intentKey: h.key, status: h.status, day: h.day, timeZone: h.timeZone, contentSha256: h.contentSha256 || null, sourceSha256: h.sourceSha256 || null };
      if (g.sightings.some((E) => JSON.stringify(b(E)) === JSON.stringify(b(B))) || (g.sightings.push(B), m = true), g.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
    }
    if (u.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
  }, save: async () => {
    if (o.throwIfAborted(), m) {
      if (a && await e.file("communication-cache", { operation: "read", name: n }) !== i) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
      u.records.sort((h, p) => (h.type + ":" + h.businessKey).localeCompare(p.type + ":" + p.businessKey));
      for (const h of u.records) h.sightings.sort((p, g) => JSON.stringify(b(p)).localeCompare(JSON.stringify(b(g))));
      u.revision++, u.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete u.sha256, u.sha256 = C(u), await e.file("communication-cache", { operation: "write", name: n, content: JSON.stringify(u) }), m = false, i = JSON.stringify(u), a = true;
    }
    const l = JSON.parse(await e.file("communication-cache", { operation: "read", name: n })), { sha256: w, ...F } = l;
    if (w !== C(F) || w !== u.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
    return { revision: u.revision, sha256: u.sha256, records: u.records.length };
  }, blocked: (l, w) => u.records.some((F) => F.type === l && F.businessKey === w) };
}
const L = (e, o) => async (r, s, t) => {
  o.throwIfAborted();
  try {
    return await e.browser("browser", { operation: r, ...s ? { selector: s } : {}, ...t === void 0 ? {} : { value: t }, timeoutMs: 3e3 });
  } catch (n) {
    const u = String(n.message || n);
    if (!/^\(-3\) loading /u.test(u)) throw n;
    let a = null;
    if (r === "navigate" && t === "https://www.zhipin.com/web/geek/chat" && (a = new URL(t)), r === "click" && s === ".chat-position-content .right-content > :first-child") {
      const i = /^\(-3\) loading '([^']+)'/u.exec(u);
      if (i) {
        const d = new URL(i[1]);
        d.origin === "https://www.zhipin.com" && /^\/job_detail\/[A-Za-z0-9_~-]+\.html$/u.test(d.pathname) && !d.username && !d.password && (a = d);
      }
    }
    if (!a) throw n;
    for (let i = 0; i < 30; i++) {
      o.throwIfAborted();
      const d = await e.browser("browser", { operation: "url", timeoutMs: 3e3 }), m = new URL(d);
      if (m.origin === a.origin && m.pathname === a.pathname) return { navigationObserved: true, url: d, originalClickRepeated: false };
      await new Promise((f) => setTimeout(f, 150));
    }
    throw n;
  }
}, V = (e) => {
  const { sha256: o, ...r } = e;
  return o === C(r);
};
async function J(e, o, r, s) {
  const t = r.progressName, n = await e.file("communication-cache", { operation: "read", name: t }), u = JSON.parse(n);
  if (!V(u) || u.accountKey !== r.accountKey || u.fixedUnreadSetSha256 !== r.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
  if (!s) return u;
  const a = s(structuredClone(u));
  if (a.revision++, a.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete a.sha256, a.sha256 = C(a), await e.file("communication-cache", { operation: "read", name: t }) !== n) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  o.throwIfAborted(), await e.file("communication-cache", { operation: "write", name: t, content: JSON.stringify(a) });
  const i = JSON.parse(await e.file("communication-cache", { operation: "read", name: t }));
  if (!V(i) || i.sha256 !== a.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
  return i;
}
async function N(e) {
  const o = await e("count", "li.message-item");
  if (!Number.isSafeInteger(o) || o < 1 || o > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
  const r = [];
  for (let s = 1; s <= o; s++) {
    const t = "li.message-item:nth-child(" + s + " of li.message-item)", n = await e("attribute", t, "data-mid"), u = await e("attribute", t, "class");
    if (!/^\d{6,40}$/.test(n || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
    const a = await e("count", t + " .text-content");
    if (a > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
    const i = a === 1 ? String(await e("read", t + " .text-content")).trim() : null, d = i === null ? String(await e("read", t)).trim() : null;
    if ((i || d || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
    const m = !!i && /^您正在与Boss.+沟通$/u.test(i), f = !m && i !== null && u.split(/\s+/u).includes("item-myself") ? "outgoing" : !m && i !== null && u.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
    r.push({ mid: n, direction: f, text: i, context: d });
  }
  if (new Set(r.map((s) => s.mid)).size !== r.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
  return r;
}
async function z(e, o) {
  const r = new URL(await e("url"));
  if (r.origin !== "https://www.zhipin.com" || r.pathname !== "/web/geek/chat" || await e("count", ".chat-conversation .user-info") !== 1) return false;
  const s = String(await e("read", ".chat-conversation .user-info")).trim(), t = (u) => u.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
  return o.recipientLabel ? String(await e("read", ".chat-conversation .user-info")).trim() === o.recipientLabel && (!o.rows?.length || await e("count", 'li.message-item[data-mid="' + o.rows[0].mid + '"]') === 1) : await e("count", ".friend-content.selected") === 1 && t(String(await e("read", ".friend-content.selected"))).includes(t(o.member.identityLine));
}
async function H(e, o, r) {
  const s = L(e, o);
  return await z(s, r) ? String(await s("read", r.accountSelector)).trim() === r.accountLabel && String(await s("read", r.recipientSelector)).trim() === r.recipientLabel && JSON.stringify(await N(s)) === JSON.stringify(r.rows) : false;
}
var _ = async ({ input: e, template: o, signal: r, artifact: s, onAccountVerified: t }) => {
  const n = e?.cohort, u = e?.profile;
  if (n?.kind !== "unread-closing-cohort" || n.closingPhase !== true || u?.version !== 1 || !u.ref?.versionId || !u.markdown?.trim()) throw Error("\u7F3A\u5C11\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u6216\u672C\u6B21\u786E\u8BA4Skill");
  const a = { ...n, sourceReviewVersion: "chat-list-direct-v5", kind: "chat-reply-source", fixedUnreadMember: true, profile: u, returnToJobs: false };
  if (!n.ready) return { ...a, ready: false, status: "fixed-unread-complete", reason: "\u56FA\u5B9A\u96C6\u5408\u5DF2\u5904\u7406\u5B8C\u6BD5\uFF0C\u4E0D\u91CD\u65B0\u626B\u63CF" };
  await Z({ input: { expected: n.accountSource }, template: o, signal: r }), t?.();
  const i = String(n.member?.text || "").split(/\r?\n/u).slice(3).join(`
`).trim();
  if (/背景不完全相符|需要其他资质|不太符合|不太?合适|不[是太]*特别契合|不[完全]*符合|不[完全]*匹配|后续有机会再合作|未能通过|暂不考虑/u.test(i) && !/[?？]|(?:是否|有没有|会不会|能否|请问|什么时候|多少|怎么|哪些)/u.test(i)) return { ...a, member: n.member, ready: false, jobId: null, jobSource: null, status: "rejected-no-reply", reason: "\u56FA\u5B9A\u672A\u8BFB\u5FEB\u7167\u4E2D\u5BF9\u65B9\u5DF2\u660E\u786E\u62D2\u7EDD\uFF0C\u4E0D\u56DE\u590D\u3001\u4E0D\u6267\u884C\u539F\u751F\u8BF7\u6C42", previewSource: true };
  const d = L(o, r), m = n.member;
  let f = await J(o, r, n);
  if (f.completed.some((c) => c.memberKey === m.key && !P(c) && !(c.status === "review" && c.replyPolicyVersion !== "work-questions-partial-known-v2"))) return { ...a, ready: false, status: "already-completed", reason: "\u8BE5\u56FA\u5B9A\u6210\u5458\u5DF2\u5904\u7406\uFF0C\u672A\u91CD\u590D\u6253\u5F00" };
  if (f.active && f.active.memberKey !== m.key) throw Error("\u6D3B\u8DC3\u4F1A\u8BDD\u4E0E\u56FA\u5B9A\u6210\u5458\u4E0D\u7B26");
  if (!await z(d, n)) {
    const c = new URL(await d("url"));
    (c.origin !== "https://www.zhipin.com" || c.pathname !== "/web/geek/chat") && await d("navigate", void 0, "https://www.zhipin.com/web/geek/chat"), await M(d, n);
  }
  const y = ".chat-conversation .user-info", l = String(await d("read", y)).trim(), w = ".chat-position-content", F = String(await d("read", w)).trim(), h = F.split(/\r?\n/u)[0], p = await N(d);
  if (!h || !l) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u7684\u62DB\u8058\u8005\u6216\u804C\u4F4D\u4E0A\u4E0B\u6587\u7F3A\u5931");
  if (/校招|校园|应届/u.test(h)) return { ...a, member: m, ready: false, status: "campus-no-reply", reason: "\u804A\u5929\u4E2D\u660E\u786E\u6821\u62DB\uFF0C\u7EE7\u7EED\u6392\u9664" };
  if (f.active?.firstMessageId && f.active.firstMessageId !== p[0].mid) throw Error("\u91CD\u5F00\u540E\u7684\u4F1A\u8BDD\u539F\u59CB\u6D88\u606F\u94FE\u5DF2\u53D8\u5316\uFF0C\u672A\u8986\u76D6\u65E7\u8FDB\u5EA6");
  f = await J(o, r, n, (c) => {
    if (c.active && c.active.memberKey !== m.key) throw Error("\u6D3B\u8DC3\u6210\u5458\u53D8\u5316");
    return c.active = { ...c.active, memberKey: m.key, identityLine: m.identityLine, recipientName: l.split(/\r?\n/u)[0], contextId: n.contextId, openedAt: c.active?.openedAt || (/* @__PURE__ */ new Date()).toISOString(), firstMessageId: p[0].mid }, c;
  });
  const g = "https://www.zhipin.com/web/geek/chat", B = "chat-" + p[0].mid, E = await N(d), S = E.filter((c) => c.direction !== "system" && c.text), D = S.at(-1), T = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", O = n.accountSource.account.accountName, A = { ...a, ownedConversation: S[0]?.direction === "outgoing", member: m, jobId: B, jobSource: g, jobTitle: h, chatJobTitle: F, jobSelector: w, recipientSelector: y, recipientLabel: l, accountSelector: T, accountLabel: O, conversationKey: "boss-chat:" + E[0].mid, rows: E };
  if (S[0]?.direction === "incoming") return { ...A, ready: false, status: "inbound-first-no-reply", reason: "\u53EF\u89C1\u4F1A\u8BDD\u7531\u5BF9\u65B9\u53D1\u8D77\uFF0C\u6309\u672C\u4EBA\u89C4\u5219\u8DF3\u8FC7" };
  if (!D || D.direction !== "incoming") return { ...A, ready: false, status: "already-replied-or-system-only", reason: "\u6CA1\u6709\u5C1A\u672A\u56DE\u590D\u7684\u771F\u4EBA\u6587\u5B57\u6765\u4FE1\uFF1B\u7CFB\u7EDF\u5361\u7247\u4E0D\u89E6\u53D1\u56DE\u590D" };
  if (/背景不完全相符|需要其他资质|不太符合|不太?合适|不[是太]*特别契合|不[完全]*符合|不[完全]*匹配|后续有机会再合作|未能通过|暂不考虑/u.test(D.text) && !/[?？]|(?:是否|有没有|会不会|能否|请问|什么时候|多少|怎么|哪些)/u.test(D.text)) return { ...A, ready: false, status: "rejected-no-reply", incomingMessageId: D.mid, reason: "\u5BF9\u65B9\u660E\u786E\u8868\u793A\u4E0D\u5408\u9002\uFF0C\u6309\u672C\u4EBA\u6700\u65B0\u8981\u6C42\u4E0D\u56DE\u590D\uFF1B\u4FDD\u7559\u6240\u6709\u539F\u5916\u53D1\u610F\u56FE" };
  const x = I("sha256").update(["boss-text-reply-v1", n.accountKey, D.mid].join(":")).digest("hex"), j = await o.state.get(), k = await $(o, r, n.accountKey, n.contextId);
  if (k.merge(j), await k.save(), j.replyIntents.some((c) => c.accountKey === n.accountKey && c.incomingMessageId === D.mid && ["reserved", "unknown", "failed"].includes(c.status)) || k.data.records.some((c) => c.type === "reply" && c.businessKey === x && c.sightings.some((v) => ["reserved", "unknown", "failed"].includes(v.status)))) {
    const c = "\u539F\u6765\u4FE1\u5DF2\u6709\u9884\u7559\u3001\u672A\u77E5\u6216\u5931\u8D25\u8BB0\u5F55\uFF0C\u4FDD\u7559\u5F85\u529E\u5E76\u7981\u6B62\u91CD\u53D1";
    return await o.attention({ key: "reply-existing-uncertain:" + n.accountKey + ":" + D.mid, title: "\u539F\u56DE\u590D\u7ED3\u679C\u5F85\u6838\u5BF9\uFF0C\u8BF7\u52FF\u91CD\u53D1", detail: { contact: m.identityLine, jobSource: g, incomingMessageId: D.mid, reason: c, externalAction: false } }), { ...A, ready: false, status: "existing-uncertain-reply", decision: "review", replyPolicyVersion: "work-questions-partial-known-v2", incomingMessageId: D.mid, key: x, reason: c };
  }
  if (j.replyIntents.some((c) => c.accountKey === n.accountKey && c.incomingMessageId === D.mid) || k.blocked("reply", x)) return { ...A, ready: false, status: "existing-reply-intent", incomingMessageId: D.mid, reason: "\u8BE5\u539F\u6765\u4FE1\u5DF2\u6709\u5916\u53D1\u610F\u56FE\uFF0C\u9884\u7559\u3001\u672A\u77E5\u53CA\u786E\u8BA4\u5747\u7981\u6B62\u91CD\u653E" };
  if ((j.conversationControls || []).some((c) => c.accountKey === n.accountKey && [A.conversationKey, "boss-chat:" + E[0].mid].includes(c.conversationKey) && c.mode === "paused")) return { ...A, ready: false, status: "manual-control", reason: "\u672C\u4EBA\u5DF2\u63A5\u7BA1\u672C\u4F1A\u8BDD\uFF0C\u81EA\u52A8\u56DE\u590D\u8DF3\u8FC7" };
  const R = new Intl.DateTimeFormat("sv-SE", { timeZone: n.configuration.replyTimeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
  if (new Set(k.data.records.filter((c) => c.type === "reply" && c.sightings.some((v) => v.day === R && v.timeZone === n.configuration.replyTimeZone && v.status !== "failed")).map((c) => c.businessKey)).size >= n.configuration.replyDailyLimit) throw Error("\u5DF2\u4FDD\u5B58\u7684\u672C\u4EBA\u56DE\u590D\u989D\u5EA6\u5DF2\u6EE1\uFF0C\u4FDD\u7559\u672A\u5B8C\u6210\u6536\u5C3E");
  const K = { ...A, ready: true, key: x, incomingMessageId: D.mid, incomingMessage: D.text, pendingMessages: S.slice(S.map((c) => c.direction).lastIndexOf("outgoing") + 1).filter((c) => c.direction === "incoming"), sourceSha256: I("sha256").update(JSON.stringify({ rows: E, jobSource: g, accountLabel: O })).digest("hex"), day: R, timeZone: n.configuration.replyTimeZone };
  if (!await H(o, r, K)) throw Error("\u5B8C\u6574\u6765\u6E90\u4FDD\u5B58\u524D\u4F1A\u8BDD\u5DF2\u53D8\u5316");
  return await s("fixed-unread-reply-source.json", JSON.stringify(K, null, 2)), K;
};
async function q(e) {
  let o = false;
  try {
    return await _({ ...e, onAccountVerified: () => {
      o = true;
    } });
  } catch (r) {
    const s = String(r.message || r), t = e.input?.cohort, n = /关联职位返回后的完整消息或对象变化|完整岗位标题缺失或截断|固定姓名搜索未取得唯一的姓名、公司和角色组合|固定成员缺少可核对的定向搜索姓名，未猜测|未读会话的实际职位链接未核对|关联职位没有可核对的继续沟通入口|固定成员当前列表|固定成员缺少唯一可见身份|固定成员可见身份|固定会话返回|关联职位完整标题与固定会话不符/u.test(s), u = o && !/账号|安全索引|账本|摘要|配置|状态|进度|Skill|预留/u.test(s) && /固定成员|固定会话|关联职位|网页操作超时|元素|目标不可见|点击目标|点击期间|\(-3\) loading/u.test(s);
    if (!(n || u) || t?.kind !== "unread-closing-cohort" || !t.member?.key) throw r;
    return await e.template.attention({ key: "fixed-member-source-review:" + t.accountKey + ":" + t.member.key, title: "\u8BE5\u672A\u8BFB\u4F1A\u8BDD\u6765\u6E90\u5F85\u6838\u5BF9\uFF0C\u672A\u6267\u884C\u5916\u53D1", detail: { contact: t.member.identityLine, fixedUnreadSetSha256: t.fixedUnreadSetSha256, memberKey: t.member.key, reason: s, externalAction: false } }), { ...t, sourceReviewVersion: "chat-list-direct-v5", kind: "chat-reply-source", fixedUnreadMember: true, profile: e.input.profile, ready: false, jobId: null, jobSource: null, status: "member-needs-review", decision: "review", replyPolicyVersion: "work-questions-partial-known-v2", reason: s };
  }
}
export {
  q as default
};
