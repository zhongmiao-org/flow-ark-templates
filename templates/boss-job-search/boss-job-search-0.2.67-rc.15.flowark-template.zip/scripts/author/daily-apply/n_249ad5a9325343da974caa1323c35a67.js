function ie(s) {
  return s.status === "review" && !s.operationKey && !s.modelRequestId && s.sourceReviewVersion !== "chat-list-direct-v5" && /关联职位没有可核对的继续沟通入口|固定成员缺少可核对的定向搜索姓名，未猜测|固定成员缺少唯一可见身份|关联职位返回后的完整消息或对象变化/u.test(String(s.reason || ""));
}
async function ae(s, g, D) {
  const { accountKey: a, contextId: t, day: l, timeZone: h, revision: b, configuration: u } = D, w = u.acceptanceNewGreetings ?? 0;
  if (w !== 0 && w !== 2) throw Error("\u9A8C\u6536\u65B0\u62DB\u547C\u6570\u53EA\u80FD\u4E3A0\uFF08\u6B63\u5F0F\u6A21\u5F0F\uFF09\u62162");
  if (!w) return null;
  g.throwIfAborted();
  const c = (i) => Array.isArray(i) ? i.map(c) : i && typeof i == "object" ? Object.fromEntries(Object.keys(i).sort().map((o) => [o, c(i[o])])) : i, v = (i) => q("sha256").update(JSON.stringify(c(i))).digest("hex"), A = (i) => {
    const { sha256: o, ...V } = i;
    if (o !== v(V)) throw Error("\u9A8C\u6536\u6765\u6E90\u6458\u8981\u4E0D\u7B26\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55");
    return i;
  }, E = A(JSON.parse(await s.file("communication-cache", { operation: "read", name: "account-outbound-safety-v1-" + a + ".json" })));
  if (E.kind !== "boss-account-outbound-safety" || E.accountKey !== a || !Array.isArray(E.records)) throw Error("\u9A8C\u6536\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u4E0D\u7B26");
  const f = new Intl.DateTimeFormat("sv-SE", { timeZone: h, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
  if (l !== f) throw Error("\u9A8C\u6536\u8DE8\u65E5\uFF0C\u505C\u6B62\u65B0\u589E");
  const r = E.records.filter((i) => i.type === "first-contact" && i.sightings.some((o) => o.day === l && o.timeZone === h)), B = r.map((i) => i.businessKey);
  if (new Set(B).size !== B.length) throw Error("\u9A8C\u6536\u5360\u989D\u952E\u91CD\u590D");
  const O = { accountKey: a, contextId: t, day: l, timeZone: h, revision: b, target: w }, N = "test-greeting-baseline-v1-" + a + "-" + v(O).slice(0, 24) + ".json";
  let m = null;
  try {
    m = await s.file("communication-cache", { operation: "read", name: N });
  } catch (i) {
    if (!String(i.message || i).includes("ENOENT")) throw i;
  }
  let C;
  if (m === null) {
    if (u.firstContactDailyBudget !== B.length + w) throw Error("\u6D4B\u8BD5\u9884\u7B97\u5FC5\u987B\u7B49\u4E8E\u672C\u65E5\u5DF2\u6709\u5360\u989D\u52A02\uFF0C\u7981\u6B62\u6269\u5927\u6216\u91CD\u7F6E\u672C\u8F6E");
    if (C = { version: 1, kind: "boss-test-greeting-baseline", identity: O, keys: B.slice().sort(), budget: u.firstContactDailyBudget, indexSha256: E.sha256, createdAt: (/* @__PURE__ */ new Date()).toISOString() }, C.sha256 = v(C), await s.file("communication-cache", { operation: "write", name: N, content: JSON.stringify(C) }), m = await s.file("communication-cache", { operation: "read", name: N }), JSON.stringify(A(JSON.parse(m))) !== JSON.stringify(C)) throw Error("\u6D4B\u8BD5\u57FA\u7EBF\u672A\u51C6\u786E\u8BFB\u56DE");
  } else C = A(JSON.parse(m));
  if (v(C.identity) !== v(O) || C.budget !== u.firstContactDailyBudget || !Array.isArray(C.keys) || C.keys.some((i) => !B.includes(i))) throw Error("\u6D4B\u8BD5\u57FA\u7EBF\u6216\u9884\u7B97\u53D8\u5316\uFF0C\u505C\u6B62\u4E14\u4FDD\u7559\u5386\u53F2");
  const d = r.filter((i) => !C.keys.includes(i.businessKey));
  if (d.length > w) throw Error("\u6D4B\u8BD5\u5360\u989D\u8D85\u51FA\u4E24\u6B21\uFF0C\u505C\u6B62");
  for (const i of d) if (i.sightings.some((o) => o.day === l && o.timeZone === h && (o.contextId !== t || o.status === "unknown" || o.status === "failed"))) throw Error("\u6D4B\u8BD5\u65B0\u589E\u6765\u6E90\u51B2\u7A81\u6216\u7ED3\u679C\u672A\u77E5\uFF0C\u7981\u6B62\u8865\u53D1");
  const y = d.filter((i) => i.sightings.some((o) => o.day === l && o.timeZone === h && o.contextId === t && o.status === "confirmed"));
  return { version: 1, kind: "boss-test-new-greeting-completion", ...O, baselineName: N, baselineSha256: C.sha256, newOccupied: d.length, newConfirmed: y.length, confirmedKeys: y.map((i) => i.businessKey).sort(), confirmed: y.length === w, siteDailyLimitConfirmed: false, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
}
import { createHash as q } from "node:crypto";
const re = /* @__PURE__ */ (() => {
  var s = async ({ input: g, signal: D }) => {
    D.throwIfAborted();
    const a = g, t = a?.value;
    if (!a || a.version !== 1 || a.operation !== "read" || a.binding !== "account-source-result" || a.schemaValidation !== "passed" || a.dataChanged !== false || a.ref?.version !== 1 || a.ref.policy !== "credential-redacted-v1" || a.ref.source?.entryId !== "account-source") throw new Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u5DF2\u9009\u62E9\u4E14\u5B8C\u6574\u53EF\u590D\u7528\u7684\u8D26\u53F7\u6765\u6E90\uFF0C\u8BF7\u5230\u8D44\u6E90\u9875\u91CD\u65B0\u6838\u5BF9\u5E76\u4FDD\u5B58");
    if (!t || t.version !== 1 || t.kind !== "boss-account-source" || t.status !== "account-source-confirmed" || t.accountVerified !== true || t.platformUniqueIdVerified !== false || t.eligibleForActions !== false || t.role !== "jobseeker") throw new Error("\u6240\u9009\u8BB0\u5F55\u5C1A\u672A\u5B8C\u6210\u672C\u4EBA\u786E\u8BA4\u548C\u6765\u6E90\u590D\u9A8C\uFF1B\u8BF7\u5728\u5F53\u524D\u5B9E\u4F8B\u5B8C\u6210\u8D26\u53F7\u6838\u5BF9\uFF0C\u518D\u9009\u62E9\u8BE5\u6B21\u5DF2\u4FDD\u5B58\u7ED3\u679C");
    const l = ["version", "kind", "status", "accountAlias", "accountName", "phoneMask", "jobseekerResumeHref", "role", "sourceUrl", "accountVerified", "platformUniqueIdVerified", "eligibleForActions", "confirmedAt", "checkedAt", "reason"];
    if (Object.keys(t).length !== l.length || l.some((c) => !Object.prototype.hasOwnProperty.call(t, c))) throw new Error("\u6240\u9009\u8D26\u53F7\u7ED3\u679C\u7ED3\u6784\u4E0D\u7B26\uFF0C\u505C\u6B62\u91C7\u7528");
    for (const c of ["accountAlias", "accountName", "phoneMask"]) if (typeof t[c] != "string" || !t[c].trim() || t[c] !== t[c].trim() || t[c].length > 100 || /[\r\n]/.test(t[c])) throw new Error("\u8D26\u53F7\u5FC5\u8981\u5B57\u6BB5\u7F3A\u5931\u6216\u683C\u5F0F\u65E0\u6548\uFF0C\u505C\u6B62\u91C7\u7528");
    if (!/^[+\d ()-]*\*{2,}[\d ()-]+$/.test(t.phoneMask) || /登录|注册|验证码/.test(t.accountName)) throw new Error("\u8D26\u53F7\u6765\u6E90\u7F3A\u5C11\u6709\u6548\u7684\u53EF\u89C1\u59D3\u540D\u6216\u624B\u673A\u53F7\u63A9\u7801");
    if (typeof t.reason != "string" || !t.reason.trim()) throw new Error("\u8D26\u53F7\u7ED3\u679C\u7F3A\u5C11\u660E\u786E\u6838\u5BF9\u8BF4\u660E");
    const h = Date.parse(t.confirmedAt), b = Date.parse(t.checkedAt);
    if (typeof t.confirmedAt != "string" || typeof t.checkedAt != "string" || !Number.isFinite(h) || !Number.isFinite(b) || h <= 0 || b < h || b > Date.now() + 6e4) throw new Error("\u8D26\u53F7\u786E\u8BA4\u6216\u590D\u9A8C\u65F6\u95F4\u65E0\u6CD5\u6838\u5BF9\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4");
    if (typeof t.sourceUrl != "string" || typeof t.jobseekerResumeHref != "string" || !t.sourceUrl.trim() || !t.jobseekerResumeHref.trim() || t.sourceUrl.length > 16384 || t.jobseekerResumeHref.length > 16384) throw new Error("\u8D26\u53F7\u9875\u9762\u6216\u7B80\u5386\u5165\u53E3\u5730\u5740\u65E0\u6548");
    const u = new URL(t.sourceUrl), w = new URL(t.jobseekerResumeHref, t.sourceUrl);
    if (u.origin !== "https://www.zhipin.com" || u.pathname !== "/web/geek/account" || u.searchParams.get("type") !== "accountSet" || u.username || u.password || u.hash || w.origin !== u.origin || w.pathname !== "/web/geek/resume" || w.username || w.password) throw new Error("\u8D26\u53F7\u8BB0\u5F55\u7684\u9875\u9762\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u4E0D\u7B26");
    return D.throwIfAborted(), { version: 1, accountSourceValid: true, currentAccountVerified: false, account: t };
  };
  return s;
})(), oe = /* @__PURE__ */ (() => {
  async function s({ input: g, signal: D, template: a }) {
    D.throwIfAborted();
    const t = g?.expected?.account;
    if (g?.expected?.accountSourceValid !== true || t?.kind !== "boss-account-source" || t.status !== "account-source-confirmed" || t.accountVerified !== true) throw Error("\u7F3A\u5C11\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\u6765\u6E90");
    const l = async (f, r, B) => {
      D.throwIfAborted();
      const O = await a.browser("browser", { operation: f, ...r ? { selector: r } : {}, ...B === void 0 ? {} : { value: B }, timeoutMs: 3e3 });
      return D.throwIfAborted(), O;
    };
    let h = await l("url");
    if (h === "about:blank") {
      await l("navigate", void 0, t.sourceUrl);
      for (let f = 0; f < 40; f++) {
        const r = await l("url");
        if (new URL(r).origin === "https://www.zhipin.com" && await l("count", "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)") === 1) break;
        await new Promise((B) => setTimeout(B, 150));
      }
      h = await l("url");
    }
    const b = new URL(h);
    if (b.origin !== "https://www.zhipin.com" || b.username || b.password || !b.pathname.startsWith("/web/") && !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(b.pathname)) throw Error("\u5F53\u524D\u9875\u9762\u4E0D\u662FBOSS\u6C42\u804C\u9875\u9762\uFF0C\u8BF7\u5148\u767B\u5F55");
    const u = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", w = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)", c = await l("count", u), v = await l("count", w);
    if (c !== 1 || v !== 1) throw Error("\u5F53\u524D\u9875\u9762\u8D26\u53F7\u5165\u53E3\u6570\u91CF\u5F02\u5E38\uFF1A" + JSON.stringify({ nameCount: c, resumeCount: v }));
    const A = await l("read", u), E = await l("attribute", w, "href");
    if (typeof A != "string" || A.normalize("NFKC").trim() !== t.accountName.normalize("NFKC").trim() || typeof E != "string" || new URL(E, h).href !== new URL(t.jobseekerResumeHref, t.sourceUrl).href || await l("url") !== h) throw Error("\u5F53\u524D\u767B\u5F55\u8EAB\u4EFD\u3001\u6C42\u804C\u5165\u53E3\u6216\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
    return { version: 1, status: "current-account-source-matched", accountAlias: t.accountAlias, accountName: t.accountName, phoneMask: t.phoneMask, jobseekerResumeHref: t.jobseekerResumeHref, sourceUrl: t.sourceUrl, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), currentPageUrl: h, currentAccountVerified: true, platformUniqueIdVerified: false, eligibleForActions: false, accountCheckMode: "confirmed-initial-account-and-visible-header", phoneMaskRechecked: false, reason: "\u4F7F\u7528\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\uFF1B\u53EA\u8BFB\u6838\u5BF9\u5F53\u524D\u767B\u5F55\u59D3\u540D\u3001\u6C42\u804C\u5165\u53E3\u53CA\u9875\u9762\u8FDE\u7EED\u6027\uFF0C\u624B\u673A\u53F7\u63A9\u7801\u6CBF\u7528\u786E\u8BA4\u6765\u6E90\uFF0C\u6CA1\u6709\u91CD\u65B0\u8BFB\u53D6\u3002" };
  }
  return s;
})(), Y = (s) => Array.isArray(s) ? s.map(Y) : s && typeof s == "object" ? Object.fromEntries(Object.keys(s).sort().map((g) => [g, Y(s[g])])) : s, x = (s) => q("sha256").update(JSON.stringify(Y(s))).digest("hex");
async function se({ input: s, template: g, signal: D, artifact: a }, t) {
  const l = s.configuration, h = await re({ input: s.account, signal: D });
  await oe({ input: { expected: h }, template: g, signal: D });
  const b = async (d) => {
    const y = JSON.parse(await g.file("communication-cache", { operation: "read", name: d })), { sha256: i, ...o } = y;
    if (i !== x(o)) throw Error("\u539F\u6062\u590D\u8BC1\u636E\u6458\u8981\u4E0D\u7B26");
    return y;
  };
  if (!/^test-greeting-completion-v1-[a-f0-9]{64}-[a-f0-9]{24}\.json$/u.test(t)) throw Error("\u6062\u590D\u6765\u6E90\u6587\u4EF6\u540D\u65E0\u6548");
  const u = await b(t), w = new URL(h.account.jobseekerResumeHref, h.account.sourceUrl), c = q("sha256").update(JSON.stringify(["boss-visible-account-source-v1", h.account.accountName, h.account.phoneMask, w.origin + w.pathname])).digest("hex");
  if (u.accountKey !== c || u.contextId !== l.contextId || u.kind !== "boss-test-new-greeting-completion" || u.confirmed !== true || u.newConfirmed !== 2) throw Error("\u6062\u590D\u8D26\u53F7\u3001\u5B9E\u4F8B\u6216\u539F\u4E24\u6B21\u56DE\u6267\u4E0D\u7B26");
  const v = t.match(/-([a-f0-9]{24})\.json$/u)[1], A = "test-fixed-unread-set-v1-" + v + "-" + c + "-" + u.day + ".json", E = "test-fixed-unread-progress-v1-" + v + "-" + c + "-" + u.day + ".json", f = await b(A), r = await b(E);
  if (f.sha256 !== r.fixedUnreadSetSha256 || f.siteDailyLimitEvidenceSha256 !== u.sha256 || f.accountKey !== c || r.accountKey !== c || f.sourceContextId !== l.contextId) throw Error("\u56FA\u5B9A\u6210\u5458\u3001\u8FDB\u5EA6\u6216\u6D3B\u52A8\u64CD\u4F5C\u6765\u6E90\u4E0D\u7B26");
  if (r.active) {
    const d = await g.state.get(), y = r.active, i = d.replyIntents.filter((M) => M.accountKey === c && M.conversationKey === "boss-chat:" + y.firstMessageId && M.status === "unknown");
    if (i.length !== 1) throw Error("\u5B58\u5728\u672A\u6838\u5BF9\u7684\u6D3B\u52A8\u64CD\u4F5C\uFF0C\u4E0D\u81EA\u52A8\u6E05\u9664");
    const o = r.completed.find((M) => M.memberKey === y.memberKey);
    if (!o || o.status !== "review" || o.operationKey) throw Error("\u6D3B\u52A8\u6765\u6E90\u5F85\u529E\u4E0D\u53EF\u66FF\u6362");
    const V = JSON.stringify(r);
    r.reviewHistory = [...r.reviewHistory || [], o], r.completed = r.completed.filter((M) => M.memberKey !== y.memberKey), r.completed.push({ ...o, status: "review", reason: "\u56DE\u8F66\u53D1\u9001\u672A\u53D6\u5F97\u9001\u8FBE\u56DE\u6267\uFF0Cunknown\u7981\u6B62\u91CD\u53D1", operationKey: i[0].key, incomingMessageId: i[0].incomingMessageId, sourceReviewVersion: "chat-list-direct-v5", checkedAt: (/* @__PURE__ */ new Date()).toISOString() }), r.active = null, r.revision++, r.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete r.sha256, r.sha256 = x(r);
    const F = JSON.parse(await g.file("communication-cache", { operation: "read", name: E }));
    if (x(F) !== x(JSON.parse(V))) throw Error("\u4FDD\u5B58\u672A\u77E5\u5F85\u529E\u524D\u8FDB\u5EA6\u53D8\u5316");
    if (await g.file("communication-cache", { operation: "write", name: E, content: JSON.stringify(r) }), (await b(E)).sha256 !== r.sha256) throw Error("\u672A\u77E5\u5F85\u529E\u672A\u8BFB\u56DE");
  }
  let B = false;
  for (const d of [...r.completed]) if (d.status === "review" && !d.operationKey && !d.modelRequestId && d.reason === "\u5173\u8054\u804C\u4F4D\u5B8C\u6574\u6807\u9898\u4E0E\u56FA\u5B9A\u4F1A\u8BDD\u4E0D\u7B26\uFF0C\u672A\u91C7\u7528\u6765\u6E90") {
    r.reviewHistory = [...r.reviewHistory || [], d];
    const y = r.completed.indexOf(d);
    r.completed[y] = { ...d, status: "skipped-job-source-mismatch", reason: "\u6309\u672C\u4EBA\u89C4\u5219\uFF0C\u65E2\u6709\u5C97\u4F4D\u6765\u6E90\u4E0D\u4E00\u81F4\u76F4\u63A5\u8DF3\u8FC7\uFF0C\u4E0D\u67E5\u8BE2\u516C\u53F8\u5C97\u4F4D\u3001\u4E0D\u5916\u53D1", sourceReviewVersion: "chat-list-direct-v5", checkedAt: (/* @__PURE__ */ new Date()).toISOString() }, B = true;
  }
  if (B) {
    if ((await b(E)).sha256 !== r.sha256) throw Error("\u6765\u6E90\u8DF3\u8FC7\u767B\u8BB0\u524D\u8FDB\u5EA6\u53D8\u5316");
    if (r.revision++, r.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete r.sha256, r.sha256 = x(r), await g.file("communication-cache", { operation: "write", name: E, content: JSON.stringify(r) }), (await b(E)).sha256 !== r.sha256) throw Error("\u6765\u6E90\u8DF3\u8FC7\u8FDB\u5EA6\u672A\u8BFB\u56DE");
  }
  const O = r.completed.filter((d) => d.status === "review" && !d.operationKey && !d.modelRequestId && ["\u56FA\u5B9A\u6210\u5458\u7F3A\u5C11\u552F\u4E00\u53EF\u89C1\u8EAB\u4EFD\uFF0C\u672A\u731C\u6D4B\u59D3\u540D", "\u56FA\u5B9A\u6210\u5458\u5B9A\u5411\u641C\u7D22\u7ED3\u679C\u4E0D\u552F\u4E00", "\u56FA\u5B9A\u6210\u5458\u59D3\u540D\u63A7\u4EF6\u4E0D\u552F\u4E00"].includes(d.reason) && d.sourceReviewVersion !== "chat-list-direct-v5"), N = f.members.filter((d) => O.some((y) => y.memberKey === d.key)).map((d) => ({ ...d, identityLine: d.text.split(/\r?\n/u).map((y) => y.trim()).filter(Boolean)[2] })), m = { version: 1, kind: "unread-closing-cohort", restoredExistingClosing: true, closingPhase: true, contextId: l.contextId, accountKey: c, day: u.day, timeZone: u.timeZone, accountSource: h, configuration: l.value, configurationRevision: l.revision, siteDailyLimitEvidence: null, testCompletionEvidence: u, closingTrigger: "two-new-greetings-test", fixedUnreadSetName: A, fixedUnreadSetSha256: f.sha256, progressName: E, progressSha256: r.sha256, progress: r, memberCount: f.members.length, unreadMessageCount: f.unreadMessageCount, newGreeting: false, newMembersAdded: 0, remaining: N.length, ready: N.length > 0, status: "resume-fixed-unread", member: N[0] || null }, C = { ...m, items: N.map((d) => ({ ...m, member: d, ready: true })) };
  return await a("fixed-cohort-recovery-source.json", JSON.stringify({ evidenceName: t, setName: A, progressName: E, memberCount: N.length, originalDay: u.day, newGreeting: false })), C;
}
async function ce({ input: s, template: g, signal: D }) {
  D.throwIfAborted();
  const a = s?.configuration, t = s?.state;
  if (s?.restoreExistingClosing === true && a?.value?.recoveryEvidenceName) return se({ input: s, template: g, signal: D, artifact: async () => {
  } }, a.value.recoveryEvidenceName);
  if (a?.operation !== "configuration" || t?.operation !== "state.read" || a.contextId !== t.contextId || !a.value || !t.value) throw Error("\u7F3A\u5C11\u540C\u5B9E\u4F8B\u56FA\u5B9A\u914D\u7F6E\u4E0E\u5B8C\u6574\u72B6\u6001");
  const l = await re({ input: s.account, signal: D });
  await oe({ input: { expected: l }, template: g, signal: D });
  const h = l.account, b = new URL(h.jobseekerResumeHref, h.sourceUrl), u = q("sha256").update(JSON.stringify(["boss-visible-account-source-v1", h.accountName, h.phoneMask, b.origin + b.pathname])).digest("hex"), w = (e) => {
    const { sha256: n, ...j } = e;
    return n === x(j);
  }, c = async (e) => {
    try {
      return JSON.parse(await g.file("communication-cache", { operation: "read", name: e }));
    } catch (n) {
      if (String(n.message || n).includes("ENOENT")) return null;
      throw n;
    }
  }, v = async (e, n, j) => {
    if (((await c(e))?.sha256 || null) !== j) throw Error("\u6D88\u606F\u6536\u5C3E\u8BB0\u5F55\u88AB\u5176\u4ED6\u64CD\u4F5C\u66F4\u6539\uFF0C\u672A\u8986\u76D6");
    const J = { ...n };
    delete J.sha256, J.sha256 = x(J), await g.file("communication-cache", { operation: "write", name: e, content: JSON.stringify(J) });
    const R = await c(e);
    if (!w(R) || R.sha256 !== J.sha256) throw Error("\u6D88\u606F\u6536\u5C3E\u8BB0\u5F55\u5199\u5165\u540E\u672A\u5B8C\u6574\u8BFB\u56DE");
    return R;
  }, A = a.value.replyTimeZone, E = new Intl.DateTimeFormat("sv-SE", { timeZone: A, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date()), f = a.value.acceptanceNewGreetings === 2;
  if (f && s?.restoreExistingClosing === true) throw Error("\u4E24\u6B21\u65B0\u62DB\u547C\u6D4B\u8BD5\u4E0D\u5F97\u4F7F\u7528\u65E7\u6536\u5C3E\u6062\u590D\u5F00\u5173");
  const r = f ? x({ contextId: a.contextId, revision: a.revision, day: E, timeZone: A }).slice(0, 24) : null, B = await ae(g, D, { accountKey: u, contextId: a.contextId, day: E, timeZone: A, revision: a.revision, configuration: a.value });
  if (f && !B.confirmed) return { version: 1, kind: "unread-closing-cohort", closingPhase: false, ready: false, contextId: a.contextId, accountKey: u, day: E, timeZone: A, items: [], memberCount: 0, remaining: 0, status: "test-greeting-phase", testGreetingProgress: B, newGreeting: false, newMembersAdded: 0 };
  const O = f ? "test-greeting-completion-v1-" + u + "-" + r + ".json" : null;
  if (f) {
    const e = await c(O);
    if (e) {
      if (!w(e) || e.baselineSha256 !== B.baselineSha256 || x(e.confirmedKeys) !== x(B.confirmedKeys)) throw Error("\u4E24\u6B21\u62DB\u547C\u6D4B\u8BD5\u5B8C\u6210\u8BC1\u636E\u53D8\u5316\uFF0C\u505C\u6B62");
    } else await v(O, B, null);
  }
  const N = (f ? "test-active-unread-closing-v1-" + r + "-" : "active-unread-closing-v1-") + u + ".json";
  let m = await c(N);
  if (m && (!w(m) || m.kind !== "boss-active-unread-closing" || m.accountKey !== u || !/^\d{4}-\d{2}-\d{2}$/.test(m.day))) throw Error("\u6536\u5C3E\u6062\u590D\u6307\u9488\u8EAB\u4EFD\u6216\u6458\u8981\u65E0\u6548\uFF0C\u672A\u91CD\u5EFA");
  const C = s?.restoreExistingClosing === true;
  if (s?.restoreExistingClosing !== void 0 && typeof s.restoreExistingClosing != "boolean") throw Error("\u4EC5\u6062\u590D\u65E2\u6709\u6D88\u606F\u6536\u5C3E\u987B\u4E3A\u660E\u786E\u5F00\u5173");
  if (C && !m) throw Error("\u6CA1\u6709\u672C\u8D26\u53F7\u539F\u6536\u5C3E\u6307\u9488\uFF0C\u672A\u65B0\u5EFA\u96C6\u5408\u6216\u53D1\u9001\u62DB\u547C");
  const d = m?.sha256 || null;
  if (m && m.day !== E && !C) {
    const e = await c((f ? "test-fixed-unread-set-v1-" + r + "-" : "fixed-unread-set-v1-") + u + "-" + m.day + ".json"), n = await c((f ? "test-fixed-unread-progress-v1-" + r + "-" : "fixed-unread-progress-v1-") + u + "-" + m.day + ".json");
    if (!e || !n || !w(e) || !w(n) || e.sha256 !== m.fixedUnreadSetSha256 || n.fixedUnreadSetSha256 !== e.sha256 || n.accountKey !== u || !Array.isArray(e.members) || !Array.isArray(n.completed)) throw Error("\u5F80\u65E5\u6536\u5C3E\u6765\u6E90\u7F3A\u5931\u6216\u635F\u574F\uFF1B\u7981\u6B62\u91CD\u65B0\u6295\u9012");
    const j = new Set(e.members.map((S) => S.key));
    if (new Set(n.completed.map((S) => S.memberKey)).size !== n.completed.length || n.completed.some((S) => !j.has(S.memberKey))) throw Error("\u5F80\u65E5\u6536\u5C3E\u6210\u5458\u4E0D\u5B8C\u6574");
    !n.active && n.completed.length === e.members.length && n.completed.every((S) => S.status !== "review" || S.replyPolicyVersion === "work-questions-partial-known-v2") && (m = null);
  }
  const y = m?.day || E, i = f ? O : "site-daily-limit-v1-" + u + "-" + y + ".json", o = await c(i), V = (f ? "test-fixed-unread-set-v1-" + r + "-" : "fixed-unread-set-v1-") + u + "-" + y + ".json";
  let F = await c(V);
  if (!o && !m && !F) return { version: 1, kind: "unread-closing-cohort", closingPhase: false, ready: false, contextId: a.contextId, accountKey: u, day: y, timeZone: A, items: [], memberCount: 0, remaining: 0, status: "greeting-phase", newGreeting: false, newMembersAdded: 0 };
  if (!o || !w(o) || o.kind !== (f ? "boss-test-new-greeting-completion" : "boss-site-daily-limit") || o.accountKey !== u || o.confirmed !== true || o.day !== y || o.timeZone !== A) throw Error("\u672A\u627E\u5230\u672C\u8D26\u53F7\u771F\u5B9E\u7F51\u7AD9\u4E0A\u9650\u8BC1\u636E\uFF1B\u7981\u6B62\u91CD\u65B0\u6253\u62DB\u547C\u6216\u626B\u63CF\u5386\u53F2");
  if (C && !F) throw Error("\u539F\u56FA\u5B9A\u4F1A\u8BDD\u96C6\u5408\u7F3A\u5931\uFF0C\u672A\u626B\u63CF\u65B0\u589E\u6216\u91CD\u5EFA\u5386\u53F2");
  if (!F) {
    const e = async (k, I, L) => (D.throwIfAborted(), g.browser("browser", { operation: k, ...I ? { selector: I } : {}, ...L === void 0 ? {} : { value: L }, timeoutMs: 3e3 })), n = "https://www.zhipin.com/web/geek/chat", j = new URL(await e("url"));
    (j.origin !== new URL(n).origin || j.pathname !== "/web/geek/chat") && await e("navigate", null, n);
    const S = ".list-warp.v2 ul:has(> .selected)", J = S + " > :nth-child(2)", R = ".user-list-content > :first-child";
    let ee = false;
    for (let k = 0; k < 40; k++) {
      if (await e("count", J) === 1 && /^未读(?:\s*\(\d{1,4}\))?$/u.test(String(await e("read", J)).trim())) {
        ee = true;
        break;
      }
      await new Promise((I) => setTimeout(I, 250));
    }
    if (!ee) throw Error("\u7F51\u7AD9\u672A\u8BFB\u7B5B\u9009\u5165\u53E3\u672A\u5C31\u7EEA\uFF1B\u672A\u626B\u63CF\u5168\u90E8\u5386\u53F2");
    (await e("count", S + " .selected") !== 1 || !/^未读/u.test(String(await e("read", S + " .selected")).trim())) && await e("click", J);
    let K = null, $ = 0;
    for (let k = 0; k < 40; k++) {
      if (await e("count", S + " .selected") === 1 && await e("count", R) === 1) {
        const I = String(await e("read", S + " .selected")).trim(), L = await e("count", R + " > *"), z = String(await e("read", R)), T = { tabText: I, count: L, text: z };
        if (/^未读(?:\s*\(\d{1,4}\))?$/u.test(I) && JSON.stringify(T) === JSON.stringify(K) ? $++ : $ = 0, K = T, $ >= 2) break;
      }
      await new Promise((I) => setTimeout(I, 250));
    }
    if ($ < 2 || !K || !Number.isSafeInteger(K.count) || K.count < 0 || K.count > 200) throw Error("\u672A\u8BFB\u5217\u8868\u672A\u7A33\u5B9A\uFF0C\u672A\u56FA\u5B9A\u90E8\u5206\u96C6\u5408");
    const te = /^未读\s*\((\d{1,4})\)$/u.exec(K.tabText), W = te ? Number(te[1]) : 0, H = [];
    for (let k = 1; k <= K.count; k++) {
      const I = R + " > :nth-child(" + k + ")", L = String(await e("read", I)).trim(), z = I + " .friend-content";
      if (W === 0 && await e("count", z) === 0 && /^(?:暂无消息|暂无未读消息|暂无未读会话|没有未读消息)$/u.test(L)) continue;
      if (L.length > 1e4 || await e("count", z) !== 1) throw Error("\u672A\u8BFB\u6210\u5458\u8EAB\u4EFD\u6216\u5B8C\u6574\u6B63\u6587\u65E0\u6CD5\u6838\u5BF9");
      const T = String(await e("read", z)).trim(), ue = L.split(/\r?\n/u).map((ne) => ne.trim()).filter(Boolean), X = /^\d{1,4}$/u.test(ue[0] || "") ? Number(ue[0]) : null;
      if (!T || !Number.isSafeInteger(X) || X < 1) throw Error("\u672A\u8BFB\u6210\u5458\u8BA1\u6570\u65E0\u6CD5\u6838\u5BF9");
      H.push({ position: k, displayIdentity: T, unreadCount: X, text: L, attributes: [], key: x(["boss-fixed-unread-visible-member-v1", u, T]) });
    }
    if (H.reduce((k, I) => k + I.unreadCount, 0) !== W || new Set(H.map((k) => k.key)).size !== H.length) throw Error("\u672A\u8BFB\u4F1A\u8BDD\u96C6\u5408\u8986\u76D6\u6570\u91CF\u4E0D\u4E00\u81F4\uFF0C\u672A\u56FA\u5B9A\u90E8\u5206\u96C6\u5408");
    if (await e("url") !== n || String(await e("read", S + " .selected")).trim() !== K.tabText || await e("count", R + " > *") !== K.count || String(await e("read", R)) !== K.text || x(await g.state.get()) !== x(t.value)) throw Error("\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u524D\u6765\u6E90\u6216\u72B6\u6001\u53D8\u5316\uFF0C\u672A\u4FDD\u5B58");
    F = await v(V, { version: 1, kind: "boss-fixed-unread-set", accountKey: u, sourceContextId: a.contextId, day: y, timeZone: A, configurationRevision: a.revision, siteDailyLimitEvidenceName: i, siteDailyLimitEvidenceSha256: o.sha256, sourceUrl: n, selectedTabText: K.tabText, unreadMessageCount: W, members: H, createdAt: (/* @__PURE__ */ new Date()).toISOString(), membershipImmutable: true }, null);
  }
  if (!F || !w(F) || F.kind !== "boss-fixed-unread-set" || F.accountKey !== u || F.day !== y || F.siteDailyLimitEvidenceSha256 !== o.sha256 || !Array.isArray(F.members) || F.members.length > 200 || new Set(F.members.map((e) => e.key)).size !== F.members.length || F.members.reduce((e, n) => e + n.unreadCount, 0) !== F.unreadMessageCount) throw Error("\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u7F3A\u5931\u6216\u8986\u76D6\u6570\u91CF\u4E0D\u4E00\u81F4\uFF1B\u672A\u91CD\u5EFA\u6216\u6269\u5C55\u96C6\u5408");
  const U = F.members.map((e) => {
    const n = e.text.split(/\r?\n/u).map((j) => j.trim()).filter(Boolean);
    if (!/^[a-f0-9]{64}$/.test(e.key) || !/^\d+$/.test(n[0]) || !n[2] || n[2].length > 500) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u53EF\u89C1\u8EAB\u4EFD\u7F3A\u5931");
    return { ...e, identityLine: n[2] };
  });
  if (new Set(U.map((e) => e.identityLine)).size !== U.length) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u5B58\u5728\u540C\u540D\u540C\u516C\u53F8\u8EAB\u4EFD\u6B67\u4E49\uFF0C\u7981\u6B62\u731C\u6D4B");
  const M = "account-outbound-safety-v1-" + u + ".json", P = await c(M);
  if (!P || !w(P) || P.kind !== "boss-account-outbound-safety" || P.accountKey !== u || !Array.isArray(P.records) || !P.records.length) throw Error("\u539F\u8D26\u53F7\u5916\u53D1\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF0C\u963B\u6B62\u7EED\u53D1");
  if (m && (m.fixedUnreadSetSha256 !== F.sha256 || m.siteDailyLimitEvidenceSha256 !== o.sha256)) throw Error("\u6062\u590D\u6307\u9488\u4E0E\u56FA\u5B9A\u96C6\u5408\u4E0D\u7B26");
  m || (m = await v(N, { version: 1, kind: "boss-active-unread-closing", accountKey: u, day: y, timeZone: A, fixedUnreadSetSha256: F.sha256, siteDailyLimitEvidenceSha256: o.sha256, createdAt: (/* @__PURE__ */ new Date()).toISOString() }, d));
  const G = (f ? "test-fixed-unread-progress-v1-" + r + "-" : "fixed-unread-progress-v1-") + u + "-" + y + ".json";
  let p = await c(G);
  if (p && (!w(p) || p.kind !== "boss-fixed-unread-progress" || p.accountKey !== u || p.fixedUnreadSetSha256 !== F.sha256 || !Array.isArray(p.completed) || p.completed.some((e) => !U.some((n) => n.key === e.memberKey)) || new Set(p.completed.map((e) => e.memberKey)).size !== p.completed.length || p.active && !U.some((e) => e.key === p.active.memberKey))) throw Error("\u6536\u5C3E\u8FDB\u5EA6\u8EAB\u4EFD\u3001\u6458\u8981\u6216\u6210\u5458\u65E0\u6548");
  if (C && !p) throw Error("\u539F\u6D88\u606F\u6536\u5C3E\u8FDB\u5EA6\u7F3A\u5931\uFF0C\u672A\u91CD\u5EFA\u6216\u91CD\u653E");
  p || (p = await v(G, { version: 1, kind: "boss-fixed-unread-progress", accountKey: u, day: y, timeZone: A, fixedUnreadSetSha256: F.sha256, revision: 0, active: null, completed: [], createdAt: (/* @__PURE__ */ new Date()).toISOString() }, null));
  const Z = (e) => !ie(e) && (e.status !== "review" || e.replyPolicyVersion === "work-questions-partial-known-v2"), _ = p.active ? U.find((e) => e.key === p.active.memberKey) : U.find((e) => !p.completed.some((n) => n.memberKey === e.key && Z(n))), Q = { version: 1, kind: "unread-closing-cohort", restoredExistingClosing: C, closingPhase: true, ready: !!_, contextId: a.contextId, accountKey: u, accountSource: l, configuration: a.value, configurationRevision: a.revision, siteDailyLimitEvidence: f ? null : o, testCompletionEvidence: f ? o : null, closingTrigger: f ? "two-new-greetings-test" : "real-site-daily-limit", fixedUnreadSetName: V, fixedUnreadSetSha256: F.sha256, member: _ || null, memberCount: U.length, unreadMessageCount: F.unreadMessageCount, progressName: G, progressSha256: p.sha256, progress: p, remaining: U.length - p.completed.filter(Z).length, status: _ ? "resume-fixed-unread" : "fixed-unread-complete", newGreeting: false, newMembersAdded: 0 };
  if (x(await g.state.get()) !== x(t.value)) throw Error("\u51C6\u5907\u6536\u5C3E\u671F\u95F4\u6B63\u5F0F\u72B6\u6001\u53D8\u5316\uFF0C\u672A\u7EE7\u7EED");
  return Q.items = U.filter((e) => !p.completed.some((n) => n.memberKey === e.key && Z(n))).sort((e, n) => +(n.key === p.active?.memberKey) - +(e.key === p.active?.memberKey)).map((e) => ({ ...Q, member: e, ready: true })), Q;
}
var stdin_default = ce;
export {
  stdin_default as default
};
