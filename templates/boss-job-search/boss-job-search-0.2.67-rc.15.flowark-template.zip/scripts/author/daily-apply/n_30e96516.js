function P(e) {
  return e.status === "review" && !e.operationKey && !e.modelRequestId && e.sourceReviewVersion !== "chat-list-direct-v5" && /固定成员姓名控件不唯一|固定成员定向搜索结果不唯一|关联职位没有可核对的继续沟通入口|固定成员缺少可核对的定向搜索姓名，未猜测|固定成员缺少唯一可见身份|关联职位返回后的完整消息或对象变化/u.test(String(e.reason || ""));
}
async function R(e, u) {
  const n = ".user-list-content", a = (s) => s.replace(/[\s\uE000-\uF8FF]/gu, ""), t = ".list-warp.v2 input";
  await e("count", t) === 1 && String(await e("inputValue", t, null)) !== "" && await e("fill", t, "");
  const o = ".list-warp.v2 ul:has(> .selected)", r = o + " > :nth-child(2)";
  await e("count", r) === 1 && /^未读(?:\s*\(\d+\))?$/u.test(String(await e("read", r)).trim()) && !/^未读/u.test(String(await e("read", o + " .selected")).trim()) && await e("click", r);
  for (let s = 0; s < 30 && await e("count", n) !== 1; s++) await new Promise((y) => setTimeout(y, 150));
  if (await e("count", n) !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u6765\u6E90\u4E0D\u552F\u4E00");
  const c = [{ selector: n, depth: 0 }], i = [];
  let f = 0;
  for (; c.length; ) {
    const s = c.shift();
    if (++f > 400) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
    const y = await e("count", s.selector + ".friend-content") === 1, d = y ? 1 : await e("count", s.selector + " .friend-content");
    if (d === 1) {
      const w = y ? s.selector : s.selector + " .friend-content", F = String(await e("read", s.selector)).trim();
      a(F).includes(a(String(u.member.text).split(/\r?\n/u).slice(3).join(`
`).trim())) && i.push({ sel: s.selector, label: w, text: F });
      continue;
    }
    if (d > 1 && s.depth < 4) {
      const w = await e("count", s.selector + " > *");
      if (!Number.isSafeInteger(w) || w > 200) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
      for (let F = 1; F <= w; F++) c.push({ selector: s.selector + " > :nth-child(" + F + ")", depth: s.depth + 1 });
    }
  }
  if (i.length === 0 && u.member.lookupName) {
    await e("fill", t, u.member.lookupName);
    const s = ".boss-search-result .search-list";
    for (let h = 0; h < 30 && !(await e("count", s) > 0); h++) await new Promise((p) => setTimeout(p, 150));
    if (await e("count", s) !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u5B9A\u5411\u641C\u7D22\u7ED3\u679C\u4E0D\u552F\u4E00");
    const y = [s], d = [];
    let w = 0;
    for (; y.length; ) {
      const h = y.shift();
      if (++w > 100) throw Error("\u8054\u7CFB\u4EBA\u59D3\u540D\u63A7\u4EF6\u8303\u56F4\u8FC7\u5927");
      const p = await e("count", h + " > *"), g = String(await e("read", h)).trim();
      if (g === u.member.lookupName && d.push({ label: h, text: g }), p > 0 && p < 30) for (let B = 1; B <= p; B++) y.push(h + " > :nth-child(" + B + ")");
    }
    const F = d.filter((h) => !d.some((p) => p !== h && p.label.startsWith(h.label + " > ")));
    if (F.length !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u59D3\u540D\u63A7\u4EF6\u4E0D\u552F\u4E00");
    i.push(F[0]);
  }
  if (i.length !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u7F3A\u5C11\u552F\u4E00\u53EF\u89C1\u8EAB\u4EFD\uFF0C\u672A\u731C\u6D4B\u59D3\u540D");
  const m = i[0];
  if (String(await e("read", m.label)).trim() !== m.text) throw Error("\u56FA\u5B9A\u6210\u5458\u53EF\u89C1\u8EAB\u4EFD\u53D8\u5316");
  await e("click", m.label);
  for (let s = 0; s < 30; s++) {
    if (await e("count", ".chat-conversation .user-info") === 1 && await e("count", "li.message-item") > 0) {
      const y = String(await e("read", ".chat-conversation .user-info")).trim(), d = await K(e), w = a(String(u.member.text).split(/\r?\n/u).slice(3).join(`
`).trim());
      if (y && d.some((F) => F.direction === "incoming" && a(F.text || "") === w)) {
        u.recipientLabel = y, u.rows = [{ mid: d[0].mid }];
        return;
      }
    }
    await new Promise((y) => setTimeout(y, 150));
  }
  throw Error("\u56FA\u5B9A\u6210\u5458\u53EF\u89C1\u8EAB\u4EFD\u672A\u5B8C\u6574\u8BFB\u56DE");
}
async function X(e, u, n) {
  if (typeof n != "string" || !n.trim()) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u539F\u59D3\u540D\u6765\u6E90\u7F3A\u5931");
  await e("navigate", void 0, "https://www.zhipin.com/web/geek/chat"), await R(e, u);
}
function Y(e, u) {
  const n = (i) => i.normalize("NFKC").replace(/\s+/gu, " ").trim().toLocaleLowerCase("en-US");
  if (typeof e != "string" || !e.trim() || e.length > 1e3 || /(?:\.{3}|…|⋯)/u.test(e)) throw Error("\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u7F3A\u5931\u6216\u622A\u65AD\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u8BB0\u5F55");
  const a = u?.titleKeywords, t = u?.excludedRoles;
  for (const [i, f, m] of [["titleKeywords", a, 1], ["excludedRoles", t, 0]]) if (!Array.isArray(f) || f.length < m || f.length > 20 || f.some((s) => typeof s != "string" || !n(s) || s.length > 100) || new Set(f.map(n)).size !== f.length) throw Error("\u5C97\u4F4D\u8303\u56F4\u914D\u7F6E\u65E0\u6548\uFF1A" + i + "\uFF1B\u672A\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE");
  const o = n(e), r = t.filter((i) => o.includes(n(i))), c = a.filter((i) => o.includes(n(i)));
  return { version: 1, kind: "literal-full-job-title-scope", fullTitle: e, matched: c, excluded: r, allowed: r.length === 0 && c.length > 0, source: "actual-complete-job-title", jdUsed: false, searchKeywordUsedAsEvidence: false };
}
import { createHash as I } from "node:crypto";
const te = /* @__PURE__ */ (() => {
  var e = async ({ input: u, signal: n }) => {
    n.throwIfAborted();
    const a = u, t = a?.value;
    if (!a || a.version !== 1 || a.operation !== "read" || a.binding !== "account-source-result" || a.schemaValidation !== "passed" || a.dataChanged !== false || a.ref?.version !== 1 || a.ref.policy !== "credential-redacted-v1" || a.ref.source?.entryId !== "account-source") throw new Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u5DF2\u9009\u62E9\u4E14\u5B8C\u6574\u53EF\u590D\u7528\u7684\u8D26\u53F7\u6765\u6E90\uFF0C\u8BF7\u5230\u8D44\u6E90\u9875\u91CD\u65B0\u6838\u5BF9\u5E76\u4FDD\u5B58");
    if (!t || t.version !== 1 || t.kind !== "boss-account-source" || t.status !== "account-source-confirmed" || t.accountVerified !== true || t.platformUniqueIdVerified !== false || t.eligibleForActions !== false || t.role !== "jobseeker") throw new Error("\u6240\u9009\u8BB0\u5F55\u5C1A\u672A\u5B8C\u6210\u672C\u4EBA\u786E\u8BA4\u548C\u6765\u6E90\u590D\u9A8C\uFF1B\u8BF7\u5728\u5F53\u524D\u5B9E\u4F8B\u5B8C\u6210\u8D26\u53F7\u6838\u5BF9\uFF0C\u518D\u9009\u62E9\u8BE5\u6B21\u5DF2\u4FDD\u5B58\u7ED3\u679C");
    const o = ["version", "kind", "status", "accountAlias", "accountName", "phoneMask", "jobseekerResumeHref", "role", "sourceUrl", "accountVerified", "platformUniqueIdVerified", "eligibleForActions", "confirmedAt", "checkedAt", "reason"];
    if (Object.keys(t).length !== o.length || o.some((m) => !Object.prototype.hasOwnProperty.call(t, m))) throw new Error("\u6240\u9009\u8D26\u53F7\u7ED3\u679C\u7ED3\u6784\u4E0D\u7B26\uFF0C\u505C\u6B62\u91C7\u7528");
    for (const m of ["accountAlias", "accountName", "phoneMask"]) if (typeof t[m] != "string" || !t[m].trim() || t[m] !== t[m].trim() || t[m].length > 100 || /[\r\n]/.test(t[m])) throw new Error("\u8D26\u53F7\u5FC5\u8981\u5B57\u6BB5\u7F3A\u5931\u6216\u683C\u5F0F\u65E0\u6548\uFF0C\u505C\u6B62\u91C7\u7528");
    if (!/^[+\d ()-]*\*{2,}[\d ()-]+$/.test(t.phoneMask) || /登录|注册|验证码/.test(t.accountName)) throw new Error("\u8D26\u53F7\u6765\u6E90\u7F3A\u5C11\u6709\u6548\u7684\u53EF\u89C1\u59D3\u540D\u6216\u624B\u673A\u53F7\u63A9\u7801");
    if (typeof t.reason != "string" || !t.reason.trim()) throw new Error("\u8D26\u53F7\u7ED3\u679C\u7F3A\u5C11\u660E\u786E\u6838\u5BF9\u8BF4\u660E");
    const r = Date.parse(t.confirmedAt), c = Date.parse(t.checkedAt);
    if (typeof t.confirmedAt != "string" || typeof t.checkedAt != "string" || !Number.isFinite(r) || !Number.isFinite(c) || r <= 0 || c < r || c > Date.now() + 6e4) throw new Error("\u8D26\u53F7\u786E\u8BA4\u6216\u590D\u9A8C\u65F6\u95F4\u65E0\u6CD5\u6838\u5BF9\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4");
    if (typeof t.sourceUrl != "string" || typeof t.jobseekerResumeHref != "string" || !t.sourceUrl.trim() || !t.jobseekerResumeHref.trim() || t.sourceUrl.length > 16384 || t.jobseekerResumeHref.length > 16384) throw new Error("\u8D26\u53F7\u9875\u9762\u6216\u7B80\u5386\u5165\u53E3\u5730\u5740\u65E0\u6548");
    const i = new URL(t.sourceUrl), f = new URL(t.jobseekerResumeHref, t.sourceUrl);
    if (i.origin !== "https://www.zhipin.com" || i.pathname !== "/web/geek/account" || i.searchParams.get("type") !== "accountSet" || i.username || i.password || i.hash || f.origin !== i.origin || f.pathname !== "/web/geek/resume" || f.username || f.password) throw new Error("\u8D26\u53F7\u8BB0\u5F55\u7684\u9875\u9762\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u4E0D\u7B26");
    return n.throwIfAborted(), { version: 1, accountSourceValid: true, currentAccountVerified: false, account: t };
  };
  return e;
})(), Z = /* @__PURE__ */ (() => {
  async function e({ input: u, signal: n, template: a }) {
    n.throwIfAborted();
    const t = u?.expected?.account;
    if (u?.expected?.accountSourceValid !== true || t?.kind !== "boss-account-source" || t.status !== "account-source-confirmed" || t.accountVerified !== true) throw Error("\u7F3A\u5C11\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\u6765\u6E90");
    const o = async (w, F, h) => {
      n.throwIfAborted();
      const p = await a.browser("browser", { operation: w, ...F ? { selector: F } : {}, ...h === void 0 ? {} : { value: h }, timeoutMs: 3e3 });
      return n.throwIfAborted(), p;
    }, r = await o("url"), c = new URL(r);
    if (c.origin !== "https://www.zhipin.com" || c.username || c.password || !c.pathname.startsWith("/web/") && !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(c.pathname)) throw Error("\u5F53\u524D\u9875\u9762\u4E0D\u662FBOSS\u6C42\u804C\u9875\u9762\uFF0C\u8BF7\u5148\u767B\u5F55");
    const i = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", f = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)", m = await o("count", i), s = await o("count", f);
    if (m !== 1 || s !== 1) throw Error("\u5F53\u524D\u9875\u9762\u8D26\u53F7\u5165\u53E3\u6570\u91CF\u5F02\u5E38\uFF1A" + JSON.stringify({ nameCount: m, resumeCount: s }));
    const y = await o("read", i), d = await o("attribute", f, "href");
    if (typeof y != "string" || y.normalize("NFKC").trim() !== t.accountName.normalize("NFKC").trim() || typeof d != "string" || new URL(d, r).href !== new URL(t.jobseekerResumeHref, t.sourceUrl).href || await o("url") !== r) throw Error("\u5F53\u524D\u767B\u5F55\u8EAB\u4EFD\u3001\u6C42\u804C\u5165\u53E3\u6216\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
    return { version: 1, status: "current-account-source-matched", accountAlias: t.accountAlias, accountName: t.accountName, phoneMask: t.phoneMask, jobseekerResumeHref: t.jobseekerResumeHref, sourceUrl: t.sourceUrl, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), currentPageUrl: r, currentAccountVerified: true, platformUniqueIdVerified: false, eligibleForActions: false, accountCheckMode: "confirmed-initial-account-and-visible-header", phoneMaskRechecked: false, reason: "\u4F7F\u7528\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\uFF1B\u53EA\u8BFB\u6838\u5BF9\u5F53\u524D\u767B\u5F55\u59D3\u540D\u3001\u6C42\u804C\u5165\u53E3\u53CA\u9875\u9762\u8FDE\u7EED\u6027\uFF0C\u624B\u673A\u53F7\u63A9\u7801\u6CBF\u7528\u786E\u8BA4\u6765\u6E90\uFF0C\u6CA1\u6709\u91CD\u65B0\u8BFB\u53D6\u3002" };
  }
  return e;
})(), O = (e) => Array.isArray(e) ? e.map(O) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((u) => [u, O(e[u])])) : e, $ = (e) => I("sha256").update(JSON.stringify(O(e))).digest("hex"), A = (e) => Array.isArray(e) ? e.map(A) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((u) => [u, A(e[u])])) : e, C = (e) => I("sha256").update(JSON.stringify(A(e))).digest("hex");
async function H(e, u, n, a, t = false) {
  const o = "account-outbound-safety-v1-" + n + ".json";
  let r, c = true, i;
  try {
    i = await e.file("communication-cache", { operation: "read", name: o }), r = JSON.parse(i);
  } catch (d) {
    if (!String(d.message || d).includes("ENOENT")) throw d;
    if (!t) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
    c = false, r = { version: 1, kind: "boss-account-outbound-safety", accountKey: n, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (c) {
    const { sha256: d, ...w } = r;
    if (d !== C(w)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
  }
  if (r.version !== 1 || r.kind !== "boss-account-outbound-safety" || r.accountKey !== n || !Number.isSafeInteger(r.revision) || r.revision < 0 || !Array.isArray(r.records) || r.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
  const f = /* @__PURE__ */ new Set();
  for (const d of r.records) {
    if (!["first-contact", "reply"].includes(d.type) || !/^[a-f0-9]{64}$/.test(d.businessKey) || !Array.isArray(d.sightings) || !d.sightings.length || d.sightings.length > 100 || f.has(d.type + ":" + d.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
    f.add(d.type + ":" + d.businessKey);
    for (const w of d.sightings) if (typeof w.contextId != "string" || !w.contextId || !/^[a-f0-9]{64}$/.test(w.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(w.status) || !/^\d{4}-\d{2}-\d{2}$/.test(w.day) || typeof w.timeZone != "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
  }
  let m = !c;
  return { data: r, name: o, merge: (d) => {
    if (!Array.isArray(d?.applicationIntents) || !Array.isArray(d?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
    for (const [w, F] of [["first-contact", d.applicationIntents], ["reply", d.replyIntents]]) for (const h of F) {
      if ((w === "first-contact" ? h.accountSourceSha256 : h.accountKey) !== n) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
      if (!/^[a-f0-9]{64}$/.test(h.key) || !h.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(h.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
      const p = w === "first-contact" ? C(["boss-job-safety-v1", n, h.jobId]) : I("sha256").update(["boss-text-reply-v1", n, h.incomingMessageId].join(":")).digest("hex");
      let g = r.records.find((E) => E.type === w && E.businessKey === p);
      if (g || (g = { type: w, businessKey: p, jobId: h.jobId, ...w === "reply" ? { conversationKey: h.conversationKey, incomingMessageId: h.incomingMessageId } : {}, sightings: [] }, r.records.push(g), m = true), g.jobId !== h.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
      const B = { contextId: a, intentKey: h.key, status: h.status, day: h.day, timeZone: h.timeZone, contentSha256: h.contentSha256 || null, sourceSha256: h.sourceSha256 || null };
      if (g.sightings.some((E) => JSON.stringify(A(E)) === JSON.stringify(A(B))) || (g.sightings.push(B), m = true), g.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
    }
    if (r.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
  }, save: async () => {
    if (u.throwIfAborted(), m) {
      if (c && await e.file("communication-cache", { operation: "read", name: o }) !== i) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
      r.records.sort((h, p) => (h.type + ":" + h.businessKey).localeCompare(p.type + ":" + p.businessKey));
      for (const h of r.records) h.sightings.sort((p, g) => JSON.stringify(A(p)).localeCompare(JSON.stringify(A(g))));
      r.revision++, r.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete r.sha256, r.sha256 = C(r), await e.file("communication-cache", { operation: "write", name: o, content: JSON.stringify(r) }), m = false, i = JSON.stringify(r), c = true;
    }
    const d = JSON.parse(await e.file("communication-cache", { operation: "read", name: o })), { sha256: w, ...F } = d;
    if (w !== C(F) || w !== r.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
    return { revision: r.revision, sha256: r.sha256, records: r.records.length };
  }, blocked: (d, w) => r.records.some((F) => F.type === d && F.businessKey === w) };
}
const L = (e, u) => async (n, a, t) => {
  u.throwIfAborted();
  try {
    return await e.browser("browser", { operation: n, ...a ? { selector: a } : {}, ...t === void 0 ? {} : { value: t }, timeoutMs: 3e3 });
  } catch (o) {
    const r = String(o.message || o);
    if (!/^\(-3\) loading /u.test(r)) throw o;
    let c = null;
    if (n === "navigate" && t === "https://www.zhipin.com/web/geek/chat" && (c = new URL(t)), n === "click" && a === ".chat-position-content .right-content > :first-child") {
      const i = /^\(-3\) loading '([^']+)'/u.exec(r);
      if (i) {
        const f = new URL(i[1]);
        f.origin === "https://www.zhipin.com" && /^\/job_detail\/[A-Za-z0-9_~-]+\.html$/u.test(f.pathname) && !f.username && !f.password && (c = f);
      }
    }
    if (!c) throw o;
    for (let i = 0; i < 30; i++) {
      u.throwIfAborted();
      const f = await e.browser("browser", { operation: "url", timeoutMs: 3e3 }), m = new URL(f);
      if (m.origin === c.origin && m.pathname === c.pathname) return { navigationObserved: true, url: f, originalClickRepeated: false };
      await new Promise((s) => setTimeout(s, 150));
    }
    throw o;
  }
}, V = (e) => {
  const { sha256: u, ...n } = e;
  return u === C(n);
};
async function J(e, u, n, a) {
  const t = n.progressName, o = await e.file("communication-cache", { operation: "read", name: t }), r = JSON.parse(o);
  if (!V(r) || r.accountKey !== n.accountKey || r.fixedUnreadSetSha256 !== n.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
  if (!a) return r;
  const c = a(structuredClone(r));
  if (c.revision++, c.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete c.sha256, c.sha256 = C(c), await e.file("communication-cache", { operation: "read", name: t }) !== o) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  u.throwIfAborted(), await e.file("communication-cache", { operation: "write", name: t, content: JSON.stringify(c) });
  const i = JSON.parse(await e.file("communication-cache", { operation: "read", name: t }));
  if (!V(i) || i.sha256 !== c.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
  return i;
}
async function K(e) {
  const u = await e("count", "li.message-item");
  if (!Number.isSafeInteger(u) || u < 1 || u > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
  const n = [];
  for (let a = 1; a <= u; a++) {
    const t = "li.message-item:nth-child(" + a + " of li.message-item)", o = await e("attribute", t, "data-mid"), r = await e("attribute", t, "class");
    if (!/^\d{6,40}$/.test(o || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
    const c = await e("count", t + " .text-content");
    if (c > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
    const i = c === 1 ? String(await e("read", t + " .text-content")).trim() : null, f = i === null ? String(await e("read", t)).trim() : null;
    if ((i || f || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
    const m = !!i && /^您正在与Boss.+沟通$/u.test(i), s = !m && i !== null && r.split(/\s+/u).includes("item-myself") ? "outgoing" : !m && i !== null && r.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
    n.push({ mid: o, direction: s, text: i, context: f });
  }
  if (new Set(n.map((a) => a.mid)).size !== n.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
  return n;
}
async function z(e, u) {
  const n = new URL(await e("url"));
  if (n.origin !== "https://www.zhipin.com" || n.pathname !== "/web/geek/chat" || await e("count", ".chat-conversation .user-info") !== 1) return false;
  const a = String(await e("read", ".chat-conversation .user-info")).trim(), t = (r) => r.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
  return u.recipientLabel ? String(await e("read", ".chat-conversation .user-info")).trim() === u.recipientLabel && (!u.rows?.length || await e("count", 'li.message-item[data-mid="' + u.rows[0].mid + '"]') === 1) : await e("count", ".friend-content.selected") === 1 && t(String(await e("read", ".friend-content.selected"))).includes(t(u.member.identityLine));
}
async function _(e, u, n) {
  const a = L(e, u);
  return await z(a, n) ? String(await a("read", n.accountSelector)).trim() === n.accountLabel && String(await a("read", n.recipientSelector)).trim() === n.recipientLabel && JSON.stringify(await K(a)) === JSON.stringify(n.rows) : false;
}
var q = async ({ input: e, template: u, signal: n, artifact: a, onAccountVerified: t }) => {
  const o = e?.cohort, r = e?.profile;
  if (o?.kind !== "unread-closing-cohort" || o.closingPhase !== true || r?.version !== 1 || !r.ref?.versionId || !r.markdown?.trim()) throw Error("\u7F3A\u5C11\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u6216\u672C\u6B21\u786E\u8BA4Skill");
  const c = { ...o, sourceReviewVersion: "chat-list-direct-v5", kind: "chat-reply-source", fixedUnreadMember: true, profile: r, returnToJobs: false };
  if (!o.ready) return { ...c, ready: false, status: "fixed-unread-complete", reason: "\u56FA\u5B9A\u96C6\u5408\u5DF2\u5904\u7406\u5B8C\u6BD5\uFF0C\u4E0D\u91CD\u65B0\u626B\u63CF" };
  await Z({ input: { expected: o.accountSource }, template: u, signal: n }), t?.();
  const i = String(o.member?.text || "").split(/\r?\n/u).slice(3).join(`
`).trim();
  if (/背景不完全相符|需要其他资质|不太符合|不太?合适|不[是太]*特别契合|不[完全]*符合|不[完全]*匹配|后续有机会再合作|未能通过|暂不考虑/u.test(i) && !/[?？]|(?:是否|有没有|会不会|能否|请问|什么时候|多少|怎么|哪些)/u.test(i)) return { ...c, member: o.member, ready: false, jobId: null, jobSource: null, status: "rejected-no-reply", reason: "\u56FA\u5B9A\u672A\u8BFB\u5FEB\u7167\u4E2D\u5BF9\u65B9\u5DF2\u660E\u786E\u62D2\u7EDD\uFF0C\u4E0D\u56DE\u590D\u3001\u4E0D\u6267\u884C\u539F\u751F\u8BF7\u6C42", previewSource: true };
  const f = L(u, n), m = o.member;
  let s = await J(u, n, o);
  if (s.completed.some((l) => l.memberKey === m.key && !P(l) && !(l.status === "review" && l.replyPolicyVersion !== "work-questions-partial-known-v2"))) return { ...c, ready: false, status: "already-completed", reason: "\u8BE5\u56FA\u5B9A\u6210\u5458\u5DF2\u5904\u7406\uFF0C\u672A\u91CD\u590D\u6253\u5F00" };
  if (s.active && s.active.memberKey !== m.key) throw Error("\u6D3B\u8DC3\u4F1A\u8BDD\u4E0E\u56FA\u5B9A\u6210\u5458\u4E0D\u7B26");
  if (!await z(f, o)) {
    const l = new URL(await f("url"));
    (l.origin !== "https://www.zhipin.com" || l.pathname !== "/web/geek/chat") && await f("navigate", void 0, "https://www.zhipin.com/web/geek/chat"), await R(f, o);
  }
  const y = ".chat-conversation .user-info", d = String(await f("read", y)).trim(), w = ".chat-position-content", F = String(await f("read", w)).trim(), h = F.split(/\r?\n/u)[0], p = await K(f);
  if (!h || !d) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u7684\u62DB\u8058\u8005\u6216\u804C\u4F4D\u4E0A\u4E0B\u6587\u7F3A\u5931");
  if (/校招|校园|应届/u.test(h)) return { ...c, member: m, ready: false, status: "campus-no-reply", reason: "\u804A\u5929\u4E2D\u660E\u786E\u6821\u62DB\uFF0C\u7EE7\u7EED\u6392\u9664" };
  if (s.active?.firstMessageId && s.active.firstMessageId !== p[0].mid) throw Error("\u91CD\u5F00\u540E\u7684\u4F1A\u8BDD\u539F\u59CB\u6D88\u606F\u94FE\u5DF2\u53D8\u5316\uFF0C\u672A\u8986\u76D6\u65E7\u8FDB\u5EA6");
  s = await J(u, n, o, (l) => {
    if (l.active && l.active.memberKey !== m.key) throw Error("\u6D3B\u8DC3\u6210\u5458\u53D8\u5316");
    return l.active = { ...l.active, memberKey: m.key, identityLine: m.identityLine, recipientName: d.split(/\r?\n/u)[0], contextId: o.contextId, openedAt: l.active?.openedAt || (/* @__PURE__ */ new Date()).toISOString(), firstMessageId: p[0].mid }, l;
  });
  const g = "https://www.zhipin.com/web/geek/chat", B = "chat-" + p[0].mid, E = await K(f), S = E.filter((l) => l.direction !== "system" && l.text), D = S.at(-1), T = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", U = o.accountSource.account.accountName, b = { ...c, ownedConversation: S[0]?.direction === "outgoing", member: m, jobId: B, jobSource: g, jobTitle: h, chatJobTitle: F, jobSelector: w, recipientSelector: y, recipientLabel: d, accountSelector: T, accountLabel: U, conversationKey: "boss-chat:" + E[0].mid, rows: E };
  if (S[0]?.direction === "incoming") return { ...b, ready: false, status: "inbound-first-no-reply", reason: "\u53EF\u89C1\u4F1A\u8BDD\u7531\u5BF9\u65B9\u53D1\u8D77\uFF0C\u6309\u672C\u4EBA\u89C4\u5219\u8DF3\u8FC7" };
  if (!D || D.direction !== "incoming") return { ...b, ready: false, status: "already-replied-or-system-only", reason: "\u6CA1\u6709\u5C1A\u672A\u56DE\u590D\u7684\u771F\u4EBA\u6587\u5B57\u6765\u4FE1\uFF1B\u7CFB\u7EDF\u5361\u7247\u4E0D\u89E6\u53D1\u56DE\u590D" };
  if (/背景不完全相符|需要其他资质|不太符合|不太?合适|不[是太]*特别契合|不[完全]*符合|不[完全]*匹配|后续有机会再合作|未能通过|暂不考虑/u.test(D.text) && !/[?？]|(?:是否|有没有|会不会|能否|请问|什么时候|多少|怎么|哪些)/u.test(D.text)) return { ...b, ready: false, status: "rejected-no-reply", incomingMessageId: D.mid, reason: "\u5BF9\u65B9\u660E\u786E\u8868\u793A\u4E0D\u5408\u9002\uFF0C\u6309\u672C\u4EBA\u6700\u65B0\u8981\u6C42\u4E0D\u56DE\u590D\uFF1B\u4FDD\u7559\u6240\u6709\u539F\u5916\u53D1\u610F\u56FE" };
  const x = I("sha256").update(["boss-text-reply-v1", o.accountKey, D.mid].join(":")).digest("hex"), j = await u.state.get(), k = await H(u, n, o.accountKey, o.contextId);
  if (k.merge(j), await k.save(), j.replyIntents.some((l) => l.accountKey === o.accountKey && l.incomingMessageId === D.mid && ["reserved", "unknown", "failed"].includes(l.status)) || k.data.records.some((l) => l.type === "reply" && l.businessKey === x && l.sightings.some((v) => ["reserved", "unknown", "failed"].includes(v.status)))) {
    const l = "\u539F\u6765\u4FE1\u5DF2\u6709\u9884\u7559\u3001\u672A\u77E5\u6216\u5931\u8D25\u8BB0\u5F55\uFF0C\u4FDD\u7559\u5F85\u529E\u5E76\u7981\u6B62\u91CD\u53D1";
    return await u.attention({ key: "reply-existing-uncertain:" + o.accountKey + ":" + D.mid, title: "\u539F\u56DE\u590D\u7ED3\u679C\u5F85\u6838\u5BF9\uFF0C\u8BF7\u52FF\u91CD\u53D1", detail: { contact: m.identityLine, jobSource: g, incomingMessageId: D.mid, reason: l, externalAction: false } }), { ...b, ready: false, status: "existing-uncertain-reply", decision: "review", replyPolicyVersion: "work-questions-partial-known-v2", incomingMessageId: D.mid, key: x, reason: l };
  }
  if (j.replyIntents.some((l) => l.accountKey === o.accountKey && l.incomingMessageId === D.mid) || k.blocked("reply", x)) return { ...b, ready: false, status: "existing-reply-intent", incomingMessageId: D.mid, reason: "\u8BE5\u539F\u6765\u4FE1\u5DF2\u6709\u5916\u53D1\u610F\u56FE\uFF0C\u9884\u7559\u3001\u672A\u77E5\u53CA\u786E\u8BA4\u5747\u7981\u6B62\u91CD\u653E" };
  if ((j.conversationControls || []).some((l) => l.accountKey === o.accountKey && [b.conversationKey, "boss-chat:" + E[0].mid].includes(l.conversationKey) && l.mode === "paused")) return { ...b, ready: false, status: "manual-control", reason: "\u672C\u4EBA\u5DF2\u63A5\u7BA1\u672C\u4F1A\u8BDD\uFF0C\u81EA\u52A8\u56DE\u590D\u8DF3\u8FC7" };
  const M = new Intl.DateTimeFormat("sv-SE", { timeZone: o.configuration.replyTimeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
  if (new Set(k.data.records.filter((l) => l.type === "reply" && l.sightings.some((v) => v.day === M && v.timeZone === o.configuration.replyTimeZone && v.status !== "failed")).map((l) => l.businessKey)).size >= o.configuration.replyDailyLimit) throw Error("\u5DF2\u4FDD\u5B58\u7684\u672C\u4EBA\u56DE\u590D\u989D\u5EA6\u5DF2\u6EE1\uFF0C\u4FDD\u7559\u672A\u5B8C\u6210\u6536\u5C3E");
  const N = { ...b, ready: true, key: x, incomingMessageId: D.mid, incomingMessage: D.text, pendingMessages: S.slice(S.map((l) => l.direction).lastIndexOf("outgoing") + 1).filter((l) => l.direction === "incoming"), sourceSha256: I("sha256").update(JSON.stringify({ rows: E, jobSource: g, accountLabel: U })).digest("hex"), day: M, timeZone: o.configuration.replyTimeZone };
  if (!await _(u, n, N)) throw Error("\u5B8C\u6574\u6765\u6E90\u4FDD\u5B58\u524D\u4F1A\u8BDD\u5DF2\u53D8\u5316");
  return await a("fixed-unread-reply-source.json", JSON.stringify(N, null, 2)), N;
};
async function W(e) {
  let u = false;
  try {
    return await q({ ...e, onAccountVerified: () => {
      u = true;
    } });
  } catch (n) {
    const a = String(n.message || n), t = e.input?.cohort, o = /关联职位返回后的完整消息或对象变化|完整岗位标题缺失或截断|固定姓名搜索未取得唯一的姓名、公司和角色组合|固定成员缺少可核对的定向搜索姓名，未猜测|未读会话的实际职位链接未核对|关联职位没有可核对的继续沟通入口|固定成员当前列表|固定成员缺少唯一可见身份|固定成员可见身份|固定会话返回|关联职位完整标题与固定会话不符/u.test(a), r = u && !/账号|安全索引|账本|摘要|配置|状态|进度|Skill|预留/u.test(a) && /固定成员|固定会话|关联职位|网页操作超时|元素|目标不可见|点击目标|点击期间|\(-3\) loading/u.test(a);
    if (!(o || r) || t?.kind !== "unread-closing-cohort" || !t.member?.key) throw n;
    return await e.template.attention({ key: "fixed-member-source-review:" + t.accountKey + ":" + t.member.key, title: "\u8BE5\u672A\u8BFB\u4F1A\u8BDD\u6765\u6E90\u5F85\u6838\u5BF9\uFF0C\u672A\u6267\u884C\u5916\u53D1", detail: { contact: t.member.identityLine, fixedUnreadSetSha256: t.fixedUnreadSetSha256, memberKey: t.member.key, reason: a, externalAction: false } }), { ...t, sourceReviewVersion: "chat-list-direct-v5", kind: "chat-reply-source", fixedUnreadMember: true, profile: e.input.profile, ready: false, jobId: null, jobSource: null, status: "member-needs-review", decision: "review", replyPolicyVersion: "work-questions-partial-known-v2", reason: a };
  }
}
async function stdin_default(e) {
  const u = e.input;
  if (u?.kind !== "chat-reply-source" || u.fixedUnreadMember !== true) throw Error("\u7F3A\u5C11\u539F\u56FA\u5B9A\u6210\u5458\u4E0A\u4E0B\u6587");
  const n = [];
  if (u.jobId) for (const [t, o, r] of [["native-contact-index-v1-" + u.accountKey + ".json", "boss-native-contact-index", "actions"], ["resume-delivery-index-v1-" + u.accountKey + ".json", "boss-resume-delivery-index", "deliveries"]]) {
    let c;
    try {
      c = await e.template.file("communication-cache", { operation: "read", name: t });
    } catch (s) {
      if (String(s.message || s).includes("ENOENT")) continue;
      throw s;
    }
    const i = JSON.parse(c), { sha256: f, ...m } = i;
    if (f !== $(m) || i.kind !== o || i.accountKey !== u.accountKey || !Array.isArray(i[r])) throw Error("\u539F\u751F\u52A8\u4F5C\u8D26\u672C\u6765\u6E90\u4E0D\u7B26");
    for (const s of i[r]) s.jobSource === u.jobSource && (s.memberKey === u.member.key || s.firstMessageId === u.rows?.[0]?.mid) && n.push({ type: s.contactType || "resume", requestMid: s.requestMid, status: s.status, key: s.key, receipt: s.receipt || null, agreementConfirmed: s.agreementConfirmed === true, contactValueObserved: s.contactValueObserved === true });
  }
  return { ...u.ready ? await W({ ...e, input: { cohort: { ...u, kind: "unread-closing-cohort" }, profile: u.profile } }) : u, nativeActions: n };
}
export {
  stdin_default as default
};
