import { createHash as g } from "node:crypto";
const h = (t) => Array.isArray(t) ? t.map(h) : t && typeof t == "object" ? Object.fromEntries(Object.keys(t).sort().map((r) => [r, h(t[r])])) : t, d = (t) => g("sha256").update(JSON.stringify(h(t))).digest("hex"), y = (t, r) => (a, s, e) => (r.throwIfAborted(), t.browser("browser", { operation: a, ...s ? { selector: s } : {}, ...e === void 0 ? {} : { value: e }, timeoutMs: 3e3 }));
async function p(t, r, a) {
  const s = new URL(await t("url"));
  if (s.origin !== "https://www.zhipin.com" || s.pathname !== "/web/geek/chat" || String(await t("read", r.recipientSelector)).trim() !== r.recipientLabel || String(await t("read", r.accountSelector)).trim() !== r.accountLabel || await t("count", 'li.message-item[data-mid="' + r.firstMessageId + '"]') !== 1) throw Error("\u5F53\u524D\u8D26\u53F7\u6216\u4F1A\u8BDD\u6D88\u606F\u94FE\u53D8\u5316\uFF0C\u4E0D\u64CD\u4F5C");
  if (((await a.state.get()).conversationControls || []).some((o) => o.accountKey === r.accountKey && [r.conversationKey, "boss-chat:" + r.firstMessageId].includes(o.conversationKey) && o.mode === "paused")) throw Error("\u672C\u4EBA\u5DF2\u63A5\u7BA1\u4F1A\u8BDD");
}
async function b(t) {
  const r = await t("count", "li.message-item");
  if (!Number.isSafeInteger(r) || r < 1 || r > 100) throw Error("\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u8303\u56F4\u65E0\u6548");
  const a = [];
  for (let s = 1; s <= r; s++) {
    const e = "li.message-item:nth-child(" + s + " of li.message-item)", o = await t("attribute", e, "data-mid"), i = String(await t("attribute", e, "class") || ""), n = String(await t("read", e)).trim();
    if (!/^\d{6,40}$/u.test(o || "") || n.length > 2e4) throw Error("\u539F\u751F\u6D88\u606F\u8EAB\u4EFD\u4E0D\u5B8C\u6574");
    a.push({ mid: o, cls: i, text: n });
  }
  return a;
}
async function v(t, r) {
  const a = "resume-delivery-index-v1-" + r.accountKey + ".json";
  let s = null;
  try {
    s = await t.file("communication-cache", { operation: "read", name: a });
  } catch (i) {
    if (!String(i.message || i).includes("ENOENT")) throw i;
  }
  const e = s ? JSON.parse(s) : { version: 1, kind: "boss-resume-delivery-index", accountKey: r.accountKey, revision: 0, uploads: [], deliveries: [] };
  if (s) {
    const { sha256: i, ...n } = e;
    if (i !== d(n)) throw Error("\u539F\u9644\u4EF6\u8D26\u672C\u6458\u8981\u4E0D\u7B26");
  }
  if (e.accountKey !== r.accountKey || e.kind !== "boss-resume-delivery-index" || !Array.isArray(e.deliveries) || !Array.isArray(e.uploads) || e.deliveries.length > 2e3 || new Set(e.deliveries.map((i) => i.key)).size !== e.deliveries.length) throw Error("\u539F\u9644\u4EF6\u8D26\u672C\u7ED3\u6784\u4E0D\u7B26");
  return { book: e, save: async () => {
    let i = null;
    try {
      i = await t.file("communication-cache", { operation: "read", name: a });
    } catch (c) {
      if (!String(c.message || c).includes("ENOENT")) throw c;
    }
    if (i !== s) throw Error("\u9644\u4EF6\u8D26\u672C\u5E76\u53D1\u53D8\u5316");
    e.revision++, e.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete e.sha256, e.sha256 = d(e);
    const n = JSON.stringify(e);
    if (await t.file("communication-cache", { operation: "write", name: a, content: n }), await t.file("communication-cache", { operation: "read", name: a }) !== n) throw Error("\u9644\u4EF6\u8D26\u672C\u672A\u51C6\u786E\u8BFB\u56DE");
    s = n;
  } };
}
async function stdin_default({ input: t, template: r, signal: a, artifact: s }) {
  const e = t?.closingSource;
  if (e?.kind !== "chat-reply-source" || !e.member?.key) throw Error("\u7F3A\u5C11\u56FA\u5B9A\u4F1A\u8BDD\u6765\u6E90");
  if (e.ownedConversation !== true || ["rejected-no-reply", "campus-no-reply", "manual-control", "already-completed"].includes(e.status)) return { version: 1, kind: "boss-resume-request-source", ready: false, status: "fixed-member-native-skipped", reason: e.reason };
  const o = { ...e, kind: "boss-resume-request-source", firstMessageId: e.rows[0].mid }, i = y(r, a);
  await p(i, o, r);
  const n = await b(i), c = [];
  for (const u of n) {
    if (!u.cls.split(/\s/u).includes("item-friend") || !u.text.includes("\u6211\u60F3\u8981\u4E00\u4EFD\u60A8\u7684\u9644\u4EF6\u7B80\u5386\uFF0C\u60A8\u662F\u5426\u540C\u610F")) continue;
    const m = 'li.message-item[data-mid="' + u.mid + '"]', l = m + " .message-dialog-both .card-btn:nth-child(2)", w = m + " .message-dialog-both .card-btn:nth-child(1)";
    await i("count", l) === 1 && await i("count", w) === 1 && String(await i("read", l)).trim() === "\u540C\u610F" && String(await i("read", w)).trim() === "\u62D2\u7EDD" && c.push({ mid: u.mid, root: m, agree: l, text: u.text, key: d(["boss-resume-request-v1", e.accountKey, o.firstMessageId, u.mid]) });
  }
  const f = { ...o, requests: c, ready: c.length > 0, status: c.length ? "pending-native-resume-requests" : "no-pending-resume-request", sourceMessageIds: n.map((u) => u.mid), sourceSha256: d({ accountKey: e.accountKey, recipientLabel: e.recipientLabel, firstMessageId: o.firstMessageId, requests: c }) };
  return await s("native-resume-source.json", JSON.stringify(f)), f;
}
export {
  stdin_default as default
};
