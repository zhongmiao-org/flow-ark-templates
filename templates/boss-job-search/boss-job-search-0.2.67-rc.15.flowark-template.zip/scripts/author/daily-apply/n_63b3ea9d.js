import { createHash as K } from "node:crypto";
const x = (w) => Array.isArray(w) ? w.map(x) : w && typeof w == "object" ? Object.fromEntries(Object.keys(w).sort().map((n) => [n, x(w[n])])) : w, h = (w) => K("sha256").update(JSON.stringify(x(w))).digest("hex");
async function stdin_default({ input: w, template: n, signal: E, artifact: M }) {
  const e = w, s = "wechat";
  if (!["wechat", "phone"].includes(s) || e?.kind !== "chat-reply-source" || !e.fixedUnreadMember || !e.member?.key) throw Error("\u539F\u751F\u4EA4\u6362\u7F3A\u5C11\u56FA\u5B9A\u6210\u5458\u6765\u6E90");
  const m = { version: 1, kind: "boss-native-contact-result", contactType: s, memberKey: e.member.key, actions: [], websiteMessagesSent: 0 };
  if (e.ownedConversation !== true || !e.jobId || ["job-title-outside-configured-scope", "rejected-no-reply", "manual-control", "already-completed", "fixed-unread-complete"].includes(e.status)) return { ...m, status: "skipped", reason: e.reason };
  const r = async (t, o, c) => {
    E.throwIfAborted();
    const a = await n.browser("browser", { operation: t, ...o ? { selector: o } : {}, ...c === void 0 ? {} : { value: c }, timeoutMs: 3e3 });
    return E.throwIfAborted(), a;
  }, p = async () => {
    const t = new URL(await r("url"));
    if (t.origin !== "https://www.zhipin.com" || t.pathname !== "/web/geek/chat" || await r("count", e.recipientSelector) !== 1 || String(await r("read", e.recipientSelector)).trim() !== e.recipientLabel || String(await r("read", e.accountSelector)).trim() !== e.accountLabel) throw Error("\u539F\u751F\u4EA4\u6362\u8D26\u53F7\u3001\u5BF9\u8C61\u6216\u5C97\u4F4D\u53D8\u5316");
    if (((await n.state.get()).conversationControls || []).some((c) => c.accountKey === e.accountKey && [e.conversationKey, "boss-chat:" + e.rows[0].mid].includes(c.conversationKey) && c.mode === "paused")) throw Error("\u4F1A\u8BDD\u5DF2\u7531\u672C\u4EBA\u63A5\u7BA1");
  };
  await p();
  const g = "native-contact-index-v1-" + e.accountKey + ".json";
  let d, S = null;
  try {
    S = await n.file("communication-cache", { operation: "read", name: g }), d = JSON.parse(S);
    const { sha256: t, ...o } = d;
    if (t !== h(o) || d.accountKey !== e.accountKey || d.kind !== "boss-native-contact-index" || !Array.isArray(d.actions)) throw Error("\u539F\u751F\u4EA4\u6362\u8D26\u672C\u4E0D\u7B26");
  } catch (t) {
    if (!String(t.message || t).includes("ENOENT")) throw t;
    d = { version: 1, kind: "boss-native-contact-index", accountKey: e.accountKey, revision: 0, actions: [] };
  }
  const f = async () => {
    let t = null;
    try {
      t = await n.file("communication-cache", { operation: "read", name: g });
    } catch (c) {
      if (!String(c.message || c).includes("ENOENT")) throw c;
    }
    if (t !== S) throw Error("\u539F\u751F\u4EA4\u6362\u8D26\u672C\u5E76\u53D1\u53D8\u5316");
    d.revision++, delete d.sha256, d.sha256 = h(d);
    const o = JSON.stringify(d);
    if (await n.file("communication-cache", { operation: "write", name: g, content: o }), await n.file("communication-cache", { operation: "read", name: g }) !== o) throw Error("\u4EA4\u6362\u8BB0\u5F55\u672A\u5B8C\u6574\u8BFB\u56DE");
    S = o;
  }, q = [], k = await r("count", "li.message-item");
  if (!Number.isSafeInteger(k) || k > 500) throw Error("\u6D88\u606F\u6570\u91CF\u65E0\u6CD5\u6838\u5BF9");
  for (let t = 1; t <= k; t++) {
    const o = "li.message-item:nth-of-type(" + t + ")", c = String(await r("attribute", o, "class") || ""), a = String(await r("read", o)).trim();
    if (!c.split(/\s/u).includes("item-friend") || !(s === "wechat" ? /交换微信/u : /交换(?:手机号|手机号码|电话)/u).test(a) || !/(?:希望|想|请求|是否同意)/u.test(a)) continue;
    const i = await r("attribute", o, "data-mid");
    if (typeof i != "string" || !/^\d+$/u.test(i)) throw Error("\u539F\u751F\u8BF7\u6C42\u7F16\u53F7\u7F3A\u5931");
    const u = 'li.message-item[data-mid="' + i + '"]', y = await r("count", u + " .card-btn");
    let l = null;
    for (let v = 1; v <= y; v++) {
      const j = u + " .card-btn:nth-child(" + v + ")";
      if (await r("count", j) === 1 && String(await r("read", j)).trim() === "\u540C\u610F") {
        if (l) throw Error("\u4EA4\u6362\u540C\u610F\u63A7\u4EF6\u4E0D\u552F\u4E00");
        l = j;
      }
    }
    l ? q.push({ mid: i, root: u, text: a, agree: l }) : /已同意|已交换|已拒绝|已取消|已过期/u.test(a) || (m.actions.push({ requestMid: i, status: "todo", reason: "\u539F\u751F\u8BF7\u6C42\u63A7\u4EF6\u5C1A\u672A\u6838\u5B9E" }), await n.attention({ key: h(["contact-control-review", e.accountKey, i, s]), title: "\u8054\u7CFB\u65B9\u5F0F\u8BF7\u6C42\u5F85\u6838\u5BF9", detail: { contact: e.recipientLabel, jobSource: e.jobSource, contactType: s, requestMid: i } }));
  }
  for (const t of q) {
    const o = h(["boss-native-contact-v1", e.accountKey, e.rows[0].mid, t.mid, s]), c = d.actions.find((i) => i.key === o || i.requestMid === t.mid && i.contactType === s);
    if (c) {
      m.actions.push({ requestMid: t.mid, status: "existing-no-replay", priorStatus: c.status });
      continue;
    }
    if (await p(), String(await r("read", t.root)).trim() !== t.text || String(await r("read", t.agree)).trim() !== "\u540C\u610F") throw Error("\u4EA4\u6362\u8BF7\u6C42\u5DF2\u53D8\u5316");
    const a = { key: o, contactType: s, requestMid: t.mid, firstMessageId: e.rows[0].mid, memberKey: e.member.key, recipientLabel: e.recipientLabel, jobSource: e.jobSource, contextId: e.contextId, status: "reserved", createdAt: (/* @__PURE__ */ new Date()).toISOString() };
    d.actions.push(a), await f();
    const b = await n.effect.prepare({ action: s === "wechat" ? "exchange-wechat" : "exchange-phone", key: o, description: "\u539F\u751F\u540C\u610F\u5F53\u524D\u56FA\u5B9A\u4F1A\u8BDD\u7684" + (s === "wechat" ? "\u5FAE\u4FE1" : "\u624B\u673A\u53F7") + "\u4EA4\u6362\u8BF7\u6C42" });
    if (a.effectId = b.id, await f(), !b.execute) {
      a.status = "unknown", await f(), m.actions.push({ requestMid: t.mid, status: "existing-effect-no-replay" });
      continue;
    }
    try {
      if (await p(), String(await r("read", t.root)).trim() !== t.text || String(await r("read", t.agree)).trim() !== "\u540C\u610F") throw Error("\u70B9\u51FB\u524D\u4EA4\u6362\u8BF7\u6C42\u53D8\u5316");
      await r("click", t.agree);
      let i = null;
      for (let u = 0; u < 20; u++) {
        await p();
        const y = String(await r("read", t.root)).trim();
        if (y !== t.text && /已同意|已交换|交换成功/u.test(y)) {
          i = { requestMid: t.mid, text: y, observedAt: (/* @__PURE__ */ new Date()).toISOString() };
          break;
        }
        await new Promise((l) => setTimeout(l, 250));
      }
      if (!i) throw Error("\u672A\u53D6\u5F97\u539F\u751F\u4EA4\u6362\u660E\u786E\u56DE\u6267");
      if (a.status = "confirmed", a.agreementConfirmed = true, a.receipt = i, await f(), await n.effect.resolve({ id: b.id, state: "confirmed", evidence: i }), m.actions.push({ requestMid: t.mid, status: "confirmed", receipt: i }), s === "wechat") {
        const u = /(?:微信号|微信账号)\s*[:：]\s*([A-Za-z][A-Za-z0-9_-]{5,19}|\d{6,20})(?![A-Za-z0-9_-])/u.exec(i.text);
        a.contactValueObserved = !!u, await f(), await n.attention({ key: h(["boss-wechat-contact", e.accountKey, e.rows[0].mid, t.mid]), title: u ? "\u5DF2\u53D6\u5F97\u8054\u7CFB\u4EBA\u5FAE\u4FE1\u53F7" : "\u5FAE\u4FE1\u4EA4\u6362\u5DF2\u540C\u610F\uFF0C\u53F7\u7801\u5F85\u6838\u5BF9", detail: { contact: e.recipientLabel, jobSource: e.jobSource, requestMid: t.mid, ...u ? { wechat: u[1] } : {}, source: "BOSS\u539F\u751F\u4EA4\u6362\u56DE\u6267", agreementConfirmed: true, contactValueObserved: !!u } });
      }
    } catch (i) {
      throw a.status === "confirmed" || (a.status = "unknown", a.reason = String(i.message || i), await f(), await n.effect.resolve({ id: b.id, state: "unknown", evidence: { requestMid: t.mid, reason: a.reason } }), await n.attention({ key: h(["contact-unknown", o]), title: "\u539F\u751F\u4EA4\u6362\u7ED3\u679C\u5F85\u6838\u5BF9\uFF0C\u8BF7\u52FF\u91CD\u590D\u64CD\u4F5C", detail: { contact: e.recipientLabel, jobSource: e.jobSource, requestMid: t.mid, contactType: s, reason: a.reason } })), i;
    }
  }
  return m.status = m.actions.length ? "processed" : "no-pending-request", await M("native-" + s + "-result.json", JSON.stringify(m, null, 2)), m;
}
export {
  stdin_default as default
};
