import { createHash as C } from "node:crypto";
const S = (e) => Array.isArray(e) ? e.map(S) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((u) => [u, S(e[u])])) : e, b = (e) => C("sha256").update(JSON.stringify(S(e))).digest("hex");
async function I(e, u, r, d, y = false) {
  const i = "account-outbound-safety-v1-" + r + ".json";
  let o, a = true, f;
  try {
    f = await e.file("communication-cache", { operation: "read", name: i }), o = JSON.parse(f);
  } catch (n) {
    if (!String(n.message || n).includes("ENOENT")) throw n;
    if (!y) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
    a = false, o = { version: 1, kind: "boss-account-outbound-safety", accountKey: r, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (a) {
    const { sha256: n, ...c } = o;
    if (n !== b(c)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
  }
  if (o.version !== 1 || o.kind !== "boss-account-outbound-safety" || o.accountKey !== r || !Number.isSafeInteger(o.revision) || o.revision < 0 || !Array.isArray(o.records) || o.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
  const w = /* @__PURE__ */ new Set();
  for (const n of o.records) {
    if (!["first-contact", "reply"].includes(n.type) || !/^[a-f0-9]{64}$/.test(n.businessKey) || !Array.isArray(n.sightings) || !n.sightings.length || n.sightings.length > 100 || w.has(n.type + ":" + n.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
    w.add(n.type + ":" + n.businessKey);
    for (const c of n.sightings) if (typeof c.contextId != "string" || !c.contextId || !/^[a-f0-9]{64}$/.test(c.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(c.status) || !/^\d{4}-\d{2}-\d{2}$/.test(c.day) || typeof c.timeZone != "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
  }
  let m = !a;
  return { data: o, name: i, merge: (n) => {
    if (!Array.isArray(n?.applicationIntents) || !Array.isArray(n?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
    for (const [c, E] of [["first-contact", n.applicationIntents], ["reply", n.replyIntents]]) for (const t of E) {
      if ((c === "first-contact" ? t.accountSourceSha256 : t.accountKey) !== r) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
      if (!/^[a-f0-9]{64}$/.test(t.key) || !t.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(t.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
      const g = c === "first-contact" ? b(["boss-job-safety-v1", r, t.jobId]) : C("sha256").update(["boss-text-reply-v1", r, t.incomingMessageId].join(":")).digest("hex");
      let l = o.records.find((B) => B.type === c && B.businessKey === g);
      if (l || (l = { type: c, businessKey: g, jobId: t.jobId, ...c === "reply" ? { conversationKey: t.conversationKey, incomingMessageId: t.incomingMessageId } : {}, sightings: [] }, o.records.push(l), m = true), l.jobId !== t.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
      const D = { contextId: d, intentKey: t.key, status: t.status, day: t.day, timeZone: t.timeZone, contentSha256: t.contentSha256 || null, sourceSha256: t.sourceSha256 || null };
      if (l.sightings.some((B) => JSON.stringify(S(B)) === JSON.stringify(S(D))) || (l.sightings.push(D), m = true), l.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
    }
    if (o.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
  }, save: async () => {
    if (u.throwIfAborted(), m) {
      if (a && await e.file("communication-cache", { operation: "read", name: i }) !== f) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
      o.records.sort((t, g) => (t.type + ":" + t.businessKey).localeCompare(g.type + ":" + g.businessKey));
      for (const t of o.records) t.sightings.sort((g, l) => JSON.stringify(S(g)).localeCompare(JSON.stringify(S(l))));
      o.revision++, o.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete o.sha256, o.sha256 = b(o), await e.file("communication-cache", { operation: "write", name: i, content: JSON.stringify(o) }), m = false, f = JSON.stringify(o), a = true;
    }
    const n = JSON.parse(await e.file("communication-cache", { operation: "read", name: i })), { sha256: c, ...E } = n;
    if (c !== b(E) || c !== o.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
    return { revision: o.revision, sha256: o.sha256, records: o.records.length };
  }, blocked: (n, c) => o.records.some((E) => E.type === n && E.businessKey === c) };
}
const x = (e, u) => async (r, d, y) => (u.throwIfAborted(), e.browser("browser", { operation: r, ...d ? { selector: d } : {}, ...y === void 0 ? {} : { value: y }, timeoutMs: 3e3 })), k = (e) => {
  const { sha256: u, ...r } = e;
  return u === b(r);
};
async function J(e, u, r, d) {
  const y = r.progressName, i = await e.file("communication-cache", { operation: "read", name: y }), o = JSON.parse(i);
  if (!k(o) || o.accountKey !== r.accountKey || o.fixedUnreadSetSha256 !== r.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
  if (!d) return o;
  const a = d(structuredClone(o));
  if (a.revision++, a.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete a.sha256, a.sha256 = b(a), await e.file("communication-cache", { operation: "read", name: y }) !== i) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  u.throwIfAborted(), await e.file("communication-cache", { operation: "write", name: y, content: JSON.stringify(a) });
  const f = JSON.parse(await e.file("communication-cache", { operation: "read", name: y }));
  if (!k(f) || f.sha256 !== a.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
  return f;
}
async function p(e) {
  const u = await e("count", "li.message-item");
  if (!Number.isSafeInteger(u) || u < 1 || u > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
  const r = [];
  for (let d = 1; d <= u; d++) {
    const y = "li.message-item:nth-child(" + d + " of li.message-item)", i = await e("attribute", y, "data-mid"), o = await e("attribute", y, "class");
    if (!/^\d{6,40}$/.test(i || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
    const a = await e("count", y + " .text-content");
    if (a > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
    const f = a === 1 ? String(await e("read", y + " .text-content")).trim() : null, w = f === null ? String(await e("read", y)).trim() : null;
    if ((f || w || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
    const m = !!f && /^您正在与Boss.+沟通$/u.test(f), F = !m && f !== null && o.split(/\s+/u).includes("item-myself") ? "outgoing" : !m && f !== null && o.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
    r.push({ mid: i, direction: F, text: f, context: w });
  }
  if (new Set(r.map((d) => d.mid)).size !== r.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
  return r;
}
async function M(e, u) {
  const r = new URL(await e("url"));
  if (r.origin !== "https://www.zhipin.com" || r.pathname !== "/web/geek/chat" || await e("count", ".chat-conversation .user-info") !== 1) return false;
  const d = String(await e("read", ".chat-conversation .user-info")).trim(), y = (i) => i.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
  return String(await e("read", ".chat-conversation .user-info")).trim() === u.recipientLabel && await e("count", 'li.message-item[data-mid="' + u.rows[0].mid + '"]') === 1;
}
async function O(e, u, r) {
  const d = x(e, u);
  return await M(d, r) ? String(await d("read", r.accountSelector)).trim() === r.accountLabel && String(await d("read", r.recipientSelector)).trim() === r.recipientLabel && JSON.stringify(await p(d)) === JSON.stringify(r.rows) : false;
}
var j = async ({ input: e, signal: u, template: r, artifact: d }) => {
  if (e?.kind !== "chat-reply-draft") throw Error("Missing AI reply stage");
  if (e.send && (typeof e.reply != "string" || Array.from(e.reply).length < 1 || Array.from(e.reply).length > 50)) throw Error("\u53D1\u9001\u524D\u56DE\u590D\u987B\u4E3A1\u81F350\u5B57\uFF0C\u672A\u5EFA\u7ACB\u53D1\u9001\u610F\u56FE");
  if (!e.send) return { ...e, kind: "chat-reply-dispatch", dispatched: false };
  const y = (t) => C("sha256").update(t).digest("hex");
  if (y(e.reply) !== e.contentSha256 || !e.model?.requestId || e.decision !== "reply" || e.closingPhase !== true || e.fixedUnreadMember !== true || e.siteDailyLimitEvidence?.confirmed !== true && !(e.closingTrigger === "two-new-greetings-test" && e.testCompletionEvidence?.kind === "boss-test-new-greeting-completion" && e.testCompletionEvidence.confirmed === true && e.testCompletionEvidence.newConfirmed === 2) || !e.fixedUnreadSetSha256 || e.key !== y(["boss-text-reply-v1", e.accountKey, e.incomingMessageId].join(":"))) throw Error("Reply text or model source changed");
  const i = (t, g, l) => (u.throwIfAborted(), r.browser("browser", { operation: t, ...g ? { selector: g } : {}, ...l !== void 0 ? { value: l } : {}, timeoutMs: 3e3 })), o = () => O(r, u, e);
  if (!await o()) throw Error("Conversation changed while AI was thinking; no send");
  let a = await r.state.get();
  const f = await I(r, u, e.accountKey, e.contextId);
  if (f.merge(a), await f.save(), (a.replyIntents || []).some((t) => t.accountKey === e.accountKey && t.incomingMessageId === e.incomingMessageId) || f.blocked("reply", e.key)) return { ...e, kind: "chat-reply-dispatch", dispatched: false, reason: "Persistent reply intent already exists; no replay" };
  const w = (a.conversationControls || []).filter((t) => t.accountKey === e.accountKey && t.conversationKey === e.conversationKey);
  if (w.some((t) => t.mode === "paused")) throw Error("Conversation is under manual control");
  const m = w.length ? Math.max(...w.map((t) => t.controlEpoch)) : 1;
  let F = a.replyIntents || [];
  if (F.length >= 500 || F.filter((t) => t.accountKey === e.accountKey && t.day === e.day && t.timeZone === e.timeZone && t.status !== "failed").length >= e.configuration.replyDailyLimit) throw Error("Reply quota or ledger capacity reached");
  if (await i("count", "#chat-input") !== 1 || String(await i("read", "#chat-input")).trim() !== "") throw Error("Composer contains an existing draft; no overwrite");
  if (await i("count", ".chat-conversation .btn-send") !== 1 || String(await i("read", ".chat-conversation .btn-send")).trim() !== "\u53D1\u9001") throw Error("Send target is ambiguous");
  const A = await r.effect.prepare({ action: "reply", key: e.key, description: "\u5411\u5F53\u524D\u51C6\u786E\u5DF2\u6709\u4F1A\u8BDD\u56DE\u590D\u539F\u6765\u4FE1 " + e.incomingMessageId + "\uFF1B\u4EC5\u6B64\u6587\u672C\uFF0C\u4E0D\u53D1\u9001\u9644\u4EF6\u6216\u65B0\u7684\u9996\u6B21\u62DB\u547C\u3002", review: { version: 1, target: e.jobTitle + `
` + e.jobSource + `
\u539F\u6765\u4FE1 ` + e.incomingMessageId, content: e.reply } });
  if (!A.execute) return { ...e, kind: "chat-reply-dispatch", dispatched: false, reason: "Existing effect blocks repeated reply" };
  const n = { key: e.key, accountKey: e.accountKey, conversationKey: e.conversationKey, incomingMessageId: e.incomingMessageId, jobId: e.jobId, contentSha256: e.contentSha256, sourceSha256: e.sourceSha256, profileVersionId: e.profile.ref.versionId, configurationRevision: e.configurationRevision, controlEpoch: m, day: e.day, timeZone: e.timeZone, createdAt: (/* @__PURE__ */ new Date()).toISOString(), status: "reserved" };
  let c = false, E = false;
  try {
    a = await r.state.get(), F = a.replyIntents || [];
    const t = await I(r, u, e.accountKey, e.contextId);
    if (t.merge(a), await t.save(), F.some((s) => s.accountKey === e.accountKey && s.incomingMessageId === e.incomingMessageId) || t.blocked("reply", e.key)) throw Error("\u786E\u8BA4\u671F\u95F4\u539F\u6765\u4FE1\u5DF2\u5EFA\u7ACB\u56DE\u590D\u610F\u56FE\uFF0C\u505C\u6B62\u65E7\u8349\u7A3F");
    if ((a.conversationControls || []).some((s) => s.accountKey === e.accountKey && [e.conversationKey, "boss-chat:" + e.rows[0].mid].includes(s.conversationKey) && s.mode === "paused")) throw Error("\u786E\u8BA4\u671F\u95F4\u672C\u4EBA\u5DF2\u63A5\u7BA1\u4F1A\u8BDD");
    if (new Set(t.data.records.filter((s) => s.type === "reply" && s.sightings.some((h) => h.day === e.day && h.timeZone === e.timeZone && h.status !== "failed")).map((s) => s.businessKey)).size >= e.configuration.replyDailyLimit || F.length >= 500) throw Error("\u786E\u8BA4\u671F\u95F4\u56DE\u590D\u989D\u5EA6\u6216\u8D26\u672C\u5BB9\u91CF\u5DF2\u6EE1");
    if (await r.state.set({ ...a, replyIntents: [...F, n] }), E = true, a = await r.state.get(), a.replyIntents.filter((s) => s.key === e.key && s.status === "reserved").length !== 1 || !await o()) throw Error("Reservation or exact conversation changed");
    const l = await I(r, u, e.accountKey, e.contextId);
    l.merge(a);
    const D = await l.save();
    if (!l.data.records.some((s) => s.type === "reply" && s.businessKey === e.key && s.sightings.some((h) => h.contextId === e.contextId && h.intentKey === e.key && h.status === "reserved"))) throw Error("\u56DE\u590D\u5B89\u5168\u7D22\u5F15\u9884\u7559\u672A\u8BFB\u56DE");
    await d("reply-reservation.json", JSON.stringify({ intent: n, effect: A, safety: D, sourceSha256: e.sourceSha256, reply: e.reply, model: e.model }, null, 2)), await i("fill", "#chat-input", e.reply);
    let B = false;
    for (let s = 0; s < 12; s++) {
      if (String(await i("read", "#chat-input")).trim() === e.reply) {
        B = true;
        break;
      }
      await new Promise((h) => setTimeout(h, 100));
    }
    if (!B || !await o() || String(await i("read", "#chat-input")).trim() !== e.reply) throw Error("Draft or recipient changed before send");
    const v = await r.state.get(), K = await I(r, u, e.accountKey, e.contextId);
    if (v.replyIntents.filter((s) => s.accountKey === e.accountKey && s.incomingMessageId === e.incomingMessageId).length !== 1 || v.replyIntents.filter((s) => s.key === e.key && s.status === "reserved").length !== 1 || !K.data.records.some((s) => s.type === "reply" && s.businessKey === e.key && s.sightings.some((h) => h.contextId === e.contextId && h.intentKey === e.key && h.status === "reserved")) || K.data.records.some((s) => s.type === "reply" && s.businessKey === e.key && s.sightings.some((h) => h.contextId !== e.contextId || h.intentKey !== e.key || h.status !== "reserved")) || (v.conversationControls || []).some((s) => s.accountKey === e.accountKey && [e.conversationKey, "boss-chat:" + e.rows[0].mid].includes(s.conversationKey) && s.mode === "paused") || !await o() || String(await i("read", "#chat-input")).trim() !== e.reply) throw Error("\u53D1\u9001\u524D\u5BF9\u8C61\u3001\u6765\u4FE1\u3001\u9884\u7559\u6216\u63A5\u7BA1\u72B6\u6001\u53D8\u5316");
    if (!/按\s*Enter\s*键发送/u.test(String(await i("read", ".chat-conversation")))) throw Error("\u7F51\u7AD9\u672A\u786E\u8BA4Enter\u53D1\u9001\u6A21\u5F0F\uFF1B\u4E0D\u6267\u884C\u53D1\u9001");
    if (c = true, await i("click", "#chat-input"), !await o() || String(await i("read", "#chat-input")).trim() !== e.reply) throw Error("\u56DE\u8F66\u524D\u5F53\u524D\u804A\u5929\u6216\u8349\u7A3F\u53D8\u5316\uFF0C\u4E0D\u53D1\u9001");
    return await i("press", "#chat-input", "Enter"), { ...e, kind: "chat-reply-dispatch", dispatched: true, effect: A, intent: n, websiteConfirmed: false };
  } catch (t) {
    const g = c ? "unknown" : "failed";
    if (await r.effect.resolve({ id: A.id, state: g, evidence: { kind: "reply-not-confirmed", incomingMessageId: e.incomingMessageId, jobSource: e.jobSource, attempted: c, reason: String(t.message || t) } }), a = await r.state.get(), E) {
      await r.state.set({ ...a, replyIntents: a.replyIntents.map((D) => D.key === e.key ? { ...D, status: g } : D) }), a = await r.state.get();
      const l = await I(r, u, e.accountKey, e.contextId);
      l.merge(a), await l.save();
    }
    throw t;
  }
};
export {
  j as default
};
