import { createHash } from "node:crypto";
const canonical = (v) => Array.isArray(v) ? v.map(canonical) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical(v[k])])) : v;
const digest = (v) => createHash("sha256").update(JSON.stringify(canonical(v))).digest("hex");
async function safetyIndex(template, signal, accountKey, contextId, initialize = false) {
  const name = "account-outbound-safety-v1-" + accountKey + ".json";
  let data, existed = true, baseline;
  try {
    baseline = await template.file("communication-cache", { operation: "read", name });
    data = JSON.parse(baseline);
  } catch (error) {
    if (!String(error.message || error).includes("ENOENT")) throw error;
    if (!initialize) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
    existed = false;
    data = { version: 1, kind: "boss-account-outbound-safety", accountKey, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (existed) {
    const { sha256, ...body } = data;
    if (sha256 !== digest(body)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
  }
  if (data.version !== 1 || data.kind !== "boss-account-outbound-safety" || data.accountKey !== accountKey || !Number.isSafeInteger(data.revision) || data.revision < 0 || !Array.isArray(data.records) || data.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
  const records = /* @__PURE__ */ new Set();
  for (const r of data.records) {
    if (!["first-contact", "reply"].includes(r.type) || !/^[a-f0-9]{64}$/.test(r.businessKey) || !Array.isArray(r.sightings) || !r.sightings.length || r.sightings.length > 100 || records.has(r.type + ":" + r.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
    records.add(r.type + ":" + r.businessKey);
    for (const s of r.sightings) if (typeof s.contextId !== "string" || !s.contextId || !/^[a-f0-9]{64}$/.test(s.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(s.status) || !/^\d{4}-\d{2}-\d{2}$/.test(s.day) || typeof s.timeZone !== "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
  }
  let dirty = !existed;
  const merge = (state) => {
    if (!Array.isArray(state?.applicationIntents) || !Array.isArray(state?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
    for (const [type, rows] of [["first-contact", state.applicationIntents], ["reply", state.replyIntents]]) for (const i of rows) {
      if ((type === "first-contact" ? i.accountSourceSha256 : i.accountKey) !== accountKey) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
      if (!/^[a-f0-9]{64}$/.test(i.key) || !i.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(i.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
      const businessKey = type === "first-contact" ? digest(["boss-job-safety-v1", accountKey, i.jobId]) : createHash("sha256").update(["boss-text-reply-v1", accountKey, i.incomingMessageId].join(":")).digest("hex");
      let r = data.records.find((r2) => r2.type === type && r2.businessKey === businessKey);
      if (!r) {
        r = { type, businessKey, jobId: i.jobId, ...type === "reply" ? { conversationKey: i.conversationKey, incomingMessageId: i.incomingMessageId } : {}, sightings: [] };
        data.records.push(r);
        dirty = true;
      }
      if (r.jobId !== i.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
      const sight = { contextId, intentKey: i.key, status: i.status, day: i.day, timeZone: i.timeZone, contentSha256: i.contentSha256 || null, sourceSha256: i.sourceSha256 || null };
      if (!r.sightings.some((s) => JSON.stringify(canonical(s)) === JSON.stringify(canonical(sight)))) {
        r.sightings.push(sight);
        dirty = true;
      }
      if (r.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
    }
    if (data.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
  };
  const save = async () => {
    signal.throwIfAborted();
    if (dirty) {
      if (existed && await template.file("communication-cache", { operation: "read", name }) !== baseline) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
      data.records.sort((a, b) => (a.type + ":" + a.businessKey).localeCompare(b.type + ":" + b.businessKey));
      for (const r of data.records) r.sightings.sort((a, b) => JSON.stringify(canonical(a)).localeCompare(JSON.stringify(canonical(b))));
      data.revision++;
      data.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      delete data.sha256;
      data.sha256 = digest(data);
      await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(data) });
      dirty = false;
      baseline = JSON.stringify(data);
      existed = true;
    }
    const back = JSON.parse(await template.file("communication-cache", { operation: "read", name }));
    const { sha256, ...body } = back;
    if (sha256 !== digest(body) || sha256 !== data.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
    return { revision: data.revision, sha256: data.sha256, records: data.records.length };
  };
  return { data, name, merge, save, blocked: (type, key) => data.records.some((r) => r.type === type && r.businessKey === key) };
}
const closingRead = (template, signal) => async (operation, selector, value) => {
  signal.throwIfAborted();
  return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
};
const closingValid = (v) => {
  const { sha256, ...body } = v;
  return sha256 === digest(body);
};
async function closingProgress(template, signal, c, change) {
  const name = c.progressName, raw = await template.file("communication-cache", { operation: "read", name }), p = JSON.parse(raw);
  if (!closingValid(p) || p.accountKey !== c.accountKey || p.fixedUnreadSetSha256 !== c.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
  if (!change) return p;
  const next = change(structuredClone(p));
  next.revision++;
  next.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  delete next.sha256;
  next.sha256 = digest(next);
  if (await template.file("communication-cache", { operation: "read", name }) !== raw) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  signal.throwIfAborted();
  await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(next) });
  const back = JSON.parse(await template.file("communication-cache", { operation: "read", name }));
  if (!closingValid(back) || back.sha256 !== next.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
  return back;
}
async function closingMessages(read) {
  const count = await read("count", "li.message-item");
  if (!Number.isSafeInteger(count) || count < 1 || count > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
  const rows = [];
  for (let n = 1; n <= count; n++) {
    const selector = "li.message-item:nth-child(" + n + " of li.message-item)", mid = await read("attribute", selector, "data-mid"), cls = await read("attribute", selector, "class");
    if (!/^\d{6,40}$/.test(mid || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
    const texts = await read("count", selector + " .text-content");
    if (texts > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
    const text = texts === 1 ? String(await read("read", selector + " .text-content")).trim() : null, context = text === null ? String(await read("read", selector)).trim() : null;
    if ((text || context || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
    const systemText = !!text && /^您正在与Boss.+沟通$/u.test(text), direction = !systemText && text !== null && cls.split(/\s+/u).includes("item-myself") ? "outgoing" : !systemText && text !== null && cls.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
    rows.push({ mid, direction, text, context });
  }
  if (new Set(rows.map((r) => r.mid)).size !== rows.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
  return rows;
}
async function closingRecipient(read, c) {
  const url = new URL(await read("url"));
  if (url.origin !== "https://www.zhipin.com" || url.pathname !== "/web/geek/chat" || await read("count", ".chat-conversation .user-info") !== 1 || await read("count", ".friend-content.selected") !== 1) return false;
  const header = String(await read("read", ".chat-conversation .user-info")).trim(), selected = String(await read("read", ".friend-content.selected")).trim(), compact = (v) => v.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
  return compact(header) === compact(c.member.identityLine) && selected.split(/\r?\n/u).map((x) => x.trim()).includes(c.member.identityLine);
}
async function closingSourceSame(template, signal, c) {
  const read = closingRead(template, signal);
  if (!await closingRecipient(read, c)) return false;
  const name = String(await read("read", c.accountSelector)).trim();
  return name === c.accountLabel && String(await read("read", c.recipientSelector)).trim() === c.recipientLabel && String(await read("read", c.jobSelector)).trim() === c.chatJobTitle && JSON.stringify(await closingMessages(read)) === JSON.stringify(c.rows);
}
var stdin_default = async ({ input, template, signal, artifact }) => {
  if (input?.kind !== "unread-closing-cohort") throw Error("\u7F3A\u5C11\u56FA\u5B9A\u6536\u5C3E\u6765\u6E90");
  if (input.closingPhase === false) return { version: 1, kind: "fixed-unread-closing-summary", closingPhase: false, siteDailyLimitConfirmed: false, newGreeting: false, memberCount: 0, remaining: 0, dayTaskComplete: false, decision: "continue", reason: "\u5C1A\u65E0\u771F\u5B9E\u7F51\u7AD9\u4E0A\u9650\u8BC1\u636E\uFF0C\u672C\u6279\u4E0D\u8BFB\u53D6\u4F1A\u8BDD" };
  const p = await closingProgress(template, signal, input), confirmed = p.completed.filter((x) => x.status === "confirmed"), review = p.completed.filter((x) => x.status === "review"), remaining = input.memberCount - p.completed.length;
  const result = { version: 1, kind: "fixed-unread-closing-summary", siteDailyLimitConfirmed: input.siteDailyLimitEvidence?.confirmed === true, testCompletionConfirmed: input.testCompletionEvidence?.confirmed === true, newGreeting: false, newMembersAdded: 0, fixedUnreadSetSha256: input.fixedUnreadSetSha256, memberCount: input.memberCount, originalUnreadMessageCount: input.unreadMessageCount, confirmedReplies: confirmed.length, skipped: p.completed.length - confirmed.length - review.length, needsReview: review.length, remaining, activeMember: p.active?.memberKey || null, completed: p.completed, progressSha256: p.sha256, dayTaskComplete: remaining === 0, decision: remaining ? "review" : "complete", progress: input.fixedUnreadSetSha256 + ":" + p.completed.length, reason: remaining ? "\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u5C1A\u6709\u672A\u5B8C\u6210\u6210\u5458\uFF0C\u91CD\u5F00\u540E\u4ECE\u6D3B\u8DC3\u4F1A\u8BDD\u6062\u590D" : "\u56FA\u5B9A\u672A\u8BFB\u4F1A\u8BDD\u96C6\u5408\u5904\u7406\u5B8C\u6BD5\uFF1B\u4E4B\u540E\u65B0\u5230\u7684\u5176\u4ED6\u4F1A\u8BDD\u672A\u52A0\u5165\u672C\u8F6E" };
  await artifact("fixed-unread-closing-summary.json", JSON.stringify(result, null, 2));
  await template.result(result);
  return result;
};
export {
  stdin_default as default
};
