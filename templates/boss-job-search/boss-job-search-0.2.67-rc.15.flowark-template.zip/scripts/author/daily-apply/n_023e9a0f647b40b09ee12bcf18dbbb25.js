async function acceptanceGreetingGate(template, signal, scope) {
  const { accountKey, contextId, day, timeZone, revision, configuration } = scope;
  const target = configuration.acceptanceNewGreetings ?? 0;
  if (target !== 0 && target !== 2) throw Error("\u9A8C\u6536\u65B0\u62DB\u547C\u6570\u53EA\u80FD\u4E3A0\uFF08\u6B63\u5F0F\u6A21\u5F0F\uFF09\u62162");
  if (!target) return null;
  signal.throwIfAborted();
  const canon = (v) => Array.isArray(v) ? v.map(canon) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canon(v[k])])) : v;
  const hash = (v) => createHash("sha256").update(JSON.stringify(canon(v))).digest("hex");
  const checked = (v) => {
    const { sha256, ...body } = v;
    if (sha256 !== hash(body)) throw Error("\u9A8C\u6536\u6765\u6E90\u6458\u8981\u4E0D\u7B26\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55");
    return v;
  };
  const index = checked(JSON.parse(await template.file("communication-cache", { operation: "read", name: "account-outbound-safety-v1-" + accountKey + ".json" })));
  if (index.kind !== "boss-account-outbound-safety" || index.accountKey !== accountKey || !Array.isArray(index.records)) throw Error("\u9A8C\u6536\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u4E0D\u7B26");
  const today = new Intl.DateTimeFormat("sv-SE", { timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
  if (day !== today) throw Error("\u9A8C\u6536\u8DE8\u65E5\uFF0C\u505C\u6B62\u65B0\u589E");
  const occupied = index.records.filter((r) => r.type === "first-contact" && r.sightings.some((s) => s.day === day && s.timeZone === timeZone));
  const keys = occupied.map((r) => r.businessKey);
  if (new Set(keys).size !== keys.length) throw Error("\u9A8C\u6536\u5360\u989D\u952E\u91CD\u590D");
  const identity = { accountKey, contextId, day, timeZone, revision, target };
  const name = "test-greeting-baseline-v1-" + accountKey + "-" + hash(identity).slice(0, 24) + ".json";
  let raw = null;
  try {
    raw = await template.file("communication-cache", { operation: "read", name });
  } catch (e) {
    if (!String(e.message || e).includes("ENOENT")) throw e;
  }
  let baseline;
  if (raw === null) {
    if (configuration.firstContactDailyBudget !== keys.length + target) throw Error("\u6D4B\u8BD5\u9884\u7B97\u5FC5\u987B\u7B49\u4E8E\u672C\u65E5\u5DF2\u6709\u5360\u989D\u52A02\uFF0C\u7981\u6B62\u6269\u5927\u6216\u91CD\u7F6E\u672C\u8F6E");
    baseline = { version: 1, kind: "boss-test-greeting-baseline", identity, keys: keys.slice().sort(), budget: configuration.firstContactDailyBudget, indexSha256: index.sha256, createdAt: (/* @__PURE__ */ new Date()).toISOString() };
    baseline.sha256 = hash(baseline);
    await template.file("communication-cache", { operation: "write", name, content: JSON.stringify(baseline) });
    raw = await template.file("communication-cache", { operation: "read", name });
    if (JSON.stringify(checked(JSON.parse(raw))) !== JSON.stringify(baseline)) throw Error("\u6D4B\u8BD5\u57FA\u7EBF\u672A\u51C6\u786E\u8BFB\u56DE");
  } else baseline = checked(JSON.parse(raw));
  if (hash(baseline.identity) !== hash(identity) || baseline.budget !== configuration.firstContactDailyBudget || !Array.isArray(baseline.keys) || baseline.keys.some((k) => !keys.includes(k))) throw Error("\u6D4B\u8BD5\u57FA\u7EBF\u6216\u9884\u7B97\u53D8\u5316\uFF0C\u505C\u6B62\u4E14\u4FDD\u7559\u5386\u53F2");
  const added = occupied.filter((r) => !baseline.keys.includes(r.businessKey));
  if (added.length > target) throw Error("\u6D4B\u8BD5\u5360\u989D\u8D85\u51FA\u4E24\u6B21\uFF0C\u505C\u6B62");
  for (const r of added) if (r.sightings.some((s) => s.day === day && s.timeZone === timeZone && (s.contextId !== contextId || s.status === "unknown" || s.status === "failed"))) throw Error("\u6D4B\u8BD5\u65B0\u589E\u6765\u6E90\u51B2\u7A81\u6216\u7ED3\u679C\u672A\u77E5\uFF0C\u7981\u6B62\u8865\u53D1");
  const confirmed = added.filter((r) => r.sightings.some((s) => s.day === day && s.timeZone === timeZone && s.contextId === contextId && s.status === "confirmed"));
  return { version: 1, kind: "boss-test-new-greeting-completion", ...identity, baselineName: name, baselineSha256: baseline.sha256, newOccupied: added.length, newConfirmed: confirmed.length, confirmedKeys: confirmed.map((r) => r.businessKey).sort(), confirmed: confirmed.length === target, siteDailyLimitConfirmed: false, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
}
async function firstContactBudgetSnapshot(template, signal, scope) {
  const { accountKey, contextId, day, timeZone, limit, state, ownIntent = null, jobId = null } = scope;
  const hash = (value) => createHash("sha256").update(JSON.stringify(value)).digest("hex");
  const canonical = (value) => Array.isArray(value) ? value.map(canonical) : value && typeof value === "object" ? Object.fromEntries(Object.keys(value).sort().map((key) => [key, canonical(value[key])])) : value;
  const validDay = (value) => typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/u.test(value) && Number.isFinite(Date.parse(value + "T00:00:00Z")) && (/* @__PURE__ */ new Date(value + "T00:00:00Z")).toISOString().slice(0, 10) === value;
  const validStatus = (value) => ["reserved", "confirmed", "unknown", "failed"].includes(value);
  if (!/^[a-f0-9]{64}$/u.test(accountKey || "") || typeof contextId !== "string" || !contextId || !validDay(day) || typeof timeZone !== "string" || !timeZone || !Number.isSafeInteger(limit) || limit < 0 || limit > 150) throw Error("\u672C\u65E5\u81EA\u52A8\u65B0\u589E\u9884\u7B97\u7684\u8D26\u53F7\u3001\u65E5\u671F\u3001\u65F6\u533A\u6216\u6570\u91CF\u65E0\u6548");
  const currentDay = new Intl.DateTimeFormat("sv-SE", { timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
  if (currentDay !== day) throw Error("\u9884\u7B97\u6838\u5BF9\u671F\u95F4\u8DE8\u65E5\uFF0C\u505C\u6B62\u539F\u4F1A\u8BDD\u5E76\u4FDD\u7559\u8BB0\u5F55");
  signal.throwIfAborted();
  const name = "account-outbound-safety-v1-" + accountKey + ".json";
  const content = await template.file("communication-cache", { operation: "read", name });
  if (typeof content !== "string" || Buffer.byteLength(content) > 10 * 1024 * 1024) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\u6216\u8D85\u51FA\u8303\u56F4\uFF0C\u4E0D\u5EFA\u7ACB\u7A7A\u9884\u7B97");
  const index = JSON.parse(content), { sha256, ...body } = index;
  if (index.version !== 1 || index.kind !== "boss-account-outbound-safety" || index.accountKey !== accountKey || !Number.isSafeInteger(index.revision) || index.revision < 0 || !Array.isArray(index.records) || index.records.length > 2e3 || sha256 !== hash(canonical(body))) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u6458\u8981\u4E0D\u7B26\uFF0C\u4E0D\u5EFA\u7ACB\u65B0\u9884\u7B97");
  const unique = /* @__PURE__ */ new Set(), occupied = /* @__PURE__ */ new Set();
  let ownRecord = null, candidateAlreadyRecorded = false;
  for (const record of index.records) {
    signal.throwIfAborted();
    if (!record || !["first-contact", "reply"].includes(record.type) || !/^[a-f0-9]{64}$/u.test(record.businessKey || "") || !Array.isArray(record.sightings) || record.sightings.length < 1 || record.sightings.length > 100 || unique.has(record.type + ":" + record.businessKey)) throw Error("\u5B89\u5168\u7D22\u5F15\u8BB0\u5F55\u7ED3\u6784\u3001\u5BB9\u91CF\u6216\u552F\u4E00\u6027\u65E0\u6548");
    unique.add(record.type + ":" + record.businessKey);
    if (record.type === "first-contact" && (typeof record.jobId !== "string" || !record.jobId || record.businessKey !== hash(["boss-job-safety-v1", accountKey, record.jobId]))) throw Error("\u9996\u6B21\u6C9F\u901A\u4E1A\u52A1\u952E\u4E0E\u51C6\u786E\u5C97\u4F4D\u4E0D\u7B26");
    for (const sight of record.sightings) {
      if (!sight || typeof sight.contextId !== "string" || !sight.contextId || !/^[a-f0-9]{64}$/u.test(sight.intentKey || "") || !validStatus(sight.status) || !validDay(sight.day) || typeof sight.timeZone !== "string" || !sight.timeZone) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u6765\u6E90\u6216\u72B6\u6001\u65E0\u6548");
      if (record.type !== "first-contact") continue;
      if (sight.timeZone !== timeZone || sight.day > day) throw Error("\u9996\u6B21\u6C9F\u901A\u7D22\u5F15\u65F6\u533A\u51B2\u7A81\u6216\u5B58\u5728\u672A\u6765\u65E5\u671F\uFF0C\u4FDD\u7559\u539F\u9884\u7B97\u505C\u6B62");
      if (sight.day === day) occupied.add(record.businessKey);
    }
    if (record.type === "first-contact" && jobId !== null && record.jobId === jobId) candidateAlreadyRecorded = true;
    if (record.type === "first-contact" && ownIntent && record.jobId === ownIntent.jobId) ownRecord = record;
  }
  if (!state || !Array.isArray(state.applicationIntents) || state.applicationIntents.length > 500) throw Error("\u7F3A\u5C11\u5F53\u524D\u5B8C\u6574\u610F\u56FE\u8D26\u672C\uFF0C\u4E0D\u80FD\u8BA1\u7B97\u9884\u7B97");
  const localKeys = /* @__PURE__ */ new Set();
  for (const intent of state.applicationIntents) {
    if (!intent || intent.accountSourceSha256 !== accountKey || intent.timeZone !== timeZone || !validDay(intent.day) || intent.day > day || !validStatus(intent.status) || typeof intent.jobId !== "string" || !intent.jobId || intent.key !== hash(["boss-application-v1", accountKey, intent.jobId]) || localKeys.has(intent.key)) throw Error("\u672C\u5B9E\u4F8B\u610F\u56FE\u6765\u6E90\u3001\u65F6\u533A\u6216\u552F\u4E00\u6027\u65E0\u6548\uFF0C\u4E0D\u80FD\u8BA1\u7B97\u9884\u7B97");
    localKeys.add(intent.key);
    if (intent.day === day) occupied.add(hash(["boss-job-safety-v1", accountKey, intent.jobId]));
  }
  let ownReservationCounted = false;
  if (ownIntent) {
    const matches = state.applicationIntents.filter((intent) => intent.key === ownIntent.key);
    if (ownIntent.status !== "reserved" || ownIntent.day !== day || ownIntent.timeZone !== timeZone || matches.length !== 1 || JSON.stringify(canonical(matches[0])) !== JSON.stringify(canonical(ownIntent)) || !ownRecord || !ownRecord.sightings.every((sight) => sight.contextId === contextId && sight.intentKey === ownIntent.key && sight.status === "reserved" && sight.day === day && sight.timeZone === timeZone)) throw Error("\u63D0\u4EA4\u524D\u7F3A\u5C11\u672C\u6B21\u552F\u4E00\u3001\u5DF2\u5199\u51FA\u5E76\u8BFB\u56DE\u7684\u9884\u7B97\u9884\u7559");
    ownReservationCounted = occupied.has(ownRecord.businessKey);
    if (!ownReservationCounted) throw Error("\u672C\u6B21\u9884\u7559\u672A\u8BA1\u5165\u786C\u9884\u7B97\uFF0C\u505C\u6B62\u63D0\u4EA4");
  }
  const used = occupied.size, remaining = Math.max(0, limit - used);
  return { version: 1, kind: "boss-first-contact-daily-budget", accountKey, day, timeZone, limit, used, remaining, exhausted: remaining === 0, withinLimit: used <= limit, candidateAlreadyRecorded, ownReservationCounted, readyForReservation: !ownIntent && remaining > 0 && !candidateAlreadyRecorded, readyForSubmission: !!ownIntent && ownReservationCounted && limit > 0 && used <= limit, safetyRevision: index.revision, safetySha256: sha256, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), siteDailyLimitConfirmed: false, countBasis: "unique-account-job-keys-in-day-index-and-current-state", failedAttemptsRemainOccupied: true };
}
import { createHash } from "node:crypto";
const cursorCanonical = (value) => Array.isArray(value) ? value.map(cursorCanonical) : value && typeof value === "object" ? Object.fromEntries(Object.keys(value).sort().map((key) => [key, cursorCanonical(value[key])])) : value;
const cursorDigest = (value) => createHash("sha256").update(JSON.stringify(cursorCanonical(value))).digest("hex");
const cursorCard = (position) => "div:nth-of-type(" + position + ") > div:nth-of-type(1) > li:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1)";
function cursorJob(href, base) {
  const u = new URL(href, base), match = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(u.pathname);
  if (u.origin !== "https://www.zhipin.com" || u.username || u.password || u.hash || !match)
    throw Error("\u589E\u91CF\u4F4D\u7F6E\u7F3A\u5C11\u51C6\u786E\u5C97\u4F4D\u94FE\u63A5");
  return { jobId: match[1], jobSource: u.origin + u.pathname };
}
async function openIncrementalCursor(template, signal, scope) {
  const fields = ["accountKey", "contextId", "configurationRevision", "day", "timeZone", "searchUrl"];
  if (!scope || fields.some((key) => scope[key] === void 0) || !/^[a-f0-9]{64}$/.test(scope.accountKey) || !scope.contextId || !Number.isSafeInteger(scope.configurationRevision) || !/^\d{4}-\d{2}-\d{2}$/.test(scope.day)) throw Error("\u589E\u91CF\u4F4D\u7F6E\u7F3A\u5C11\u56FA\u5B9A\u8303\u56F4");
  const u = new URL(scope.searchUrl);
  if (u.origin !== "https://www.zhipin.com" || u.pathname !== "/web/geek/jobs" || u.username || u.password || u.hash || !u.searchParams.get("query")) throw Error("\u589E\u91CF\u68C0\u7D22\u6765\u6E90\u65E0\u6548");
  const name = "single-job-list-v1-" + scope.accountKey + "-" + cursorDigest(scope).slice(0, 32) + ".json";
  let original = null, data;
  try {
    original = await template.file("communication-cache", { operation: "read", name });
  } catch (error) {
    if (!String(error.message || error).includes("ENOENT")) throw error;
  }
  if (original !== null) {
    data = JSON.parse(original);
    const { sha256, ...body } = data;
    if (sha256 !== cursorDigest(body) || data.version !== 1 || data.kind !== "boss-single-job-list-cursor" || fields.some((key) => data[key] !== scope[key]) || !Number.isSafeInteger(data.revision) || data.revision < 0 || !Number.isSafeInteger(data.through) || data.through < 0 || !Number.isSafeInteger(data.listCount) || data.listCount < data.through || data.listCount > 500 || data.through > 0 && typeof data.throughId !== "string" || typeof data.exhausted !== "boolean")
      throw Error("\u5DF2\u4FDD\u5B58\u7684\u589E\u91CF\u4F4D\u7F6E\u8EAB\u4EFD\u3001\u6458\u8981\u6216\u7ED3\u6784\u65E0\u6548\uFF1B\u672A\u6E05\u7A7A\u91CD\u5EFA");
  } else data = {
    version: 1,
    kind: "boss-single-job-list-cursor",
    ...scope,
    revision: 0,
    through: 0,
    throughId: null,
    listCount: 0,
    firstId: null,
    tailId: null,
    exhausted: false,
    lastLoad: null
  };
  const plan = (patch) => {
    const next = { ...data, ...patch, revision: data.revision + 1 };
    delete next.sha256;
    next.sha256 = cursorDigest(next);
    return { version: 1, name, scope, beforeSha256: original === null ? null : createHash("sha256").update(original).digest("hex"), value: next };
  };
  const save = async (update) => {
    signal.throwIfAborted();
    if (!update || update.name !== name || cursorDigest(update.scope) !== cursorDigest(scope) || update.beforeSha256 !== (original === null ? null : createHash("sha256").update(original).digest("hex")))
      throw Error("\u589E\u91CF\u4F4D\u7F6E\u5199\u5165\u8BA1\u5212\u6765\u6E90\u4E0D\u7B26");
    const { sha256, ...body } = update.value;
    if (sha256 !== cursorDigest(body) || body.revision !== data.revision + 1)
      throw Error("\u589E\u91CF\u4F4D\u7F6E\u5199\u5165\u8BA1\u5212\u6458\u8981\u6216\u4FEE\u8BA2\u4E0D\u7B26");
    let before = null;
    try {
      before = await template.file("communication-cache", { operation: "read", name });
    } catch (error) {
      if (!String(error.message || error).includes("ENOENT")) throw error;
    }
    if (before !== original) throw Error("\u589E\u91CF\u4F4D\u7F6E\u5DF2\u88AB\u5176\u4ED6\u64CD\u4F5C\u4FEE\u6539\uFF0C\u505C\u6B62\u8986\u76D6");
    const content = JSON.stringify(update.value);
    await template.file("communication-cache", { operation: "write", name, content });
    if (await template.file("communication-cache", { operation: "read", name }) !== content)
      throw Error("\u589E\u91CF\u4F4D\u7F6E\u4FDD\u5B58\u540E\u672A\u5B8C\u6574\u8BFB\u56DE");
    data = update.value;
    original = content;
    return { name, revision: data.revision, through: data.through, listCount: data.listCount, sha256: data.sha256 };
  };
  return { name, get data() {
    return data;
  }, plan, save };
}
async function observeIncrementalPosition(read, cursor, count, searchUrl) {
  if (!Number.isSafeInteger(count) || count < 1 || count > 500) throw Error("\u589E\u91CF\u5217\u8868\u5C1A\u672A\u5C31\u7EEA\u6216\u8D85\u51FA\u8BFB\u53D6\u8303\u56F4");
  const idAt = async (position) => cursorJob(await read({ operation: "attribute", selector: cursorCard(position) + " > a:nth-of-type(1)", value: "href" }), searchUrl).jobId;
  const firstId = await idAt(1), tailId = await idAt(count), old = cursor.data;
  let through = old.through, restored = false;
  const anchorMatches = through === 0 || through <= count && await idAt(through) === old.throughId;
  const appendMatches = old.listCount === 0 || count >= old.listCount && firstId === old.firstId && await idAt(old.listCount) === old.tailId;
  if (!anchorMatches || !appendMatches) {
    if (!old.throughId) throw Error("\u5217\u8868\u5237\u65B0\u540E\u6CA1\u6709\u53EF\u6838\u5BF9\u7684\u5DF2\u5904\u7406\u951A\u70B9\uFF1B\u672A\u6309\u65E7\u5E8F\u53F7\u7EE7\u7EED");
    const matches = [];
    for (let position = 1; position <= count; position++) if (await idAt(position) === old.throughId) matches.push(position);
    if (matches.length !== 1) throw Error("\u5217\u8868\u5237\u65B0\u6216\u91CD\u6392\u540E\u6062\u590D\u4F4D\u7F6E\u4E0D\u660E\u786E\uFF0C\u672A\u6E05\u7A7A\u8FDB\u5EA6\u6216\u731C\u6D4B\u4F4D\u7F6E");
    through = matches[0];
    restored = true;
  }
  if (await read({ operation: "url" }) !== searchUrl || await read({ operation: "count", selector: "div > div:nth-of-type(1) > li" }) !== count || await idAt(1) !== firstId || await idAt(count) !== tailId) throw Error("\u8BFB\u53D6\u589E\u91CF\u4F4D\u7F6E\u671F\u95F4\u5217\u8868\u53D8\u5316");
  return { through, throughId: through > 0 ? await idAt(through) : null, listCount: count, firstId, tailId, restored };
}
var stdin_default = async ({ input, template, signal }) => {
  signal.throwIfAborted();
  const raw = input?.fixedConfiguration, closing = input?.closing, summary = input?.closingSummary;
  if (closing?.version !== 1 || closing.kind !== "unread-closing-cohort" || typeof closing.closingPhase !== "boolean" || raw?.contextId !== closing.contextId) throw Error("\u7F3A\u5C11\u540C\u5B9E\u4F8B\u672C\u6279\u6536\u5C3E\u9636\u6BB5\u6838\u5BF9");
  if (closing.closingPhase) {
    if (summary?.kind !== "fixed-unread-closing-summary" || summary.siteDailyLimitConfirmed !== true && !(closing.closingTrigger === "two-new-greetings-test" && summary.testCompletionConfirmed === true) || summary.fixedUnreadSetSha256 !== closing.fixedUnreadSetSha256 || summary.memberCount !== closing.memberCount || summary.newGreeting !== false || !["complete", "review"].includes(summary.decision)) throw Error("\u56FA\u5B9A\u6536\u5C3E\u6C47\u603B\u4E0E\u672C\u8F6E\u6210\u5458\u4E0D\u7B26");
    const result2 = { ...summary, kind: "daily-continuous-decision", closingPhase: true, reason: summary.reason };
    await template.result(result2);
    return result2;
  }
  const testGate = await acceptanceGreetingGate(template, signal, { accountKey: closing.accountKey, contextId: raw.contextId, day: closing.day, timeZone: closing.timeZone, revision: raw.revision, configuration: raw.value });
  if (testGate?.confirmed) {
    const result2 = { version: 1, kind: "daily-continuous-decision", decision: "continue", progress: testGate.baselineSha256 + ":two-confirmed-start-unread", reason: "\u672C\u8F6E\u4E24\u6B21\u65B0\u62DB\u547C\u5DF2\u53D6\u5F97\u56DE\u6267\uFF0C\u4E0B\u4E00\u6279\u81EA\u52A8\u56FA\u5B9A\u5E76\u5904\u7406\u672A\u8BFB\uFF1B\u975E\u7F51\u7AD9\u4E0A\u9650", siteDailyLimitConfirmed: false, testCompletionConfirmed: true, newGreeting: false, dayTaskComplete: false };
    await template.result(result2);
    return result2;
  }
  const quotaName = "site-daily-limit-v1-" + closing.accountKey + "-" + closing.day + ".json";
  let quota = null;
  try {
    quota = JSON.parse(await template.file("communication-cache", { operation: "read", name: quotaName }));
  } catch (error) {
    if (!String(error?.message || error).includes("ENOENT") || !String(error?.message || error).includes(quotaName)) throw error;
  }
  if (quota) {
    const { sha256, ...body } = quota;
    if (sha256 !== cursorDigest(body) || quota.kind !== "boss-site-daily-limit" || quota.accountKey !== closing.accountKey || quota.day !== closing.day || quota.timeZone !== closing.timeZone || quota.confirmed !== true) throw Error("\u771F\u5B9E\u4E0A\u9650\u8BC1\u636E\u8EAB\u4EFD\u6216\u6458\u8981\u4E0D\u7B26");
    const result2 = { version: 1, kind: "daily-continuous-decision", decision: "continue", progress: quota.sha256 + ":start-unread-closing", reason: "\u771F\u5B9E\u7F51\u7AD9\u4E0A\u9650\u5DF2\u4FDD\u5B58\uFF0C\u4E0B\u4E00\u6279\u76F4\u63A5\u6062\u590D\u6D88\u606F\u6536\u5C3E\uFF0C\u4E0D\u518D\u521D\u59CB\u5316\u6295\u9012", siteDailyLimitConfirmed: true, newGreeting: false, dayTaskComplete: false };
    await template.result(result2);
    return result2;
  }
  const configuredBudget = raw?.value?.firstContactDailyBudget;
  if (!Number.isSafeInteger(configuredBudget) || configuredBudget < 0 || configuredBudget > 150) throw Error("\u7EED\u6279\u7F3A\u5C11\u672C\u4EBA\u660E\u786E\u914D\u7F6E\u7684\u672C\u65E5\u786C\u9884\u7B97");
  if (configuredBudget === 0) {
    const result2 = { version: 1, kind: "daily-continuous-decision", decision: "review", progress: closing.day + ":budget-disabled", reason: "\u672C\u65E5\u81EA\u52A8\u65B0\u589E\u9884\u7B97\u4E3A0\uFF0C\u672A\u65B0\u589E\u62DB\u547C\uFF1B\u4E0D\u662F\u7F51\u7AD9\u4E0A\u9650", siteDailyLimitConfirmed: false, dayTaskComplete: false, newGreeting: false };
    await template.result(result2);
    return result2;
  }
  const branch = input?.accountBranch;
  if (!branch || typeof branch !== "object" || Array.isArray(branch) || Object.keys(branch).length > 200) throw Error("\u7EED\u6279\u8D26\u53F7\u6765\u6E90\u5206\u652F\u7F3A\u5931\u6216\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
  const accounts = Object.values(branch).filter((v) => v && typeof v === "object" && !Array.isArray(v) && v.version === 1 && v.status === "current-account-source-matched" && v.currentAccountVerified === true && v.eligibleForActions === false);
  if (accounts.length !== 1) throw Error("\u7EED\u6279\u9700\u8981\u552F\u4E00\u7684\u672C\u6B21\u5DF2\u590D\u9A8C\u8D26\u53F7\u7ED3\u679C\uFF0C\u4E0D\u6309\u65E7\u8282\u70B9ID\u731C\u6D4B\u6765\u6E90");
  const account = accounts[0];
  if (!raw || raw.version !== 1 || raw.operation !== "configuration" || !raw.contextId || !Number.isSafeInteger(raw.revision) || !account || account.status !== "current-account-source-matched") throw Error("\u7EED\u6279\u7F3A\u5C11\u672C\u6B21\u56FA\u5B9A\u914D\u7F6E\u53CA\u8D26\u53F7\u6765\u6E90");
  const configuration = await template.configuration();
  if (cursorDigest(configuration) !== cursorDigest(raw.value)) throw Error("\u7EED\u6279\u914D\u7F6E\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u539F\u4F1A\u8BDD");
  const resume = new URL(account.jobseekerResumeHref, account.sourceUrl);
  if (resume.origin !== "https://www.zhipin.com" || resume.pathname !== "/web/geek/resume") throw Error("\u7EED\u6279\u8D26\u53F7\u5165\u53E3\u4E0D\u7B26");
  const accountKey = createHash("sha256").update(JSON.stringify(["boss-visible-account-source-v1", account.accountName, account.phoneMask, resume.origin + resume.pathname])).digest("hex");
  const state = await template.state.get();
  signal.throwIfAborted();
  if (!configuration || !state || !Array.isArray(state.queueEntries) || !Array.isArray(state.applicationIntents)) throw Error("\u8FDE\u7EED\u5904\u7406\u7684\u914D\u7F6E\u6216\u5B8C\u6574\u72B6\u6001\u6765\u6E90\u4E0D\u4E00\u81F4");
  const timeZone = configuration.replyTimeZone;
  const day = new Intl.DateTimeFormat("sv-SE", { timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
  if (day !== closing.day || timeZone !== closing.timeZone) throw Error("\u8FDE\u7EED\u4F1A\u8BDD\u8DE8\u65E5\u6216\u65F6\u533A\u53D8\u5316\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u539F\u8BB0\u5F55");
  const queue = state.queueEntries.filter((row) => row.day === day && row.timeZone === timeZone);
  const intents = state.applicationIntents.filter((row) => row.day === day && row.timeZone === timeZone);
  const processing = queue.filter((row) => row.status === "processing").length;
  const pending = queue.filter((row) => row.status === "queued").length;
  const confirmedToday = intents.filter((row) => row.status === "confirmed").length;
  const firstContactBudget = await firstContactBudgetSnapshot(template, signal, { accountKey, contextId: raw.contextId, day, timeZone, limit: configuredBudget, state });
  if (firstContactBudget.exhausted || !firstContactBudget.withinLimit) {
    const result2 = { version: 1, kind: "daily-continuous-decision", decision: "review", progress: cursorDigest({ day, timeZone, accountKey, firstContactBudget }), reason: "\u672C\u65E5\u81EA\u52A8\u65B0\u589E\u786C\u9884\u7B97\u5DF2\u7528\u5B8C\uFF0C\u505C\u6B62\u65B0\u589E\uFF1B\u5C1A\u672A\u53D6\u5F97\u771F\u5B9E\u7F51\u7AD9\u4E0A\u9650\uFF0C\u9996\u6B21\u63A5\u7EED\u672A\u9A8C\u6536", firstContactBudget, siteDailyLimitConfirmed: false, dayTaskComplete: false, newGreeting: false };
    await template.result(result2);
    return result2;
  }
  const read = (command) => {
    signal.throwIfAborted();
    return template.browser("browser", { ...command, timeoutMs: 1e4 });
  };
  const citySelector = "body > div:nth-of-type(1) > div:nth-of-type(2) > div:nth-of-type(2) > div > div:nth-of-type(1) > span", cards = "div > div:nth-of-type(1) > li";
  const source = await read({ operation: "url" }), page = new URL(source);
  if (page.origin !== "https://www.zhipin.com" || page.pathname !== "/web/geek/jobs" || page.username || page.password || page.hash) throw Error("\u7EED\u6279\u8FDB\u5EA6\u7F3A\u5C11\u771F\u5B9E\u5C97\u4F4D\u5217\u8868\u6765\u6E90");
  if (!Array.isArray(configuration.targetRoles) || !configuration.targetRoles.some((role) => typeof role === "string" && role.trim() === page.searchParams.get("query"))) throw Error("\u7EED\u6279\u7B49\u5F85\u524D\u7684\u5B9E\u9645\u68C0\u7D22\u8BCD\u4E0E\u56FA\u5B9A\u914D\u7F6E\u4E0D\u7B26");
  const pauseList = () => new Promise((resolve, reject) => {
    signal.throwIfAborted();
    const stop = () => {
      clearTimeout(timer);
      reject(signal.reason || Error("\u5DF2\u53D6\u6D88"));
    };
    const timer = setTimeout(() => {
      signal.removeEventListener("abort", stop);
      resolve();
    }, 250);
    signal.addEventListener("abort", stop, { once: true });
  });
  let actualCity = "", visibleCount = 0, stableList = 0, lastList = "";
  const listUntil = Date.now() + 1e4;
  while (Date.now() < listUntil) {
    if (await read({ operation: "url" }) !== source) throw Error("\u7EED\u6279\u7B49\u5F85\u671F\u95F4\u5C97\u4F4D\u5217\u8868\u6765\u6E90\u53D8\u5316");
    const cityCount = await read({ operation: "count", selector: citySelector });
    visibleCount = await read({ operation: "count", selector: cards });
    if (!Number.isSafeInteger(cityCount) || cityCount < 0 || cityCount > 1 || !Number.isSafeInteger(visibleCount) || visibleCount < 0 || visibleCount > 500) throw Error("\u7EED\u6279\u5217\u8868\u5B9A\u4F4D\u6570\u91CF\u4E0D\u7B26");
    actualCity = cityCount === 1 ? await read({ operation: "read", selector: citySelector }) : "";
    if (typeof actualCity !== "string" || !Array.isArray(configuration.cities) || actualCity.trim() && !configuration.cities.includes(actualCity.trim())) throw Error("\u7EED\u6279\u7B49\u5F85\u671F\u95F4\u5B9E\u9645\u57CE\u5E02\u4E0E\u914D\u7F6E\u4E0D\u7B26");
    const currentList = JSON.stringify([actualCity.trim(), visibleCount]);
    const readyList = configuration.cities.includes(actualCity.trim()) && visibleCount > 0;
    stableList = readyList ? currentList === lastList ? stableList + 1 : 1 : 0;
    lastList = currentList;
    if (stableList >= 2) break;
    await pauseList();
  }
  if (stableList < 2) throw Error("\u7EED\u6279\u5217\u8868\u5728\u6709\u9650\u7B49\u5F85\u5185\u672A\u5C31\u7EEA\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u539F\u8FD0\u884C");
  if (typeof actualCity !== "string" || !Array.isArray(configuration.cities) || !configuration.cities.includes(actualCity.trim()) || !Number.isSafeInteger(visibleCount) || visibleCount < 1 || visibleCount > 500) throw Error("\u7EED\u6279\u8FDB\u5EA6\u7684\u5B9E\u9645\u57CE\u5E02\u6216\u5217\u8868\u6570\u91CF\u4E0D\u7B26");
  const lastSelector = "div:nth-of-type(" + visibleCount + ") > div:nth-of-type(1) > li:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1) > a:nth-of-type(1)";
  const lastHref = await read({ operation: "attribute", selector: lastSelector, value: "href" });
  if (typeof lastHref !== "string" || !lastHref || lastHref.length > 4096 || lastHref.trim() !== lastHref) throw Error("\u7EED\u6279\u8FDB\u5EA6\u7F3A\u5C11\u5B8C\u6574\u5C97\u4F4D\u94FE\u63A5");
  const lastPage = new URL(lastHref, source), match = /^\/job_detail\/([A-Za-z0-9_~-]+)\.html$/.exec(lastPage.pathname);
  if (lastPage.origin !== "https://www.zhipin.com" || lastPage.username || lastPage.password || lastPage.hash || !match) throw Error("\u7EED\u6279\u8FDB\u5EA6\u7684\u5C97\u4F4D\u8EAB\u4EFD\u65E0\u6548");
  if (await read({ operation: "url" }) !== source || await read({ operation: "count", selector: cards }) !== visibleCount || await read({ operation: "attribute", selector: lastSelector, value: "href" }) !== lastHref || (await read({ operation: "read", selector: citySelector })).trim() !== actualCity.trim()) throw Error("\u7EED\u6279\u8FDB\u5EA6\u8BFB\u53D6\u671F\u95F4\u5217\u8868\u6765\u6E90\u53D8\u5316");
  const query = page.searchParams.get("query");
  if (!Array.isArray(configuration.targetRoles) || !configuration.targetRoles.length || typeof query !== "string" || !configuration.targetRoles.some((role) => typeof role === "string" && query === role.trim())) throw Error("\u7EED\u6279\u8FDB\u5EA6\u7684\u5B9E\u9645\u68C0\u7D22\u8BCD\u4E0E\u56FA\u5B9A\u914D\u7F6E\u4E0D\u7B26");
  const cursor = await openIncrementalCursor(template, signal, { accountKey, contextId: raw.contextId, configurationRevision: raw.revision, day, timeZone, searchUrl: source });
  const position = await observeIncrementalPosition(read, cursor, visibleCount, source);
  const currentPending = queue.filter((row) => row.status === "queued" && row.searchUrl === source).length;
  const queries = configuration.targetRoles.map((role) => role.trim());
  if (new Set(queries).size !== queries.length) throw Error("\u68C0\u7D22\u8BCD\u91CD\u590D\uFF0C\u672A\u81EA\u52A8\u6269\u5927\u6216\u6539\u5199\u914D\u7F6E");
  const rotationScope = { accountKey, contextId: raw.contextId, configurationRevision: raw.revision, day, timeZone, queries };
  const rotationName = "single-job-queries-v1-" + accountKey + "-" + cursorDigest(rotationScope).slice(0, 32) + ".json";
  let rotationText = null, rotation;
  try {
    rotationText = await template.file("communication-cache", { operation: "read", name: rotationName });
  } catch (error) {
    if (!String(error.message || error).includes("ENOENT")) throw error;
  }
  if (rotationText === null) rotation = { version: 1, kind: "boss-single-job-query-progress", scope: rotationScope, exhaustedQueries: [] };
  else {
    rotation = JSON.parse(rotationText);
    const { sha256, ...body } = rotation;
    if (sha256 !== cursorDigest(body) || rotation.version !== 1 || rotation.kind !== "boss-single-job-query-progress" || cursorDigest(rotation.scope) !== cursorDigest(rotationScope) || !Array.isArray(rotation.exhaustedQueries) || new Set(rotation.exhaustedQueries).size !== rotation.exhaustedQueries.length || rotation.exhaustedQueries.some((q) => !queries.includes(q))) throw Error("\u68C0\u7D22\u8F6E\u6362\u8BB0\u5F55\u7F3A\u5931\u8EAB\u4EFD\u6216\u6458\u8981\u4E0D\u7B26");
  }
  if (rotation.loadEvidenceVersion !== 2) {
    rotation.exhaustedQueries = [];
    rotation.loadEvidenceVersion = 2;
  }
  let nextQuery = query, rotated = false, allQueriesExhausted = false;
  const exhausted = cursor.data.exhausted === true && cursor.data.lastLoad?.scrollTarget === "body" && cursor.data.lastLoad?.region === "document" && cursor.data.lastLoad?.heightAfter > cursor.data.lastLoad?.viewportAfter && position.through >= visibleCount && currentPending === 0;
  if (exhausted) {
    if (!rotation.exhaustedQueries.includes(query)) rotation.exhaustedQueries.push(query);
    nextQuery = queries.find((q) => !rotation.exhaustedQueries.includes(q)) || query;
    allQueriesExhausted = rotation.exhaustedQueries.length === queries.length;
    delete rotation.sha256;
    rotation.sha256 = cursorDigest(rotation);
    const content = JSON.stringify(rotation);
    let before = null;
    try {
      before = await template.file("communication-cache", { operation: "read", name: rotationName });
    } catch (error) {
      if (!String(error.message || error).includes("ENOENT")) throw error;
    }
    if (before !== rotationText) throw Error("\u68C0\u7D22\u8F6E\u6362\u8FDB\u5EA6\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u8986\u76D6");
    await template.file("communication-cache", { operation: "write", name: rotationName, content });
    if (await template.file("communication-cache", { operation: "read", name: rotationName }) !== content) throw Error("\u68C0\u7D22\u8F6E\u6362\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
    if (!allQueriesExhausted) {
      if (await read({ operation: "url" }) !== source) throw Error("\u5207\u6362\u68C0\u7D22\u524D\u6765\u6E90\u53D8\u5316");
      const target = new URL(source);
      target.searchParams.set("query", nextQuery);
      await read({ operation: "navigate", value: target.href });
      let stable = 0;
      const until = Date.now() + 1e4;
      while (Date.now() < until) {
        if (await read({ operation: "url" }) !== target.href) throw Error("\u5207\u6362\u540E\u7684\u68C0\u7D22\u6765\u6E90\u4E0D\u7B26");
        const n = await read({ operation: "count", selector: cards });
        if (n > 0 && n <= 500 && await read({ operation: "count", selector: citySelector }) === 1 && String(await read({ operation: "read", selector: citySelector })).trim() === actualCity.trim()) stable++;
        else stable = 0;
        if (stable >= 2) break;
        await pauseList();
      }
      if (stable < 2) throw Error("\u4E0B\u4E00\u68C0\u7D22\u8BCD\u672A\u5728\u6709\u9650\u7B49\u5F85\u5185\u5C31\u7EEA");
      rotated = true;
    }
  }
  const hasWork = currentPending > 0 || position.through < visibleCount || !exhausted || rotated;
  const progress = cursorDigest({ day, timeZone, query: nextQuery, through: position.through, listCount: visibleCount, tail: position.tailId, lastLoad: cursor.data.lastLoad ? [cursor.data.lastLoad.offsetAfter, cursor.data.lastLoad.heightAfter, cursor.data.lastLoad.countAfter, cursor.data.lastLoad.atEnd] : null, exhaustedQueries: rotation.exhaustedQueries, queue: queue.map((row) => [row.key, row.status]).sort(), intents: intents.map((row) => [row.key, row.status]).sort() });
  const decision = processing || allQueriesExhausted || !hasWork ? "review" : "continue";
  const reason = processing ? "\u4ECD\u6709\u5C97\u4F4D\u5904\u7406\u72B6\u6001\u672A\u6536\u5C3E\uFF0C\u505C\u6B62\u7EED\u53D1\u6838\u5BF9\u539F\u8BB0\u5F55" : allQueriesExhausted ? "\u5168\u90E8\u914D\u7F6E\u68C0\u7D22\u8BCD\u5728\u672C\u6B21\u89E6\u5E95\u7B49\u5F85\u540E\u5747\u65E0\u65B0\u589E\uFF1B\u4FDD\u5B58\u539F\u56E0\u505C\u6B62\uFF0C\u4E0D\u7B97\u7F51\u7AD9\u5F53\u5929\u4E0A\u9650" : rotated ? "\u5F53\u524D\u68C0\u7D22\u672C\u6B21\u52A0\u8F7D\u672A\u89C1\u65B0\u589E\uFF0C\u5DF2\u5207\u6362\u5230 " + nextQuery : "\u4ECE\u5DF2\u4FDD\u5B58\u4F4D\u7F6E\u7EE7\u7EED\u5904\u7406\uFF1B\u5F53\u524D\u4F1A\u8BDD\u4E0D\u4EE520\u6B21\u4F5C\u4E3A\u53D1\u9001\u4E0A\u9650";
  const result = { version: 1, kind: "daily-continuous-decision", decision, progress, reason, day, timeZone, firstContactBudget, confirmedToday, pending, processing, query: nextQuery, rotated, exhaustedQueries: rotation.exhaustedQueries, through: position.through, visibleCount, siteDailyLimitConfirmed: false, dayTaskComplete: false };
  await template.result(result);
  return result;
};
export {
  stdin_default as default
};
