import { createHash as C } from "node:crypto";
const b = (e) => Array.isArray(e) ? e.map(b) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((u) => [u, b(e[u])])) : e, S = (e) => C("sha256").update(JSON.stringify(b(e))).digest("hex");
async function A(e, u, r, y, d = false) {
  const a = "account-outbound-safety-v1-" + r + ".json";
  let o, n = true, c;
  try {
    c = await e.file("communication-cache", { operation: "read", name: a }), o = JSON.parse(c);
  } catch (i) {
    if (!String(i.message || i).includes("ENOENT")) throw i;
    if (!d) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
    n = false, o = { version: 1, kind: "boss-account-outbound-safety", accountKey: r, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (n) {
    const { sha256: i, ...l } = o;
    if (i !== S(l)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
  }
  if (o.version !== 1 || o.kind !== "boss-account-outbound-safety" || o.accountKey !== r || !Number.isSafeInteger(o.revision) || o.revision < 0 || !Array.isArray(o.records) || o.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
  const w = /* @__PURE__ */ new Set();
  for (const i of o.records) {
    if (!["first-contact", "reply"].includes(i.type) || !/^[a-f0-9]{64}$/.test(i.businessKey) || !Array.isArray(i.sightings) || !i.sightings.length || i.sightings.length > 100 || w.has(i.type + ":" + i.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
    w.add(i.type + ":" + i.businessKey);
    for (const l of i.sightings) if (typeof l.contextId != "string" || !l.contextId || !/^[a-f0-9]{64}$/.test(l.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(l.status) || !/^\d{4}-\d{2}-\d{2}$/.test(l.day) || typeof l.timeZone != "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
  }
  let m = !n;
  return { data: o, name: a, merge: (i) => {
    if (!Array.isArray(i?.applicationIntents) || !Array.isArray(i?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
    for (const [l, E] of [["first-contact", i.applicationIntents], ["reply", i.replyIntents]]) for (const t of E) {
      if ((l === "first-contact" ? t.accountSourceSha256 : t.accountKey) !== r) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
      if (!/^[a-f0-9]{64}$/.test(t.key) || !t.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(t.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
      const g = l === "first-contact" ? S(["boss-job-safety-v1", r, t.jobId]) : C("sha256").update(["boss-text-reply-v1", r, t.incomingMessageId].join(":")).digest("hex");
      let f = o.records.find((B) => B.type === l && B.businessKey === g);
      if (f || (f = { type: l, businessKey: g, jobId: t.jobId, ...l === "reply" ? { conversationKey: t.conversationKey, incomingMessageId: t.incomingMessageId } : {}, sightings: [] }, o.records.push(f), m = true), f.jobId !== t.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
      const D = { contextId: y, intentKey: t.key, status: t.status, day: t.day, timeZone: t.timeZone, contentSha256: t.contentSha256 || null, sourceSha256: t.sourceSha256 || null };
      if (f.sightings.some((B) => JSON.stringify(b(B)) === JSON.stringify(b(D))) || (f.sightings.push(D), m = true), f.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
    }
    if (o.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
  }, save: async () => {
    if (u.throwIfAborted(), m) {
      if (n && await e.file("communication-cache", { operation: "read", name: a }) !== c) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
      o.records.sort((t, g) => (t.type + ":" + t.businessKey).localeCompare(g.type + ":" + g.businessKey));
      for (const t of o.records) t.sightings.sort((g, f) => JSON.stringify(b(g)).localeCompare(JSON.stringify(b(f))));
      o.revision++, o.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete o.sha256, o.sha256 = S(o), await e.file("communication-cache", { operation: "write", name: a, content: JSON.stringify(o) }), m = false, c = JSON.stringify(o), n = true;
    }
    const i = JSON.parse(await e.file("communication-cache", { operation: "read", name: a })), { sha256: l, ...E } = i;
    if (l !== S(E) || l !== o.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
    return { revision: o.revision, sha256: o.sha256, records: o.records.length };
  }, blocked: (i, l) => o.records.some((E) => E.type === i && E.businessKey === l) };
}
const k = (e, u) => async (r, y, d) => (u.throwIfAborted(), e.browser("browser", { operation: r, ...y ? { selector: y } : {}, ...d === void 0 ? {} : { value: d }, timeoutMs: 3e3 })), x = (e) => {
  const { sha256: u, ...r } = e;
  return u === S(r);
};
async function J(e, u, r, y) {
  const d = r.progressName, a = await e.file("communication-cache", { operation: "read", name: d }), o = JSON.parse(a);
  if (!x(o) || o.accountKey !== r.accountKey || o.fixedUnreadSetSha256 !== r.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
  if (!y) return o;
  const n = y(structuredClone(o));
  if (n.revision++, n.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete n.sha256, n.sha256 = S(n), await e.file("communication-cache", { operation: "read", name: d }) !== a) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  u.throwIfAborted(), await e.file("communication-cache", { operation: "write", name: d, content: JSON.stringify(n) });
  const c = JSON.parse(await e.file("communication-cache", { operation: "read", name: d }));
  if (!x(c) || c.sha256 !== n.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
  return c;
}
async function p(e) {
  const u = await e("count", "li.message-item");
  if (!Number.isSafeInteger(u) || u < 1 || u > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
  const r = [];
  for (let y = 1; y <= u; y++) {
    const d = "li.message-item:nth-child(" + y + " of li.message-item)", a = await e("attribute", d, "data-mid"), o = await e("attribute", d, "class");
    if (!/^\d{6,40}$/.test(a || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
    const n = await e("count", d + " .text-content");
    if (n > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
    const c = n === 1 ? String(await e("read", d + " .text-content")).trim() : null, w = c === null ? String(await e("read", d)).trim() : null;
    if ((c || w || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
    const m = !!c && /^您正在与Boss.+沟通$/u.test(c), F = !m && c !== null && o.split(/\s+/u).includes("item-myself") ? "outgoing" : !m && c !== null && o.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
    r.push({ mid: a, direction: F, text: c, context: w });
  }
  if (new Set(r.map((y) => y.mid)).size !== r.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
  return r;
}
async function M(e, u) {
  const r = new URL(await e("url"));
  if (r.origin !== "https://www.zhipin.com" || r.pathname !== "/web/geek/chat" || await e("count", ".chat-conversation .user-info") !== 1) return false;
  const y = String(await e("read", ".chat-conversation .user-info")).trim(), d = (m) => m.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, ""), a = d(u.member.identityLine), o = d(y), n = await e("count", ".friend-content.selected");
  if (n > 1) return false;
  const c = n === 1 ? d(String(await e("read", ".friend-content.selected"))) : null;
  if (o === a) return c === null || c.includes(a);
  const w = /^(.{1,20}?(?:先生|女士))/u.exec(a)?.[1];
  return !!w && a.endsWith("\u730E\u5934\u987E\u95EE") && o === w + "\u730E\u5934\u987E\u95EE" && (c !== null ? c.includes(a) : u.member.searchIdentityProof?.identityLine === u.member.identityLine && d(u.member.searchIdentityProof.targetText).includes(a));
}
async function O(e, u, r) {
  const y = k(e, u);
  return await M(y, r) ? String(await y("read", r.accountSelector)).trim() === r.accountLabel && String(await y("read", r.recipientSelector)).trim() === r.recipientLabel && String(await y("read", r.jobSelector)).trim() === r.chatJobTitle && JSON.stringify(await p(y)) === JSON.stringify(r.rows) : false;
}
var j = async ({ input: e, signal: u, template: r, artifact: y }) => {
  if (e?.kind !== "chat-reply-draft") throw Error("Missing AI reply stage");
  if (e.send && (typeof e.reply != "string" || Array.from(e.reply).length < 1 || Array.from(e.reply).length > 50)) throw Error("\u53D1\u9001\u524D\u56DE\u590D\u987B\u4E3A1\u81F350\u5B57\uFF0C\u672A\u5EFA\u7ACB\u53D1\u9001\u610F\u56FE");
  if (!e.send) return { ...e, kind: "chat-reply-dispatch", dispatched: false };
  const d = (t) => C("sha256").update(t).digest("hex");
  if (d(e.reply) !== e.contentSha256 || !e.model?.requestId || e.decision !== "reply" || e.closingPhase !== true || e.fixedUnreadMember !== true || e.siteDailyLimitEvidence?.confirmed !== true && !(e.closingTrigger === "two-new-greetings-test" && e.testCompletionEvidence?.kind === "boss-test-new-greeting-completion" && e.testCompletionEvidence.confirmed === true && e.testCompletionEvidence.newConfirmed === 2) || !e.fixedUnreadSetSha256 || e.key !== d(["boss-text-reply-v1", e.accountKey, e.incomingMessageId].join(":"))) throw Error("Reply text or model source changed");
  const a = (t, g, f) => (u.throwIfAborted(), r.browser("browser", { operation: t, ...g ? { selector: g } : {}, ...f !== void 0 ? { value: f } : {}, timeoutMs: 3e3 })), o = () => O(r, u, e);
  if (!await o()) throw Error("Conversation changed while AI was thinking; no send");
  let n = await r.state.get();
  const c = await A(r, u, e.accountKey, e.contextId);
  if (c.merge(n), await c.save(), (n.replyIntents || []).some((t) => t.accountKey === e.accountKey && t.incomingMessageId === e.incomingMessageId) || c.blocked("reply", e.key)) return { ...e, kind: "chat-reply-dispatch", dispatched: false, reason: "Persistent reply intent already exists; no replay" };
  const w = (n.conversationControls || []).filter((t) => t.accountKey === e.accountKey && t.conversationKey === e.conversationKey);
  if (w.some((t) => t.mode === "paused")) throw Error("Conversation is under manual control");
  const m = w.length ? Math.max(...w.map((t) => t.controlEpoch)) : 1;
  let F = n.replyIntents || [];
  if (F.length >= 500 || F.filter((t) => t.accountKey === e.accountKey && t.day === e.day && t.timeZone === e.timeZone && t.status !== "failed").length >= e.configuration.replyDailyLimit) throw Error("Reply quota or ledger capacity reached");
  if (await a("count", "#chat-input") !== 1 || String(await a("read", "#chat-input")).trim() !== "") throw Error("Composer contains an existing draft; no overwrite");
  if (await a("count", ".chat-conversation .btn-send") !== 1 || String(await a("read", ".chat-conversation .btn-send")).trim() !== "\u53D1\u9001") throw Error("Send target is ambiguous");
  const I = await r.effect.prepare({ action: "reply", key: e.key, description: "\u5411\u5F53\u524D\u51C6\u786E\u5DF2\u6709\u4F1A\u8BDD\u56DE\u590D\u539F\u6765\u4FE1 " + e.incomingMessageId + "\uFF1B\u4EC5\u6B64\u6587\u672C\uFF0C\u4E0D\u53D1\u9001\u9644\u4EF6\u6216\u65B0\u7684\u9996\u6B21\u62DB\u547C\u3002", review: { version: 1, target: e.jobTitle + `
` + e.jobSource + `
\u539F\u6765\u4FE1 ` + e.incomingMessageId, content: e.reply } });
  if (!I.execute) return { ...e, kind: "chat-reply-dispatch", dispatched: false, reason: "Existing effect blocks repeated reply" };
  const i = { key: e.key, accountKey: e.accountKey, conversationKey: e.conversationKey, incomingMessageId: e.incomingMessageId, jobId: e.jobId, contentSha256: e.contentSha256, sourceSha256: e.sourceSha256, profileVersionId: e.profile.ref.versionId, configurationRevision: e.configurationRevision, controlEpoch: m, day: e.day, timeZone: e.timeZone, createdAt: (/* @__PURE__ */ new Date()).toISOString(), status: "reserved" };
  let l = false, E = false;
  try {
    n = await r.state.get(), F = n.replyIntents || [];
    const t = await A(r, u, e.accountKey, e.contextId);
    if (t.merge(n), await t.save(), F.some((s) => s.accountKey === e.accountKey && s.incomingMessageId === e.incomingMessageId) || t.blocked("reply", e.key)) throw Error("\u786E\u8BA4\u671F\u95F4\u539F\u6765\u4FE1\u5DF2\u5EFA\u7ACB\u56DE\u590D\u610F\u56FE\uFF0C\u505C\u6B62\u65E7\u8349\u7A3F");
    if ((n.conversationControls || []).some((s) => s.accountKey === e.accountKey && [e.conversationKey, "boss-chat:" + e.rows[0].mid].includes(s.conversationKey) && s.mode === "paused")) throw Error("\u786E\u8BA4\u671F\u95F4\u672C\u4EBA\u5DF2\u63A5\u7BA1\u4F1A\u8BDD");
    if (new Set(t.data.records.filter((s) => s.type === "reply" && s.sightings.some((h) => h.day === e.day && h.timeZone === e.timeZone && h.status !== "failed")).map((s) => s.businessKey)).size >= e.configuration.replyDailyLimit || F.length >= 500) throw Error("\u786E\u8BA4\u671F\u95F4\u56DE\u590D\u989D\u5EA6\u6216\u8D26\u672C\u5BB9\u91CF\u5DF2\u6EE1");
    if (await r.state.set({ ...n, replyIntents: [...F, i] }), E = true, n = await r.state.get(), n.replyIntents.filter((s) => s.key === e.key && s.status === "reserved").length !== 1 || !await o()) throw Error("Reservation or exact conversation changed");
    const f = await A(r, u, e.accountKey, e.contextId);
    f.merge(n);
    const D = await f.save();
    if (!f.data.records.some((s) => s.type === "reply" && s.businessKey === e.key && s.sightings.some((h) => h.contextId === e.contextId && h.intentKey === e.key && h.status === "reserved"))) throw Error("\u56DE\u590D\u5B89\u5168\u7D22\u5F15\u9884\u7559\u672A\u8BFB\u56DE");
    await y("reply-reservation.json", JSON.stringify({ intent: i, effect: I, safety: D, sourceSha256: e.sourceSha256, reply: e.reply, model: e.model }, null, 2)), await a("fill", "#chat-input", e.reply);
    let B = false;
    for (let s = 0; s < 12; s++) {
      if (String(await a("read", "#chat-input")).trim() === e.reply) {
        B = true;
        break;
      }
      await new Promise((h) => setTimeout(h, 100));
    }
    if (!B || !await o() || String(await a("read", "#chat-input")).trim() !== e.reply) throw Error("Draft or recipient changed before send");
    const v = await r.state.get(), K = await A(r, u, e.accountKey, e.contextId);
    if (v.replyIntents.filter((s) => s.accountKey === e.accountKey && s.incomingMessageId === e.incomingMessageId).length !== 1 || v.replyIntents.filter((s) => s.key === e.key && s.status === "reserved").length !== 1 || !K.data.records.some((s) => s.type === "reply" && s.businessKey === e.key && s.sightings.some((h) => h.contextId === e.contextId && h.intentKey === e.key && h.status === "reserved")) || K.data.records.some((s) => s.type === "reply" && s.businessKey === e.key && s.sightings.some((h) => h.contextId !== e.contextId || h.intentKey !== e.key || h.status !== "reserved")) || (v.conversationControls || []).some((s) => s.accountKey === e.accountKey && [e.conversationKey, "boss-chat:" + e.rows[0].mid].includes(s.conversationKey) && s.mode === "paused") || !await o() || String(await a("read", "#chat-input")).trim() !== e.reply) throw Error("\u53D1\u9001\u524D\u5BF9\u8C61\u3001\u6765\u4FE1\u3001\u9884\u7559\u6216\u63A5\u7BA1\u72B6\u6001\u53D8\u5316");
    if (!/按\s*Enter\s*键发送/u.test(String(await a("read", ".chat-conversation")))) throw Error("\u7F51\u7AD9\u672A\u786E\u8BA4Enter\u53D1\u9001\u6A21\u5F0F\uFF1B\u4E0D\u6267\u884C\u53D1\u9001");
    return l = true, await a("press", "#chat-input", "Enter"), { ...e, kind: "chat-reply-dispatch", dispatched: true, effect: I, intent: i, websiteConfirmed: false };
  } catch (t) {
    const g = l ? "unknown" : "failed";
    if (await r.effect.resolve({ id: I.id, state: g, evidence: { kind: "reply-not-confirmed", incomingMessageId: e.incomingMessageId, jobSource: e.jobSource, attempted: l, reason: String(t.message || t) } }), n = await r.state.get(), E) {
      await r.state.set({ ...n, replyIntents: n.replyIntents.map((D) => D.key === e.key ? { ...D, status: g } : D) }), n = await r.state.get();
      const f = await A(r, u, e.accountKey, e.contextId);
      f.merge(n), await f.save();
    }
    throw t;
  }
};
export {
  j as default
};
