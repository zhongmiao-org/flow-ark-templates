async function L(e, t, a, n, u) {
  t.throwIfAborted();
  try {
    return await e.browser("browser", { operation: a, ...n ? { selector: n } : {}, ...u === void 0 ? {} : { value: u }, timeoutMs: 3e3 });
  } catch (i) {
    if (a !== "navigate" || !["https://www.zhipin.com/web/geek/chat", "https://www.zhipin.com/web/geek/resume"].includes(u) || !/^\(-3\) loading /u.test(String(i?.message || i))) throw i;
    for (let r = 0; r < 40; r++) {
      t.throwIfAborted();
      const o = await e.browser("browser", { operation: "url", timeoutMs: 3e3 });
      if (o === u) return o;
      await new Promise((s) => setTimeout(s, 150));
    }
    throw i;
  }
}
function O(e, t) {
  const a = (s) => s.normalize("NFKC").replace(/\s+/gu, " ").trim().toLocaleLowerCase("en-US");
  if (typeof e != "string" || !e.trim() || e.length > 1e3 || /(?:\.{3}|…|⋯)/u.test(e)) throw Error("\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u7F3A\u5931\u6216\u622A\u65AD\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u8BB0\u5F55");
  const n = t?.titleKeywords, u = t?.excludedRoles;
  for (const [s, c, m] of [["titleKeywords", n, 1], ["excludedRoles", u, 0]]) if (!Array.isArray(c) || c.length < m || c.length > 20 || c.some((w) => typeof w != "string" || !a(w) || w.length > 100) || new Set(c.map(a)).size !== c.length) throw Error("\u5C97\u4F4D\u8303\u56F4\u914D\u7F6E\u65E0\u6548\uFF1A" + s + "\uFF1B\u672A\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE");
  const i = a(e), r = u.filter((s) => i.includes(a(s))), o = n.filter((s) => i.includes(a(s)));
  return { version: 1, kind: "literal-full-job-title-scope", fullTitle: e, matched: o, excluded: r, allowed: r.length === 0 && o.length > 0, source: "actual-complete-job-title", jdUsed: false, searchKeywordUsedAsEvidence: false };
}
import { createHash as U } from "node:crypto";
const K = (e) => Array.isArray(e) ? e.map(K) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((t) => [t, K(e[t])])) : e, f = (e) => U("sha256").update(JSON.stringify(K(e))).digest("hex"), B = (e) => String(e).replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, ""), J = (e, t) => (a, n, u) => L(e, t, a, n, u), x = async (e, t) => {
  try {
    return await e.file("communication-cache", { operation: "read", name: t });
  } catch (a) {
    if (String(a.message || a).includes("ENOENT")) return null;
    throw a;
  }
};
async function M(e, t) {
  const a = "resume-delivery-index-v1-" + t.accountKey + ".json", n = await x(e, a);
  let u = n === null ? { version: 1, kind: "boss-resume-delivery-index", accountKey: t.accountKey, revision: 0, uploads: [], deliveries: [] } : JSON.parse(n);
  if (n !== null) {
    const { sha256: i, ...r } = u;
    if (i !== f(r)) throw Error("\u9644\u4EF6\u8D26\u672C\u6458\u8981\u65E0\u6548\uFF0C\u672A\u91CD\u5EFA");
  }
  if (u.version !== 1 || u.kind !== "boss-resume-delivery-index" || u.accountKey !== t.accountKey || !Number.isSafeInteger(u.revision) || !Array.isArray(u.uploads) || !Array.isArray(u.deliveries) || u.uploads.length > 100 || u.deliveries.length > 2e3 || new Set(u.uploads.map((i) => i.key)).size !== u.uploads.length || new Set(u.deliveries.map((i) => i.key)).size !== u.deliveries.length) throw Error("\u9644\u4EF6\u8D26\u672C\u8EAB\u4EFD\u3001\u5BB9\u91CF\u6216\u552F\u4E00\u6027\u65E0\u6548\uFF0C\u539F\u8BB0\u5F55\u4FDD\u7559");
  return { name: a, raw: n, value: u };
}
async function y(e, t) {
  if (await x(e, t.name) !== t.raw) throw Error("\u9644\u4EF6\u8D26\u672C\u5DF2\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  t.value.revision++, t.value.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete t.value.sha256, t.value.sha256 = f(t.value), await e.file("communication-cache", { operation: "write", name: t.name, content: JSON.stringify(t.value) });
  const a = await x(e, t.name), n = JSON.parse(a), { sha256: u, ...i } = n;
  if (u !== f(i) || u !== t.value.sha256) throw Error("\u9644\u4EF6\u8D26\u672C\u672A\u5B8C\u6574\u8BFB\u56DE");
  return t.raw = a, { name: t.name, sha256: u, revision: n.revision };
}
async function q(e, t) {
  const a = new URL(await e("url"));
  return a.origin === "https://www.zhipin.com" && a.pathname === "/web/geek/chat" && await e("count", ".chat-conversation .user-info") === 1 && B(await e("read", ".chat-conversation .user-info")) === B(t.recipientLabel) && await e("count", t.request.agreeSelector) === 1 && String(await e("read", t.request.agreeSelector)).trim() === "\u540C\u610F" && await e("count", t.request.root) === 1 && String(await e("read", t.request.root)).trim() === t.request.text && String(await e("read", ".chat-position-content")).trim() === t.chatJobTitle;
}
async function W(e) {
  const t = ".resume-attachment";
  if (await e("count", t) !== 1 || await e("count", t + " > h3") !== 1 || !String(await e("read", t + " > h3")).trim().startsWith("\u9644\u4EF6\u7BA1\u7406")) throw Error("\u7F51\u7AD9\u9644\u4EF6\u7BA1\u7406\u7ED3\u6784\u5C1A\u672A\u6838\u5BF9\uFF0C\u672A\u64CD\u4F5C");
  return t;
}
async function P(e, t) {
  const a = await W(e), n = a + " .annex-item", u = await e("count", n);
  if (!Number.isSafeInteger(u) || u < 0 || u > 3) throw Error("\u9644\u4EF6\u5E93\u6587\u4EF6\u6570\u91CF\u65E0\u6CD5\u6838\u5BF9");
  const i = [];
  for (let o = 1; o <= u; o++) {
    const s = n + ":nth-child(" + o + ")", c = String(await e("read", s)).trim();
    if (c.length > 4e3) throw Error("\u9644\u4EF6\u6761\u76EE\u8FC7\u957F\uFF0C\u672A\u622A\u65AD");
    i.push({ selector: s, text: c });
  }
  const r = i.filter((o) => o.text.split(/\r?\n/u).map((s) => s.trim()).includes(t.displayName));
  if (r.length > 1) throw Error("\u9644\u4EF6\u5E93\u6709\u540C\u540D\u6587\u4EF6\uFF0C\u7981\u6B62\u6309\u4F4D\u7F6E\u53D1\u9001");
  return { root: a, count: u, rows: i, match: r[0] || null };
}
async function V(e, t) {
  const a = (c) => String(c).replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, ""), n = async () => {
    const c = new URL(await e("url"));
    return c.origin === "https://www.zhipin.com" && c.pathname === "/web/geek/chat" && await e("count", ".chat-conversation .user-info") === 1 && a(await e("read", ".chat-conversation .user-info")) === a(t.recipientLabel) && await e("count", t.request.agreeSelector) === 1 && await e("count", t.request.root) === 1 && String(await e("read", t.request.root)).trim() === t.request.text && String(await e("read", ".chat-position-content")).trim() === t.chatJobTitle;
  };
  if (await n()) return;
  await e("navigate", void 0, "https://www.zhipin.com/web/geek/chat");
  const u = ".list-warp.v2 input";
  let i = false;
  for (let c = 0; c < 40; c++) {
    if (await e("count", u) === 1) {
      i = true;
      break;
    }
    await new Promise((m) => setTimeout(m, 150));
  }
  if (!i) throw Error("\u539F\u4F1A\u8BDD\u5B9A\u5411\u641C\u7D22\u5C1A\u672A\u52A0\u8F7D\uFF0C\u672A\u9009\u62E9\u5176\u4ED6\u4F1A\u8BDD");
  if (await n()) return;
  await e("fill", u, t.recipientName);
  const r = ".boss-search-result .search-list";
  let o = [];
  for (let c = 0; c < 30; c++) {
    const m = await e("count", r);
    if (!Number.isSafeInteger(m) || m > 50) throw Error("\u8054\u7CFB\u4EBA\u5B9A\u5411\u641C\u7D22\u8303\u56F4\u65E0\u6548");
    o = [];
    for (let w = 1; w <= m; w++) {
      const E = r + ":nth-child(" + w + " of .search-list)", h = String(await e("read", E)).trim();
      typeof t.searchResultText == "string" && a(h.split(/职位\s*[:：]/u)[0]) === a(t.searchResultText.split(/职位\s*[:：]/u)[0]) && o.push({ selector: E, text: h });
    }
    if (o.length) break;
    await new Promise((w) => setTimeout(w, 150));
  }
  if (o.length !== 1) throw Error("\u672A\u627E\u5230\u552F\u4E00\u7684\u539F\u59D3\u540D\u3001\u516C\u53F8\u548C\u89D2\u8272\u7EC4\u5408\uFF0C\u672A\u6253\u5F00\u5176\u4ED6\u4F1A\u8BDD");
  const s = o[0];
  if (String(await e("read", s.selector)).trim() !== s.text) throw Error("\u539F\u8054\u7CFB\u4EBA\u641C\u7D22\u7ED3\u679C\u53D8\u5316\uFF0C\u672A\u70B9\u51FB");
  await e("click", s.selector), i = false;
  for (let c = 0; c < 40; c++) {
    if (await n()) {
      i = true;
      break;
    }
    await new Promise((m) => setTimeout(m, 150));
  }
  if (!i) throw Error("\u539F\u4F1A\u8BDD\u3001\u539F\u9644\u4EF6\u8BF7\u6C42\u672A\u91CD\u65B0\u8BFB\u56DE\uFF0C\u4E0D\u53D1\u9001");
}
function R(e, t) {
  if (!e?.class?.split(/\s/u).includes("item-system") || !/^[0-9]{6,40}$/.test(e.mid || "")) return null;
  const a = /您的附件简历\s+(.+?)\s+已发送给Boss(?:点击查看附件)?/u.exec(e.text || "");
  if (!a) return null;
  const n = a[1].trim(), u = n.normalize("NFKC"), i = t.displayName.normalize("NFKC");
  if (u === i) return { shown: n, serverNameTruncated: false };
  const r = u.endsWith("...") ? "..." : u.endsWith("\u2026") ? "\u2026" : null;
  if (r) {
    const o = u.slice(0, -r.length);
    if (o.length >= 8 && i.startsWith(o)) return { shown: n, serverNameTruncated: true };
  }
  return null;
}
async function d(e, t) {
  const a = new URL(await e("url")), n = t.accountSource.account, u = new URL(n.jobseekerResumeHref, n.sourceUrl);
  if (a.origin !== "https://www.zhipin.com") throw Error("\u5F53\u524D\u8D26\u53F7\u9875\u9762\u6765\u6E90\u53D8\u5316\uFF0C\u672A\u53D1\u9001\u9644\u4EF6");
  if (a.pathname === "/web/geek/resume") {
    if (a.origin + a.pathname !== u.origin + u.pathname || await e("count", ".nav-figure") !== 1 || String(await e("read", ".nav-figure")).normalize("NFKC").trim() !== n.accountName.normalize("NFKC").trim() || await e("count", ".resume-attachment") !== 1) throw Error("\u672C\u4EBA\u9644\u4EF6\u7BA1\u7406\u9875\u7684\u8D26\u53F7\u6216\u6765\u6E90\u53D8\u5316\uFF0C\u672A\u53D1\u9001");
    return;
  }
  const i = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", r = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)";
  if (a.pathname !== "/web/geek/chat" || await e("count", i) !== 1 || await e("count", r) !== 1 || String(await e("read", i)).normalize("NFKC").trim() !== n.accountName.normalize("NFKC").trim() || new URL(await e("attribute", r, "href"), a.href).href !== u.href) throw Error("\u5F53\u524D\u4F1A\u8BDD\u9875\u6C42\u804C\u8D26\u53F7\u53D8\u5316\uFF0C\u672A\u53D1\u9001\u9644\u4EF6");
}
async function I(e) {
  const t = await e("count", "li.message-item");
  if (!Number.isSafeInteger(t) || t < 1 || t > 100) throw Error("\u5F53\u524D\u6D88\u606F\u8303\u56F4\u4E0D\u80FD\u5B8C\u6574\u6838\u5BF9");
  const a = [];
  for (let n = 1; n <= t; n++) {
    const u = "li.message-item:nth-child(" + n + " of li.message-item)", i = await e("attribute", u, "data-mid"), r = await e("attribute", u, "class"), o = String(await e("read", u)).trim();
    if (!/^\d{6,40}$/.test(i || "") || typeof r != "string" || o.length > 2e4) throw Error("\u6D88\u606F\u6765\u6E90\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
    a.push({ mid: i, class: r, text: o });
  }
  return a;
}
async function $({ input: e, template: t, signal: a, artifact: n }) {
  if (a.throwIfAborted(), e?.kind !== "native-resume-send-preparation" || e.execute !== true || e.needsUpload !== false) throw Error("\u7F3A\u5C11\u672C\u6B21\u7F51\u7AD9\u73B0\u6709\u9644\u4EF6\u51C6\u5907\uFF1B\u4E0D\u4E0A\u4F20\u6216\u81EA\u5B9A\u4E49\u53D1\u9001");
  const { source: u, file: i } = e;
  if (i?.kind !== "boss-user-confirmed-existing-attachment" || i.userSpecifiedName !== true || i.serverBytesVerified !== false || typeof i.displayName != "string") throw Error("\u7F3A\u5C11\u672C\u4EBA\u6307\u5B9A\u7684\u7F51\u7AD9\u9644\u4EF6\u8EAB\u4EFD");
  if (!O(u.jobTitle, u.configuration).allowed) throw Error("\u9644\u4EF6\u5C97\u4F4D\u8303\u56F4\u672A\u901A\u8FC7\uFF0C\u4FDD\u7559\u8BB0\u5F55\u4E14\u4E0D\u53D1\u9001");
  const r = J(t, a), o = await M(t, u), s = o.value.deliveries.find((F) => F.key === u.requestKey);
  if (s?.mode !== "native-existing-attachment" || s.status !== "reserved" || s.effectId || s.sendKey || s.sourceSha256 !== u.sourceSha256 || f(s.file) !== f(i)) throw Error("\u539F\u8BF7\u6C42\u5DF2\u6709\u64CD\u4F5C\u6216\u672C\u6B21\u9884\u7559\u53D8\u5316\uFF0C\u4E0D\u91CD\u590D\u53D1\u9001");
  await d(r, u), await r("navigate", null, "https://www.zhipin.com/web/geek/resume");
  let c;
  for (let F = 0; F < 40; F++) {
    if (a.throwIfAborted(), await r("count", ".resume-attachment") === 1) {
      c = await P(r, i);
      break;
    }
    await new Promise((A) => setTimeout(A, 150));
  }
  if (await d(r, u), !c?.match || c.match.text !== i.libraryRow || c.count !== i.libraryCount) throw Error("\u7F51\u7AD9\u9644\u4EF6\u5E93\u4E0E\u672C\u4EBA\u6838\u5BF9\u7684\u51C6\u5907\u6765\u6E90\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u6838\u5BF9\uFF0C\u4E0D\u56DE\u9000\u5176\u4ED6\u6587\u4EF6");
  if (await V(r, u), await d(r, u), !await q(r, u) || f(await I(r)) !== f(u.rows)) throw Error("\u539F\u4F1A\u8BDD\u6216\u8BF7\u6C42\u5DF2\u53D8\u5316\uFF0C\u4E0D\u53D1\u9001");
  if (((await t.state.get()).conversationControls || []).some((F) => F.accountKey === u.accountKey && [u.conversationKey, "boss-chat:" + u.firstMessageId].includes(F.conversationKey) && F.mode === "paused")) throw Error("\u672C\u4EBA\u5DF2\u63A5\u7BA1\uFF0C\u4E0D\u53D1\u9001\u9644\u4EF6");
  const w = f(["boss-native-resume-send-v1", u.accountKey, u.requestKey]), E = await t.effect.prepare({ action: "send-resume", key: w, description: "\u4EC5\u901A\u8FC7BOSS\u539F\u751F\u529F\u80FD\u53D1\u9001\u672C\u4EBA\u786E\u8BA4\u7684\u7F51\u7AD9\u73B0\u6709\u9644\u4EF6\u4E00\u6B21", review: { version: 1, target: u.recipientLabel + `
` + u.chatJobTitle + `
` + u.jobSource, content: "\u7F51\u7AD9\u73B0\u6709\u9644\u4EF6\uFF1A" + i.displayName + `
` + i.libraryRow + `
\u7531\u672C\u4EBA\u5728BOSS\u7EF4\u62A4\u548C\u786E\u8BA4\u6700\u65B0\u7248\u672C\u3002\u672C\u6D41\u7A0B\u4E0D\u8BFB\u53D6\u672C\u5730\u7B80\u5386\u3001\u4E0D\u4E0A\u4F20\u3001\u4E0D\u8C03\u7528\u79C1\u6709\u53D1\u9001\u63A5\u53E3\uFF1B\u4EC5\u4F7F\u7528\u539F\u751F\u540C\u610F/\u53D1\u7B80\u5386\u53CA\u6587\u4EF6\u9009\u62E9\u63A7\u4EF6\u3002\u7F51\u7AD9\u6587\u4EF6\u5185\u5BB9\u672A\u4F5C\u5B57\u8282\u6458\u8981\u8BC1\u660E\u3002
\u539F\u8BF7\u6C42 ` + u.request.mid + "\uFF1B\u53D1\u9001\u4E00\u6B21\uFF0C\u672A\u77E5\u4E0D\u91CD\u653E\u3002" } });
  if (!E.execute) throw Error("\u672C\u8BF7\u6C42\u5DF2\u6709\u53D1\u9001\u64CD\u4F5C\u8BB0\u5F55\uFF0C\u672A\u91CD\u653E");
  if (s.status = "submitting", s.effectId = E.id, s.effectRunId = E.runId, s.sendKey = w, s.sourceMessageIds = u.rows.map((F) => F.mid), s.fileSelection = null, await y(t, o), !await q(r, u) || f(await I(r)) !== f(u.rows)) throw Error("\u53D1\u9001\u786E\u8BA4\u671F\u95F4\u539F\u8BF7\u6C42\u53D8\u5316\uFF0C\u672A\u70B9\u51FB");
  await d(r, u);
  let h = true, C = false, D = null, b = [];
  await r("click", u.request.agreeSelector);
  for (let F = 0; F < 100; F++) {
    if (a.throwIfAborted(), await d(r, u), B(await r("read", ".chat-conversation .user-info")) !== B(u.recipientLabel) || String(await r("read", ".chat-position-content")).trim() !== u.chatJobTitle) throw Error("\u539F\u751F\u9644\u4EF6\u64CD\u4F5C\u671F\u95F4\u4F1A\u8BDD\u53D8\u5316\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55\u4E14\u4E0D\u518D\u70B9\u51FB");
    const A = ".choose-resume-dialog .resume-list li.list-item:not(.video-list-item)", v = await r("count", A);
    if (!C && v > 0) {
      if (v > 3) throw Error("\u539F\u751F\u9644\u4EF6\u9009\u62E9\u8303\u56F4\u5F02\u5E38\uFF0C\u672A\u731C\u6D4B\u6587\u4EF6");
      const l = [];
      for (let N = 1; N <= v; N++) {
        const k = A + ":nth-child(" + N + ")";
        if (await r("count", k + " .resume-name") !== 1) throw Error("\u9644\u4EF6\u540D\u79F0\u4E0D\u552F\u4E00");
        String(await r("read", k + " .resume-name")).trim() === i.displayName && l.push(k);
      }
      if (l.length !== 1) throw Error("\u539F\u751F\u9009\u62E9\u5668\u4E2D\u6CA1\u6709\u552F\u4E00\u7684\u672C\u4EBA\u6307\u5B9A\u6587\u4EF6\uFF0C\u4E0D\u9009\u62E9\u5176\u4ED6\u9644\u4EF6");
      if (await r("click", l[0]), !String(await r("attribute", l[0], "class")).split(/\s/u).includes("selected") || await r("count", ".choose-resume-dialog .resume-list li.selected") !== 1 || String(await r("read", l[0] + " .resume-name")).trim() !== i.displayName) throw Error("\u539F\u751F\u9644\u4EF6\u9009\u62E9\u672A\u8BFB\u56DE");
      const g = ".choose-resume-dialog .btn-confirm";
      if (await r("count", g) !== 1 || String(await r("read", g)).trim() !== "\u53D1\u9001" || await r("attribute", g, "disabled") !== null || String(await r("attribute", g, "class")).split(/\s/u).includes("disabled")) throw Error("\u539F\u751F\u53D1\u9001\u6309\u94AE\u5C1A\u4E0D\u53EF\u7528");
      if (await d(r, u), !await q(r, u)) throw Error("\u9644\u4EF6\u9009\u62E9\u540E\u539F\u8BF7\u6C42\u53D8\u5316\uFF0C\u672A\u53D1\u9001");
      if (s.fileSelection = { mode: "exact-user-confirmed-site-file", exactFileName: i.displayName, fileConfirmationDigest: f(i), selectedRow: l[0], selectedLabel: String(await r("read", l[0] + " .resume-name")).trim(), checkedAt: (/* @__PURE__ */ new Date()).toISOString(), serverBytesVerified: false }, await y(t, o), String(await r("read", l[0] + " .resume-name")).trim() !== i.displayName || !String(await r("attribute", l[0], "class")).split(/\s/u).includes("selected")) throw Error("\u539F\u751F\u53D1\u9001\u524D\u6587\u4EF6\u9009\u62E9\u53D8\u5316\uFF0C\u4E0D\u70B9\u51FB");
      C = true, await r("click", g);
    }
    b = await I(r);
    const j = new Set(u.rows.map((l) => l.mid)), S = s.fileSelection, p = b.filter((l) => !j.has(l.mid) && R(l, i) && S?.exactFileName === i.displayName && S.fileConfirmationDigest === f(i));
    if (p.length > 1) throw Error("\u591A\u4E2A\u539F\u751F\u9644\u4EF6\u56DE\u6267\u65E0\u6CD5\u552F\u4E00\u5173\u8054\uFF0C\u4E0D\u91CD\u53D1");
    if (p.length === 1) {
      D = { version: 1, kind: "boss-native-resume-send-receipt", accountKey: u.accountKey, recipientLabel: u.recipientLabel, jobSource: u.jobSource, requestMid: u.request.mid, message: p[0], file: i, siteName: R(p[0], i), fileSelection: S, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), exactFileSelected: true, nativeWebsiteFunction: true, serverBytesVerified: false };
      break;
    }
    await new Promise((l) => setTimeout(l, 250));
  }
  if (await n("native-resume-send-observation.json", JSON.stringify({ source: u, file: i, nativeAgreeAttempted: h, clickedSend: C, receipt: D, rows: b }, null, 2)), !D) {
    await t.effect.resolve({ id: E.id, state: "unknown", evidence: { nativeAgreeAttempted: h, clickedSend: C, reason: "\u672A\u53D6\u5F97\u540C\u4F1A\u8BDD\u552F\u4E00\u539F\u751F\u9644\u4EF6\u56DE\u6267\uFF1B\u4E0D\u91CD\u653E" } }), s.status = "unknown", await y(t, o), await t.attention({ key: "native-resume-unknown-" + u.requestKey, title: "\u7F51\u7AD9\u539F\u751F\u9644\u4EF6\u53D1\u9001\u7ED3\u679C\u5F85\u6838\u5BF9\uFF0C\u8BF7\u52FF\u91CD\u53D1", detail: { recipientLabel: u.recipientLabel, requestMid: u.request.mid, file: i, nativeAgreeAttempted: h, clickedSend: C } });
    const F = { version: 1, kind: "resume-send-result", status: "unknown", confirmedWebsiteMessages: 0, actualWebsiteMessagesUnknown: true, websiteUploads: 0, aiCalled: false };
    return await n("native-resume-stage-result.json", JSON.stringify(F)), F;
  }
  await t.effect.resolve({ id: E.id, state: "confirmed", evidence: D }), s.status = "confirmed", s.evidence = D;
  const T = await y(t, o), z = { version: 1, kind: "resume-send-result", status: "native-resume-sent-confirmed", file: i, receipt: D, ledger: T, confirmedWebsiteMessages: 1, websiteMessagesSent: 1, websiteUploads: 0, aiCalled: false, nativeWebsiteFunction: true, serverBytesVerified: false };
  return await n("native-resume-stage-result.json", JSON.stringify(z)), z;
}
export {
  $ as default
};
