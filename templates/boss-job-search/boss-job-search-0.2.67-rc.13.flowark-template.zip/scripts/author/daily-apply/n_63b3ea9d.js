import { createHash as A } from "node:crypto";
const K = (w) => Array.isArray(w) ? w.map(K) : w && typeof w == "object" ? Object.fromEntries(Object.keys(w).sort().map((n) => [n, K(w[n])])) : w, h = (w) => A("sha256").update(JSON.stringify(K(w))).digest("hex");
async function T({ input: w, template: n, signal: M, artifact: N }) {
  const t = w, u = "wechat";
  if (!["wechat", "phone"].includes(u) || t?.kind !== "chat-reply-source" || !t.fixedUnreadMember || !t.member?.key) throw Error("\u539F\u751F\u4EA4\u6362\u7F3A\u5C11\u56FA\u5B9A\u6210\u5458\u6765\u6E90");
  const l = { version: 1, kind: "boss-native-contact-result", contactType: u, memberKey: t.member.key, actions: [], websiteMessagesSent: 0 };
  if (!t.jobId || ["job-title-outside-configured-scope", "rejected-no-reply", "manual-control", "already-completed", "fixed-unread-complete"].includes(t.status)) return { ...l, status: "skipped", reason: t.reason };
  const o = async (e, r, c) => {
    M.throwIfAborted();
    const a = await n.browser("browser", { operation: e, ...r ? { selector: r } : {}, ...c === void 0 ? {} : { value: c }, timeoutMs: 3e3 });
    return M.throwIfAborted(), a;
  }, g = async () => {
    const e = new URL(await o("url"));
    if (e.origin !== "https://www.zhipin.com" || e.pathname !== "/web/geek/chat" || await o("count", t.recipientSelector) !== 1 || String(await o("read", t.recipientSelector)).trim() !== t.recipientLabel || String(await o("read", t.jobSelector)).trim() !== t.chatJobTitle || String(await o("read", t.accountSelector)).trim() !== t.accountLabel) throw Error("\u539F\u751F\u4EA4\u6362\u8D26\u53F7\u3001\u5BF9\u8C61\u6216\u5C97\u4F4D\u53D8\u5316");
    if (((await n.state.get()).conversationControls || []).some((c) => c.accountKey === t.accountKey && [t.conversationKey, "boss-chat:" + t.rows[0].mid].includes(c.conversationKey) && c.mode === "paused")) throw Error("\u4F1A\u8BDD\u5DF2\u7531\u672C\u4EBA\u63A5\u7BA1");
  };
  await g();
  const q = t.chatJobTitle.split(/\r?\n/u).map((e) => e.trim()).filter(Boolean), j = /^(\d+(?:\.\d+)?)-(\d+(?:\.\d+)?)K(?:·\d+薪)?$/iu.exec(q[1]), p = (e) => e.normalize("NFKC").toLocaleLowerCase("en-US");
  if (!j || !t.configuration.cities?.includes(q[2]) || Number(j[2]) * 1e3 < t.configuration.salaryMin || t.configuration.salaryMax > 0 && Number(j[1]) * 1e3 > t.configuration.salaryMax || !t.configuration.titleKeywords?.some((e) => p(t.jobTitle).includes(p(e))) || t.configuration.excludedRoles?.some((e) => p(t.jobTitle).includes(p(e)))) return { ...l, status: "todo", reason: "\u5F53\u524D\u5B8C\u6574\u5C97\u4F4D\u8303\u56F4\u3001\u57CE\u5E02\u6216\u6708\u85AA\u4EA4\u96C6\u672A\u6838\u5B9E\uFF0C\u4E0D\u4EA4\u6362\u8054\u7CFB\u65B9\u5F0F" };
  const S = "native-contact-index-v1-" + t.accountKey + ".json";
  let s, x = null;
  try {
    x = await n.file("communication-cache", { operation: "read", name: S }), s = JSON.parse(x);
    const { sha256: e, ...r } = s;
    if (e !== h(r) || s.accountKey !== t.accountKey || s.kind !== "boss-native-contact-index" || !Array.isArray(s.actions)) throw Error("\u539F\u751F\u4EA4\u6362\u8D26\u672C\u4E0D\u7B26");
  } catch (e) {
    if (!String(e.message || e).includes("ENOENT")) throw e;
    s = { version: 1, kind: "boss-native-contact-index", accountKey: t.accountKey, revision: 0, actions: [] };
  }
  const m = async () => {
    let e = null;
    try {
      e = await n.file("communication-cache", { operation: "read", name: S });
    } catch (c) {
      if (!String(c.message || c).includes("ENOENT")) throw c;
    }
    if (e !== x) throw Error("\u539F\u751F\u4EA4\u6362\u8D26\u672C\u5E76\u53D1\u53D8\u5316");
    s.revision++, delete s.sha256, s.sha256 = h(s);
    const r = JSON.stringify(s);
    if (await n.file("communication-cache", { operation: "write", name: S, content: r }), await n.file("communication-cache", { operation: "read", name: S }) !== r) throw Error("\u4EA4\u6362\u8BB0\u5F55\u672A\u5B8C\u6574\u8BFB\u56DE");
    x = r;
  }, O = [], k = await o("count", "li.message-item");
  if (!Number.isSafeInteger(k) || k > 500) throw Error("\u6D88\u606F\u6570\u91CF\u65E0\u6CD5\u6838\u5BF9");
  for (let e = 1; e <= k; e++) {
    const r = "li.message-item:nth-of-type(" + e + ")", c = String(await o("attribute", r, "class") || ""), a = String(await o("read", r)).trim();
    if (!c.split(/\s/u).includes("item-friend") || !(u === "wechat" ? /交换微信/u : /交换(?:手机号|手机号码|电话)/u).test(a) || !/(?:希望|想|请求|是否同意)/u.test(a)) continue;
    const i = await o("attribute", r, "data-mid");
    if (typeof i != "string" || !/^\d+$/u.test(i)) throw Error("\u539F\u751F\u8BF7\u6C42\u7F16\u53F7\u7F3A\u5931");
    const d = 'li.message-item[data-mid="' + i + '"]', y = await o("count", d + " .card-btn");
    let f = null;
    for (let v = 1; v <= y; v++) {
      const E = d + " .card-btn:nth-child(" + v + ")";
      if (await o("count", E) === 1 && String(await o("read", E)).trim() === "\u540C\u610F") {
        if (f) throw Error("\u4EA4\u6362\u540C\u610F\u63A7\u4EF6\u4E0D\u552F\u4E00");
        f = E;
      }
    }
    f ? O.push({ mid: i, root: d, text: a, agree: f }) : /已同意|已交换|已拒绝|已取消|已过期/u.test(a) || (l.actions.push({ requestMid: i, status: "todo", reason: "\u539F\u751F\u8BF7\u6C42\u63A7\u4EF6\u5C1A\u672A\u6838\u5B9E" }), await n.attention({ key: h(["contact-control-review", t.accountKey, i, u]), title: "\u8054\u7CFB\u65B9\u5F0F\u8BF7\u6C42\u5F85\u6838\u5BF9", detail: { contact: t.recipientLabel, jobSource: t.jobSource, contactType: u, requestMid: i } }));
  }
  for (const e of O) {
    const r = h(["boss-native-contact-v1", t.accountKey, t.rows[0].mid, e.mid, u]), c = s.actions.find((i) => i.key === r);
    if (c) {
      l.actions.push({ requestMid: e.mid, status: "existing-no-replay", priorStatus: c.status });
      continue;
    }
    if (await g(), String(await o("read", e.root)).trim() !== e.text || String(await o("read", e.agree)).trim() !== "\u540C\u610F") throw Error("\u4EA4\u6362\u8BF7\u6C42\u5DF2\u53D8\u5316");
    const a = { key: r, contactType: u, requestMid: e.mid, firstMessageId: t.rows[0].mid, memberKey: t.member.key, recipientLabel: t.recipientLabel, jobSource: t.jobSource, contextId: t.contextId, status: "reserved", createdAt: (/* @__PURE__ */ new Date()).toISOString() };
    s.actions.push(a), await m();
    const b = await n.effect.prepare({ action: u === "wechat" ? "exchange-wechat" : "exchange-phone", key: r, description: "\u539F\u751F\u540C\u610F\u5F53\u524D\u56FA\u5B9A\u4F1A\u8BDD\u7684" + (u === "wechat" ? "\u5FAE\u4FE1" : "\u624B\u673A\u53F7") + "\u4EA4\u6362\u8BF7\u6C42" });
    if (a.effectId = b.id, await m(), !b.execute) {
      a.status = "unknown", await m(), l.actions.push({ requestMid: e.mid, status: "existing-effect-no-replay" });
      continue;
    }
    try {
      if (await g(), String(await o("read", e.root)).trim() !== e.text || String(await o("read", e.agree)).trim() !== "\u540C\u610F") throw Error("\u70B9\u51FB\u524D\u4EA4\u6362\u8BF7\u6C42\u53D8\u5316");
      await o("click", e.agree);
      let i = null;
      for (let d = 0; d < 20; d++) {
        await g();
        const y = String(await o("read", e.root)).trim();
        if (y !== e.text && /已同意|已交换|交换成功/u.test(y)) {
          i = { requestMid: e.mid, text: y, observedAt: (/* @__PURE__ */ new Date()).toISOString() };
          break;
        }
        await new Promise((f) => setTimeout(f, 250));
      }
      if (!i) throw Error("\u672A\u53D6\u5F97\u539F\u751F\u4EA4\u6362\u660E\u786E\u56DE\u6267");
      if (a.status = "confirmed", a.agreementConfirmed = true, a.receipt = i, await m(), await n.effect.resolve({ id: b.id, state: "confirmed", evidence: i }), l.actions.push({ requestMid: e.mid, status: "confirmed", receipt: i }), u === "wechat") {
        const d = /(?:微信号|微信账号)\s*[:：]\s*([A-Za-z][A-Za-z0-9_-]{5,19}|\d{6,20})(?![A-Za-z0-9_-])/u.exec(i.text);
        a.contactValueObserved = !!d, await m(), await n.attention({ key: h(["boss-wechat-contact", t.accountKey, t.rows[0].mid, e.mid]), title: d ? "\u5DF2\u53D6\u5F97\u8054\u7CFB\u4EBA\u5FAE\u4FE1\u53F7" : "\u5FAE\u4FE1\u4EA4\u6362\u5DF2\u540C\u610F\uFF0C\u53F7\u7801\u5F85\u6838\u5BF9", detail: { contact: t.recipientLabel, jobSource: t.jobSource, requestMid: e.mid, ...d ? { wechat: d[1] } : {}, source: "BOSS\u539F\u751F\u4EA4\u6362\u56DE\u6267", agreementConfirmed: true, contactValueObserved: !!d } });
      }
    } catch (i) {
      throw a.status === "confirmed" || (a.status = "unknown", a.reason = String(i.message || i), await m(), await n.effect.resolve({ id: b.id, state: "unknown", evidence: { requestMid: e.mid, reason: a.reason } }), await n.attention({ key: h(["contact-unknown", r]), title: "\u539F\u751F\u4EA4\u6362\u7ED3\u679C\u5F85\u6838\u5BF9\uFF0C\u8BF7\u52FF\u91CD\u590D\u64CD\u4F5C", detail: { contact: t.recipientLabel, jobSource: t.jobSource, requestMid: e.mid, contactType: u, reason: a.reason } })), i;
    }
  }
  return l.status = l.actions.length ? "processed" : "no-pending-request", await N("native-" + u + "-result.json", JSON.stringify(l, null, 2)), l;
}
export {
  T as default
};
