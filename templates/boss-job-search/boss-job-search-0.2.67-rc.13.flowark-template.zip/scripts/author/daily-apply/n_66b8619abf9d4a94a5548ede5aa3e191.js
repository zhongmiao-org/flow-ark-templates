function k(e) {
  return e.status === "review" && !e.operationKey && !e.modelRequestId && e.sourceReviewVersion !== "fixed-chat-navigation-v3" && /关联职位没有可核对的继续沟通入口|固定成员缺少可核对的定向搜索姓名，未猜测|固定成员缺少唯一可见身份|关联职位返回后的完整消息或对象变化/u.test(String(e.reason || ""));
}
import { createHash as B } from "node:crypto";
const E = (e) => Array.isArray(e) ? e.map(E) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((u) => [u, E(e[u])])) : e, D = (e) => B("sha256").update(JSON.stringify(E(e))).digest("hex");
async function I(e, u, t, a, c = false) {
  const y = "account-outbound-safety-v1-" + t + ".json";
  let r, i = true, d;
  try {
    d = await e.file("communication-cache", { operation: "read", name: y }), r = JSON.parse(d);
  } catch (s) {
    if (!String(s.message || s).includes("ENOENT")) throw s;
    if (!c) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
    i = false, r = { version: 1, kind: "boss-account-outbound-safety", accountKey: t, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (i) {
    const { sha256: s, ...n } = r;
    if (s !== D(n)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
  }
  if (r.version !== 1 || r.kind !== "boss-account-outbound-safety" || r.accountKey !== t || !Number.isSafeInteger(r.revision) || r.revision < 0 || !Array.isArray(r.records) || r.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
  const l = /* @__PURE__ */ new Set();
  for (const s of r.records) {
    if (!["first-contact", "reply"].includes(s.type) || !/^[a-f0-9]{64}$/.test(s.businessKey) || !Array.isArray(s.sightings) || !s.sightings.length || s.sightings.length > 100 || l.has(s.type + ":" + s.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
    l.add(s.type + ":" + s.businessKey);
    for (const n of s.sightings) if (typeof n.contextId != "string" || !n.contextId || !/^[a-f0-9]{64}$/.test(n.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(n.status) || !/^\d{4}-\d{2}-\d{2}$/.test(n.day) || typeof n.timeZone != "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
  }
  let h = !i;
  return { data: r, name: y, merge: (s) => {
    if (!Array.isArray(s?.applicationIntents) || !Array.isArray(s?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
    for (const [n, F] of [["first-contact", s.applicationIntents], ["reply", s.replyIntents]]) for (const o of F) {
      if ((n === "first-contact" ? o.accountSourceSha256 : o.accountKey) !== t) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
      if (!/^[a-f0-9]{64}$/.test(o.key) || !o.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(o.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
      const w = n === "first-contact" ? D(["boss-job-safety-v1", t, o.jobId]) : B("sha256").update(["boss-text-reply-v1", t, o.incomingMessageId].join(":")).digest("hex");
      let m = r.records.find((b) => b.type === n && b.businessKey === w);
      if (m || (m = { type: n, businessKey: w, jobId: o.jobId, ...n === "reply" ? { conversationKey: o.conversationKey, incomingMessageId: o.incomingMessageId } : {}, sightings: [] }, r.records.push(m), h = true), m.jobId !== o.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
      const S = { contextId: a, intentKey: o.key, status: o.status, day: o.day, timeZone: o.timeZone, contentSha256: o.contentSha256 || null, sourceSha256: o.sourceSha256 || null };
      if (m.sightings.some((b) => JSON.stringify(E(b)) === JSON.stringify(E(S))) || (m.sightings.push(S), h = true), m.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
    }
    if (r.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
  }, save: async () => {
    if (u.throwIfAborted(), h) {
      if (i && await e.file("communication-cache", { operation: "read", name: y }) !== d) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
      r.records.sort((o, w) => (o.type + ":" + o.businessKey).localeCompare(w.type + ":" + w.businessKey));
      for (const o of r.records) o.sightings.sort((w, m) => JSON.stringify(E(w)).localeCompare(JSON.stringify(E(m))));
      r.revision++, r.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete r.sha256, r.sha256 = D(r), await e.file("communication-cache", { operation: "write", name: y, content: JSON.stringify(r) }), h = false, d = JSON.stringify(r), i = true;
    }
    const s = JSON.parse(await e.file("communication-cache", { operation: "read", name: y })), { sha256: n, ...F } = s;
    if (n !== D(F) || n !== r.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
    return { revision: r.revision, sha256: r.sha256, records: r.records.length };
  }, blocked: (s, n) => r.records.some((F) => F.type === s && F.businessKey === n) };
}
const C = (e, u) => async (t, a, c) => (u.throwIfAborted(), e.browser("browser", { operation: t, ...a ? { selector: a } : {}, ...c === void 0 ? {} : { value: c }, timeoutMs: 3e3 })), v = (e) => {
  const { sha256: u, ...t } = e;
  return u === D(t);
};
async function x(e, u, t, a) {
  const c = t.progressName, y = await e.file("communication-cache", { operation: "read", name: c }), r = JSON.parse(y);
  if (!v(r) || r.accountKey !== t.accountKey || r.fixedUnreadSetSha256 !== t.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
  if (!a) return r;
  const i = a(structuredClone(r));
  if (i.revision++, i.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete i.sha256, i.sha256 = D(i), await e.file("communication-cache", { operation: "read", name: c }) !== y) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  u.throwIfAborted(), await e.file("communication-cache", { operation: "write", name: c, content: JSON.stringify(i) });
  const d = JSON.parse(await e.file("communication-cache", { operation: "read", name: c }));
  if (!v(d) || d.sha256 !== i.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
  return d;
}
async function A(e) {
  const u = await e("count", "li.message-item");
  if (!Number.isSafeInteger(u) || u < 1 || u > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
  const t = [];
  for (let a = 1; a <= u; a++) {
    const c = "li.message-item:nth-child(" + a + " of li.message-item)", y = await e("attribute", c, "data-mid"), r = await e("attribute", c, "class");
    if (!/^\d{6,40}$/.test(y || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
    const i = await e("count", c + " .text-content");
    if (i > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
    const d = i === 1 ? String(await e("read", c + " .text-content")).trim() : null, l = d === null ? String(await e("read", c)).trim() : null;
    if ((d || l || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
    const h = !!d && /^您正在与Boss.+沟通$/u.test(d), g = !h && d !== null && r.split(/\s+/u).includes("item-myself") ? "outgoing" : !h && d !== null && r.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
    t.push({ mid: y, direction: g, text: d, context: l });
  }
  if (new Set(t.map((a) => a.mid)).size !== t.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
  return t;
}
async function p(e, u) {
  const t = new URL(await e("url"));
  if (t.origin !== "https://www.zhipin.com" || t.pathname !== "/web/geek/chat" || await e("count", ".chat-conversation .user-info") !== 1) return false;
  const a = String(await e("read", ".chat-conversation .user-info")).trim(), c = (h) => h.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, ""), y = c(u.member.identityLine), r = c(a), i = await e("count", ".friend-content.selected");
  if (i > 1) return false;
  const d = i === 1 ? c(String(await e("read", ".friend-content.selected"))) : null;
  if (r === y) return d === null || d.includes(y);
  const l = /^(.{1,20}?(?:先生|女士))/u.exec(y)?.[1];
  return !!l && y.endsWith("\u730E\u5934\u987E\u95EE") && r === l + "\u730E\u5934\u987E\u95EE" && (d !== null ? d.includes(y) : u.member.searchIdentityProof?.identityLine === u.member.identityLine && c(u.member.searchIdentityProof.targetText).includes(y));
}
async function M(e, u, t) {
  const a = C(e, u);
  return await p(a, t) ? String(await a("read", t.accountSelector)).trim() === t.accountLabel && String(await a("read", t.recipientSelector)).trim() === t.recipientLabel && String(await a("read", t.jobSelector)).trim() === t.chatJobTitle && JSON.stringify(await A(a)) === JSON.stringify(t.rows) : false;
}
var j = async ({ input: e, signal: u, template: t, artifact: a, logger: c }) => {
  if (e?.kind !== "chat-reply-dispatch") throw Error("Missing single-dispatch stage");
  const y = (g) => B("sha256").update(g).digest("hex"), r = (g) => String(g).replace(/\s+/g, ""), i = (g, f, s) => (u.throwIfAborted(), t.browser("browser", { operation: g, ...f ? { selector: f } : {}, ...s !== void 0 ? { value: s } : {}, timeoutMs: 3e3 })), d = () => A(i);
  let l = null;
  if (e.dispatched) try {
    const g = Date.now() + 1e4;
    for (; Date.now() < g; ) {
      if (new URL(await i("url")).origin !== "https://www.zhipin.com" || new URL(await i("url")).pathname !== "/web/geek/chat" || String(await i("read", e.accountSelector)).trim() !== e.accountLabel || String(await i("read", e.jobSelector)).trim() !== e.chatJobTitle || !await p(i, e) || String(await i("read", e.recipientSelector)).trim() !== e.recipientLabel) throw Error("Conversation changed after dispatch");
      const o = await d();
      if (JSON.stringify(o.slice(0, e.rows.length)) !== JSON.stringify(e.rows)) throw Error("Original conversation history changed after dispatch");
      const w = o.slice(e.rows.length).filter((m) => m.direction === "outgoing");
      if (w.length > 1) throw Error("More than one new outbound message; no attribution");
      if (w.length === 1) {
        const m = w[0];
        if (r(m.text) !== r(e.reply)) throw Error("New outbound content differs from fixed AI reply");
        const S = 'li.message-item[data-mid="' + m.mid + '"] > div > div > i';
        if (await i("count", S) === 1) {
          const b = String(await i("read", S)).trim();
          if (["\u9001\u8FBE", "\u5DF2\u8BFB"].includes(b)) {
            l = { version: 1, kind: "existing-conversation-ai-reply-delivery", incomingMessageId: e.incomingMessageId, outgoingMessageId: m.mid, jobId: e.jobId, jobSource: e.jobSource, conversationKey: e.conversationKey, accountKey: e.accountKey, operationId: e.effect.id, operationKey: e.key, runId: e.effect.runId, sourceSha256: e.sourceSha256, approvedText: e.reply, contentSha256: e.contentSha256, observedText: m.text, observedSha256: y(m.text), receipt: b, observedAt: (/* @__PURE__ */ new Date()).toISOString(), model: e.model, profileRef: e.profile.ref, configurationRevision: e.configurationRevision, rows: o };
            break;
          }
        }
      }
      await new Promise((m) => setTimeout(m, 200));
    }
    if (!l) throw Error("Website delivery receipt did not appear within the bounded observation");
    await a("reply-delivery-proof.json", JSON.stringify(l, null, 2)), await t.effect.resolve({ id: e.effect.id, state: "confirmed", evidence: l });
    const f = await t.state.get();
    if (f.replyIntents.filter((o) => o.key === e.key && o.status === "reserved" && o.contentSha256 === e.contentSha256).length !== 1) throw Error("Reply reservation changed before receipt persistence");
    await t.state.set({ ...f, replyIntents: f.replyIntents.map((o) => o.key === e.key ? { ...o, status: "confirmed" } : o) });
    const s = await t.state.get();
    if (s.replyIntents.filter((o) => o.key === e.key && o.status === "confirmed").length !== 1) throw Error("Reply confirmation could not be read back");
    const n = await I(t, u, e.accountKey, e.contextId);
    n.merge(s);
    const F = await n.save();
    if (!n.data.records.some((o) => o.type === "reply" && o.businessKey === e.key && o.sightings.some((w) => w.contextId === e.contextId && w.intentKey === e.key && w.status === "confirmed"))) throw Error("\u9001\u8FBE\u5DF2\u6838\u5BF9\uFF0C\u4F46\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u786E\u8BA4\u672A\u8BFB\u56DE\uFF1B\u4FDD\u7559\u539F\u610F\u56FE\uFF0C\u4E0D\u91CD\u53D1");
    await a("reply-safety-confirmation.json", JSON.stringify({ operationKey: e.key, incomingMessageId: e.incomingMessageId, ...F }, null, 2)), c.info({ status: "reply-confirmed", incomingMessageId: e.incomingMessageId, outgoingMessageId: l.outgoingMessageId, receipt: l.receipt });
  } catch (g) {
    if (!l) {
      await t.effect.resolve({ id: e.effect.id, state: "unknown", evidence: { reason: String(g.message || g), incomingMessageId: e.incomingMessageId, jobSource: e.jobSource, doNotReplay: true } });
      const f = await t.state.get();
      await t.state.set({ ...f, replyIntents: f.replyIntents.map((F) => F.key === e.key ? { ...F, status: "unknown" } : F) });
      const s = await t.state.get(), n = await I(t, u, e.accountKey, e.contextId);
      n.merge(s), await n.save();
    }
    throw await t.attention({ key: "reply-unresolved:" + e.key, title: "\u672C\u6761\u56DE\u590D\u9700\u8981\u6838\u5BF9\u9001\u8FBE\uFF0C\u8BF7\u52FF\u91CD\u53D1", detail: { jobTitle: e.jobTitle, jobSource: e.jobSource, incomingMessageId: e.incomingMessageId, reason: String(g.message || g), doNotReplay: true } }), g;
  }
  const h = { kind: "chat-reply-result", accountKey: e.accountKey, status: l ? "confirmed" : e.decision === "skip" ? "skipped-no-work-question" : e.status || "skipped", jobId: e.jobId || null, jobTitle: e.jobTitle || null, jobSource: e.jobSource || null, reason: l ? "AI reply has a real website delivery receipt" : e.reason, incomingMessageId: e.incomingMessageId || null, outgoingMessageId: l?.outgoingMessageId || null, receipt: l?.receipt || null, newGreeting: false, nativeActions: e.nativeActions || [], attachmentSent: (e.nativeActions || []).some((g) => g.type === "resume" && g.status === "confirmed") };
  if (e.member) {
    const g = await x(t, u, e, (f) => {
      const s = f.completed.find((n) => n.memberKey === e.member.key);
      if (s) {
        if (s.status !== "review" || s.replyPolicyVersion === e.replyPolicyVersion && !k(s)) return f;
        f.reviewHistory = [...f.reviewHistory || [], s], f.completed = f.completed.filter((n) => n.memberKey !== e.member.key);
      }
      if (f.active && f.active.memberKey !== e.member.key) throw Error("\u9001\u8FBE\u6838\u5BF9\u540E\u7684\u6D3B\u8DC3\u4F1A\u8BDD\u5DF2\u53D8\u5316");
      return f.completed.push({ sourceReviewVersion: e.sourceReviewVersion || null, nativeActions: e.nativeActions || [], memberKey: e.member.key, identityLine: e.member.identityLine, replyPolicyVersion: e.replyPolicyVersion || null, status: l ? "confirmed" : e.decision === "review" ? "review" : e.decision === "skip" ? "skipped-no-work-question" : e.status || "skipped", reason: h.reason, incomingMessageId: e.incomingMessageId || null, outgoingMessageId: l?.outgoingMessageId || null, receipt: l?.receipt || null, operationKey: e.key || null, modelRequestId: e.model?.requestId || null, checkedAt: (/* @__PURE__ */ new Date()).toISOString() }), f.active = null, f;
    });
    h.fixedUnreadSetSha256 = e.fixedUnreadSetSha256, h.memberKey = e.member.key, h.completed = g.completed.length, h.remaining = e.memberCount - g.completed.length, h.progressSha256 = g.sha256;
  }
  return await a("fixed-unread-member-result.json", JSON.stringify(h, null, 2)), h;
};
export {
  j as default
};
