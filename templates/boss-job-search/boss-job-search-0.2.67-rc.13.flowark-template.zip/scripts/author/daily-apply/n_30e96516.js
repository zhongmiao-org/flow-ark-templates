function q(e) {
  return e.status === "review" && !e.operationKey && !e.modelRequestId && e.sourceReviewVersion !== "fixed-chat-navigation-v3" && /关联职位没有可核对的继续沟通入口|固定成员缺少可核对的定向搜索姓名，未猜测|固定成员缺少唯一可见身份|关联职位返回后的完整消息或对象变化/u.test(String(e.reason || ""));
}
async function T(e, i) {
  const n = ".user-list-content > :first-child", l = (a) => a.replace(/[\s\uE000-\uF8FF]/gu, ""), u = ".list-warp.v2 input";
  await e("count", u) === 1 && String(await e("inputValue", u, null)) !== "" && await e("fill", u, "");
  const t = ".list-warp.v2 ul:has(> .selected)", r = t + " > :first-child";
  await e("count", r) === 1 && String(await e("read", r)).trim() === "\u5168\u90E8" && String(await e("read", t + " .selected")).trim() !== "\u5168\u90E8" && await e("click", r);
  for (let a = 0; a < 30 && await e("count", n) !== 1; a++) await new Promise((p) => setTimeout(p, 150));
  if (await e("count", n) !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u6765\u6E90\u4E0D\u552F\u4E00");
  const c = [{ selector: n, depth: 0 }], o = [];
  let s = 0;
  for (; c.length; ) {
    const a = c.shift();
    if (++s > 400) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
    const p = await e("count", a.selector + ".friend-content") === 1, h = p ? 1 : await e("count", a.selector + " .friend-content");
    if (h === 1) {
      const F = p ? a.selector : a.selector + " .friend-content", w = String(await e("read", F)).trim();
      l(w).includes(l(i.member.identityLine)) && o.push({ sel: a.selector, label: F, text: w });
      continue;
    }
    if (h > 1 && a.depth < 4) {
      const F = await e("count", a.selector + " > *");
      if (!Number.isSafeInteger(F) || F > 200) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
      for (let w = 1; w <= F; w++) c.push({ selector: a.selector + " > :nth-child(" + w + ")", depth: a.depth + 1 });
    }
  }
  if (o.length !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u7F3A\u5C11\u552F\u4E00\u53EF\u89C1\u8EAB\u4EFD\uFF0C\u672A\u731C\u6D4B\u59D3\u540D");
  const f = o[0];
  if (String(await e("read", f.label)).trim() !== f.text) throw Error("\u56FA\u5B9A\u6210\u5458\u53EF\u89C1\u8EAB\u4EFD\u53D8\u5316");
  await e("click", f.label);
  for (let a = 0; a < 30; a++) {
    if (await O(e, i) && await e("count", "li.message-item") > 0) return;
    await new Promise((p) => setTimeout(p, 150));
  }
  throw Error("\u56FA\u5B9A\u6210\u5458\u53EF\u89C1\u8EAB\u4EFD\u672A\u5B8C\u6574\u8BFB\u56DE");
}
async function W(e, i, n) {
  if (typeof n != "string" || !n.trim()) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u539F\u59D3\u540D\u6765\u6E90\u7F3A\u5931");
  await e("navigate", void 0, "https://www.zhipin.com/web/geek/chat"), await T(e, i);
}
function P(e, i) {
  const n = (o) => o.normalize("NFKC").replace(/\s+/gu, " ").trim().toLocaleLowerCase("en-US");
  if (typeof e != "string" || !e.trim() || e.length > 1e3 || /(?:\.{3}|…|⋯)/u.test(e)) throw Error("\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u7F3A\u5931\u6216\u622A\u65AD\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u8BB0\u5F55");
  const l = i?.titleKeywords, u = i?.excludedRoles;
  for (const [o, s, f] of [["titleKeywords", l, 1], ["excludedRoles", u, 0]]) if (!Array.isArray(s) || s.length < f || s.length > 20 || s.some((a) => typeof a != "string" || !n(a) || a.length > 100) || new Set(s.map(n)).size !== s.length) throw Error("\u5C97\u4F4D\u8303\u56F4\u914D\u7F6E\u65E0\u6548\uFF1A" + o + "\uFF1B\u672A\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE");
  const t = n(e), r = u.filter((o) => t.includes(n(o))), c = l.filter((o) => t.includes(n(o)));
  return { version: 1, kind: "literal-full-job-title-scope", fullTitle: e, matched: c, excluded: r, allowed: r.length === 0 && c.length > 0, source: "actual-complete-job-title", jdUsed: false, searchKeywordUsedAsEvidence: false };
}
import { createHash as I } from "node:crypto";
const oe = /* @__PURE__ */ (() => {
  var e = async ({ input: i, signal: n }) => {
    n.throwIfAborted();
    const l = i, u = l?.value;
    if (!l || l.version !== 1 || l.operation !== "read" || l.binding !== "account-source-result" || l.schemaValidation !== "passed" || l.dataChanged !== false || l.ref?.version !== 1 || l.ref.policy !== "credential-redacted-v1" || l.ref.source?.entryId !== "account-source") throw new Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u5DF2\u9009\u62E9\u4E14\u5B8C\u6574\u53EF\u590D\u7528\u7684\u8D26\u53F7\u6765\u6E90\uFF0C\u8BF7\u5230\u8D44\u6E90\u9875\u91CD\u65B0\u6838\u5BF9\u5E76\u4FDD\u5B58");
    if (!u || u.version !== 1 || u.kind !== "boss-account-source" || u.status !== "account-source-confirmed" || u.accountVerified !== true || u.platformUniqueIdVerified !== false || u.eligibleForActions !== false || u.role !== "jobseeker") throw new Error("\u6240\u9009\u8BB0\u5F55\u5C1A\u672A\u5B8C\u6210\u672C\u4EBA\u786E\u8BA4\u548C\u6765\u6E90\u590D\u9A8C\uFF1B\u8BF7\u5728\u5F53\u524D\u5B9E\u4F8B\u5B8C\u6210\u8D26\u53F7\u6838\u5BF9\uFF0C\u518D\u9009\u62E9\u8BE5\u6B21\u5DF2\u4FDD\u5B58\u7ED3\u679C");
    const t = ["version", "kind", "status", "accountAlias", "accountName", "phoneMask", "jobseekerResumeHref", "role", "sourceUrl", "accountVerified", "platformUniqueIdVerified", "eligibleForActions", "confirmedAt", "checkedAt", "reason"];
    if (Object.keys(u).length !== t.length || t.some((f) => !Object.prototype.hasOwnProperty.call(u, f))) throw new Error("\u6240\u9009\u8D26\u53F7\u7ED3\u679C\u7ED3\u6784\u4E0D\u7B26\uFF0C\u505C\u6B62\u91C7\u7528");
    for (const f of ["accountAlias", "accountName", "phoneMask"]) if (typeof u[f] != "string" || !u[f].trim() || u[f] !== u[f].trim() || u[f].length > 100 || /[\r\n]/.test(u[f])) throw new Error("\u8D26\u53F7\u5FC5\u8981\u5B57\u6BB5\u7F3A\u5931\u6216\u683C\u5F0F\u65E0\u6548\uFF0C\u505C\u6B62\u91C7\u7528");
    if (!/^[+\d ()-]*\*{2,}[\d ()-]+$/.test(u.phoneMask) || /登录|注册|验证码/.test(u.accountName)) throw new Error("\u8D26\u53F7\u6765\u6E90\u7F3A\u5C11\u6709\u6548\u7684\u53EF\u89C1\u59D3\u540D\u6216\u624B\u673A\u53F7\u63A9\u7801");
    if (typeof u.reason != "string" || !u.reason.trim()) throw new Error("\u8D26\u53F7\u7ED3\u679C\u7F3A\u5C11\u660E\u786E\u6838\u5BF9\u8BF4\u660E");
    const r = Date.parse(u.confirmedAt), c = Date.parse(u.checkedAt);
    if (typeof u.confirmedAt != "string" || typeof u.checkedAt != "string" || !Number.isFinite(r) || !Number.isFinite(c) || r <= 0 || c < r || c > Date.now() + 6e4) throw new Error("\u8D26\u53F7\u786E\u8BA4\u6216\u590D\u9A8C\u65F6\u95F4\u65E0\u6CD5\u6838\u5BF9\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4");
    if (typeof u.sourceUrl != "string" || typeof u.jobseekerResumeHref != "string" || !u.sourceUrl.trim() || !u.jobseekerResumeHref.trim() || u.sourceUrl.length > 16384 || u.jobseekerResumeHref.length > 16384) throw new Error("\u8D26\u53F7\u9875\u9762\u6216\u7B80\u5386\u5165\u53E3\u5730\u5740\u65E0\u6548");
    const o = new URL(u.sourceUrl), s = new URL(u.jobseekerResumeHref, u.sourceUrl);
    if (o.origin !== "https://www.zhipin.com" || o.pathname !== "/web/geek/account" || o.searchParams.get("type") !== "accountSet" || o.username || o.password || o.hash || s.origin !== o.origin || s.pathname !== "/web/geek/resume" || s.username || s.password) throw new Error("\u8D26\u53F7\u8BB0\u5F55\u7684\u9875\u9762\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u4E0D\u7B26");
    return n.throwIfAborted(), { version: 1, accountSourceValid: true, currentAccountVerified: false, account: u };
  };
  return e;
})(), G = /* @__PURE__ */ (() => {
  async function e({ input: i, signal: n, template: l }) {
    n.throwIfAborted();
    const u = i?.expected?.account;
    if (i?.expected?.accountSourceValid !== true || u?.kind !== "boss-account-source" || u.status !== "account-source-confirmed" || u.accountVerified !== true) throw Error("\u7F3A\u5C11\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\u6765\u6E90");
    const t = async (F, w, m) => {
      n.throwIfAborted();
      const y = await l.browser("browser", { operation: F, ...w ? { selector: w } : {}, ...m === void 0 ? {} : { value: m }, timeoutMs: 3e3 });
      return n.throwIfAborted(), y;
    }, r = await t("url"), c = new URL(r);
    if (c.origin !== "https://www.zhipin.com" || c.username || c.password || !c.pathname.startsWith("/web/") && !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(c.pathname)) throw Error("\u5F53\u524D\u9875\u9762\u4E0D\u662FBOSS\u6C42\u804C\u9875\u9762\uFF0C\u8BF7\u5148\u767B\u5F55");
    const o = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", s = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)", f = await t("count", o), a = await t("count", s);
    if (f !== 1 || a !== 1) throw Error("\u5F53\u524D\u9875\u9762\u8D26\u53F7\u5165\u53E3\u6570\u91CF\u5F02\u5E38\uFF1A" + JSON.stringify({ nameCount: f, resumeCount: a }));
    const p = await t("read", o), h = await t("attribute", s, "href");
    if (typeof p != "string" || p.normalize("NFKC").trim() !== u.accountName.normalize("NFKC").trim() || typeof h != "string" || new URL(h, r).href !== new URL(u.jobseekerResumeHref, u.sourceUrl).href || await t("url") !== r) throw Error("\u5F53\u524D\u767B\u5F55\u8EAB\u4EFD\u3001\u6C42\u804C\u5165\u53E3\u6216\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
    return { version: 1, status: "current-account-source-matched", accountAlias: u.accountAlias, accountName: u.accountName, phoneMask: u.phoneMask, jobseekerResumeHref: u.jobseekerResumeHref, sourceUrl: u.sourceUrl, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), currentPageUrl: r, currentAccountVerified: true, platformUniqueIdVerified: false, eligibleForActions: false, accountCheckMode: "confirmed-initial-account-and-visible-header", phoneMaskRechecked: false, reason: "\u4F7F\u7528\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\uFF1B\u53EA\u8BFB\u6838\u5BF9\u5F53\u524D\u767B\u5F55\u59D3\u540D\u3001\u6C42\u804C\u5165\u53E3\u53CA\u9875\u9762\u8FDE\u7EED\u6027\uFF0C\u624B\u673A\u53F7\u63A9\u7801\u6CBF\u7528\u786E\u8BA4\u6765\u6E90\uFF0C\u6CA1\u6709\u91CD\u65B0\u8BFB\u53D6\u3002" };
  }
  return e;
})(), R = (e) => Array.isArray(e) ? e.map(R) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((i) => [i, R(e[i])])) : e, Q = (e) => I("sha256").update(JSON.stringify(R(e))).digest("hex"), C = (e) => Array.isArray(e) ? e.map(C) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((i) => [i, C(e[i])])) : e, v = (e) => I("sha256").update(JSON.stringify(C(e))).digest("hex");
async function X(e, i, n, l, u = false) {
  const t = "account-outbound-safety-v1-" + n + ".json";
  let r, c = true, o;
  try {
    o = await e.file("communication-cache", { operation: "read", name: t }), r = JSON.parse(o);
  } catch (h) {
    if (!String(h.message || h).includes("ENOENT")) throw h;
    if (!u) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
    c = false, r = { version: 1, kind: "boss-account-outbound-safety", accountKey: n, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (c) {
    const { sha256: h, ...F } = r;
    if (h !== v(F)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
  }
  if (r.version !== 1 || r.kind !== "boss-account-outbound-safety" || r.accountKey !== n || !Number.isSafeInteger(r.revision) || r.revision < 0 || !Array.isArray(r.records) || r.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
  const s = /* @__PURE__ */ new Set();
  for (const h of r.records) {
    if (!["first-contact", "reply"].includes(h.type) || !/^[a-f0-9]{64}$/.test(h.businessKey) || !Array.isArray(h.sightings) || !h.sightings.length || h.sightings.length > 100 || s.has(h.type + ":" + h.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
    s.add(h.type + ":" + h.businessKey);
    for (const F of h.sightings) if (typeof F.contextId != "string" || !F.contextId || !/^[a-f0-9]{64}$/.test(F.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(F.status) || !/^\d{4}-\d{2}-\d{2}$/.test(F.day) || typeof F.timeZone != "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
  }
  let f = !c;
  return { data: r, name: t, merge: (h) => {
    if (!Array.isArray(h?.applicationIntents) || !Array.isArray(h?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
    for (const [F, w] of [["first-contact", h.applicationIntents], ["reply", h.replyIntents]]) for (const m of w) {
      if ((F === "first-contact" ? m.accountSourceSha256 : m.accountKey) !== n) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
      if (!/^[a-f0-9]{64}$/.test(m.key) || !m.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(m.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
      const y = F === "first-contact" ? v(["boss-job-safety-v1", n, m.jobId]) : I("sha256").update(["boss-text-reply-v1", n, m.incomingMessageId].join(":")).digest("hex");
      let g = r.records.find((A) => A.type === F && A.businessKey === y);
      if (g || (g = { type: F, businessKey: y, jobId: m.jobId, ...F === "reply" ? { conversationKey: m.conversationKey, incomingMessageId: m.incomingMessageId } : {}, sightings: [] }, r.records.push(g), f = true), g.jobId !== m.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
      const B = { contextId: l, intentKey: m.key, status: m.status, day: m.day, timeZone: m.timeZone, contentSha256: m.contentSha256 || null, sourceSha256: m.sourceSha256 || null };
      if (g.sightings.some((A) => JSON.stringify(C(A)) === JSON.stringify(C(B))) || (g.sightings.push(B), f = true), g.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
    }
    if (r.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
  }, save: async () => {
    if (i.throwIfAborted(), f) {
      if (c && await e.file("communication-cache", { operation: "read", name: t }) !== o) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
      r.records.sort((m, y) => (m.type + ":" + m.businessKey).localeCompare(y.type + ":" + y.businessKey));
      for (const m of r.records) m.sightings.sort((y, g) => JSON.stringify(C(y)).localeCompare(JSON.stringify(C(g))));
      r.revision++, r.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete r.sha256, r.sha256 = v(r), await e.file("communication-cache", { operation: "write", name: t, content: JSON.stringify(r) }), f = false, o = JSON.stringify(r), c = true;
    }
    const h = JSON.parse(await e.file("communication-cache", { operation: "read", name: t })), { sha256: F, ...w } = h;
    if (F !== v(w) || F !== r.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
    return { revision: r.revision, sha256: r.sha256, records: r.records.length };
  }, blocked: (h, F) => r.records.some((w) => w.type === h && w.businessKey === F) };
}
const Z = (e, i) => async (n, l, u) => {
  i.throwIfAborted();
  try {
    return await e.browser("browser", { operation: n, ...l ? { selector: l } : {}, ...u === void 0 ? {} : { value: u }, timeoutMs: 3e3 });
  } catch (t) {
    const r = String(t.message || t);
    if (!/^\(-3\) loading /u.test(r)) throw t;
    let c = null;
    if (n === "navigate" && u === "https://www.zhipin.com/web/geek/chat" && (c = new URL(u)), n === "click" && l === ".chat-position-content .right-content > :first-child") {
      const o = /^\(-3\) loading '([^']+)'/u.exec(r);
      if (o) {
        const s = new URL(o[1]);
        s.origin === "https://www.zhipin.com" && /^\/job_detail\/[A-Za-z0-9_~-]+\.html$/u.test(s.pathname) && !s.username && !s.password && (c = s);
      }
    }
    if (!c) throw t;
    for (let o = 0; o < 30; o++) {
      i.throwIfAborted();
      const s = await e.browser("browser", { operation: "url", timeoutMs: 3e3 }), f = new URL(s);
      if (f.origin === c.origin && f.pathname === c.pathname) return { navigationObserved: true, url: s, originalClickRepeated: false };
      await new Promise((a) => setTimeout(a, 150));
    }
    throw t;
  }
}, $ = (e) => {
  const { sha256: i, ...n } = e;
  return i === v(n);
};
async function J(e, i, n, l) {
  const u = n.progressName, t = await e.file("communication-cache", { operation: "read", name: u }), r = JSON.parse(t);
  if (!$(r) || r.accountKey !== n.accountKey || r.fixedUnreadSetSha256 !== n.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
  if (!l) return r;
  const c = l(structuredClone(r));
  if (c.revision++, c.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete c.sha256, c.sha256 = v(c), await e.file("communication-cache", { operation: "read", name: u }) !== t) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  i.throwIfAborted(), await e.file("communication-cache", { operation: "write", name: u, content: JSON.stringify(c) });
  const o = JSON.parse(await e.file("communication-cache", { operation: "read", name: u }));
  if (!$(o) || o.sha256 !== c.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
  return o;
}
async function x(e) {
  const i = await e("count", "li.message-item");
  if (!Number.isSafeInteger(i) || i < 1 || i > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
  const n = [];
  for (let l = 1; l <= i; l++) {
    const u = "li.message-item:nth-child(" + l + " of li.message-item)", t = await e("attribute", u, "data-mid"), r = await e("attribute", u, "class");
    if (!/^\d{6,40}$/.test(t || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
    const c = await e("count", u + " .text-content");
    if (c > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
    const o = c === 1 ? String(await e("read", u + " .text-content")).trim() : null, s = o === null ? String(await e("read", u)).trim() : null;
    if ((o || s || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
    const f = !!o && /^您正在与Boss.+沟通$/u.test(o), a = !f && o !== null && r.split(/\s+/u).includes("item-myself") ? "outgoing" : !f && o !== null && r.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
    n.push({ mid: t, direction: a, text: o, context: s });
  }
  if (new Set(n.map((l) => l.mid)).size !== n.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
  return n;
}
async function O(e, i) {
  const n = new URL(await e("url"));
  if (n.origin !== "https://www.zhipin.com" || n.pathname !== "/web/geek/chat" || await e("count", ".chat-conversation .user-info") !== 1) return false;
  const l = String(await e("read", ".chat-conversation .user-info")).trim(), u = (f) => f.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, ""), t = u(i.member.identityLine), r = u(l), c = await e("count", ".friend-content.selected");
  if (c > 1) return false;
  const o = c === 1 ? u(String(await e("read", ".friend-content.selected"))) : null;
  if (r === t) return o === null || o.includes(t);
  const s = /^(.{1,20}?(?:先生|女士))/u.exec(t)?.[1];
  return !!s && t.endsWith("\u730E\u5934\u987E\u95EE") && r === s + "\u730E\u5934\u987E\u95EE" && (o !== null ? o.includes(t) : i.member.searchIdentityProof?.identityLine === i.member.identityLine && u(i.member.searchIdentityProof.targetText).includes(t));
}
async function Y(e, i, n) {
  const l = Z(e, i);
  return await O(l, n) ? String(await l("read", n.accountSelector)).trim() === n.accountLabel && String(await l("read", n.recipientSelector)).trim() === n.recipientLabel && String(await l("read", n.jobSelector)).trim() === n.chatJobTitle && JSON.stringify(await x(l)) === JSON.stringify(n.rows) : false;
}
var ee = async ({ input: e, template: i, signal: n, artifact: l, onAccountVerified: u }) => {
  const t = e?.cohort, r = e?.profile;
  if (t?.kind !== "unread-closing-cohort" || t.closingPhase !== true || r?.version !== 1 || !r.ref?.versionId || !r.markdown?.trim()) throw Error("\u7F3A\u5C11\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u6216\u672C\u6B21\u786E\u8BA4Skill");
  const c = { ...t, sourceReviewVersion: "fixed-chat-navigation-v3", kind: "chat-reply-source", fixedUnreadMember: true, profile: r, returnToJobs: false };
  if (!t.ready) return { ...c, ready: false, status: "fixed-unread-complete", reason: "\u56FA\u5B9A\u96C6\u5408\u5DF2\u5904\u7406\u5B8C\u6BD5\uFF0C\u4E0D\u91CD\u65B0\u626B\u63CF" };
  await G({ input: { expected: t.accountSource }, template: i, signal: n }), u?.();
  const o = String(t.member?.text || "").split(/\r?\n/u).slice(3).join(`
`).trim();
  if (/不太?合适|不[是太]*特别契合|不[完全]*符合|不[完全]*匹配|后续有机会再合作|未能通过|暂不考虑/u.test(o) && !/[?？]|(?:是否|有没有|会不会|能否|请问|什么时候|多少|怎么|哪些)/u.test(o)) return { ...c, member: t.member, ready: false, jobId: null, jobSource: null, status: "rejected-no-reply", reason: "\u56FA\u5B9A\u672A\u8BFB\u5FEB\u7167\u4E2D\u5BF9\u65B9\u5DF2\u660E\u786E\u62D2\u7EDD\uFF0C\u4E0D\u56DE\u590D\u3001\u4E0D\u6267\u884C\u539F\u751F\u8BF7\u6C42", previewSource: true };
  const s = Z(i, n), f = t.member;
  let a = await J(i, n, t);
  if (a.completed.some((d) => d.memberKey === f.key && !q(d) && !(d.status === "review" && d.replyPolicyVersion !== "work-questions-partial-known-v2"))) return { ...c, ready: false, status: "already-completed", reason: "\u8BE5\u56FA\u5B9A\u6210\u5458\u5DF2\u5904\u7406\uFF0C\u672A\u91CD\u590D\u6253\u5F00" };
  if (a.active && a.active.memberKey !== f.key) throw Error("\u6D3B\u8DC3\u4F1A\u8BDD\u4E0E\u56FA\u5B9A\u6210\u5458\u4E0D\u7B26");
  if (!await O(s, t)) {
    const d = new URL(await s("url"));
    (d.origin !== "https://www.zhipin.com" || d.pathname !== "/web/geek/chat") && await s("navigate", void 0, "https://www.zhipin.com/web/geek/chat"), await T(s, t);
  }
  const p = ".chat-conversation .user-info", h = String(await s("read", p)).trim(), F = ".chat-position-content", w = String(await s("read", F)).trim(), m = w.split(/\r?\n/u)[0], y = await x(s);
  if (!m || !h) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u7684\u62DB\u8058\u8005\u6216\u804C\u4F4D\u4E0A\u4E0B\u6587\u7F3A\u5931");
  const g = P(m, t.configuration);
  if (!g.allowed) return { ...c, member: f, ready: false, status: "job-title-outside-configured-scope", jobTitle: m, chatJobTitle: w, recipientLabel: h, jobSelector: F, recipientSelector: p, rows: y, jobId: null, jobSource: null, titleScope: g, reason: "\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u672A\u547D\u4E2D\u5141\u8BB8\u8BCD\u6216\u547D\u4E2D\u6392\u9664\u9879\uFF1B\u4E0D\u6253\u5F00\u5173\u8054\u5C97\u4F4D\u3001\u4E0D\u8C03\u7528\u6A21\u578B\u3001\u4E0D\u6267\u884C\u539F\u751F\u8BF7\u6C42" };
  if (a.active?.firstMessageId && a.active.firstMessageId !== y[0].mid) throw Error("\u91CD\u5F00\u540E\u7684\u4F1A\u8BDD\u539F\u59CB\u6D88\u606F\u94FE\u5DF2\u53D8\u5316\uFF0C\u672A\u8986\u76D6\u65E7\u8FDB\u5EA6");
  a = await J(i, n, t, (d) => {
    if (d.active && d.active.memberKey !== f.key) throw Error("\u6D3B\u8DC3\u6210\u5458\u53D8\u5316");
    return d.active = { ...d.active, memberKey: f.key, identityLine: f.identityLine, recipientName: h.split(/\r?\n/u)[0], contextId: t.contextId, openedAt: d.active?.openedAt || (/* @__PURE__ */ new Date()).toISOString(), firstMessageId: y[0].mid }, d;
  });
  let B = a.active.jobSource, A = a.active.jobId;
  if (!B) {
    const d = ".chat-position-content .right-content > :first-child";
    if (await s("count", d) !== 1 || String(await s("read", d)).trim() !== "\u67E5\u770B\u804C\u4F4D" || !await O(s, t) || JSON.stringify(await x(s)) !== JSON.stringify(y)) throw Error("\u5173\u8054\u804C\u4F4D\u5165\u53E3\u6216\u4F1A\u8BDD\u5185\u5BB9\u53D8\u5316");
    await s("click", d);
    let E;
    for (let S = 0; S < 30 && (E = new URL(await s("url")), !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(E.pathname)); S++) await new Promise((H) => setTimeout(H, 150));
    if (E.origin !== "https://www.zhipin.com" || !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(E.pathname)) throw Error("\u672A\u8BFB\u4F1A\u8BDD\u7684\u5B9E\u9645\u804C\u4F4D\u94FE\u63A5\u672A\u6838\u5BF9");
    if (await s("count", "h1") !== 1 || String(await s("read", "h1")).normalize("NFKC").trim() !== m.replace(/（猎头职位）$/u, "").normalize("NFKC").trim()) throw Error("\u5173\u8054\u804C\u4F4D\u5B8C\u6574\u6807\u9898\u4E0E\u56FA\u5B9A\u4F1A\u8BDD\u4E0D\u7B26\uFF0C\u672A\u91C7\u7528\u6765\u6E90");
    if (B = E.origin + E.pathname, A = E.pathname.split("/").at(-1).slice(0, -5), a = await J(i, n, t, (S) => {
      if (S.active?.memberKey !== f.key) throw Error("\u6D3B\u8DC3\u6210\u5458\u53D8\u5316");
      return Object.assign(S.active, { jobSource: B, jobId: A }), S;
    }), await W(s, t, a.active.recipientName), JSON.stringify(await x(s)) !== JSON.stringify(y)) throw Error("\u5173\u8054\u804C\u4F4D\u8FD4\u56DE\u540E\u7684\u5B8C\u6574\u6D88\u606F\u6216\u5BF9\u8C61\u53D8\u5316\uFF0C\u672A\u751F\u6210\u56DE\u590D");
  }
  const j = await x(s), U = j.filter((d) => d.direction !== "system" && d.text), D = U.at(-1), _ = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", L = t.accountSource.account.accountName, b = { ...c, member: f, jobId: A, jobSource: B, jobTitle: m, chatJobTitle: w, jobSelector: F, recipientSelector: p, recipientLabel: h, accountSelector: _, accountLabel: L, conversationKey: "boss-job:" + A, rows: j }, V = P(m, t.configuration);
  if (!V.allowed) return { ...b, titleScope: V, ready: false, status: "job-title-outside-configured-scope", reason: "\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u672A\u901A\u8FC7\u5141\u8BB8\u8BCD\u6216\u547D\u4E2D\u6392\u9664\u9879\uFF1B\u4E0D\u8C03\u7528\u6A21\u578B\u3001\u4E0D\u5EFA\u7ACB\u56DE\u590D\u610F\u56FE" };
  if (!D || D.direction !== "incoming") return { ...b, ready: false, status: "already-replied-or-system-only", reason: "\u6CA1\u6709\u5C1A\u672A\u56DE\u590D\u7684\u771F\u4EBA\u6587\u5B57\u6765\u4FE1\uFF1B\u7CFB\u7EDF\u5361\u7247\u4E0D\u89E6\u53D1\u56DE\u590D" };
  if (/不太?合适|不[是太]*特别契合|不[完全]*符合|不[完全]*匹配|后续有机会再合作|未能通过|暂不考虑/u.test(D.text) && !/[?？]|(?:是否|有没有|会不会|能否|请问|什么时候|多少|怎么|哪些)/u.test(D.text)) return { ...b, ready: false, status: "rejected-no-reply", incomingMessageId: D.mid, reason: "\u5BF9\u65B9\u660E\u786E\u8868\u793A\u4E0D\u5408\u9002\uFF0C\u6309\u672C\u4EBA\u6700\u65B0\u8981\u6C42\u4E0D\u56DE\u590D\uFF1B\u4FDD\u7559\u6240\u6709\u539F\u5916\u53D1\u610F\u56FE" };
  const N = I("sha256").update(["boss-text-reply-v1", t.accountKey, D.mid].join(":")).digest("hex"), K = await i.state.get(), k = await X(i, n, t.accountKey, t.contextId);
  if (k.merge(K), await k.save(), K.replyIntents.some((d) => d.accountKey === t.accountKey && d.incomingMessageId === D.mid && ["reserved", "unknown", "failed"].includes(d.status)) || k.data.records.some((d) => d.type === "reply" && d.businessKey === N && d.sightings.some((E) => ["reserved", "unknown", "failed"].includes(E.status)))) {
    const d = "\u539F\u6765\u4FE1\u5DF2\u6709\u9884\u7559\u3001\u672A\u77E5\u6216\u5931\u8D25\u8BB0\u5F55\uFF0C\u4FDD\u7559\u5F85\u529E\u5E76\u7981\u6B62\u91CD\u53D1";
    return await i.attention({ key: "reply-existing-uncertain:" + t.accountKey + ":" + D.mid, title: "\u539F\u56DE\u590D\u7ED3\u679C\u5F85\u6838\u5BF9\uFF0C\u8BF7\u52FF\u91CD\u53D1", detail: { contact: f.identityLine, jobSource: B, incomingMessageId: D.mid, reason: d, externalAction: false } }), { ...b, ready: false, status: "existing-uncertain-reply", decision: "review", replyPolicyVersion: "work-questions-partial-known-v2", incomingMessageId: D.mid, key: N, reason: d };
  }
  if (K.replyIntents.some((d) => d.accountKey === t.accountKey && d.incomingMessageId === D.mid) || k.blocked("reply", N)) return { ...b, ready: false, status: "existing-reply-intent", incomingMessageId: D.mid, reason: "\u8BE5\u539F\u6765\u4FE1\u5DF2\u6709\u5916\u53D1\u610F\u56FE\uFF0C\u9884\u7559\u3001\u672A\u77E5\u53CA\u786E\u8BA4\u5747\u7981\u6B62\u91CD\u653E" };
  if ((K.conversationControls || []).some((d) => d.accountKey === t.accountKey && [b.conversationKey, "boss-chat:" + j[0].mid].includes(d.conversationKey) && d.mode === "paused")) return { ...b, ready: false, status: "manual-control", reason: "\u672C\u4EBA\u5DF2\u63A5\u7BA1\u672C\u4F1A\u8BDD\uFF0C\u81EA\u52A8\u56DE\u590D\u8DF3\u8FC7" };
  const z = new Intl.DateTimeFormat("sv-SE", { timeZone: t.configuration.replyTimeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
  if (new Set(k.data.records.filter((d) => d.type === "reply" && d.sightings.some((E) => E.day === z && E.timeZone === t.configuration.replyTimeZone && E.status !== "failed")).map((d) => d.businessKey)).size >= t.configuration.replyDailyLimit) throw Error("\u5DF2\u4FDD\u5B58\u7684\u672C\u4EBA\u56DE\u590D\u989D\u5EA6\u5DF2\u6EE1\uFF0C\u4FDD\u7559\u672A\u5B8C\u6210\u6536\u5C3E");
  const M = { ...b, ready: true, key: N, incomingMessageId: D.mid, incomingMessage: D.text, pendingMessages: U.slice(U.map((d) => d.direction).lastIndexOf("outgoing") + 1).filter((d) => d.direction === "incoming"), sourceSha256: I("sha256").update(JSON.stringify({ rows: j, jobSource: B, accountLabel: L })).digest("hex"), day: z, timeZone: t.configuration.replyTimeZone };
  if (!await Y(i, n, M)) throw Error("\u5B8C\u6574\u6765\u6E90\u4FDD\u5B58\u524D\u4F1A\u8BDD\u5DF2\u53D8\u5316");
  return await l("fixed-unread-reply-source.json", JSON.stringify(M, null, 2)), M;
};
async function ue(e) {
  let i = false;
  try {
    return await ee({ ...e, onAccountVerified: () => {
      i = true;
    } });
  } catch (n) {
    const l = String(n.message || n), u = e.input?.cohort, t = /关联职位返回后的完整消息或对象变化|完整岗位标题缺失或截断|固定姓名搜索未取得唯一的姓名、公司和角色组合|固定成员缺少可核对的定向搜索姓名，未猜测|未读会话的实际职位链接未核对|关联职位没有可核对的继续沟通入口|固定成员当前列表|固定成员缺少唯一可见身份|固定成员可见身份|固定会话返回|关联职位完整标题与固定会话不符/u.test(l), r = i && !/账号|安全索引|账本|摘要|配置|状态|进度|Skill|预留/u.test(l) && /固定成员|固定会话|关联职位|网页操作超时|元素|目标不可见|点击目标|点击期间|\(-3\) loading/u.test(l);
    if (!(t || r) || u?.kind !== "unread-closing-cohort" || !u.member?.key) throw n;
    return await e.template.attention({ key: "fixed-member-source-review:" + u.accountKey + ":" + u.member.key, title: "\u8BE5\u672A\u8BFB\u4F1A\u8BDD\u6765\u6E90\u5F85\u6838\u5BF9\uFF0C\u672A\u6267\u884C\u5916\u53D1", detail: { contact: u.member.identityLine, fixedUnreadSetSha256: u.fixedUnreadSetSha256, memberKey: u.member.key, reason: l, externalAction: false } }), { ...u, sourceReviewVersion: "fixed-chat-navigation-v3", kind: "chat-reply-source", fixedUnreadMember: true, profile: e.input.profile, ready: false, jobId: null, jobSource: null, status: "member-needs-review", decision: "review", replyPolicyVersion: "work-questions-partial-known-v2", reason: l };
  }
}
async function se(e) {
  const i = e.input;
  if (i?.kind !== "chat-reply-source" || i.fixedUnreadMember !== true) throw Error("\u7F3A\u5C11\u539F\u56FA\u5B9A\u6210\u5458\u4E0A\u4E0B\u6587");
  const n = [];
  if (i.jobId) for (const [u, t, r] of [["native-contact-index-v1-" + i.accountKey + ".json", "boss-native-contact-index", "actions"], ["resume-delivery-index-v1-" + i.accountKey + ".json", "boss-resume-delivery-index", "deliveries"]]) {
    let c;
    try {
      c = await e.template.file("communication-cache", { operation: "read", name: u });
    } catch (a) {
      if (String(a.message || a).includes("ENOENT")) continue;
      throw a;
    }
    const o = JSON.parse(c), { sha256: s, ...f } = o;
    if (s !== Q(f) || o.kind !== t || o.accountKey !== i.accountKey || !Array.isArray(o[r])) throw Error("\u539F\u751F\u52A8\u4F5C\u8D26\u672C\u6765\u6E90\u4E0D\u7B26");
    for (const a of o[r]) a.jobSource === i.jobSource && (a.memberKey === i.member.key || a.firstMessageId === i.rows?.[0]?.mid) && n.push({ type: a.contactType || "resume", requestMid: a.requestMid, status: a.status, key: a.key, receipt: a.receipt || null, agreementConfirmed: a.agreementConfirmed === true, contactValueObserved: a.contactValueObserved === true });
  }
  return { ...i.ready ? await ue({ ...e, input: { cohort: { ...i, kind: "unread-closing-cohort" }, profile: i.profile } }) : i, nativeActions: n };
}
export {
  se as default
};
