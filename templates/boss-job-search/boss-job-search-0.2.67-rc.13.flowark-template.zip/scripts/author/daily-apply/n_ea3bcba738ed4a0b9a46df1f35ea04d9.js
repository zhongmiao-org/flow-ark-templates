async function Q(r, n) {
  const a = (i) => String(i).normalize("NFKC").replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, ""), c = ".list-warp.v2 input", u = ".boss-search-result .search-list";
  if (await r("count", c) !== 1) throw Error("\u5F53\u524D\u8054\u7CFB\u4EBA\u641C\u7D22\u5165\u53E3\u4E0D\u552F\u4E00\uFF0C\u672A\u56FA\u5B9A\u6536\u4EF6\u4EBA");
  const o = a(n.recipientName), F = a(n.recipientLabel), l = a(n.chatJobTitle.split(/\r?\n/u).map((i) => i.trim()).filter(Boolean)[0].replace(/（猎头职位）$/u, "")), t = F.startsWith(o) ? F.slice(o.length) : "";
  if (!o || !t || !l) throw Error("\u7F3A\u5C11\u539F\u59D3\u540D\u3001\u516C\u53F8\u89D2\u8272\u6216\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\uFF0C\u672A\u56FA\u5B9A\u641C\u7D22\u7ED3\u679C");
  await r("fill", c, n.recipientName);
  for (let i = 0; i < 30; i++) {
    const s = await r("count", u), f = [];
    if (!Number.isSafeInteger(s) || s > 50) throw Error("\u8054\u7CFB\u4EBA\u641C\u7D22\u8303\u56F4\u65E0\u6548");
    for (let h = 1; h <= s; h++) {
      const b = u + ":nth-child(" + h + " of .search-list)", y = String(await r("read", b)).trim(), C = a(y), w = C.indexOf("\u804C\u4F4D:");
      if (w < 0 || C.indexOf("\u804C\u4F4D:", w + 3) >= 0) continue;
      const p = C.slice(0, w);
      if (C.slice(w + 3) !== l || !p.startsWith(o) || !p.endsWith(t)) continue;
      const B = p.slice(o.length, p.length - t.length);
      p !== F && (!B || B.length > 200) || f.push({ selector: b, text: y });
    }
    if (f.length > 1) throw Error("\u59D3\u540D\u3001\u516C\u53F8\u89D2\u8272\u4E0E\u5C97\u4F4D\u5B58\u5728\u591A\u4E2A\u7ED3\u679C\uFF0C\u672A\u9009\u62E9");
    if (f.length === 1) {
      const h = f[0];
      if (String(await r("read", h.selector)).trim() !== h.text) throw Error("\u8054\u7CFB\u4EBA\u5B8C\u6574\u641C\u7D22\u884C\u5DF2\u53D8\u5316");
      return h.text;
    }
    await new Promise((h) => setTimeout(h, 150));
  }
  throw Error("\u672A\u53D6\u5F97\u552F\u4E00\u7684\u59D3\u540D\u3001\u516C\u53F8\u89D2\u8272\u53CA\u5B8C\u6574\u5C97\u4F4D\u641C\u7D22\u884C\uFF0C\u672A\u5EFA\u7ACB\u9644\u4EF6\u610F\u56FE");
}
async function X(r, n, a, c, u) {
  n.throwIfAborted();
  try {
    return await r.browser("browser", { operation: a, ...c ? { selector: c } : {}, ...u === void 0 ? {} : { value: u }, timeoutMs: 3e3 });
  } catch (o) {
    if (a !== "navigate" || !["https://www.zhipin.com/web/geek/chat", "https://www.zhipin.com/web/geek/resume"].includes(u) || !/^\(-3\) loading /u.test(String(o?.message || o))) throw o;
    for (let F = 0; F < 40; F++) {
      n.throwIfAborted();
      const l = await r.browser("browser", { operation: "url", timeoutMs: 3e3 });
      if (l === u) return l;
      await new Promise((t) => setTimeout(t, 150));
    }
    throw o;
  }
}
function Y(r, n) {
  const a = (t) => t.normalize("NFKC").replace(/\s+/gu, " ").trim().toLocaleLowerCase("en-US");
  if (typeof r != "string" || !r.trim() || r.length > 1e3 || /(?:\.{3}|…|⋯)/u.test(r)) throw Error("\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u7F3A\u5931\u6216\u622A\u65AD\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u8BB0\u5F55");
  const c = n?.titleKeywords, u = n?.excludedRoles;
  for (const [t, i, s] of [["titleKeywords", c, 1], ["excludedRoles", u, 0]]) if (!Array.isArray(i) || i.length < s || i.length > 20 || i.some((f) => typeof f != "string" || !a(f) || f.length > 100) || new Set(i.map(a)).size !== i.length) throw Error("\u5C97\u4F4D\u8303\u56F4\u914D\u7F6E\u65E0\u6548\uFF1A" + t + "\uFF1B\u672A\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE");
  const o = a(r), F = u.filter((t) => o.includes(a(t))), l = c.filter((t) => o.includes(a(t)));
  return { version: 1, kind: "literal-full-job-title-scope", fullTitle: r, matched: l, excluded: F, allowed: F.length === 0 && l.length > 0, source: "actual-complete-job-title", jdUsed: false, searchKeywordUsedAsEvidence: false };
}
import { createHash as V } from "node:crypto";
const uu = /* @__PURE__ */ (() => {
  var r = async ({ input: n, signal: a }) => {
    a.throwIfAborted();
    const c = n, u = c?.value;
    if (!c || c.version !== 1 || c.operation !== "read" || c.binding !== "account-source-result" || c.schemaValidation !== "passed" || c.dataChanged !== false || c.ref?.version !== 1 || c.ref.policy !== "credential-redacted-v1" || c.ref.source?.entryId !== "account-source") throw new Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u5DF2\u9009\u62E9\u4E14\u5B8C\u6574\u53EF\u590D\u7528\u7684\u8D26\u53F7\u6765\u6E90\uFF0C\u8BF7\u5230\u8D44\u6E90\u9875\u91CD\u65B0\u6838\u5BF9\u5E76\u4FDD\u5B58");
    if (!u || u.version !== 1 || u.kind !== "boss-account-source" || u.status !== "account-source-confirmed" || u.accountVerified !== true || u.platformUniqueIdVerified !== false || u.eligibleForActions !== false || u.role !== "jobseeker") throw new Error("\u6240\u9009\u8BB0\u5F55\u5C1A\u672A\u5B8C\u6210\u672C\u4EBA\u786E\u8BA4\u548C\u6765\u6E90\u590D\u9A8C\uFF1B\u8BF7\u5728\u5F53\u524D\u5B9E\u4F8B\u5B8C\u6210\u8D26\u53F7\u6838\u5BF9\uFF0C\u518D\u9009\u62E9\u8BE5\u6B21\u5DF2\u4FDD\u5B58\u7ED3\u679C");
    const o = ["version", "kind", "status", "accountAlias", "accountName", "phoneMask", "jobseekerResumeHref", "role", "sourceUrl", "accountVerified", "platformUniqueIdVerified", "eligibleForActions", "confirmedAt", "checkedAt", "reason"];
    if (Object.keys(u).length !== o.length || o.some((s) => !Object.prototype.hasOwnProperty.call(u, s))) throw new Error("\u6240\u9009\u8D26\u53F7\u7ED3\u679C\u7ED3\u6784\u4E0D\u7B26\uFF0C\u505C\u6B62\u91C7\u7528");
    for (const s of ["accountAlias", "accountName", "phoneMask"]) if (typeof u[s] != "string" || !u[s].trim() || u[s] !== u[s].trim() || u[s].length > 100 || /[\r\n]/.test(u[s])) throw new Error("\u8D26\u53F7\u5FC5\u8981\u5B57\u6BB5\u7F3A\u5931\u6216\u683C\u5F0F\u65E0\u6548\uFF0C\u505C\u6B62\u91C7\u7528");
    if (!/^[+\d ()-]*\*{2,}[\d ()-]+$/.test(u.phoneMask) || /登录|注册|验证码/.test(u.accountName)) throw new Error("\u8D26\u53F7\u6765\u6E90\u7F3A\u5C11\u6709\u6548\u7684\u53EF\u89C1\u59D3\u540D\u6216\u624B\u673A\u53F7\u63A9\u7801");
    if (typeof u.reason != "string" || !u.reason.trim()) throw new Error("\u8D26\u53F7\u7ED3\u679C\u7F3A\u5C11\u660E\u786E\u6838\u5BF9\u8BF4\u660E");
    const F = Date.parse(u.confirmedAt), l = Date.parse(u.checkedAt);
    if (typeof u.confirmedAt != "string" || typeof u.checkedAt != "string" || !Number.isFinite(F) || !Number.isFinite(l) || F <= 0 || l < F || l > Date.now() + 6e4) throw new Error("\u8D26\u53F7\u786E\u8BA4\u6216\u590D\u9A8C\u65F6\u95F4\u65E0\u6CD5\u6838\u5BF9\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4");
    if (typeof u.sourceUrl != "string" || typeof u.jobseekerResumeHref != "string" || !u.sourceUrl.trim() || !u.jobseekerResumeHref.trim() || u.sourceUrl.length > 16384 || u.jobseekerResumeHref.length > 16384) throw new Error("\u8D26\u53F7\u9875\u9762\u6216\u7B80\u5386\u5165\u53E3\u5730\u5740\u65E0\u6548");
    const t = new URL(u.sourceUrl), i = new URL(u.jobseekerResumeHref, u.sourceUrl);
    if (t.origin !== "https://www.zhipin.com" || t.pathname !== "/web/geek/account" || t.searchParams.get("type") !== "accountSet" || t.username || t.password || t.hash || i.origin !== t.origin || i.pathname !== "/web/geek/resume" || i.username || i.password) throw new Error("\u8D26\u53F7\u8BB0\u5F55\u7684\u9875\u9762\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u4E0D\u7B26");
    return a.throwIfAborted(), { version: 1, accountSourceValid: true, currentAccountVerified: false, account: u };
  };
  return r;
})(), eu = /* @__PURE__ */ (() => {
  async function r({ input: n, signal: a, template: c }) {
    a.throwIfAborted();
    const u = n?.expected?.account;
    if (n?.expected?.accountSourceValid !== true || u?.kind !== "boss-account-source" || u.status !== "account-source-confirmed" || u.accountVerified !== true) throw Error("\u7F3A\u5C11\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\u6765\u6E90");
    const o = async (y, C, w) => {
      a.throwIfAborted();
      const p = await c.browser("browser", { operation: y, ...C ? { selector: C } : {}, ...w === void 0 ? {} : { value: w }, timeoutMs: 3e3 });
      return a.throwIfAborted(), p;
    };
    let F = await o("url");
    if (F === "about:blank") {
      await o("navigate", void 0, u.sourceUrl);
      for (let y = 0; y < 40; y++) {
        const C = await o("url");
        if (new URL(C).origin === "https://www.zhipin.com" && await o("count", "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)") === 1) break;
        await new Promise((w) => setTimeout(w, 150));
      }
      F = await o("url");
    }
    const l = new URL(F);
    if (l.origin !== "https://www.zhipin.com" || l.username || l.password || !l.pathname.startsWith("/web/") && !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(l.pathname)) throw Error("\u5F53\u524D\u9875\u9762\u4E0D\u662FBOSS\u6C42\u804C\u9875\u9762\uFF0C\u8BF7\u5148\u767B\u5F55");
    const t = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", i = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)", s = await o("count", t), f = await o("count", i);
    if (s !== 1 || f !== 1) throw Error("\u5F53\u524D\u9875\u9762\u8D26\u53F7\u5165\u53E3\u6570\u91CF\u5F02\u5E38\uFF1A" + JSON.stringify({ nameCount: s, resumeCount: f }));
    const h = await o("read", t), b = await o("attribute", i, "href");
    if (typeof h != "string" || h.normalize("NFKC").trim() !== u.accountName.normalize("NFKC").trim() || typeof b != "string" || new URL(b, F).href !== new URL(u.jobseekerResumeHref, u.sourceUrl).href || await o("url") !== F) throw Error("\u5F53\u524D\u767B\u5F55\u8EAB\u4EFD\u3001\u6C42\u804C\u5165\u53E3\u6216\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
    return { version: 1, status: "current-account-source-matched", accountAlias: u.accountAlias, accountName: u.accountName, phoneMask: u.phoneMask, jobseekerResumeHref: u.jobseekerResumeHref, sourceUrl: u.sourceUrl, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), currentPageUrl: F, currentAccountVerified: true, platformUniqueIdVerified: false, eligibleForActions: false, accountCheckMode: "confirmed-initial-account-and-visible-header", phoneMaskRechecked: false, reason: "\u4F7F\u7528\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\uFF1B\u53EA\u8BFB\u6838\u5BF9\u5F53\u524D\u767B\u5F55\u59D3\u540D\u3001\u6C42\u804C\u5165\u53E3\u53CA\u9875\u9762\u8FDE\u7EED\u6027\uFF0C\u624B\u673A\u53F7\u63A9\u7801\u6CBF\u7528\u786E\u8BA4\u6765\u6E90\uFF0C\u6CA1\u6709\u91CD\u65B0\u8BFB\u53D6\u3002" };
  }
  return r;
})(), q = (r) => Array.isArray(r) ? r.map(q) : r && typeof r == "object" ? Object.fromEntries(Object.keys(r).sort().map((n) => [n, q(r[n])])) : r, S = (r) => V("sha256").update(JSON.stringify(q(r))).digest("hex");
async function tu(r, n) {
  const a = (i) => String(i).replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, ""), c = async () => {
    const i = new URL(await r("url"));
    return i.origin === "https://www.zhipin.com" && i.pathname === "/web/geek/chat" && await r("count", ".chat-conversation .user-info") === 1 && a(await r("read", ".chat-conversation .user-info")) === a(n.recipientLabel) && await r("count", n.request.agreeSelector) === 1 && await r("count", n.request.root) === 1 && String(await r("read", n.request.root)).trim() === n.request.text && String(await r("read", ".chat-position-content")).trim() === n.chatJobTitle;
  };
  if (await c()) return;
  await r("navigate", void 0, "https://www.zhipin.com/web/geek/chat");
  const u = ".list-warp.v2 input";
  let o = false;
  for (let i = 0; i < 40; i++) {
    if (await r("count", u) === 1) {
      o = true;
      break;
    }
    await new Promise((s) => setTimeout(s, 150));
  }
  if (!o) throw Error("\u539F\u4F1A\u8BDD\u5B9A\u5411\u641C\u7D22\u5C1A\u672A\u52A0\u8F7D\uFF0C\u672A\u9009\u62E9\u5176\u4ED6\u4F1A\u8BDD");
  if (await c()) return;
  await r("fill", u, n.recipientName);
  const F = ".boss-search-result .search-list";
  let l = [];
  for (let i = 0; i < 30; i++) {
    const s = await r("count", F);
    if (!Number.isSafeInteger(s) || s > 50) throw Error("\u8054\u7CFB\u4EBA\u5B9A\u5411\u641C\u7D22\u8303\u56F4\u65E0\u6548");
    l = [];
    for (let f = 1; f <= s; f++) {
      const h = F + ":nth-child(" + f + " of .search-list)", b = String(await r("read", h)).trim();
      typeof n.searchResultText == "string" && a(b.split(/职位\s*[:：]/u)[0]) === a(n.searchResultText.split(/职位\s*[:：]/u)[0]) && l.push({ selector: h, text: b });
    }
    if (l.length) break;
    await new Promise((f) => setTimeout(f, 150));
  }
  if (l.length !== 1) throw Error("\u672A\u627E\u5230\u552F\u4E00\u7684\u539F\u59D3\u540D\u3001\u516C\u53F8\u548C\u89D2\u8272\u7EC4\u5408\uFF0C\u672A\u6253\u5F00\u5176\u4ED6\u4F1A\u8BDD");
  const t = l[0];
  if (String(await r("read", t.selector)).trim() !== t.text) throw Error("\u539F\u8054\u7CFB\u4EBA\u641C\u7D22\u7ED3\u679C\u53D8\u5316\uFF0C\u672A\u70B9\u51FB");
  await r("click", t.selector), o = false;
  for (let i = 0; i < 40; i++) {
    if (await c()) {
      o = true;
      break;
    }
    await new Promise((s) => setTimeout(s, 150));
  }
  if (!o) throw Error("\u539F\u4F1A\u8BDD\u3001\u539F\u9644\u4EF6\u8BF7\u6C42\u672A\u91CD\u65B0\u8BFB\u56DE\uFF0C\u4E0D\u53D1\u9001");
}
async function ru({ input: r, template: n, signal: a, artifact: c }) {
  a.throwIfAborted();
  const u = r?.closingSource;
  if (!u || u.kind !== "chat-reply-source" || !u.member?.key) throw Error("\u7F3A\u5C11\u540C\u4E00\u4E3B\u6D41\u7A0B\u56FA\u5B9A\u672A\u8BFB\u6210\u5458\u6765\u6E90\uFF0C\u7981\u6B62\u539F\u751F\u64CD\u4F5C");
  if (!u.jobId || ["job-title-outside-configured-scope", "rejected-no-reply", "manual-control", "already-completed", "fixed-unread-complete"].includes(u.status)) return { version: 1, kind: "boss-resume-request-source", ready: false, status: "fixed-member-native-skipped", reason: u.reason, websiteMessagesSent: 0, aiCalled: false };
  const o = r?.configuration, F = r?.state;
  if (o?.contextId !== u.contextId) throw Error("\u539F\u751F\u64CD\u4F5C\u4E0E\u56FA\u5B9A\u4F1A\u8BDD\u5B9E\u4F8B\u6765\u6E90\u4E0D\u540C");
  if (o?.operation !== "configuration" || F?.operation !== "state.read" || o.contextId !== F.contextId || !o.value || !F.value) throw Error("\u7F3A\u5C11\u540C\u5B9E\u4F8B\u7684\u56FA\u5B9A\u914D\u7F6E\u4E0E\u72B6\u6001");
  const l = await uu({ input: r.account, signal: a });
  await eu({ input: { expected: l }, template: n, signal: a });
  const t = (e, d, m) => X(n, a, e, d, m), i = new URL(await t("url"));
  if (i.origin !== "https://www.zhipin.com" || i.pathname !== "/web/geek/chat") throw Error("\u8BF7\u5148\u5728\u5185\u7F6E\u7F51\u9875\u6253\u5F00\u8981\u5904\u7406\u7684\u5DF2\u6709\u4F1A\u8BDD\uFF1B\u4E0D\u4F1A\u53D1\u8D77\u65B0\u7684\u9996\u6B21\u6C9F\u901A");
  const s = l.account, f = new URL(s.jobseekerResumeHref, s.sourceUrl), h = V("sha256").update(JSON.stringify(["boss-visible-account-source-v1", s.accountName, s.phoneMask, f.origin + f.pathname])).digest("hex"), b = (e) => e.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, ""), y = ".chat-conversation .user-info", C = ".chat-position-content";
  if (await t("count", y) !== 1 || await t("count", C) !== 1) throw Error("\u5F53\u524D\u4F1A\u8BDD\u6216\u5C97\u4F4D\u4E0D\u552F\u4E00");
  const w = String(await t("read", y)).trim(), p = String(await t("read", C)).trim(), x = w.split(/\r?\n/u)[0], B = p.split(/\r?\n/u).map((e) => e.trim()).filter(Boolean);
  if (w !== u.recipientLabel || p !== u.chatJobTitle) throw Error("\u539F\u751F\u9644\u4EF6\u5BF9\u8C61\u4E0E\u56FA\u5B9A\u672A\u8BFB\u6210\u5458\u4E0D\u7B26");
  if (!x || w.length > 1e3 || B.length < 3) throw Error("\u7F3A\u5C11\u51C6\u786E\u62DB\u8058\u8005\u3001\u516C\u53F8\u6216\u5C97\u4F4D\u6765\u6E90");
  const U = async () => {
    const e = await t("count", "li.message-item");
    if (!Number.isSafeInteger(e) || e < 1 || e > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u6D88\u606F\u8303\u56F4\u4E0D\u53EF\u6838\u5BF9\uFF0C\u672A\u622A\u65AD");
    const d = [];
    for (let m = 1; m <= e; m++) {
      const A = "li.message-item:nth-child(" + m + " of li.message-item)", D = await t("attribute", A, "data-mid"), I = await t("attribute", A, "class"), H = String(await t("read", A)).trim();
      if (!/^\d{6,40}$/.test(D || "") || typeof I != "string" || H.length > 2e4) throw Error("\u6D88\u606F\u8EAB\u4EFD\u6216\u5B8C\u6574\u6B63\u6587\u65E0\u6548");
      d.push({ mid: D, class: I, text: H });
    }
    if (new Set(d.map((m) => m.mid)).size !== d.length) throw Error("\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
    return d;
  }, g = await U(), N = [];
  for (const e of g) {
    if (!e.class.split(/\s/u).includes("item-friend") || !e.text.includes("\u6211\u60F3\u8981\u4E00\u4EFD\u60A8\u7684\u9644\u4EF6\u7B80\u5386\uFF0C\u60A8\u662F\u5426\u540C\u610F")) continue;
    const d = 'li.message-item[data-mid="' + e.mid + '"]', m = d + " .message-dialog-both .card-btn:nth-child(2)", A = d + " .message-dialog-both .card-btn:nth-child(1)";
    await t("count", m) === 1 && await t("count", A) === 1 && String(await t("read", m)).trim() === "\u540C\u610F" && String(await t("read", A)).trim() === "\u62D2\u7EDD" && N.push({ mid: e.mid, root: d, agreeSelector: m, rejectSelector: A, text: e.text });
  }
  if (!N.length) {
    const e = { version: 1, kind: "boss-resume-request-source", ready: false, status: "no-pending-resume-request", reason: "\u5F53\u524D\u4F1A\u8BDD\u6CA1\u6709\u51C6\u786E\u7684\u672A\u5904\u7406\u9644\u4EF6\u8BF7\u6C42\uFF0C\u4E0D\u4E0A\u4F20\u6216\u53D1\u9001", websiteMessagesSent: 0, aiCalled: false };
    return await c("native-resume-stage-result.json", JSON.stringify(e)), e;
  }
  if (N.length !== 1) throw Error("\u5B58\u5728\u591A\u4E2A\u672A\u5904\u7406\u9644\u4EF6\u8BF7\u6C42\uFF0C\u8BF7\u672C\u4EBA\u660E\u786E\u5F53\u524D\u8BF7\u6C42\uFF0C\u4E0D\u6309\u4F4D\u7F6E\u731C\u6D4B");
  const k = N[0], O = /^(\d+(?:\.\d+)?)-(\d+(?:\.\d+)?)K(?:·\d+薪)?$/iu.exec(B[1]);
  if (!O || !o.value.cities?.includes(B[2]) || Number(O[2]) * 1e3 < o.value.salaryMin || o.value.salaryMax > 0 && Number(O[1]) * 1e3 > o.value.salaryMax) throw Error("\u5C97\u4F4D\u57CE\u5E02\u6216\u6708\u85AA\u4EA4\u96C6\u672A\u901A\u8FC7\uFF0C\u4E0D\u53D1\u9001\u9644\u4EF6");
  const J = Y(B[0], o.value);
  if (!J.allowed) throw Error("\u9644\u4EF6\u8BF7\u6C42\u7684\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u672A\u901A\u8FC7\u672C\u4EBA\u5141\u8BB8\u8BCD\u548C\u6392\u9664\u9879\uFF1B\u672A\u5EFA\u7ACB\u53D1\u9001\u610F\u56FE");
  if ((o.value.excludedRoles || []).some((e) => e && B[0].normalize("NFKC").toLowerCase().includes(e.normalize("NFKC").toLowerCase()))) throw Error("\u5F53\u524D\u5C97\u4F4D\u547D\u4E2D\u672C\u4EBA\u6392\u9664\u6761\u4EF6");
  const R = await Q(t, { recipientName: x, recipientLabel: w, chatJobTitle: p });
  if (String(await t("read", y)).trim() !== w || JSON.stringify(await U()) !== JSON.stringify(g)) throw Error("\u56FA\u5B9A\u8054\u7CFB\u4EBA\u671F\u95F4\u539F\u4F1A\u8BDD\u6216\u8BF7\u6C42\u53D8\u5316");
  const z = { searchResultText: R, accountKey: h, recipientLabel: w, chatJobTitle: p, firstMessageId: g[0].mid, requestMid: k.mid, rowsSha256: S(g) }, L = "resume-job-source-v1-" + S(z) + ".json";
  let M = null;
  try {
    const e = JSON.parse(await n.file("communication-cache", { operation: "read", name: "resume-delivery-index-v1-" + h + ".json" })), { sha256: d, ...m } = e;
    if (d !== S(m) || e.accountKey !== h || e.kind !== "boss-resume-delivery-index" || !Array.isArray(e.deliveries)) throw Error("\u539F\u9644\u4EF6\u8D26\u672C\u4E0D\u7B26\uFF0C\u672A\u91C7\u7528");
    const A = S(["boss-resume-request-v1", h, g[0].mid, k.mid]);
    M = e.deliveries.find((D) => D.key === A && D.effectId && D.sendKey && b(D.recipientLabel) === b(w) && D.firstMessageId === g[0].mid && D.requestMid === k.mid) || null;
  } catch (e) {
    if (!String(e.message || e).includes("ENOENT")) throw e;
  }
  let E = null;
  try {
    const e = await n.file("communication-cache", { operation: "read", name: L });
    E = JSON.parse(e);
    const { sha256: d, ...m } = E;
    if (d !== S(m) || E.kind !== "boss-resume-job-source" || S(E.identity) !== S(z)) throw Error("\u539F\u8BF7\u6C42\u5C97\u4F4D\u89C2\u5BDF\u7F13\u5B58\u4E0D\u7B26\uFF0C\u4E0D\u91C7\u7528");
  } catch (e) {
    if (!String(e.message || e).includes("ENOENT")) throw e;
  }
  let j, v;
  if (M) {
    const e = new URL(M.jobSource);
    if (e.origin !== "https://www.zhipin.com" || !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(e.pathname) || e.search || e.hash) throw Error("\u539F\u53D1\u9001\u8BB0\u5F55\u5C97\u4F4D\u6765\u6E90\u4E0D\u7B26");
    j = e.href, v = e.pathname.split("/").at(-1).slice(0, -5);
  } else if (E && Date.now() - Date.parse(E.checkedAt) >= 0 && Date.now() - Date.parse(E.checkedAt) <= 9e5) {
    const e = new URL(E.jobSource);
    if (e.origin !== "https://www.zhipin.com" || !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(e.pathname) || e.search || e.hash || E.jobTitle !== B[0] || e.pathname.split("/").at(-1).slice(0, -5) !== E.jobId) throw Error("\u539F\u8BF7\u6C42\u5C97\u4F4D\u89C2\u5BDF\u7F13\u5B58\u7684\u6765\u6E90\u65E0\u6548");
    j = e.href, v = E.jobId;
  } else {
    const e = ".chat-position-content .right-content > :first-child";
    if (await t("count", e) !== 1 || String(await t("read", e)).replace(/[\uE000-\uF8FF]/gu, "").trim() !== "\u67E5\u770B\u804C\u4F4D") throw Error("\u7F3A\u5C11\u5F53\u524D\u4F1A\u8BDD\u552F\u4E00\u7684\u539F\u5173\u8054\u804C\u4F4D\u5165\u53E3");
    await t("click", e);
    let d;
    for (let A = 0; A < 40; A++) {
      const D = new URL(await t("url"));
      if (D.origin === "https://www.zhipin.com" && /^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(D.pathname) && await t("count", "h1") === 1 && String(await t("read", "h1")).trim() === B[0].replace(/（猎头职位）$/u, "").trim()) {
        d = D;
        break;
      }
      await new Promise((I) => setTimeout(I, 150));
    }
    if (!d) throw Error("\u539F\u5173\u8054\u804C\u4F4D\u6765\u6E90\u4E0E\u6807\u9898\u672A\u8BFB\u56DE");
    j = d.origin + d.pathname, v = d.pathname.split("/").at(-1).slice(0, -5), E = { version: 1, kind: "boss-resume-job-source", identity: z, jobSource: j, jobId: v, jobTitle: B[0], checkedAt: (/* @__PURE__ */ new Date()).toISOString(), isActionAuthorization: false }, E.sha256 = S(E);
    const m = JSON.stringify(E);
    if (await n.file("communication-cache", { operation: "write", name: L, content: m }), await n.file("communication-cache", { operation: "read", name: L }) !== m) throw Error("\u539F\u5C97\u4F4D\u89C2\u5BDF\u672A\u5B8C\u6574\u8BFB\u56DE\uFF0C\u4E0D\u91C7\u7528");
    if (await c("resume-job-source-observation.json", JSON.stringify(E, null, 2)), await tu(t, { recipientName: x, recipientLabel: w, request: k, chatJobTitle: p, searchResultText: R }), JSON.stringify(await U()) !== JSON.stringify(g)) throw Error("\u8FD4\u56DE\u540E\u7684\u4F1A\u8BDD\u6216\u539F\u8BF7\u6C42\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62");
  }
  const _ = await n.state.get(), K = "boss-job:" + v;
  if ((_.conversationControls || []).some((e) => e.accountKey === h && [K, "boss-chat:" + g[0].mid].includes(e.conversationKey) && e.mode === "paused")) throw Error("\u672C\u4EBA\u5DF2\u63A5\u7BA1\u6B64\u4F1A\u8BDD\uFF0C\u4E0D\u53D1\u9001\u9644\u4EF6");
  const P = S(["boss-resume-request-v1", h, g[0].mid, k.mid]), W = "account-outbound-safety-v1-" + h + ".json", T = JSON.parse(await n.file("communication-cache", { operation: "read", name: W })), { sha256: Z, ...G } = T;
  if (Z !== S(G) || T.accountKey !== h || T.kind !== "boss-account-outbound-safety") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\u6216\u4E0D\u7B26\uFF0C\u7981\u6B62\u9644\u4EF6\u5916\u53D1");
  const $ = { version: 1, kind: "boss-resume-request-source", ready: true, contextId: o.contextId, configurationRevision: o.revision, configuration: o.value, titleScope: J, accountSource: l, accountKey: h, recipientLabel: w, recipientName: x, chatJobTitle: p, searchResultText: R, jobTitle: B[0], jobSource: j, jobId: v, conversationKey: K, firstMessageId: g[0].mid, request: k, requestKey: P, rows: g, sourceSha256: S({ accountKey: h, recipientLabel: w, jobSource: j, rows: g, searchResultText: R }), aiCalled: false, websiteMessagesSent: 0 };
  return await c("resume-request-source.json", JSON.stringify($, null, 2)), $;
}
export {
  ru as default
};
