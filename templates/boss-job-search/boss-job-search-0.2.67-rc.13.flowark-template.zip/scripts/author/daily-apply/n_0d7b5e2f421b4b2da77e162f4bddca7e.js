async function A(u, t, r, a, e) {
  t.throwIfAborted();
  try {
    return await u.browser("browser", { operation: r, ...a ? { selector: a } : {}, ...e === void 0 ? {} : { value: e }, timeoutMs: 3e3 });
  } catch (i) {
    if (r !== "navigate" || !["https://www.zhipin.com/web/geek/chat", "https://www.zhipin.com/web/geek/resume"].includes(e) || !/^\(-3\) loading /u.test(String(i?.message || i))) throw i;
    for (let n = 0; n < 40; n++) {
      t.throwIfAborted();
      const s = await u.browser("browser", { operation: "url", timeoutMs: 3e3 });
      if (s === e) return s;
      await new Promise((c) => setTimeout(c, 150));
    }
    throw i;
  }
}
function B(u, t) {
  const r = (c) => c.normalize("NFKC").replace(/\s+/gu, " ").trim().toLocaleLowerCase("en-US");
  if (typeof u != "string" || !u.trim() || u.length > 1e3 || /(?:\.{3}|…|⋯)/u.test(u)) throw Error("\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u7F3A\u5931\u6216\u622A\u65AD\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u8BB0\u5F55");
  const a = t?.titleKeywords, e = t?.excludedRoles;
  for (const [c, o, F] of [["titleKeywords", a, 1], ["excludedRoles", e, 0]]) if (!Array.isArray(o) || o.length < F || o.length > 20 || o.some((w) => typeof w != "string" || !r(w) || w.length > 100) || new Set(o.map(r)).size !== o.length) throw Error("\u5C97\u4F4D\u8303\u56F4\u914D\u7F6E\u65E0\u6548\uFF1A" + c + "\uFF1B\u672A\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE");
  const i = r(u), n = e.filter((c) => i.includes(r(c))), s = a.filter((c) => i.includes(r(c)));
  return { version: 1, kind: "literal-full-job-title-scope", fullTitle: u, matched: s, excluded: n, allowed: n.length === 0 && s.length > 0, source: "actual-complete-job-title", jdUsed: false, searchKeywordUsedAsEvidence: false };
}
import { createHash as b } from "node:crypto";
const p = (u) => Array.isArray(u) ? u.map(p) : u && typeof u == "object" ? Object.fromEntries(Object.keys(u).sort().map((t) => [t, p(u[t])])) : u, h = (u) => b("sha256").update(JSON.stringify(p(u))).digest("hex"), D = (u) => String(u).replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, ""), v = (u, t) => (r, a, e) => A(u, t, r, a, e), E = async (u, t) => {
  try {
    return await u.file("communication-cache", { operation: "read", name: t });
  } catch (r) {
    if (String(r.message || r).includes("ENOENT")) return null;
    throw r;
  }
};
async function S(u, t) {
  const r = "resume-delivery-index-v1-" + t.accountKey + ".json", a = await E(u, r);
  let e = a === null ? { version: 1, kind: "boss-resume-delivery-index", accountKey: t.accountKey, revision: 0, uploads: [], deliveries: [] } : JSON.parse(a);
  if (a !== null) {
    const { sha256: i, ...n } = e;
    if (i !== h(n)) throw Error("\u9644\u4EF6\u8D26\u672C\u6458\u8981\u65E0\u6548\uFF0C\u672A\u91CD\u5EFA");
  }
  if (e.version !== 1 || e.kind !== "boss-resume-delivery-index" || e.accountKey !== t.accountKey || !Number.isSafeInteger(e.revision) || !Array.isArray(e.uploads) || !Array.isArray(e.deliveries) || e.uploads.length > 100 || e.deliveries.length > 2e3 || new Set(e.uploads.map((i) => i.key)).size !== e.uploads.length || new Set(e.deliveries.map((i) => i.key)).size !== e.deliveries.length) throw Error("\u9644\u4EF6\u8D26\u672C\u8EAB\u4EFD\u3001\u5BB9\u91CF\u6216\u552F\u4E00\u6027\u65E0\u6548\uFF0C\u539F\u8BB0\u5F55\u4FDD\u7559");
  return { name: r, raw: a, value: e };
}
async function N(u, t) {
  if (await E(u, t.name) !== t.raw) throw Error("\u9644\u4EF6\u8D26\u672C\u5DF2\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  t.value.revision++, t.value.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete t.value.sha256, t.value.sha256 = h(t.value), await u.file("communication-cache", { operation: "write", name: t.name, content: JSON.stringify(t.value) });
  const r = await E(u, t.name), a = JSON.parse(r), { sha256: e, ...i } = a;
  if (e !== h(i) || e !== t.value.sha256) throw Error("\u9644\u4EF6\u8D26\u672C\u672A\u5B8C\u6574\u8BFB\u56DE");
  return t.raw = r, { name: t.name, sha256: e, revision: a.revision };
}
async function g(u, t) {
  const r = new URL(await u("url"));
  return r.origin === "https://www.zhipin.com" && r.pathname === "/web/geek/chat" && await u("count", ".chat-conversation .user-info") === 1 && D(await u("read", ".chat-conversation .user-info")) === D(t.recipientLabel) && await u("count", t.request.agreeSelector) === 1 && String(await u("read", t.request.agreeSelector)).trim() === "\u540C\u610F" && await u("count", t.request.root) === 1 && String(await u("read", t.request.root)).trim() === t.request.text && String(await u("read", ".chat-position-content")).trim() === t.chatJobTitle;
}
async function k(u) {
  const t = ".resume-attachment";
  if (await u("count", t) !== 1 || await u("count", t + " > h3") !== 1 || !String(await u("read", t + " > h3")).trim().startsWith("\u9644\u4EF6\u7BA1\u7406")) throw Error("\u7F51\u7AD9\u9644\u4EF6\u7BA1\u7406\u7ED3\u6784\u5C1A\u672A\u6838\u5BF9\uFF0C\u672A\u64CD\u4F5C");
  return t;
}
async function x(u, t) {
  const r = await k(u), a = r + " .annex-item", e = await u("count", a);
  if (!Number.isSafeInteger(e) || e < 0 || e > 3) throw Error("\u9644\u4EF6\u5E93\u6587\u4EF6\u6570\u91CF\u65E0\u6CD5\u6838\u5BF9");
  const i = [];
  for (let s = 1; s <= e; s++) {
    const c = a + ":nth-child(" + s + ")", o = String(await u("read", c)).trim();
    if (o.length > 4e3) throw Error("\u9644\u4EF6\u6761\u76EE\u8FC7\u957F\uFF0C\u672A\u622A\u65AD");
    i.push({ selector: c, text: o });
  }
  const n = i.filter((s) => s.text.split(/\r?\n/u).map((c) => c.trim()).includes(t.displayName));
  if (n.length > 1) throw Error("\u9644\u4EF6\u5E93\u6709\u540C\u540D\u6587\u4EF6\uFF0C\u7981\u6B62\u6309\u4F4D\u7F6E\u53D1\u9001");
  return { root: r, count: e, rows: i, match: n[0] || null };
}
async function K(u, t) {
  const r = (o) => String(o).replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, ""), a = async () => {
    const o = new URL(await u("url"));
    return o.origin === "https://www.zhipin.com" && o.pathname === "/web/geek/chat" && await u("count", ".chat-conversation .user-info") === 1 && r(await u("read", ".chat-conversation .user-info")) === r(t.recipientLabel) && await u("count", t.request.agreeSelector) === 1 && await u("count", t.request.root) === 1 && String(await u("read", t.request.root)).trim() === t.request.text && String(await u("read", ".chat-position-content")).trim() === t.chatJobTitle;
  };
  if (await a()) return;
  await u("navigate", void 0, "https://www.zhipin.com/web/geek/chat");
  const e = ".list-warp.v2 input";
  let i = false;
  for (let o = 0; o < 40; o++) {
    if (await u("count", e) === 1) {
      i = true;
      break;
    }
    await new Promise((F) => setTimeout(F, 150));
  }
  if (!i) throw Error("\u539F\u4F1A\u8BDD\u5B9A\u5411\u641C\u7D22\u5C1A\u672A\u52A0\u8F7D\uFF0C\u672A\u9009\u62E9\u5176\u4ED6\u4F1A\u8BDD");
  if (await a()) return;
  await u("fill", e, t.recipientName);
  const n = ".boss-search-result .search-list";
  let s = [];
  for (let o = 0; o < 30; o++) {
    const F = await u("count", n);
    if (!Number.isSafeInteger(F) || F > 50) throw Error("\u8054\u7CFB\u4EBA\u5B9A\u5411\u641C\u7D22\u8303\u56F4\u65E0\u6548");
    s = [];
    for (let w = 1; w <= F; w++) {
      const m = n + ":nth-child(" + w + " of .search-list)", f = String(await u("read", m)).trim();
      typeof t.searchResultText == "string" && r(f.split(/职位\s*[:：]/u)[0]) === r(t.searchResultText.split(/职位\s*[:：]/u)[0]) && s.push({ selector: m, text: f });
    }
    if (s.length) break;
    await new Promise((w) => setTimeout(w, 150));
  }
  if (s.length !== 1) throw Error("\u672A\u627E\u5230\u552F\u4E00\u7684\u539F\u59D3\u540D\u3001\u516C\u53F8\u548C\u89D2\u8272\u7EC4\u5408\uFF0C\u672A\u6253\u5F00\u5176\u4ED6\u4F1A\u8BDD");
  const c = s[0];
  if (String(await u("read", c.selector)).trim() !== c.text) throw Error("\u539F\u8054\u7CFB\u4EBA\u641C\u7D22\u7ED3\u679C\u53D8\u5316\uFF0C\u672A\u70B9\u51FB");
  await u("click", c.selector), i = false;
  for (let o = 0; o < 40; o++) {
    if (await a()) {
      i = true;
      break;
    }
    await new Promise((F) => setTimeout(F, 150));
  }
  if (!i) throw Error("\u539F\u4F1A\u8BDD\u3001\u539F\u9644\u4EF6\u8BF7\u6C42\u672A\u91CD\u65B0\u8BFB\u56DE\uFF0C\u4E0D\u53D1\u9001");
}
function I(u, t) {
  if (!u?.class?.split(/\s/u).includes("item-system") || !/^[0-9]{6,40}$/.test(u.mid || "")) return null;
  const r = /您的附件简历\s+(.+?)\s+已发送给Boss(?:点击查看附件)?/u.exec(u.text || "");
  if (!r) return null;
  const a = r[1].trim(), e = a.normalize("NFKC"), i = t.displayName.normalize("NFKC");
  if (e === i) return { shown: a, serverNameTruncated: false };
  const n = e.endsWith("...") ? "..." : e.endsWith("\u2026") ? "\u2026" : null;
  if (n) {
    const s = e.slice(0, -n.length);
    if (s.length >= 8 && i.startsWith(s)) return { shown: a, serverNameTruncated: true };
  }
  return null;
}
async function d(u, t) {
  const r = new URL(await u("url")), a = t.accountSource.account, e = new URL(a.jobseekerResumeHref, a.sourceUrl);
  if (r.origin !== "https://www.zhipin.com") throw Error("\u5F53\u524D\u8D26\u53F7\u9875\u9762\u6765\u6E90\u53D8\u5316\uFF0C\u672A\u53D1\u9001\u9644\u4EF6");
  if (r.pathname === "/web/geek/resume") {
    if (r.origin + r.pathname !== e.origin + e.pathname || await u("count", ".nav-figure") !== 1 || String(await u("read", ".nav-figure")).normalize("NFKC").trim() !== a.accountName.normalize("NFKC").trim() || await u("count", ".resume-attachment") !== 1) throw Error("\u672C\u4EBA\u9644\u4EF6\u7BA1\u7406\u9875\u7684\u8D26\u53F7\u6216\u6765\u6E90\u53D8\u5316\uFF0C\u672A\u53D1\u9001");
    return;
  }
  const i = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", n = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)";
  if (r.pathname !== "/web/geek/chat" || await u("count", i) !== 1 || await u("count", n) !== 1 || String(await u("read", i)).normalize("NFKC").trim() !== a.accountName.normalize("NFKC").trim() || new URL(await u("attribute", n, "href"), r.href).href !== e.href) throw Error("\u5F53\u524D\u4F1A\u8BDD\u9875\u6C42\u804C\u8D26\u53F7\u53D8\u5316\uFF0C\u672A\u53D1\u9001\u9644\u4EF6");
}
async function C(u) {
  const t = await u("count", "li.message-item");
  if (!Number.isSafeInteger(t) || t < 1 || t > 100) throw Error("\u5F53\u524D\u6D88\u606F\u8303\u56F4\u4E0D\u80FD\u5B8C\u6574\u6838\u5BF9");
  const r = [];
  for (let a = 1; a <= t; a++) {
    const e = "li.message-item:nth-child(" + a + " of li.message-item)", i = await u("attribute", e, "data-mid"), n = await u("attribute", e, "class"), s = String(await u("read", e)).trim();
    if (!/^\d{6,40}$/.test(i || "") || typeof n != "string" || s.length > 2e4) throw Error("\u6D88\u606F\u6765\u6E90\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
    r.push({ mid: i, class: n, text: s });
  }
  return r;
}
async function z({ input: u, template: t, signal: r, artifact: a }) {
  r.throwIfAborted();
  const e = u?.source;
  if (e?.kind !== "boss-resume-request-source") throw Error("\u7F3A\u5C11\u5F53\u524D\u51C6\u786E\u9644\u4EF6\u8BF7\u6C42\u6765\u6E90");
  if (!e.ready) {
    const l = { ...e, execute: false, needsUpload: false, websiteUploads: 0, confirmedWebsiteMessages: 0 };
    return await a("native-resume-stage-result.json", JSON.stringify(l)), l;
  }
  if (!B(e.jobTitle, e.configuration).allowed) throw Error("\u9644\u4EF6\u5C97\u4F4D\u8303\u56F4\u672A\u901A\u8FC7\uFF0C\u4FDD\u7559\u8BB0\u5F55\u4E14\u4E0D\u53D1\u9001");
  const i = u?.fileName;
  if (typeof i != "string" || !i.trim() || i !== i.trim() || i.length > 300 || /[\/\\\r\n]/u.test(i) || !i.toLowerCase().endsWith(".pdf")) throw Error("\u8BF7\u586B\u5199\u672C\u4EBA\u5DF2\u5728BOSS\u6838\u5BF9\u7684\u73B0\u6709\u9644\u4EF6\u5B8C\u6574\u6587\u4EF6\u540D\uFF0C\u4E0D\u8BFB\u53D6\u6216\u4E0A\u4F20\u672C\u5730\u6587\u4EF6");
  const n = v(t, r);
  if (await d(n, e), !await g(n, e) || h(await C(n)) !== h(e.rows)) throw Error("\u5F53\u524D\u8BF7\u6C42\u6216\u5B8C\u6574\u4F1A\u8BDD\u53D8\u5316\uFF0C\u672A\u51C6\u5907\u9644\u4EF6\u53D1\u9001");
  const s = await S(t, e), c = s.value.deliveries.find((l) => l.key === e.requestKey || l.firstMessageId === e.firstMessageId && l.requestMid === e.request.mid);
  if (c) {
    const l = { version: 1, kind: "resume-send-result", execute: false, needsUpload: false, status: "existing-resume-intent-no-replay", previousStatus: c.status, originalEffectStateUnchanged: true, websiteUploads: 0, confirmedWebsiteMessages: 0, newSendAttempts: 0, aiCalled: false };
    return await a("native-resume-stage-result.json", JSON.stringify(l)), l;
  }
  await n("navigate", null, "https://www.zhipin.com/web/geek/resume");
  let o;
  for (let l = 0; l < 40; l++) {
    if (r.throwIfAborted(), await n("count", ".resume-attachment") === 1) {
      o = await x(n, { displayName: i });
      break;
    }
    await new Promise((y) => setTimeout(y, 150));
  }
  if (await d(n, e), !o?.match) throw Error("\u672C\u4EBA\u786E\u8BA4\u7684\u51C6\u786E\u6587\u4EF6\u4E0D\u5728\u5F53\u524D\u7F51\u7AD9\u9644\u4EF6\u5E93\uFF0C\u8BF7\u672C\u4EBA\u5148\u5728BOSS\u7EF4\u62A4\uFF1B\u672C\u6D41\u7A0B\u4E0D\u4E0A\u4F20\u3001\u4E0D\u5220\u9664\u3001\u4E0D\u56DE\u9000\u5176\u4ED6\u6587\u4EF6");
  const F = { kind: "boss-user-confirmed-existing-attachment", displayName: i, source: "boss-existing-attachment-library", libraryRow: o.match.text, libraryCount: o.count, userSpecifiedName: true, serverBytesVerified: false };
  if (await K(n, e), await d(n, e), !await g(n, e) || h(await C(n)) !== h(e.rows)) throw Error("\u6838\u5BF9\u9644\u4EF6\u671F\u95F4\u539F\u4F1A\u8BDD\u6216\u539F\u8BF7\u6C42\u53D8\u5316\uFF0C\u672A\u53D1\u9001");
  if (((await t.state.get()).conversationControls || []).some((l) => l.accountKey === e.accountKey && [e.conversationKey, "boss-chat:" + e.firstMessageId].includes(l.conversationKey) && l.mode === "paused")) throw Error("\u672C\u4EBA\u5DF2\u63A5\u7BA1\uFF0C\u4E0D\u6267\u884C\u9644\u4EF6\u64CD\u4F5C");
  if (await E(t, s.name) !== s.raw) throw Error("\u6838\u5BF9\u671F\u95F4\u9644\u4EF6\u8D26\u672C\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  if (s.value.deliveries.length >= 2e3) throw Error("\u9644\u4EF6\u8D26\u672C\u5BB9\u91CF\u5DF2\u6EE1\uFF0C\u4FDD\u7559\u5386\u53F2\u4E14\u4E0D\u53D1\u9001");
  s.value.deliveries.push({ key: e.requestKey, mode: "native-existing-attachment", requestMid: e.request.mid, firstMessageId: e.firstMessageId, recipientLabel: e.recipientLabel, jobSource: e.jobSource, file: F, status: "reserved", sourceSha256: e.sourceSha256, createdAt: (/* @__PURE__ */ new Date()).toISOString() });
  const m = await N(t, s), f = { version: 1, kind: "native-resume-send-preparation", execute: true, needsUpload: false, source: e, file: F, ledger: m, websiteUploads: 0, confirmedWebsiteMessages: 0, aiCalled: false };
  return await a("native-resume-preparation.json", JSON.stringify(f, null, 2)), await a("native-resume-stage-result.json", JSON.stringify({ version: 1, kind: "resume-send-result", status: "native-existing-file-prepared-not-sent", file: F, websiteUploads: 0, confirmedWebsiteMessages: 0 })), f;
}
export {
  z as default
};
