function oe(a) {
  return a.status === "review" && !a.operationKey && !a.modelRequestId && a.sourceReviewVersion !== "fixed-chat-navigation-v3" && /关联职位没有可核对的继续沟通入口|固定成员缺少可核对的定向搜索姓名，未猜测|固定成员缺少唯一可见身份|关联职位返回后的完整消息或对象变化/u.test(String(a.reason || ""));
}
async function ne(a, E, B) {
  const { accountKey: o, contextId: u, day: f, timeZone: F, revision: C, configuration: r } = B, d = r.acceptanceNewGreetings ?? 0;
  if (d !== 0 && d !== 2) throw Error("\u9A8C\u6536\u65B0\u62DB\u547C\u6570\u53EA\u80FD\u4E3A0\uFF08\u6B63\u5F0F\u6A21\u5F0F\uFF09\u62162");
  if (!d) return null;
  E.throwIfAborted();
  const s = (n) => Array.isArray(n) ? n.map(s) : n && typeof n == "object" ? Object.fromEntries(Object.keys(n).sort().map((i) => [i, s(n[i])])) : n, S = (n) => W("sha256").update(JSON.stringify(s(n))).digest("hex"), y = (n) => {
    const { sha256: i, ...J } = n;
    if (i !== S(J)) throw Error("\u9A8C\u6536\u6765\u6E90\u6458\u8981\u4E0D\u7B26\uFF0C\u4FDD\u7559\u539F\u8BB0\u5F55");
    return n;
  }, D = y(JSON.parse(await a.file("communication-cache", { operation: "read", name: "account-outbound-safety-v1-" + o + ".json" })));
  if (D.kind !== "boss-account-outbound-safety" || D.accountKey !== o || !Array.isArray(D.records)) throw Error("\u9A8C\u6536\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u4E0D\u7B26");
  const h = new Intl.DateTimeFormat("sv-SE", { timeZone: F, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
  if (f !== h) throw Error("\u9A8C\u6536\u8DE8\u65E5\uFF0C\u505C\u6B62\u65B0\u589E");
  const b = D.records.filter((n) => n.type === "first-contact" && n.sightings.some((i) => i.day === f && i.timeZone === F)), g = b.map((n) => n.businessKey);
  if (new Set(g).size !== g.length) throw Error("\u9A8C\u6536\u5360\u989D\u952E\u91CD\u590D");
  const N = { accountKey: o, contextId: u, day: f, timeZone: F, revision: C, target: d }, L = "test-greeting-baseline-v1-" + o + "-" + S(N).slice(0, 24) + ".json";
  let c = null;
  try {
    c = await a.file("communication-cache", { operation: "read", name: L });
  } catch (n) {
    if (!String(n.message || n).includes("ENOENT")) throw n;
  }
  let w;
  if (c === null) {
    if (r.firstContactDailyBudget !== g.length + d) throw Error("\u6D4B\u8BD5\u9884\u7B97\u5FC5\u987B\u7B49\u4E8E\u672C\u65E5\u5DF2\u6709\u5360\u989D\u52A02\uFF0C\u7981\u6B62\u6269\u5927\u6216\u91CD\u7F6E\u672C\u8F6E");
    if (w = { version: 1, kind: "boss-test-greeting-baseline", identity: N, keys: g.slice().sort(), budget: r.firstContactDailyBudget, indexSha256: D.sha256, createdAt: (/* @__PURE__ */ new Date()).toISOString() }, w.sha256 = S(w), await a.file("communication-cache", { operation: "write", name: L, content: JSON.stringify(w) }), c = await a.file("communication-cache", { operation: "read", name: L }), JSON.stringify(y(JSON.parse(c))) !== JSON.stringify(w)) throw Error("\u6D4B\u8BD5\u57FA\u7EBF\u672A\u51C6\u786E\u8BFB\u56DE");
  } else w = y(JSON.parse(c));
  if (S(w.identity) !== S(N) || w.budget !== r.firstContactDailyBudget || !Array.isArray(w.keys) || w.keys.some((n) => !g.includes(n))) throw Error("\u6D4B\u8BD5\u57FA\u7EBF\u6216\u9884\u7B97\u53D8\u5316\uFF0C\u505C\u6B62\u4E14\u4FDD\u7559\u5386\u53F2");
  const M = b.filter((n) => !w.keys.includes(n.businessKey));
  if (M.length > d) throw Error("\u6D4B\u8BD5\u5360\u989D\u8D85\u51FA\u4E24\u6B21\uFF0C\u505C\u6B62");
  for (const n of M) if (n.sightings.some((i) => i.day === f && i.timeZone === F && (i.contextId !== u || i.status === "unknown" || i.status === "failed"))) throw Error("\u6D4B\u8BD5\u65B0\u589E\u6765\u6E90\u51B2\u7A81\u6216\u7ED3\u679C\u672A\u77E5\uFF0C\u7981\u6B62\u8865\u53D1");
  const k = M.filter((n) => n.sightings.some((i) => i.day === f && i.timeZone === F && i.contextId === u && i.status === "confirmed"));
  return { version: 1, kind: "boss-test-new-greeting-completion", ...N, baselineName: L, baselineSha256: w.sha256, newOccupied: M.length, newConfirmed: k.length, confirmedKeys: k.map((n) => n.businessKey).sort(), confirmed: k.length === d, siteDailyLimitConfirmed: false, checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
}
import { createHash as W } from "node:crypto";
const ie = /* @__PURE__ */ (() => {
  var a = async ({ input: E, signal: B }) => {
    B.throwIfAborted();
    const o = E, u = o?.value;
    if (!o || o.version !== 1 || o.operation !== "read" || o.binding !== "account-source-result" || o.schemaValidation !== "passed" || o.dataChanged !== false || o.ref?.version !== 1 || o.ref.policy !== "credential-redacted-v1" || o.ref.source?.entryId !== "account-source") throw new Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u5DF2\u9009\u62E9\u4E14\u5B8C\u6574\u53EF\u590D\u7528\u7684\u8D26\u53F7\u6765\u6E90\uFF0C\u8BF7\u5230\u8D44\u6E90\u9875\u91CD\u65B0\u6838\u5BF9\u5E76\u4FDD\u5B58");
    if (!u || u.version !== 1 || u.kind !== "boss-account-source" || u.status !== "account-source-confirmed" || u.accountVerified !== true || u.platformUniqueIdVerified !== false || u.eligibleForActions !== false || u.role !== "jobseeker") throw new Error("\u6240\u9009\u8BB0\u5F55\u5C1A\u672A\u5B8C\u6210\u672C\u4EBA\u786E\u8BA4\u548C\u6765\u6E90\u590D\u9A8C\uFF1B\u8BF7\u5728\u5F53\u524D\u5B9E\u4F8B\u5B8C\u6210\u8D26\u53F7\u6838\u5BF9\uFF0C\u518D\u9009\u62E9\u8BE5\u6B21\u5DF2\u4FDD\u5B58\u7ED3\u679C");
    const f = ["version", "kind", "status", "accountAlias", "accountName", "phoneMask", "jobseekerResumeHref", "role", "sourceUrl", "accountVerified", "platformUniqueIdVerified", "eligibleForActions", "confirmedAt", "checkedAt", "reason"];
    if (Object.keys(u).length !== f.length || f.some((s) => !Object.prototype.hasOwnProperty.call(u, s))) throw new Error("\u6240\u9009\u8D26\u53F7\u7ED3\u679C\u7ED3\u6784\u4E0D\u7B26\uFF0C\u505C\u6B62\u91C7\u7528");
    for (const s of ["accountAlias", "accountName", "phoneMask"]) if (typeof u[s] != "string" || !u[s].trim() || u[s] !== u[s].trim() || u[s].length > 100 || /[\r\n]/.test(u[s])) throw new Error("\u8D26\u53F7\u5FC5\u8981\u5B57\u6BB5\u7F3A\u5931\u6216\u683C\u5F0F\u65E0\u6548\uFF0C\u505C\u6B62\u91C7\u7528");
    if (!/^[+\d ()-]*\*{2,}[\d ()-]+$/.test(u.phoneMask) || /登录|注册|验证码/.test(u.accountName)) throw new Error("\u8D26\u53F7\u6765\u6E90\u7F3A\u5C11\u6709\u6548\u7684\u53EF\u89C1\u59D3\u540D\u6216\u624B\u673A\u53F7\u63A9\u7801");
    if (typeof u.reason != "string" || !u.reason.trim()) throw new Error("\u8D26\u53F7\u7ED3\u679C\u7F3A\u5C11\u660E\u786E\u6838\u5BF9\u8BF4\u660E");
    const F = Date.parse(u.confirmedAt), C = Date.parse(u.checkedAt);
    if (typeof u.confirmedAt != "string" || typeof u.checkedAt != "string" || !Number.isFinite(F) || !Number.isFinite(C) || F <= 0 || C < F || C > Date.now() + 6e4) throw new Error("\u8D26\u53F7\u786E\u8BA4\u6216\u590D\u9A8C\u65F6\u95F4\u65E0\u6CD5\u6838\u5BF9\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4");
    if (typeof u.sourceUrl != "string" || typeof u.jobseekerResumeHref != "string" || !u.sourceUrl.trim() || !u.jobseekerResumeHref.trim() || u.sourceUrl.length > 16384 || u.jobseekerResumeHref.length > 16384) throw new Error("\u8D26\u53F7\u9875\u9762\u6216\u7B80\u5386\u5165\u53E3\u5730\u5740\u65E0\u6548");
    const r = new URL(u.sourceUrl), d = new URL(u.jobseekerResumeHref, u.sourceUrl);
    if (r.origin !== "https://www.zhipin.com" || r.pathname !== "/web/geek/account" || r.searchParams.get("type") !== "accountSet" || r.username || r.password || r.hash || d.origin !== r.origin || d.pathname !== "/web/geek/resume" || d.username || d.password) throw new Error("\u8D26\u53F7\u8BB0\u5F55\u7684\u9875\u9762\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u4E0D\u7B26");
    return B.throwIfAborted(), { version: 1, accountSourceValid: true, currentAccountVerified: false, account: u };
  };
  return a;
})(), ae = /* @__PURE__ */ (() => {
  async function a({ input: E, signal: B, template: o }) {
    B.throwIfAborted();
    const u = E?.expected?.account;
    if (E?.expected?.accountSourceValid !== true || u?.kind !== "boss-account-source" || u.status !== "account-source-confirmed" || u.accountVerified !== true) throw Error("\u7F3A\u5C11\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\u6765\u6E90");
    const f = async (h, b, g) => {
      B.throwIfAborted();
      const N = await o.browser("browser", { operation: h, ...b ? { selector: b } : {}, ...g === void 0 ? {} : { value: g }, timeoutMs: 3e3 });
      return B.throwIfAborted(), N;
    };
    let F = await f("url");
    if (F === "about:blank") {
      await f("navigate", void 0, u.sourceUrl);
      for (let h = 0; h < 40; h++) {
        const b = await f("url");
        if (new URL(b).origin === "https://www.zhipin.com" && await f("count", "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)") === 1) break;
        await new Promise((g) => setTimeout(g, 150));
      }
      F = await f("url");
    }
    const C = new URL(F);
    if (C.origin !== "https://www.zhipin.com" || C.username || C.password || !C.pathname.startsWith("/web/") && !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(C.pathname)) throw Error("\u5F53\u524D\u9875\u9762\u4E0D\u662FBOSS\u6C42\u804C\u9875\u9762\uFF0C\u8BF7\u5148\u767B\u5F55");
    const r = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", d = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)", s = await f("count", r), S = await f("count", d);
    if (s !== 1 || S !== 1) throw Error("\u5F53\u524D\u9875\u9762\u8D26\u53F7\u5165\u53E3\u6570\u91CF\u5F02\u5E38\uFF1A" + JSON.stringify({ nameCount: s, resumeCount: S }));
    const y = await f("read", r), D = await f("attribute", d, "href");
    if (typeof y != "string" || y.normalize("NFKC").trim() !== u.accountName.normalize("NFKC").trim() || typeof D != "string" || new URL(D, F).href !== new URL(u.jobseekerResumeHref, u.sourceUrl).href || await f("url") !== F) throw Error("\u5F53\u524D\u767B\u5F55\u8EAB\u4EFD\u3001\u6C42\u804C\u5165\u53E3\u6216\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
    return { version: 1, status: "current-account-source-matched", accountAlias: u.accountAlias, accountName: u.accountName, phoneMask: u.phoneMask, jobseekerResumeHref: u.jobseekerResumeHref, sourceUrl: u.sourceUrl, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), currentPageUrl: F, currentAccountVerified: true, platformUniqueIdVerified: false, eligibleForActions: false, accountCheckMode: "confirmed-initial-account-and-visible-header", phoneMaskRechecked: false, reason: "\u4F7F\u7528\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\uFF1B\u53EA\u8BFB\u6838\u5BF9\u5F53\u524D\u767B\u5F55\u59D3\u540D\u3001\u6C42\u804C\u5165\u53E3\u53CA\u9875\u9762\u8FDE\u7EED\u6027\uFF0C\u624B\u673A\u53F7\u63A9\u7801\u6CBF\u7528\u786E\u8BA4\u6765\u6E90\uFF0C\u6CA1\u6709\u91CD\u65B0\u8BFB\u53D6\u3002" };
  }
  return a;
})(), X = (a) => Array.isArray(a) ? a.map(X) : a && typeof a == "object" ? Object.fromEntries(Object.keys(a).sort().map((E) => [E, X(a[E])])) : a, O = (a) => W("sha256").update(JSON.stringify(X(a))).digest("hex");
async function se({ input: a, template: E, signal: B }) {
  B.throwIfAborted();
  const o = a?.configuration, u = a?.state;
  if (o?.operation !== "configuration" || u?.operation !== "state.read" || o.contextId !== u.contextId || !o.value || !u.value) throw Error("\u7F3A\u5C11\u540C\u5B9E\u4F8B\u56FA\u5B9A\u914D\u7F6E\u4E0E\u5B8C\u6574\u72B6\u6001");
  const f = await ie({ input: a.account, signal: B });
  await ae({ input: { expected: f }, template: E, signal: B });
  const F = f.account, C = new URL(F.jobseekerResumeHref, F.sourceUrl), r = W("sha256").update(JSON.stringify(["boss-visible-account-source-v1", F.accountName, F.phoneMask, C.origin + C.pathname])).digest("hex"), d = (e) => {
    const { sha256: t, ...I } = e;
    return t === O(I);
  }, s = async (e) => {
    try {
      return JSON.parse(await E.file("communication-cache", { operation: "read", name: e }));
    } catch (t) {
      if (String(t.message || t).includes("ENOENT")) return null;
      throw t;
    }
  }, S = async (e, t, I) => {
    if (((await s(e))?.sha256 || null) !== I) throw Error("\u6D88\u606F\u6536\u5C3E\u8BB0\u5F55\u88AB\u5176\u4ED6\u64CD\u4F5C\u66F4\u6539\uFF0C\u672A\u8986\u76D6");
    const K = { ...t };
    delete K.sha256, K.sha256 = O(K), await E.file("communication-cache", { operation: "write", name: e, content: JSON.stringify(K) });
    const U = await s(e);
    if (!d(U) || U.sha256 !== K.sha256) throw Error("\u6D88\u606F\u6536\u5C3E\u8BB0\u5F55\u5199\u5165\u540E\u672A\u5B8C\u6574\u8BFB\u56DE");
    return U;
  }, y = o.value.replyTimeZone, D = new Intl.DateTimeFormat("sv-SE", { timeZone: y, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date()), h = o.value.acceptanceNewGreetings === 2;
  if (h && a?.restoreExistingClosing === true) throw Error("\u4E24\u6B21\u65B0\u62DB\u547C\u6D4B\u8BD5\u4E0D\u5F97\u4F7F\u7528\u65E7\u6536\u5C3E\u6062\u590D\u5F00\u5173");
  const b = h ? O({ contextId: o.contextId, revision: o.revision, day: D, timeZone: y }).slice(0, 24) : null, g = await ne(E, B, { accountKey: r, contextId: o.contextId, day: D, timeZone: y, revision: o.revision, configuration: o.value });
  if (h && !g.confirmed) return { version: 1, kind: "unread-closing-cohort", closingPhase: false, ready: false, contextId: o.contextId, accountKey: r, day: D, timeZone: y, items: [], memberCount: 0, remaining: 0, status: "test-greeting-phase", testGreetingProgress: g, newGreeting: false, newMembersAdded: 0 };
  const N = h ? "test-greeting-completion-v1-" + r + "-" + b + ".json" : null;
  if (h) {
    const e = await s(N);
    if (e) {
      if (!d(e) || e.baselineSha256 !== g.baselineSha256 || O(e.confirmedKeys) !== O(g.confirmedKeys)) throw Error("\u4E24\u6B21\u62DB\u547C\u6D4B\u8BD5\u5B8C\u6210\u8BC1\u636E\u53D8\u5316\uFF0C\u505C\u6B62");
    } else await S(N, g, null);
  }
  const L = (h ? "test-active-unread-closing-v1-" + b + "-" : "active-unread-closing-v1-") + r + ".json";
  let c = await s(L);
  if (c && (!d(c) || c.kind !== "boss-active-unread-closing" || c.accountKey !== r || !/^\d{4}-\d{2}-\d{2}$/.test(c.day))) throw Error("\u6536\u5C3E\u6062\u590D\u6307\u9488\u8EAB\u4EFD\u6216\u6458\u8981\u65E0\u6548\uFF0C\u672A\u91CD\u5EFA");
  const w = a?.restoreExistingClosing === true;
  if (a?.restoreExistingClosing !== void 0 && typeof a.restoreExistingClosing != "boolean") throw Error("\u4EC5\u6062\u590D\u65E2\u6709\u6D88\u606F\u6536\u5C3E\u987B\u4E3A\u660E\u786E\u5F00\u5173");
  if (w && !c) throw Error("\u6CA1\u6709\u672C\u8D26\u53F7\u539F\u6536\u5C3E\u6307\u9488\uFF0C\u672A\u65B0\u5EFA\u96C6\u5408\u6216\u53D1\u9001\u62DB\u547C");
  const M = c?.sha256 || null;
  if (c && c.day !== D && !w) {
    const e = await s((h ? "test-fixed-unread-set-v1-" + b + "-" : "fixed-unread-set-v1-") + r + "-" + c.day + ".json"), t = await s((h ? "test-fixed-unread-progress-v1-" + b + "-" : "fixed-unread-progress-v1-") + r + "-" + c.day + ".json");
    if (!e || !t || !d(e) || !d(t) || e.sha256 !== c.fixedUnreadSetSha256 || t.fixedUnreadSetSha256 !== e.sha256 || t.accountKey !== r || !Array.isArray(e.members) || !Array.isArray(t.completed)) throw Error("\u5F80\u65E5\u6536\u5C3E\u6765\u6E90\u7F3A\u5931\u6216\u635F\u574F\uFF1B\u7981\u6B62\u91CD\u65B0\u6295\u9012");
    const I = new Set(e.members.map((p) => p.key));
    if (new Set(t.completed.map((p) => p.memberKey)).size !== t.completed.length || t.completed.some((p) => !I.has(p.memberKey))) throw Error("\u5F80\u65E5\u6536\u5C3E\u6210\u5458\u4E0D\u5B8C\u6574");
    !t.active && t.completed.length === e.members.length && t.completed.every((p) => p.status !== "review" || p.replyPolicyVersion === "work-questions-partial-known-v2") && (c = null);
  }
  const k = c?.day || D, n = h ? N : "site-daily-limit-v1-" + r + "-" + k + ".json", i = await s(n), J = (h ? "test-fixed-unread-set-v1-" + b + "-" : "fixed-unread-set-v1-") + r + "-" + k + ".json";
  let l = await s(J);
  if (!i && !c && !l) return { version: 1, kind: "unread-closing-cohort", closingPhase: false, ready: false, contextId: o.contextId, accountKey: r, day: k, timeZone: y, items: [], memberCount: 0, remaining: 0, status: "greeting-phase", newGreeting: false, newMembersAdded: 0 };
  if (!i || !d(i) || i.kind !== (h ? "boss-test-new-greeting-completion" : "boss-site-daily-limit") || i.accountKey !== r || i.confirmed !== true || i.day !== k || i.timeZone !== y) throw Error("\u672A\u627E\u5230\u672C\u8D26\u53F7\u771F\u5B9E\u7F51\u7AD9\u4E0A\u9650\u8BC1\u636E\uFF1B\u7981\u6B62\u91CD\u65B0\u6253\u62DB\u547C\u6216\u626B\u63CF\u5386\u53F2");
  if (w && !l) throw Error("\u539F\u56FA\u5B9A\u4F1A\u8BDD\u96C6\u5408\u7F3A\u5931\uFF0C\u672A\u626B\u63CF\u65B0\u589E\u6216\u91CD\u5EFA\u5386\u53F2");
  if (!l) {
    const e = async (A, v, R) => (B.throwIfAborted(), E.browser("browser", { operation: A, ...v ? { selector: v } : {}, ...R === void 0 ? {} : { value: R }, timeoutMs: 3e3 })), t = "https://www.zhipin.com/web/geek/chat", I = new URL(await e("url"));
    (I.origin !== new URL(t).origin || I.pathname !== "/web/geek/chat") && await e("navigate", null, t);
    const p = ".list-warp.v2 ul:has(> .selected)", K = p + " > :nth-child(2)", U = ".user-list-content > :first-child";
    let Y = false;
    for (let A = 0; A < 40; A++) {
      if (await e("count", K) === 1 && /^未读(?:\s*\(\d{1,4}\))?$/u.test(String(await e("read", K)).trim())) {
        Y = true;
        break;
      }
      await new Promise((v) => setTimeout(v, 250));
    }
    if (!Y) throw Error("\u7F51\u7AD9\u672A\u8BFB\u7B5B\u9009\u5165\u53E3\u672A\u5C31\u7EEA\uFF1B\u672A\u626B\u63CF\u5168\u90E8\u5386\u53F2");
    (await e("count", p + " .selected") !== 1 || !/^未读/u.test(String(await e("read", p + " .selected")).trim())) && await e("click", K);
    let x = null, H = 0;
    for (let A = 0; A < 40; A++) {
      if (await e("count", p + " .selected") === 1 && await e("count", U) === 1) {
        const v = String(await e("read", p + " .selected")).trim(), R = await e("count", U + " > *"), z = String(await e("read", U)), T = { tabText: v, count: R, text: z };
        if (/^未读(?:\s*\(\d{1,4}\))?$/u.test(v) && JSON.stringify(T) === JSON.stringify(x) ? H++ : H = 0, x = T, H >= 2) break;
      }
      await new Promise((v) => setTimeout(v, 250));
    }
    if (H < 2 || !x || !Number.isSafeInteger(x.count) || x.count < 0 || x.count > 200) throw Error("\u672A\u8BFB\u5217\u8868\u672A\u7A33\u5B9A\uFF0C\u672A\u56FA\u5B9A\u90E8\u5206\u96C6\u5408");
    const ee = /^未读\s*\((\d{1,4})\)$/u.exec(x.tabText), _ = ee ? Number(ee[1]) : 0, V = [];
    for (let A = 1; A <= x.count; A++) {
      const v = U + " > :nth-child(" + A + ")", R = String(await e("read", v)).trim(), z = v + " .friend-content";
      if (_ === 0 && await e("count", z) === 0 && /^(?:暂无消息|暂无未读消息|暂无未读会话|没有未读消息)$/u.test(R)) continue;
      if (R.length > 1e4 || await e("count", z) !== 1) throw Error("\u672A\u8BFB\u6210\u5458\u8EAB\u4EFD\u6216\u5B8C\u6574\u6B63\u6587\u65E0\u6CD5\u6838\u5BF9");
      const T = String(await e("read", z)).trim(), ue = R.split(/\r?\n/u).map((re) => re.trim()).filter(Boolean), Q = /^\d{1,4}$/u.test(ue[0] || "") ? Number(ue[0]) : null;
      if (!T || !Number.isSafeInteger(Q) || Q < 1) throw Error("\u672A\u8BFB\u6210\u5458\u8BA1\u6570\u65E0\u6CD5\u6838\u5BF9");
      V.push({ position: A, displayIdentity: T, unreadCount: Q, text: R, attributes: [], key: O(["boss-fixed-unread-visible-member-v1", r, T]) });
    }
    if (V.reduce((A, v) => A + v.unreadCount, 0) !== _ || new Set(V.map((A) => A.key)).size !== V.length) throw Error("\u672A\u8BFB\u4F1A\u8BDD\u96C6\u5408\u8986\u76D6\u6570\u91CF\u4E0D\u4E00\u81F4\uFF0C\u672A\u56FA\u5B9A\u90E8\u5206\u96C6\u5408");
    if (await e("url") !== t || String(await e("read", p + " .selected")).trim() !== x.tabText || await e("count", U + " > *") !== x.count || String(await e("read", U)) !== x.text || O(await E.state.get()) !== O(u.value)) throw Error("\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u524D\u6765\u6E90\u6216\u72B6\u6001\u53D8\u5316\uFF0C\u672A\u4FDD\u5B58");
    l = await S(J, { version: 1, kind: "boss-fixed-unread-set", accountKey: r, sourceContextId: o.contextId, day: k, timeZone: y, configurationRevision: o.revision, siteDailyLimitEvidenceName: n, siteDailyLimitEvidenceSha256: i.sha256, sourceUrl: t, selectedTabText: x.tabText, unreadMessageCount: _, members: V, createdAt: (/* @__PURE__ */ new Date()).toISOString(), membershipImmutable: true }, null);
  }
  if (!l || !d(l) || l.kind !== "boss-fixed-unread-set" || l.accountKey !== r || l.day !== k || l.siteDailyLimitEvidenceSha256 !== i.sha256 || !Array.isArray(l.members) || l.members.length > 200 || new Set(l.members.map((e) => e.key)).size !== l.members.length || l.members.reduce((e, t) => e + t.unreadCount, 0) !== l.unreadMessageCount) throw Error("\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u7F3A\u5931\u6216\u8986\u76D6\u6570\u91CF\u4E0D\u4E00\u81F4\uFF1B\u672A\u91CD\u5EFA\u6216\u6269\u5C55\u96C6\u5408");
  const j = l.members.map((e) => {
    const t = e.text.split(/\r?\n/u).map((I) => I.trim()).filter(Boolean);
    if (!/^[a-f0-9]{64}$/.test(e.key) || !/^\d+$/.test(t[0]) || !t[2] || t[2].length > 500) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u53EF\u89C1\u8EAB\u4EFD\u7F3A\u5931");
    return { ...e, identityLine: t[2] };
  });
  if (new Set(j.map((e) => e.identityLine)).size !== j.length) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u5B58\u5728\u540C\u540D\u540C\u516C\u53F8\u8EAB\u4EFD\u6B67\u4E49\uFF0C\u7981\u6B62\u731C\u6D4B");
  const te = "account-outbound-safety-v1-" + r + ".json", P = await s(te);
  if (!P || !d(P) || P.kind !== "boss-account-outbound-safety" || P.accountKey !== r || !Array.isArray(P.records) || !P.records.length) throw Error("\u539F\u8D26\u53F7\u5916\u53D1\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF0C\u963B\u6B62\u7EED\u53D1");
  if (c && (c.fixedUnreadSetSha256 !== l.sha256 || c.siteDailyLimitEvidenceSha256 !== i.sha256)) throw Error("\u6062\u590D\u6307\u9488\u4E0E\u56FA\u5B9A\u96C6\u5408\u4E0D\u7B26");
  c || (c = await S(L, { version: 1, kind: "boss-active-unread-closing", accountKey: r, day: k, timeZone: y, fixedUnreadSetSha256: l.sha256, siteDailyLimitEvidenceSha256: i.sha256, createdAt: (/* @__PURE__ */ new Date()).toISOString() }, M));
  const $ = (h ? "test-fixed-unread-progress-v1-" + b + "-" : "fixed-unread-progress-v1-") + r + "-" + k + ".json";
  let m = await s($);
  if (m && (!d(m) || m.kind !== "boss-fixed-unread-progress" || m.accountKey !== r || m.fixedUnreadSetSha256 !== l.sha256 || !Array.isArray(m.completed) || m.completed.some((e) => !j.some((t) => t.key === e.memberKey)) || new Set(m.completed.map((e) => e.memberKey)).size !== m.completed.length || m.active && !j.some((e) => e.key === m.active.memberKey))) throw Error("\u6536\u5C3E\u8FDB\u5EA6\u8EAB\u4EFD\u3001\u6458\u8981\u6216\u6210\u5458\u65E0\u6548");
  if (w && !m) throw Error("\u539F\u6D88\u606F\u6536\u5C3E\u8FDB\u5EA6\u7F3A\u5931\uFF0C\u672A\u91CD\u5EFA\u6216\u91CD\u653E");
  m || (m = await S($, { version: 1, kind: "boss-fixed-unread-progress", accountKey: r, day: k, timeZone: y, fixedUnreadSetSha256: l.sha256, revision: 0, active: null, completed: [], createdAt: (/* @__PURE__ */ new Date()).toISOString() }, null));
  const G = (e) => !oe(e) && (e.status !== "review" || e.replyPolicyVersion === "work-questions-partial-known-v2"), q = m.active ? j.find((e) => e.key === m.active.memberKey) : j.find((e) => !m.completed.some((t) => t.memberKey === e.key && G(t))), Z = { version: 1, kind: "unread-closing-cohort", restoredExistingClosing: w, closingPhase: true, ready: !!q, contextId: o.contextId, accountKey: r, accountSource: f, configuration: o.value, configurationRevision: o.revision, siteDailyLimitEvidence: h ? null : i, testCompletionEvidence: h ? i : null, closingTrigger: h ? "two-new-greetings-test" : "real-site-daily-limit", fixedUnreadSetName: J, fixedUnreadSetSha256: l.sha256, member: q || null, memberCount: j.length, unreadMessageCount: l.unreadMessageCount, progressName: $, progressSha256: m.sha256, progress: m, remaining: j.length - m.completed.filter(G).length, status: q ? "resume-fixed-unread" : "fixed-unread-complete", newGreeting: false, newMembersAdded: 0 };
  if (O(await E.state.get()) !== O(u.value)) throw Error("\u51C6\u5907\u6536\u5C3E\u671F\u95F4\u6B63\u5F0F\u72B6\u6001\u53D8\u5316\uFF0C\u672A\u7EE7\u7EED");
  return Z.items = j.filter((e) => !m.completed.some((t) => t.memberKey === e.key && G(t))).sort((e, t) => +(t.key === m.active?.memberKey) - +(e.key === m.active?.memberKey)).map((e) => ({ ...Z, member: e, ready: true })), Z;
}
export {
  se as default
};
