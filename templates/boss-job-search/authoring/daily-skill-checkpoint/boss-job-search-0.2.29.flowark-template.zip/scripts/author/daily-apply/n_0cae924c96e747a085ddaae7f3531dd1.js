import { createHash } from "node:crypto";
var stdin_default = async ({ input, signal }) => {
  signal.throwIfAborted();
  const obj = (v) => !!v && typeof v === "object" && !Array.isArray(v);
  const hash = (v) => createHash("sha256").update(v).digest("hex");
  if (!obj(input) || Object.keys(input).sort().join(",") !== "candidate,configuration,hardConditions,ledger") throw Error("\u7F3A\u5C11\u672C\u9879\u5019\u9009\u3001\u56FA\u5B9A\u914D\u7F6E\u3001\u786C\u6761\u4EF6\u6216\u6700\u65B0\u8D26\u672C");
  const { candidate: c, configuration: raw, hardConditions: h, ledger: l } = input, q = raw?.value;
  if (!obj(raw) || raw.version !== 1 || raw.operation !== "configuration" || !Number.isSafeInteger(raw.revision) || raw.revision < 0 || typeof raw.contextId !== "string" || !obj(q) || !Array.isArray(q.cities) || !Array.isArray(q.targetRoles) || !q.targetRoles.length || !Array.isArray(q.excludedRoles)) throw Error("\u672C\u6B21\u56FA\u5B9A\u6C42\u804C\u914D\u7F6E\u65E0\u6548");
  if (!obj(c) || c.version !== 1 || c.kind !== "daily-verified-jd-candidate" || c.status !== "candidate-source-and-return-verified" || c.sourceCollected !== true || c.listReturned !== true || c.returnCityVerified !== true || c.returnCandidateIdentityVerified !== true || c.currentDetailSelected !== true || c.candidateJobCityVerified !== true || c.descriptionComplete !== false || c.externalAppearanceVerified !== false || c.eligibleForActions !== false) throw Error("\u672C\u9879\u6765\u6E90\u4E0D\u662F\u5DF2\u6838\u5BF9\u8FD4\u56DE\u8EAB\u4EFD\u7684\u6587\u5B57\u5019\u9009");
  if (!obj(h) || h.kind !== "daily-job-hard-conditions" || h.status !== "hard-conditions-ready-for-skill" || h.readyForSkillAssessment !== true || !obj(l) || l.kind !== "daily-application-ledger-check" || l.status !== "ledger-ready-for-skill" || l.readyForSkillAssessment !== true || l.existingIntent !== null || !Array.isArray(l.issues) || l.issues.length || !Number.isSafeInteger(l.stateRevision) || l.stateRevision < 0 || l.contextId !== raw.contextId || !Number.isSafeInteger(l.quota?.remaining) || l.quota.remaining < 1) throw Error("\u786C\u6761\u4EF6\u6216\u6700\u65B0\u8D26\u672C\u672A\u5141\u8BB8\u672C\u9879\u8FDB\u5165\u8BC4\u4F30");
  if ([c, h, l].some((v) => v.configurationRevision !== raw.revision || v.jobSource !== c.jobSource || v.jobTitle !== c.jobTitle || v.actualCity !== c.actualCity || v.jobCity !== c.jobCity || v.eligibleForActions !== false) || c.actualCity !== c.jobCity || !q.cities.includes(c.actualCity) || JSON.stringify(c.configuredCities) !== JSON.stringify(q.cities) || h.configuredDay !== c.configuredDay || l.day !== c.configuredDay || l.timeZone !== c.timeZone) throw Error("\u672C\u9879\u5C97\u4F4D\u3001\u57CE\u5E02\u3001\u65E5\u671F\u6216\u56FA\u5B9A\u4FEE\u8BA2\u4E0D\u4E00\u81F4");
  const page = new URL(c.jobSource);
  if (page.protocol !== "https:" || page.hostname !== "www.zhipin.com" || page.port || page.username || page.password || page.search || page.hash || !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(page.pathname)) throw Error("\u804C\u4F4D\u6765\u6E90\u5730\u5740\u65E0\u6548");
  const day = new Intl.DateTimeFormat("sv-SE", { timeZone: c.timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
  if (day !== c.configuredDay) throw Error("\u5DF2\u8DE8\u5929\uFF0C\u91CD\u65B0\u51C6\u5907\u672C\u6279\u914D\u7F6E\u4E0E\u8D26\u672C");
  if (typeof c.description !== "string" || !c.description.trim() || hash(c.description) !== c.descriptionHash || c.descriptionHash !== h.descriptionHash) throw Error("\u672C\u9879\u6B63\u6587\u4E0E\u5DF2\u6838\u5BF9\u6765\u6E90\u6458\u8981\u4E0D\u4E00\u81F4");
  const issues = [];
  if (c.description.length > 2e4) issues.push("\u672C\u9879\u6B63\u6587\u8D85\u8FC7\u8BC4\u4F30\u8F93\u5165\u4E0A\u9650\uFF1B\u4E0D\u622A\u65AD\u6216\u731C\u6D4B");
  if (typeof c.jobTitle !== "string" || !c.jobTitle.trim() || c.jobTitle.length > 200) issues.push("\u804C\u4F4D\u6807\u9898\u7F3A\u5931\u6216\u8D85\u9650");
  if (typeof c.companyLabel !== "string" || !c.companyLabel.trim() || c.companyLabel.length > 256) issues.push("\u516C\u53F8\u6765\u6E90\u7F3A\u5931\u6216\u8D85\u9650");
  const source = { kind: "daily-bounded-selection-candidate", title: c.jobTitle, jobSource: c.jobSource, company: c.companyLabel, descriptionSha256: c.descriptionHash, sourceLabel: c.jobSource, completeDeclared: false, externalAppearanceVerified: false, configurationRevision: raw.revision, contextId: raw.contextId, actualCity: c.actualCity, day, timeZone: c.timeZone, ledgerStateRevision: l.stateRevision, applicationKey: l.key, accountSourceSha256: l.accountSourceSha256 };
  const result = { kind: "job-assessment-advice", decision: "review", nextAction: "ask-user", reason: "\u672C\u9879\u5019\u9009\u9700\u672C\u4EBA\u6838\u5BF9", issues, source, accountVerified: false, eligibleForActions: false, createdAt: (/* @__PURE__ */ new Date()).toISOString() };
  return { ready: issues.length === 0, job: { title: c.jobTitle, description: c.description, completeDeclared: false, externalAppearanceVerified: false, company: c.companyLabel, city: c.jobCity, salaryRaw: c.salaryRaw, sourceLabel: c.jobSource }, configuration: q, source, reviewRecord: { reviewKey: "daily-jd-input:" + hash(JSON.stringify({ source, issues })), result } };
};
export {
  stdin_default as default
};
