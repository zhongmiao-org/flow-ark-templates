import { createHash } from "node:crypto";
const canonical = (v) => Array.isArray(v) ? v.map(canonical) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical(v[k])])) : v;
const digest = (v) => createHash("sha256").update(JSON.stringify(canonical(v))).digest("hex");
const compact = (v) => String(v).replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
const reader = (template, signal) => async (operation, selector, value) => {
  signal.throwIfAborted();
  return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
};
const optional = async (template, name) => {
  try {
    return await template.file("communication-cache", { operation: "read", name });
  } catch (e) {
    if (String(e.message || e).includes("ENOENT")) return null;
    throw e;
  }
};
async function deliveryIndex(template, source) {
  const name = "resume-delivery-index-v1-" + source.accountKey + ".json", raw = await optional(template, name);
  let value = raw === null ? { version: 1, kind: "boss-resume-delivery-index", accountKey: source.accountKey, revision: 0, uploads: [], deliveries: [] } : JSON.parse(raw);
  if (raw !== null) {
    const { sha256, ...body } = value;
    if (sha256 !== digest(body)) throw Error("\u9644\u4EF6\u8D26\u672C\u6458\u8981\u65E0\u6548\uFF0C\u672A\u91CD\u5EFA");
  }
  if (value.version !== 1 || value.kind !== "boss-resume-delivery-index" || value.accountKey !== source.accountKey || !Number.isSafeInteger(value.revision) || !Array.isArray(value.uploads) || !Array.isArray(value.deliveries) || value.uploads.length > 100 || value.deliveries.length > 2e3 || new Set(value.uploads.map((v) => v.key)).size !== value.uploads.length || new Set(value.deliveries.map((v) => v.key)).size !== value.deliveries.length) throw Error("\u9644\u4EF6\u8D26\u672C\u8EAB\u4EFD\u3001\u5BB9\u91CF\u6216\u552F\u4E00\u6027\u65E0\u6548\uFF0C\u539F\u8BB0\u5F55\u4FDD\u7559");
  return { name, raw, value };
}
async function saveDeliveryIndex(template, index) {
  if (await optional(template, index.name) !== index.raw) throw Error("\u9644\u4EF6\u8D26\u672C\u5DF2\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  index.value.revision++;
  index.value.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  delete index.value.sha256;
  index.value.sha256 = digest(index.value);
  await template.file("communication-cache", { operation: "write", name: index.name, content: JSON.stringify(index.value) });
  const raw = await optional(template, index.name), back = JSON.parse(raw), { sha256, ...body } = back;
  if (sha256 !== digest(body) || sha256 !== index.value.sha256) throw Error("\u9644\u4EF6\u8D26\u672C\u672A\u5B8C\u6574\u8BFB\u56DE");
  index.raw = raw;
  return { name: index.name, sha256, revision: back.revision };
}
async function requestSame(read, source) {
  const u = new URL(await read("url"));
  return u.origin === "https://www.zhipin.com" && u.pathname === "/web/geek/chat" && await read("count", ".chat-conversation .user-info") === 1 && compact(await read("read", ".chat-conversation .user-info")) === compact(source.recipientLabel) && await read("count", source.request.agreeSelector) === 1 && String(await read("read", source.request.agreeSelector)).trim() === "\u540C\u610F" && await read("count", source.request.root) === 1 && String(await read("read", source.request.root)).trim() === source.request.text && String(await read("read", ".chat-position-content")).trim() === source.chatJobTitle;
}
function pdfSource(document) {
  const s = document?.source;
  if (document?.version !== 1 || document.status !== "ready" || s?.format !== "pdf" || s.binding !== "resume-materials" || !s.name?.toLowerCase().endsWith(".pdf") || !Number.isSafeInteger(s.byteLength) || s.byteLength < 1 || s.byteLength > 8388608 || !/^[a-f0-9]{64}$/.test(s.sha256)) throw Error("\u987B\u9009\u62E9\u5B8C\u6574\u53EF\u8BFB\u30018MiB\u4EE5\u5185\u7684\u51C6\u786EPDF\u6587\u4EF6\uFF1B\u4E0D\u56DE\u9000DOCX\u6216\u5176\u4ED6\u7248\u672C");
  return { binding: s.binding, name: s.name, displayName: s.name.split("/").at(-1), byteLength: s.byteLength, sha256: s.sha256 };
}
async function attachmentRoot(read) {
  const selector = ".resume-attachment";
  if (await read("count", selector) !== 1 || await read("count", selector + " > h3") !== 1 || !String(await read("read", selector + " > h3")).trim().startsWith("\u9644\u4EF6\u7BA1\u7406")) throw Error("\u7F51\u7AD9\u9644\u4EF6\u7BA1\u7406\u7ED3\u6784\u5C1A\u672A\u6838\u5BF9\uFF0C\u672A\u64CD\u4F5C");
  return selector;
}
async function fileLibrary(read, file) {
  const root = await attachmentRoot(read), list = root + " > .annex-list > :nth-child(2) > .annex-item", count = await read("count", list);
  if (!Number.isSafeInteger(count) || count < 0 || count > 3) throw Error("\u9644\u4EF6\u5E93\u6587\u4EF6\u6570\u91CF\u65E0\u6CD5\u6838\u5BF9");
  const rows = [];
  for (let n = 1; n <= count; n++) {
    const selector = list + ":nth-child(" + n + ")", text = String(await read("read", selector)).trim();
    if (text.length > 4e3) throw Error("\u9644\u4EF6\u6761\u76EE\u8FC7\u957F\uFF0C\u672A\u622A\u65AD");
    rows.push({ selector, text });
  }
  const matches = rows.filter((r) => r.text.split(/\r?\n/u).map((v) => v.trim()).includes(file.displayName));
  if (matches.length > 1) throw Error("\u9644\u4EF6\u5E93\u6709\u540C\u540D\u6587\u4EF6\uFF0C\u7981\u6B62\u6309\u4F4D\u7F6E\u53D1\u9001");
  return { root, count, rows, match: matches[0] || null };
}
async function findText(read, root, text) {
  const matches = [];
  let visits = 0;
  const walk = async (selector, depth2) => {
    if (++visits > 40 || depth2 > 7) throw Error("\u63A7\u4EF6\u7ED3\u6784\u8D85\u51FA\u6709\u9650\u6838\u5BF9\u8303\u56F4");
    const content = String(await read("read", selector)).trim(), count = await read("count", selector + " > *");
    if (content === text) matches.push({ selector, depth: depth2 });
    if (count > 10) throw Error("\u63A7\u4EF6\u5206\u652F\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
    for (let n = 1; n <= count; n++) await walk(selector + " > :nth-child(" + n + ")", depth2 + 1);
  };
  await walk(root, 0);
  if (!matches.length) throw Error("\u672A\u627E\u5230\u51C6\u786E\u64CD\u4F5C\u6587\u5B57\uFF1A" + text);
  const depth = Math.max(...matches.map((v) => v.depth)), last = matches.filter((v) => v.depth === depth);
  if (last.length !== 1) throw Error("\u64CD\u4F5C\u6587\u5B57\u4E0D\u552F\u4E00\uFF0C\u672A\u70B9\u51FB");
  return last[0].selector;
}
async function restoreRequestChat(read, source) {
  const compact2 = (v) => String(v).replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
  const same = async () => {
    const u = new URL(await read("url"));
    return u.origin === "https://www.zhipin.com" && u.pathname === "/web/geek/chat" && await read("count", ".chat-conversation .user-info") === 1 && compact2(await read("read", ".chat-conversation .user-info")) === compact2(source.recipientLabel) && await read("count", source.request.agreeSelector) === 1;
  };
  if (await same()) return;
  await read("navigate", void 0, "https://www.zhipin.com/web/geek/chat");
  const inputSelector = ".list-warp.v2 input";
  let ready = false;
  for (let n = 0; n < 40; n++) {
    if (await read("count", inputSelector) === 1) {
      ready = true;
      break;
    }
    await new Promise((r) => setTimeout(r, 150));
  }
  if (!ready) throw Error("\u539F\u4F1A\u8BDD\u5B9A\u5411\u641C\u7D22\u5C1A\u672A\u52A0\u8F7D\uFF0C\u672A\u9009\u62E9\u5176\u4ED6\u4F1A\u8BDD");
  if (await same()) return;
  await read("fill", inputSelector, source.recipientName);
  const root = ".boss-search-result .search-list";
  let matches = [];
  for (let n = 0; n < 30; n++) {
    const count = await read("count", root);
    if (!Number.isSafeInteger(count) || count > 50) throw Error("\u8054\u7CFB\u4EBA\u5B9A\u5411\u641C\u7D22\u8303\u56F4\u65E0\u6548");
    matches = [];
    for (let j = 1; j <= count; j++) {
      const selector = root + ":nth-child(" + j + " of .search-list)", text = String(await read("read", selector)).trim();
      if (compact2(text).includes(compact2(source.recipientLabel))) matches.push({ selector, text });
    }
    if (matches.length) break;
    await new Promise((r) => setTimeout(r, 150));
  }
  if (matches.length !== 1) throw Error("\u672A\u627E\u5230\u552F\u4E00\u7684\u539F\u59D3\u540D\u3001\u516C\u53F8\u548C\u89D2\u8272\u7EC4\u5408\uFF0C\u672A\u6253\u5F00\u5176\u4ED6\u4F1A\u8BDD");
  const target = matches[0];
  if (String(await read("read", target.selector)).trim() !== target.text) throw Error("\u539F\u8054\u7CFB\u4EBA\u641C\u7D22\u7ED3\u679C\u53D8\u5316\uFF0C\u672A\u70B9\u51FB");
  await read("click", target.selector);
  ready = false;
  for (let n = 0; n < 40; n++) {
    if (await same()) {
      ready = true;
      break;
    }
    await new Promise((r) => setTimeout(r, 150));
  }
  if (!ready) throw Error("\u539F\u4F1A\u8BDD\u3001\u539F\u9644\u4EF6\u8BF7\u6C42\u672A\u91CD\u65B0\u8BFB\u56DE\uFF0C\u4E0D\u53D1\u9001");
}
function uploadVerified(upload, file) {
  return !!upload && digest(upload.file) === digest(file) && (upload.status === "confirmed" || upload.verification?.state === "confirmed" && upload.verification.evidence?.kind === "boss-resume-upload-observation" && upload.verification.evidence.originalEffectId === upload.effectId && digest(upload.verification.evidence.file) === digest(file));
}
function attachmentReceiptName(row, file) {
  if (!row?.class?.split(/\s/u).includes("item-system") || !/^[0-9]{6,40}$/.test(row.mid || "")) return null;
  const match = /您的附件简历\s+(.+?)\s+已发送给Boss(?:点击查看附件)?/u.exec(row.text || "");
  if (!match) return null;
  const shown = match[1].trim(), normalized = shown.normalize("NFKC"), full = file.displayName.normalize("NFKC");
  if (normalized === full) return { shown, serverNameTruncated: false };
  if (normalized.endsWith("...")) {
    const prefix = normalized.slice(0, -3);
    if (prefix.length >= 2 && full.startsWith(prefix)) return { shown, serverNameTruncated: true };
  }
  return null;
}
async function stdin_default({ input, template, signal, artifact }) {
  const source = input?.source;
  if (source?.kind !== "boss-resume-request-source") throw Error("\u7F3A\u5C11\u5F53\u524D\u51C6\u786E\u9644\u4EF6\u8BF7\u6C42\u6765\u6E90");
  if (!source.ready) {
    const result2 = { ...source, execute: false, needsUpload: false, websiteUploads: 0, websiteMessagesSent: 0 };
    await template.result(result2);
    return result2;
  }
  const file = pdfSource(input.document), read = reader(template, signal);
  if (!await requestSame(read, source)) throw Error("PDF\u6838\u5BF9\u671F\u95F4\u4F1A\u8BDD\u6216\u539F\u8BF7\u6C42\u53D8\u5316\uFF0C\u672A\u4E0A\u4F20\u6216\u53D1\u9001");
  const current = await template.state.get();
  if ((current.conversationControls || []).some((c) => c.accountKey === source.accountKey && [source.conversationKey, "boss-chat:" + source.firstMessageId].includes(c.conversationKey) && c.mode === "paused")) throw Error("\u672C\u4EBA\u5DF2\u63A5\u7BA1\uFF0C\u4E0D\u6267\u884C\u9644\u4EF6\u64CD\u4F5C");
  const index = await deliveryIndex(template, source), previous = index.value.deliveries.find((v) => v.key === source.requestKey);
  if (previous?.effectId && previous.sendKey) {
    if (digest(previous.file) !== digest(file) || compact(previous.recipientLabel) !== compact(source.recipientLabel) || previous.requestMid !== source.request.mid || previous.firstMessageId !== source.firstMessageId) throw Error("\u539F\u53D1\u9001\u64CD\u4F5C\u4E0E\u672C\u6B21\u6587\u4EF6\u6216\u5BF9\u8C61\u4E0D\u7B26\uFF0C\u4E0D\u91CD\u590D\u53D1\u9001");
    const candidates = source.rows.filter((r) => BigInt(r.mid) > BigInt(previous.requestMid) && attachmentReceiptName(r, file));
    if (candidates.length !== 1) throw Error("\u539F\u53D1\u9001\u5DF2\u6709\u64CD\u4F5C\u8BB0\u5F55\uFF0C\u5C1A\u672A\u627E\u5230\u552F\u4E00\u540C\u4F1A\u8BDD\u7F51\u7AD9\u56DE\u6267\uFF1B\u4FDD\u7559\u672A\u77E5\uFF0C\u4E0D\u91CD\u53D1");
    const row = candidates[0], siteName = attachmentReceiptName(row, file);
    if (previous.verification?.state !== "confirmed") {
      const key = digest(["boss-resume-delivery-observation-v1", source.accountKey, previous.key, row.mid, file.sha256]);
      const verification = await template.effect.prepare({ action: "send-resume", key, description: "\u72EC\u7ACB\u6838\u5BF9\u539F\u9644\u4EF6\u5DF2\u9001\u8FBE\uFF0C\u4E0D\u91CD\u65B0\u53D1\u9001\uFF0C\u4FDD\u7559\u539Funknown", review: { version: 1, target: source.recipientLabel + "\n" + source.jobSource + "\n\u7F51\u7AD9\u56DE\u6267 " + row.mid, content: file.displayName + "\n" + file.byteLength + " bytes\nSHA-256 " + file.sha256 + "\n\u539F\u53D1\u9001\u64CD\u4F5C " + previous.effectId + "\n\u7F51\u7AD9\u56DE\u6267\uFF1A" + row.text + "\n\u8BF7\u5BF9\u7167\u539F\u8FD0\u884C\u51C6\u786E\u6587\u4EF6\u9009\u62E9\u548C\u5355\u6B21\u53D1\u9001\u8BB0\u5F55\uFF0C\u5E76\u4ECE\u672C\u6761\u56DE\u6267\u6253\u5F00\u9644\u4EF6\u9884\u89C8\u6838\u5BF9\u5B8C\u6574\u5185\u5BB9\u3002\u786E\u8BA4\u540E\u53EA\u767B\u8BB0\u672C\u6B21\u72EC\u7ACB\u4E8B\u5B9E\u6838\u9A8C\uFF1B\u4FDD\u7559\u539F\u672A\u77E5\u8BB0\u5F55\uFF0C\u4E0D\u91CD\u65B0\u4E0A\u4F20\u6216\u53D1\u9001\uFF0C\u4E0D\u628A\u7F29\u7565\u540D\u79F0\u5355\u72EC\u5F53\u4F5C\u5B8C\u6574\u6587\u4EF6\u8EAB\u4EFD\u3002" } });
      if (!verification.execute) throw Error("\u5DF2\u6709\u56DE\u6267\u6838\u5BF9\u8BB0\u5F55\uFF0C\u672A\u91CD\u590D\u51C6\u5907\uFF1B\u8BF7\u67E5\u770B\u539F\u7ED3\u679C");
      if (!await requestSame(read, source) || String(await read("read", 'li.message-item[data-mid="' + row.mid + '"]')).trim() !== row.text) throw Error("\u6838\u5BF9\u671F\u95F4\u539F\u56DE\u6267\u6216\u4F1A\u8BDD\u53D8\u5316\uFF0C\u672A\u767B\u8BB0\u6210\u529F");
      const evidence = { version: 1, kind: "boss-resume-delivery-observation", originalEffectId: previous.effectId, originalStatePreserved: true, requestMid: previous.requestMid, recipientLabel: source.recipientLabel, jobSource: source.jobSource, file, websiteReceipt: row, siteName, reviewMethod: "original-exact-file-selection-and-preview-from-same-receipt", checkedAt: (/* @__PURE__ */ new Date()).toISOString(), websiteMessagesSent: 0, observedPreviouslySent: 1 };
      await artifact("resume-existing-delivery-observation.json", JSON.stringify(evidence, null, 2));
      await template.effect.resolve({ id: verification.id, state: "confirmed", evidence });
      previous.verification = { state: "confirmed", effectId: verification.id, evidence };
      await saveDeliveryIndex(template, index);
    } else if (previous.verification.evidence?.websiteReceipt?.mid !== row.mid || digest(previous.verification.evidence.file) !== digest(file)) throw Error("\u65E2\u6709\u72EC\u7ACB\u56DE\u6267\u6838\u5BF9\u4E0D\u7B26\uFF0C\u672A\u6539\u5199");
    const result2 = { version: 1, kind: "resume-send-result", execute: false, needsUpload: false, status: "previous-delivery-verified", originalEffectStateUnchanged: true, receipt: previous.verification.evidence, websiteUploads: 0, websiteMessagesSent: 0, observedPreviouslySent: 1, aiCalled: false };
    await template.result(result2);
    return result2;
  }
  if (previous) {
    const upload = index.value.uploads.find((v) => v.key === previous.uploadKey);
    if (previous.status !== "reserved" || previous.effectId || previous.sendKey || previous.sourceSha256 !== source.sourceSha256 || digest(previous.file) !== digest(file) || !upload || digest(upload.file) !== digest(file)) {
      const result3 = { version: 1, kind: "resume-send-result", execute: false, needsUpload: false, status: "existing-resume-intent", previousStatus: previous.status, reason: "\u539F\u8BF7\u6C42\u5DF2\u6709\u5B9E\u9645\u53D1\u9001\u51C6\u5907\u3001\u672A\u77E5\u3001\u5931\u8D25\u6216\u786E\u8BA4\u8BB0\u5F55\uFF0C\u4E0D\u91CD\u653E", websiteUploads: 0, websiteMessagesSent: 0 };
      await template.result(result3);
      return result3;
    }
    if (!uploadVerified(upload, file)) {
      await read("navigate", void 0, "https://www.zhipin.com/web/geek/resume");
      let library;
      for (let n = 0; n < 40; n++) {
        try {
          library = await fileLibrary(read, file);
          if (library.match) break;
        } catch (e) {
          if (n === 39) throw e;
        }
        await new Promise((r) => setTimeout(r, 150));
      }
      const account = async () => new URL(await read("url")).href === "https://www.zhipin.com/web/geek/resume" && await read("count", ".nav-figure") === 1 && String(await read("read", ".nav-figure")).trim() === source.accountSource.account.accountName;
      if (!library?.match || !await account()) throw Error("\u539F\u4E0A\u4F20\u5C1A\u672A\u5728\u672C\u4EBA\u9644\u4EF6\u5E93\u6838\u9A8C\uFF1B\u4FDD\u7559\u672A\u77E5\uFF0C\u4E0D\u91CD\u65B0\u4E0A\u4F20");
      const verificationKey = digest(["boss-resume-upload-observation-v1", source.accountKey, upload.key, upload.effectId, file.sha256]);
      const verification = await template.effect.prepare({ action: "send-resume", key: verificationKey, description: "\u72EC\u7ACB\u6838\u5BF9\u5DF2\u5B58\u5728\u7684\u51C6\u786EPDF\u4E0A\u4F20\uFF0C\u4E0D\u91CD\u65B0\u4E0A\u4F20\uFF0C\u4E0D\u66F4\u6539\u539Funknown", review: { version: 1, target: "\u672C\u4EBABOSS\u9644\u4EF6\u5E93\u5DF2\u6709\u6587\u4EF6 \xB7 " + source.accountSource.account.accountName, content: file.displayName + "\n" + file.byteLength + " bytes\nSHA-256 " + file.sha256 + "\n\u539F\u4E0A\u4F20\u64CD\u4F5C " + upload.effectId + "\n\u8BF7\u5BF9\u7167\u539F\u8FD0\u884C\u7684\u4E0A\u4F20\u524D\u540E\u6587\u4EF6\u6458\u8981\u3001\u7F51\u7AD9\u9644\u4EF6\u9884\u89C8\u3001\u540D\u79F0\u4E0E\u5927\u5C0F\uFF0C\u786E\u8BA4\u8FD9\u4EFD\u51C6\u786E\u6587\u4EF6\u5DF2\u7ECF\u6DFB\u52A0\u5230\u9644\u4EF6\u5E93\u3002\u4EC5\u8BB0\u5F55\u672C\u6B21\u4E8B\u5B9E\u6838\u5BF9\uFF0C\u539F\u672A\u77E5\u8BB0\u5F55\u4FDD\u7559\uFF1B\u672C\u6B21\u4E0D\u91CD\u65B0\u4E0A\u4F20\uFF0C\u4E5F\u4E0D\u4EE3\u8868\u62DB\u8058\u65B9\u6536\u5230\u3002" } });
      if (!verification.execute) throw Error("\u5DF2\u6709\u9644\u4EF6\u6838\u5BF9\u8BB0\u5F55\uFF0C\u4E0D\u91CD\u65B0\u51C6\u5907\u6216\u91CD\u4F20\uFF1B\u8BF7\u6838\u5BF9\u539F\u7ED3\u679C");
      const latest = await fileLibrary(read, file);
      if (!await account() || latest.match?.text !== library.match.text) throw Error("\u786E\u8BA4\u671F\u95F4\u9644\u4EF6\u6216\u8D26\u53F7\u53D8\u5316\uFF0C\u672A\u91C7\u7528");
      const evidence = { version: 1, kind: "boss-resume-upload-observation", originalEffectId: upload.effectId, originalStatePreserved: true, file, libraryRow: latest.match.text, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), websiteUploads: 0, recipientSent: false };
      await artifact("resume-existing-upload-observation.json", JSON.stringify(evidence, null, 2));
      await template.effect.resolve({ id: verification.id, state: "confirmed", evidence });
      upload.verification = { state: "confirmed", effectId: verification.id, evidence };
      await saveDeliveryIndex(template, index);
    }
    const result2 = { version: 1, kind: "resume-send-preparation", execute: true, needsUpload: false, source, file, uploadKey: upload.key, uploadEffect: null, ledger: { name: index.name, sha256: index.value.sha256, revision: index.value.revision }, resumedBeforeFirstSend: true, websiteUploads: 0, websiteMessagesSent: 0, aiCalled: false };
    await artifact("resume-preparation.json", JSON.stringify(result2, null, 2));
    await template.result({ version: 1, kind: "resume-send-result", status: "existing-upload-verified-not-sent", file, websiteUploads: 0, websiteMessagesSent: 0 });
    return result2;
  }
  const uploadKey = digest(["boss-resume-upload-v1", source.accountKey, file.sha256, file.displayName]), known = index.value.uploads.find((v) => v.key === uploadKey);
  let uploadEffect = null, needsUpload = !known;
  if (known && known.status !== "confirmed") throw Error("\u672CPDF\u5DF2\u6709\u672A\u6838\u5BF9\u4E0A\u4F20\uFF0C\u4E0D\u81EA\u52A8\u91CD\u8BD5\uFF1B\u8BF7\u5148\u6838\u5BF9\u539F\u4E0A\u4F20\u7ED3\u679C");
  if (needsUpload) {
    await read("navigate", null, "https://www.zhipin.com/web/geek/resume");
    let root;
    for (let n = 0; n < 40; n++) {
      try {
        root = await attachmentRoot(read);
        break;
      } catch (e) {
        if (n === 39) throw e;
      }
      await new Promise((r) => setTimeout(r, 150));
    }
    const library = await fileLibrary(read, file);
    if (library.count >= 3 || library.match) throw Error("\u9644\u4EF6\u5E93\u5DF2\u6EE1\u6216\u5B58\u5728\u672A\u767B\u8BB0\u540C\u540D\u6587\u4EF6\uFF0C\u4FDD\u7559\u539F\u6587\u4EF6\u5E76\u505C\u6B62");
    const menu = root + " > h3 > a";
    if (await read("count", menu) !== 1) throw Error("\u4E0A\u4F20\u83DC\u5355\u4E0D\u552F\u4E00");
    await read("click", menu);
    const upload = await findText(read, menu, "\u4E0A\u4F20\u7B80\u5386");
    await read("click", upload);
    const selector = '.upload-resume-dialog:not([style*="display: none"]) input[type=file][accept*=".pdf"]';
    let ready = false;
    for (let n = 0; n < 30; n++) {
      if (await read("count", selector) === 1) {
        ready = true;
        break;
      }
      await new Promise((r) => setTimeout(r, 150));
    }
    if (!ready) throw Error("\u672A\u53D6\u5F97\u552F\u4E00\u7684\u672C\u4EBAPDF\u4E0A\u4F20\u63A7\u4EF6");
  }
  if (needsUpload) {
    const controls = [];
    for (const selector of ["span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)", 'a[href="/web/geek/recommend"]', '#header a[href="/web/geek/recommend"]', "#header", ".nav-figure", '#header a[href*="/web/geek/resume"]', '.upload-resume-dialog:not([style*="display: none"]) input[type=file][accept*=".pdf"]']) {
      const count = await read("count", selector);
      controls.push({ selector, count, ...count === 1 ? { text: await read("read", selector) } : {} });
    }
    await artifact("resume-upload-controls-preflight.json", JSON.stringify({ url: await read("url"), expectedName: source.accountSource.account.accountName, controls, websiteUploads: 0, websiteMessagesSent: 0 }, null, 2));
  }
  const uploadPageSame = async () => {
    const u = new URL(await read("url")), n = ".nav-figure";
    return u.origin === "https://www.zhipin.com" && u.pathname === "/web/geek/resume" && await read("count", n) === 1 && String(await read("read", n)).normalize("NFKC").trim() === source.accountSource.account.accountName.normalize("NFKC").trim() && await read("count", '.upload-resume-dialog:not([style*="display: none"]) input[type=file][accept*=".pdf"]') === 1;
  };
  if (needsUpload && !await uploadPageSame()) throw Error("\u672C\u4EBA\u9644\u4EF6\u9875\u3001\u8D26\u53F7\u6216\u552F\u4E00\u4E0A\u4F20\u63A7\u4EF6\u53D8\u5316\uFF0C\u672A\u9884\u7559\u6216\u4E0A\u4F20");
  if (needsUpload) {
    uploadEffect = await template.effect.prepare({ action: "send-resume", key: uploadKey, description: "\u5C06\u672C\u6B21\u51C6\u786EPDF\u4E0A\u4F20\u5230\u672C\u4EBABOSS\u9644\u4EF6\u5E93\uFF1B\u4E0A\u4F20\u4E0D\u4EE3\u8868\u62DB\u8058\u65B9\u5DF2\u6536\u5230", review: { version: 1, target: "\u672C\u4EBABOSS\u9644\u4EF6\u7BA1\u7406\n" + source.accountSource.account.accountName, content: file.name + "\n" + file.byteLength + " bytes\nSHA-256 " + file.sha256 + "\n\u968F\u540E\u4EC5\u5411\u5F53\u524D\u5DF2\u6838\u5BF9\u9644\u4EF6\u8BF7\u6C42\u53D1\u9001\u4E00\u6B21" } });
    if (!uploadEffect.execute) {
      const result2 = { version: 1, kind: "resume-send-result", execute: false, needsUpload: false, status: "upload-operation-already-exists", websiteUploads: 0, websiteMessagesSent: 0 };
      await template.result(result2);
      return result2;
    }
    index.value.uploads.push({ key: uploadKey, file, status: "reserved", effectId: uploadEffect.id, effectRunId: uploadEffect.runId, createdAt: (/* @__PURE__ */ new Date()).toISOString() });
  }
  if (needsUpload ? !await uploadPageSame() : !await requestSame(read, source)) throw Error("\u4E0A\u4F20\u786E\u8BA4\u671F\u95F4\u8D26\u53F7\u3001\u4E0A\u4F20\u63A7\u4EF6\u6216\u539F\u8BF7\u6C42\u53D8\u5316\uFF0C\u672A\u4E0A\u4F20\u6216\u53D1\u9001");
  index.value.deliveries.push({ key: source.requestKey, requestMid: source.request.mid, firstMessageId: source.firstMessageId, recipientLabel: source.recipientLabel, jobSource: source.jobSource, file, status: "reserved", uploadKey, sourceSha256: source.sourceSha256, createdAt: (/* @__PURE__ */ new Date()).toISOString() });
  const ledger = await saveDeliveryIndex(template, index);
  const result = { version: 1, kind: "resume-send-preparation", execute: true, needsUpload, source, file, uploadKey, uploadEffect, ledger, websiteUploads: 0, websiteMessagesSent: 0, aiCalled: false };
  await artifact("resume-preparation.json", JSON.stringify(result, null, 2));
  await template.result({ version: 1, kind: "resume-send-result", status: "prepared-not-sent", file, requestMid: source.request.mid, websiteMessagesSent: 0, websiteUploads: 0 });
  return result;
}
export {
  stdin_default as default
};
