import { createHash } from "node:crypto";
const canonical = (v) => Array.isArray(v) ? v.map(canonical) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical(v[k])])) : v;
const digest = (v) => createHash("sha256").update(JSON.stringify(canonical(v))).digest("hex");
const compact = (v) => String(v).replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
const reader = (template, signal) => async (operation, selector, value) => {
  signal.throwIfAborted();
  return template.browser("browser", { operation, ...selector ? { selector } : {}, ...value === void 0 ? {} : { value }, timeoutMs: 3e3 });
};
const optional = async (template, name) => {
  try {
    return await template.file("communication-cache", { operation: "read", name });
  } catch (e) {
    if (String(e.message || e).includes("ENOENT")) return null;
    throw e;
  }
};
async function deliveryIndex(template, source) {
  const name = "resume-delivery-index-v1-" + source.accountKey + ".json", raw = await optional(template, name);
  let value = raw === null ? { version: 1, kind: "boss-resume-delivery-index", accountKey: source.accountKey, revision: 0, uploads: [], deliveries: [] } : JSON.parse(raw);
  if (raw !== null) {
    const { sha256, ...body } = value;
    if (sha256 !== digest(body)) throw Error("\u9644\u4EF6\u8D26\u672C\u6458\u8981\u65E0\u6548\uFF0C\u672A\u91CD\u5EFA");
  }
  if (value.version !== 1 || value.kind !== "boss-resume-delivery-index" || value.accountKey !== source.accountKey || !Number.isSafeInteger(value.revision) || !Array.isArray(value.uploads) || !Array.isArray(value.deliveries) || value.uploads.length > 100 || value.deliveries.length > 2e3 || new Set(value.uploads.map((v) => v.key)).size !== value.uploads.length || new Set(value.deliveries.map((v) => v.key)).size !== value.deliveries.length) throw Error("\u9644\u4EF6\u8D26\u672C\u8EAB\u4EFD\u3001\u5BB9\u91CF\u6216\u552F\u4E00\u6027\u65E0\u6548\uFF0C\u539F\u8BB0\u5F55\u4FDD\u7559");
  return { name, raw, value };
}
async function saveDeliveryIndex(template, index) {
  if (await optional(template, index.name) !== index.raw) throw Error("\u9644\u4EF6\u8D26\u672C\u5DF2\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
  index.value.revision++;
  index.value.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  delete index.value.sha256;
  index.value.sha256 = digest(index.value);
  await template.file("communication-cache", { operation: "write", name: index.name, content: JSON.stringify(index.value) });
  const raw = await optional(template, index.name), back = JSON.parse(raw), { sha256, ...body } = back;
  if (sha256 !== digest(body) || sha256 !== index.value.sha256) throw Error("\u9644\u4EF6\u8D26\u672C\u672A\u5B8C\u6574\u8BFB\u56DE");
  index.raw = raw;
  return { name: index.name, sha256, revision: back.revision };
}
async function requestSame(read, source) {
  const u = new URL(await read("url"));
  return u.origin === "https://www.zhipin.com" && u.pathname === "/web/geek/chat" && await read("count", ".chat-conversation .user-info") === 1 && compact(await read("read", ".chat-conversation .user-info")) === compact(source.recipientLabel) && await read("count", source.request.agreeSelector) === 1 && String(await read("read", source.request.agreeSelector)).trim() === "\u540C\u610F" && await read("count", source.request.root) === 1 && String(await read("read", source.request.root)).trim() === source.request.text && String(await read("read", ".chat-position-content")).trim() === source.chatJobTitle;
}
function pdfSource(document) {
  const s = document?.source;
  if (document?.version !== 1 || document.status !== "ready" || s?.format !== "pdf" || s.binding !== "resume-materials" || !s.name?.toLowerCase().endsWith(".pdf") || !Number.isSafeInteger(s.byteLength) || s.byteLength < 1 || s.byteLength > 8388608 || !/^[a-f0-9]{64}$/.test(s.sha256)) throw Error("\u987B\u9009\u62E9\u5B8C\u6574\u53EF\u8BFB\u30018MiB\u4EE5\u5185\u7684\u51C6\u786EPDF\u6587\u4EF6\uFF1B\u4E0D\u56DE\u9000DOCX\u6216\u5176\u4ED6\u7248\u672C");
  return { binding: s.binding, name: s.name, displayName: s.name.split("/").at(-1), byteLength: s.byteLength, sha256: s.sha256 };
}
async function attachmentRoot(read) {
  const selector = ".resume-attachment";
  if (await read("count", selector) !== 1 || await read("count", selector + " > h3") !== 1 || !String(await read("read", selector + " > h3")).trim().startsWith("\u9644\u4EF6\u7BA1\u7406")) throw Error("\u7F51\u7AD9\u9644\u4EF6\u7BA1\u7406\u7ED3\u6784\u5C1A\u672A\u6838\u5BF9\uFF0C\u672A\u64CD\u4F5C");
  return selector;
}
async function fileLibrary(read, file) {
  const root = await attachmentRoot(read), list = root + " > .annex-list > :nth-child(2) > .annex-item", count = await read("count", list);
  if (!Number.isSafeInteger(count) || count < 0 || count > 3) throw Error("\u9644\u4EF6\u5E93\u6587\u4EF6\u6570\u91CF\u65E0\u6CD5\u6838\u5BF9");
  const rows = [];
  for (let n = 1; n <= count; n++) {
    const selector = list + ":nth-child(" + n + ")", text = String(await read("read", selector)).trim();
    if (text.length > 4e3) throw Error("\u9644\u4EF6\u6761\u76EE\u8FC7\u957F\uFF0C\u672A\u622A\u65AD");
    rows.push({ selector, text });
  }
  const matches = rows.filter((r) => r.text.split(/\r?\n/u).map((v) => v.trim()).includes(file.displayName));
  if (matches.length > 1) throw Error("\u9644\u4EF6\u5E93\u6709\u540C\u540D\u6587\u4EF6\uFF0C\u7981\u6B62\u6309\u4F4D\u7F6E\u53D1\u9001");
  return { root, count, rows, match: matches[0] || null };
}
async function findText(read, root, text) {
  const matches = [];
  let visits = 0;
  const walk = async (selector, depth2) => {
    if (++visits > 40 || depth2 > 7) throw Error("\u63A7\u4EF6\u7ED3\u6784\u8D85\u51FA\u6709\u9650\u6838\u5BF9\u8303\u56F4");
    const content = String(await read("read", selector)).trim(), count = await read("count", selector + " > *");
    if (content === text) matches.push({ selector, depth: depth2 });
    if (count > 10) throw Error("\u63A7\u4EF6\u5206\u652F\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
    for (let n = 1; n <= count; n++) await walk(selector + " > :nth-child(" + n + ")", depth2 + 1);
  };
  await walk(root, 0);
  if (!matches.length) throw Error("\u672A\u627E\u5230\u51C6\u786E\u64CD\u4F5C\u6587\u5B57\uFF1A" + text);
  const depth = Math.max(...matches.map((v) => v.depth)), last = matches.filter((v) => v.depth === depth);
  if (last.length !== 1) throw Error("\u64CD\u4F5C\u6587\u5B57\u4E0D\u552F\u4E00\uFF0C\u672A\u70B9\u51FB");
  return last[0].selector;
}
async function restoreRequestChat(read, source) {
  const compact2 = (v) => String(v).replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
  const same = async () => {
    const u = new URL(await read("url"));
    return u.origin === "https://www.zhipin.com" && u.pathname === "/web/geek/chat" && await read("count", ".chat-conversation .user-info") === 1 && compact2(await read("read", ".chat-conversation .user-info")) === compact2(source.recipientLabel) && await read("count", source.request.agreeSelector) === 1;
  };
  if (await same()) return;
  await read("navigate", void 0, "https://www.zhipin.com/web/geek/chat");
  const inputSelector = ".list-warp.v2 input";
  let ready = false;
  for (let n = 0; n < 40; n++) {
    if (await read("count", inputSelector) === 1) {
      ready = true;
      break;
    }
    await new Promise((r) => setTimeout(r, 150));
  }
  if (!ready) throw Error("\u539F\u4F1A\u8BDD\u5B9A\u5411\u641C\u7D22\u5C1A\u672A\u52A0\u8F7D\uFF0C\u672A\u9009\u62E9\u5176\u4ED6\u4F1A\u8BDD");
  if (await same()) return;
  await read("fill", inputSelector, source.recipientName);
  const root = ".boss-search-result .search-list";
  let matches = [];
  for (let n = 0; n < 30; n++) {
    const count = await read("count", root);
    if (!Number.isSafeInteger(count) || count > 50) throw Error("\u8054\u7CFB\u4EBA\u5B9A\u5411\u641C\u7D22\u8303\u56F4\u65E0\u6548");
    matches = [];
    for (let j = 1; j <= count; j++) {
      const selector = root + ":nth-child(" + j + " of .search-list)", text = String(await read("read", selector)).trim();
      if (compact2(text).includes(compact2(source.recipientLabel))) matches.push({ selector, text });
    }
    if (matches.length) break;
    await new Promise((r) => setTimeout(r, 150));
  }
  if (matches.length !== 1) throw Error("\u672A\u627E\u5230\u552F\u4E00\u7684\u539F\u59D3\u540D\u3001\u516C\u53F8\u548C\u89D2\u8272\u7EC4\u5408\uFF0C\u672A\u6253\u5F00\u5176\u4ED6\u4F1A\u8BDD");
  const target = matches[0];
  if (String(await read("read", target.selector)).trim() !== target.text) throw Error("\u539F\u8054\u7CFB\u4EBA\u641C\u7D22\u7ED3\u679C\u53D8\u5316\uFF0C\u672A\u70B9\u51FB");
  await read("click", target.selector);
  ready = false;
  for (let n = 0; n < 40; n++) {
    if (await same()) {
      ready = true;
      break;
    }
    await new Promise((r) => setTimeout(r, 150));
  }
  if (!ready) throw Error("\u539F\u4F1A\u8BDD\u3001\u539F\u9644\u4EF6\u8BF7\u6C42\u672A\u91CD\u65B0\u8BFB\u56DE\uFF0C\u4E0D\u53D1\u9001");
}
function uploadVerified(upload, file) {
  return !!upload && digest(upload.file) === digest(file) && (upload.status === "confirmed" || upload.verification?.state === "confirmed" && upload.verification.evidence?.kind === "boss-resume-upload-observation" && upload.verification.evidence.originalEffectId === upload.effectId && digest(upload.verification.evidence.file) === digest(file));
}
function attachmentReceiptName(row, file) {
  if (!row?.class?.split(/\s/u).includes("item-system") || !/^[0-9]{6,40}$/.test(row.mid || "")) return null;
  const match = /您的附件简历\s+(.+?)\s+已发送给Boss(?:点击查看附件)?/u.exec(row.text || "");
  if (!match) return null;
  const shown = match[1].trim(), normalized = shown.normalize("NFKC"), full = file.displayName.normalize("NFKC");
  if (normalized === full) return { shown, serverNameTruncated: false };
  if (normalized.endsWith("...")) {
    const prefix = normalized.slice(0, -3);
    if (prefix.length >= 2 && full.startsWith(prefix)) return { shown, serverNameTruncated: true };
  }
  return null;
}
async function accountSame(read, source) {
  const u = new URL(await read("url")), a = source.accountSource.account, expected = new URL(a.jobseekerResumeHref, a.sourceUrl);
  if (u.origin !== "https://www.zhipin.com") throw Error("\u5F53\u524D\u8D26\u53F7\u9875\u9762\u6765\u6E90\u53D8\u5316\uFF0C\u672A\u53D1\u9001\u9644\u4EF6");
  if (u.pathname === "/web/geek/resume") {
    if (u.origin + u.pathname !== expected.origin + expected.pathname || await read("count", ".nav-figure") !== 1 || String(await read("read", ".nav-figure")).normalize("NFKC").trim() !== a.accountName.normalize("NFKC").trim() || await read("count", ".resume-attachment") !== 1) throw Error("\u672C\u4EBA\u9644\u4EF6\u7BA1\u7406\u9875\u7684\u8D26\u53F7\u6216\u6765\u6E90\u53D8\u5316\uFF0C\u672A\u53D1\u9001");
    return;
  }
  const n = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", r = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)";
  if (u.pathname !== "/web/geek/chat" || await read("count", n) !== 1 || await read("count", r) !== 1 || String(await read("read", n)).normalize("NFKC").trim() !== a.accountName.normalize("NFKC").trim() || new URL(await read("attribute", r, "href"), u.href).href !== expected.href) throw Error("\u5F53\u524D\u4F1A\u8BDD\u9875\u6C42\u804C\u8D26\u53F7\u53D8\u5316\uFF0C\u672A\u53D1\u9001\u9644\u4EF6");
}
async function rowsNow(read) {
  const count = await read("count", "li.message-item");
  if (!Number.isSafeInteger(count) || count < 1 || count > 100) throw Error("\u5F53\u524D\u6D88\u606F\u8303\u56F4\u4E0D\u80FD\u5B8C\u6574\u6838\u5BF9");
  const rows = [];
  for (let n = 1; n <= count; n++) {
    const selector = "li.message-item:nth-child(" + n + " of li.message-item)", mid = await read("attribute", selector, "data-mid"), cls = await read("attribute", selector, "class"), text = String(await read("read", selector)).trim();
    if (!/^\d{6,40}$/.test(mid || "") || typeof cls !== "string" || text.length > 2e4) throw Error("\u6D88\u606F\u6765\u6E90\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
    rows.push({ mid, class: cls, text });
  }
  return rows;
}
async function stdin_default({ input: prepared, template, signal, artifact }) {
  if (prepared?.kind !== "resume-send-preparation" || !prepared.execute) throw Error("\u7F3A\u5C11\u672C\u6B21\u51C6\u786E\u9644\u4EF6\u8BF7\u6C42\u4E0E\u9884\u7559");
  const { source, file } = prepared, read = reader(template, signal), index = await deliveryIndex(template, source), delivery = index.value.deliveries.find((v) => v.key === source.requestKey), upload = index.value.uploads.find((v) => v.key === prepared.uploadKey);
  if (delivery?.status !== "reserved" || delivery.sourceSha256 !== source.sourceSha256 || !uploadVerified(upload, file) || digest(upload.file) !== digest(file) || digest(delivery.file) !== digest(file)) throw Error("\u51C6\u786EPDF\u4E0A\u4F20\u6216\u539F\u8BF7\u6C42\u9884\u7559\u5C1A\u672A\u6838\u9A8C\uFF0C\u4E0D\u53D1\u9001");
  await accountSame(read, source);
  if (new URL(await read("url")).pathname !== "/web/geek/resume") await read("navigate", null, "https://www.zhipin.com/web/geek/resume");
  let library;
  for (let n = 0; n < 30; n++) {
    try {
      library = await fileLibrary(read, file);
      break;
    } catch (e) {
      if (n === 29) throw e;
    }
    await new Promise((r) => setTimeout(r, 150));
  }
  if (!library?.match) throw Error("\u5DF2\u6838\u9A8C\u7684\u51C6\u786EPDF\u4E0D\u5728\u9644\u4EF6\u5E93\uFF0C\u4E0D\u56DE\u9000\u5176\u4ED6\u6587\u4EF6");
  await restoreRequestChat(read, source);
  if (!await requestSame(read, source) || digest(await rowsNow(read)) !== digest(source.rows)) throw Error("\u539F\u4F1A\u8BDD\u3001\u539F\u9644\u4EF6\u8BF7\u6C42\u6216\u5B8C\u6574\u6D88\u606F\u8303\u56F4\u53D8\u5316\uFF0C\u672A\u53D1\u9001");
  await accountSame(read, source);
  const state = await template.state.get();
  if ((state.conversationControls || []).some((c) => c.accountKey === source.accountKey && [source.conversationKey, "boss-chat:" + source.firstMessageId].includes(c.conversationKey) && c.mode === "paused")) throw Error("\u672C\u4EBA\u5DF2\u63A5\u7BA1\uFF0C\u4E0D\u53D1\u9001\u9644\u4EF6");
  const key = digest(["boss-resume-send-v1", source.accountKey, source.requestKey, file.sha256]), effect = await template.effect.prepare({ action: "send-resume", key, description: "\u4EC5\u5411\u5DF2\u6838\u5BF9\u7684\u5F53\u524D\u62DB\u8058\u8005\u53D1\u9001\u4E00\u6B21\u51C6\u786EPDF", review: { version: 1, target: source.recipientLabel + "\n" + source.chatJobTitle + "\n" + source.jobSource, content: file.displayName + "\n" + file.byteLength + " bytes\nSHA-256 " + file.sha256 + "\n\u4EC5\u5904\u7406\u9644\u4EF6\u8BF7\u6C42 " + source.request.mid + "\uFF0C\u4E0D\u91CD\u653E\u5176\u4ED6\u6D88\u606F" } });
  if (!effect.execute) throw Error("\u672C\u6B21\u9644\u4EF6\u53D1\u9001\u5DF2\u6709\u8BB0\u5F55\uFF0C\u4E0D\u91CD\u653E");
  delivery.status = "submitting";
  delivery.effectId = effect.id;
  delivery.sendKey = key;
  delivery.effectRunId = effect.runId;
  delivery.sourceMessageIds = source.rows.map((v) => v.mid);
  delivery.fileSelection = library.count === 1 ? { mode: "only-verified-library-file", exactFileName: file.displayName, fileSha256: file.sha256, libraryRow: library.match.text } : null;
  await saveDeliveryIndex(template, index);
  if (!await requestSame(read, source) || digest(await rowsNow(read)) !== digest(source.rows)) throw Error("\u53D1\u9001\u786E\u8BA4\u671F\u95F4\u539F\u8BF7\u6C42\u53D8\u5316\uFF0C\u672A\u70B9\u51FB");
  await accountSame(read, source);
  await read("click", source.request.agreeSelector);
  let clickedSend = false, receipt = null, observed = [];
  for (let n = 0; n < 100; n++) {
    signal.throwIfAborted();
    await accountSame(read, source);
    if (compact(await read("read", ".chat-conversation .user-info")) !== compact(source.recipientLabel) || String(await read("read", ".chat-position-content")).trim() !== source.chatJobTitle) throw Error("\u9644\u4EF6\u6838\u9A8C\u671F\u95F4\u4F1A\u8BDD\u53D8\u5316\uFF0C\u4E0D\u7EE7\u7EED\u53D1\u9001");
    const items = ".choose-resume-dialog .resume-list li.list-item:not(.video-list-item)", count = await read("count", items);
    if (!clickedSend && count > 0) {
      if (count > 3) throw Error("\u9644\u4EF6\u9009\u62E9\u5668\u8303\u56F4\u5F02\u5E38\uFF0C\u672A\u9009\u53D6");
      const matches = [];
      for (let j = 1; j <= count; j++) {
        const selector = items + ":nth-child(" + j + ")";
        if (await read("count", selector + " .resume-name") !== 1) throw Error("\u9644\u4EF6\u540D\u79F0\u4E0D\u552F\u4E00");
        if (String(await read("read", selector + " .resume-name")).trim() === file.displayName) matches.push(selector);
      }
      if (matches.length !== 1) throw Error("\u53D1\u9001\u9009\u62E9\u5668\u4E2D\u6CA1\u6709\u552F\u4E00\u51C6\u786EPDF\uFF0C\u672A\u56DE\u9000\u65E7\u7B80\u5386");
      await read("click", matches[0]);
      if (!String(await read("attribute", matches[0], "class")).split(/\s/u).includes("selected") || await read("count", ".choose-resume-dialog .resume-list li.selected") !== 1 || String(await read("read", matches[0] + " .resume-name")).trim() !== file.displayName) throw Error("\u51C6\u786EPDF\u9009\u62E9\u672A\u8BFB\u56DE");
      const button = ".choose-resume-dialog .btn-confirm";
      if (await read("count", button) !== 1 || String(await read("read", button)).trim() !== "\u53D1\u9001" || await read("attribute", button, "disabled") !== null || String(await read("attribute", button, "class")).split(/\s/u).includes("disabled")) throw Error("\u9644\u4EF6\u53D1\u9001\u6309\u94AE\u5C1A\u4E0D\u53EF\u7528");
      await accountSame(read, source);
      if (!await requestSame(read, source)) throw Error("\u9644\u4EF6\u9009\u62E9\u540E\u539F\u8BF7\u6C42\u53D8\u5316\uFF0C\u672A\u53D1\u9001");
      delivery.fileSelection = { mode: "exact-selected-file", exactFileName: file.displayName, fileSha256: file.sha256, selectedRow: matches[0], selectedLabel: String(await read("read", matches[0] + " .resume-name")).trim(), checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
      await saveDeliveryIndex(template, index);
      if (String(await read("read", matches[0] + " .resume-name")).trim() !== file.displayName || !String(await read("attribute", matches[0], "class")).split(/\s/u).includes("selected")) throw Error("\u6700\u7EC8\u53D1\u9001\u524D\u51C6\u786E\u6587\u4EF6\u9009\u62E9\u53D8\u5316\uFF0C\u672A\u70B9\u51FB");
      clickedSend = true;
      await read("click", button);
    }
    observed = await rowsNow(read);
    const original = new Set(source.rows.map((v) => v.mid)), selection = delivery.fileSelection, sent = observed.filter((v) => !original.has(v.mid) && attachmentReceiptName(v, file) && selection?.exactFileName === file.displayName && selection.fileSha256 === file.sha256);
    if (sent.length === 1) {
      receipt = { version: 1, kind: "boss-resume-send-receipt", accountKey: source.accountKey, recipientLabel: source.recipientLabel, jobSource: source.jobSource, requestMid: source.request.mid, message: sent[0], file, siteName: attachmentReceiptName(sent[0], file), fileSelection: selection, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), exactFileSelected: true };
      break;
    }
    if (sent.length > 1) throw Error("\u591A\u4E2A\u9644\u4EF6\u56DE\u6267\u65E0\u6CD5\u552F\u4E00\u5173\u8054\uFF0C\u4FDD\u7559\u672A\u77E5\u4E0D\u91CD\u53D1");
    await new Promise((r) => setTimeout(r, 250));
  }
  await artifact("resume-send-observation.json", JSON.stringify({ source, file, clickedSend, receipt, rows: observed }, null, 2));
  if (!receipt || !receipt.exactFileSelected) {
    delivery.status = "unknown";
    await template.effect.resolve({ id: effect.id, state: "unknown", evidence: { reason: "\u5C1A\u672A\u8BFB\u5230\u540C\u4F1A\u8BDD\u51C6\u786E\u6587\u4EF6\u7684\u552F\u4E00\u7F51\u7AD9\u56DE\u6267", clickedSend } });
    await saveDeliveryIndex(template, index);
    await template.attention({ key: "resume-unknown-" + source.requestKey, title: "\u9644\u4EF6\u53D1\u9001\u7ED3\u679C\u5F85\u6838\u5BF9\uFF0C\u8BF7\u52FF\u91CD\u53D1", detail: { recipientLabel: source.recipientLabel, requestMid: source.request.mid, file } });
    const result2 = { version: 1, kind: "resume-send-result", status: "unknown", websiteMessagesSent: 0, aiCalled: false };
    await template.result(result2);
    return result2;
  }
  await template.effect.resolve({ id: effect.id, state: "confirmed", evidence: receipt });
  delivery.status = "confirmed";
  delivery.evidence = receipt;
  const ledger = await saveDeliveryIndex(template, index);
  const result = { version: 1, kind: "resume-send-result", status: "resume-sent-confirmed", file, receipt, ledger, websiteMessagesSent: 1, websiteUploads: prepared.needsUpload ? 1 : 0, aiCalled: false };
  await template.result(result);
  return result;
}
export {
  stdin_default as default
};
