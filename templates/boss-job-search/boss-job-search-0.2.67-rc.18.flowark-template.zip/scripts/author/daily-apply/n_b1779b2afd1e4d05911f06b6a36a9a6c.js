import { createHash as $ } from "node:crypto";
const tt = /* @__PURE__ */ (() => {
  const I = $;
  function O(t) {
    return t.status === "review" && !t.operationKey && !t.modelRequestId && t.sourceReviewVersion !== "chat-list-direct-v5" && /固定成员姓名控件不唯一|固定成员定向搜索结果不唯一|关联职位没有可核对的继续沟通入口|固定成员缺少可核对的定向搜索姓名，未猜测|固定成员缺少唯一可见身份|关联职位返回后的完整消息或对象变化/u.test(String(t.reason || ""));
  }
  async function P(t, o) {
    const i = ".user-list-content", s = (n) => n.replace(/[\s\uE000-\uF8FF]/gu, ""), e = ".list-warp.v2 input";
    await t("count", e) === 1 && String(await t("inputValue", e, null)) !== "" && await t("fill", e, "");
    const r = ".list-warp.v2 ul:has(> .selected)", u = r + " > :nth-child(2)";
    await t("count", u) === 1 && /^未读(?:\s*\(\d+\))?$/u.test(String(await t("read", u)).trim()) && !/^未读/u.test(String(await t("read", r + " .selected")).trim()) && await t("click", u);
    for (let n = 0; n < 30 && await t("count", i) !== 1; n++) await new Promise((f) => setTimeout(f, 150));
    if (await t("count", i) !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u6765\u6E90\u4E0D\u552F\u4E00");
    const l = [{ selector: i, depth: 0 }], c = [];
    let m = 0;
    for (; l.length; ) {
      const n = l.shift();
      if (++m > 400) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
      const f = await t("count", n.selector + ".friend-content") === 1, A = f ? 1 : await t("count", n.selector + " .friend-content");
      if (A === 1) {
        const p = f ? n.selector : n.selector + " .friend-content", D = String(await t("read", n.selector)).trim();
        s(D).includes(s(String(o.member.text).split(/\r?\n/u).slice(3).join(`
`).trim())) && c.push({ sel: n.selector, label: p, text: D });
        continue;
      }
      if (A > 1 && n.depth < 4) {
        const p = await t("count", n.selector + " > *");
        if (!Number.isSafeInteger(p) || p > 200) throw Error("\u56FA\u5B9A\u6210\u5458\u5F53\u524D\u5217\u8868\u8D85\u51FA\u6838\u5BF9\u8303\u56F4");
        for (let D = 1; D <= p; D++) l.push({ selector: n.selector + " > :nth-child(" + D + ")", depth: n.depth + 1 });
      }
    }
    if (c.length === 0 && o.member.lookupName) {
      await t("fill", e, o.member.lookupName);
      const n = ".boss-search-result .search-list";
      for (let E = 0; E < 30 && !(await t("count", n) > 0); E++) await new Promise((v) => setTimeout(v, 150));
      if (await t("count", n) !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u5B9A\u5411\u641C\u7D22\u7ED3\u679C\u4E0D\u552F\u4E00");
      const f = [n], A = [];
      let p = 0;
      for (; f.length; ) {
        const E = f.shift();
        if (++p > 100) throw Error("\u8054\u7CFB\u4EBA\u59D3\u540D\u63A7\u4EF6\u8303\u56F4\u8FC7\u5927");
        const v = await t("count", E + " > *"), x = String(await t("read", E)).trim();
        if (x === o.member.lookupName && A.push({ label: E, text: x }), v > 0 && v < 30) for (let R = 1; R <= v; R++) f.push(E + " > :nth-child(" + R + ")");
      }
      const D = A.filter((E) => !A.some((v) => v !== E && v.label.startsWith(E.label + " > ")));
      if (D.length !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u59D3\u540D\u63A7\u4EF6\u4E0D\u552F\u4E00");
      c.push(D[0]);
    }
    if (c.length !== 1) throw Error("\u56FA\u5B9A\u6210\u5458\u7F3A\u5C11\u552F\u4E00\u53EF\u89C1\u8EAB\u4EFD\uFF0C\u672A\u731C\u6D4B\u59D3\u540D");
    const w = c[0];
    if (String(await t("read", w.label)).trim() !== w.text) throw Error("\u56FA\u5B9A\u6210\u5458\u53EF\u89C1\u8EAB\u4EFD\u53D8\u5316");
    await t("click", w.label);
    for (let n = 0; n < 30; n++) {
      if (await t("count", ".chat-conversation .user-info") === 1 && await t("count", "li.message-item") > 0) {
        const f = String(await t("read", ".chat-conversation .user-info")).trim(), A = await F(t), p = s(String(o.member.text).split(/\r?\n/u).slice(3).join(`
`).trim());
        if (f && A.some((D) => D.direction === "incoming" && s(D.text || "") === p)) {
          o.recipientLabel = f, o.rows = [{ mid: A[0].mid }];
          return;
        }
      }
      await new Promise((f) => setTimeout(f, 150));
    }
    throw Error("\u56FA\u5B9A\u6210\u5458\u53EF\u89C1\u8EAB\u4EFD\u672A\u5B8C\u6574\u8BFB\u56DE");
  }
  async function q(t, o, i) {
    if (typeof i != "string" || !i.trim()) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u539F\u59D3\u540D\u6765\u6E90\u7F3A\u5931");
    await t("navigate", void 0, "https://www.zhipin.com/web/geek/chat"), await P(t, o);
  }
  function Z(t, o) {
    const i = (c) => c.normalize("NFKC").replace(/\s+/gu, " ").trim().toLocaleLowerCase("en-US");
    if (typeof t != "string" || !t.trim() || t.length > 1e3 || /(?:\.{3}|…|⋯)/u.test(t)) throw Error("\u5B8C\u6574\u5C97\u4F4D\u6807\u9898\u7F3A\u5931\u6216\u622A\u65AD\uFF0C\u505C\u6B62\u5E76\u4FDD\u7559\u8BB0\u5F55");
    const s = o?.titleKeywords, e = o?.excludedRoles;
    for (const [c, m, w] of [["titleKeywords", s, 1], ["excludedRoles", e, 0]]) if (!Array.isArray(m) || m.length < w || m.length > 20 || m.some((n) => typeof n != "string" || !i(n) || n.length > 100) || new Set(m.map(i)).size !== m.length) throw Error("\u5C97\u4F4D\u8303\u56F4\u914D\u7F6E\u65E0\u6548\uFF1A" + c + "\uFF1B\u672A\u5EFA\u7ACB\u5916\u53D1\u610F\u56FE");
    const r = i(t), u = e.filter((c) => r.includes(i(c))), l = s.filter((c) => r.includes(i(c)));
    return { version: 1, kind: "literal-full-job-title-scope", fullTitle: t, matched: l, excluded: u, allowed: u.length === 0 && l.length > 0, source: "actual-complete-job-title", jdUsed: false, searchKeywordUsedAsEvidence: false };
  }
  const G = /* @__PURE__ */ (() => {
    var t = async ({ input: o, signal: i }) => {
      i.throwIfAborted();
      const s = o, e = s?.value;
      if (!s || s.version !== 1 || s.operation !== "read" || s.binding !== "account-source-result" || s.schemaValidation !== "passed" || s.dataChanged !== false || s.ref?.version !== 1 || s.ref.policy !== "credential-redacted-v1" || s.ref.source?.entryId !== "account-source") throw new Error("\u7F3A\u5C11\u672C\u5B9E\u4F8B\u5DF2\u9009\u62E9\u4E14\u5B8C\u6574\u53EF\u590D\u7528\u7684\u8D26\u53F7\u6765\u6E90\uFF0C\u8BF7\u5230\u8D44\u6E90\u9875\u91CD\u65B0\u6838\u5BF9\u5E76\u4FDD\u5B58");
      if (!e || e.version !== 1 || e.kind !== "boss-account-source" || e.status !== "account-source-confirmed" || e.accountVerified !== true || e.platformUniqueIdVerified !== false || e.eligibleForActions !== false || e.role !== "jobseeker") throw new Error("\u6240\u9009\u8BB0\u5F55\u5C1A\u672A\u5B8C\u6210\u672C\u4EBA\u786E\u8BA4\u548C\u6765\u6E90\u590D\u9A8C\uFF1B\u8BF7\u5728\u5F53\u524D\u5B9E\u4F8B\u5B8C\u6210\u8D26\u53F7\u6838\u5BF9\uFF0C\u518D\u9009\u62E9\u8BE5\u6B21\u5DF2\u4FDD\u5B58\u7ED3\u679C");
      const r = ["version", "kind", "status", "accountAlias", "accountName", "phoneMask", "jobseekerResumeHref", "role", "sourceUrl", "accountVerified", "platformUniqueIdVerified", "eligibleForActions", "confirmedAt", "checkedAt", "reason"];
      if (Object.keys(e).length !== r.length || r.some((w) => !Object.prototype.hasOwnProperty.call(e, w))) throw new Error("\u6240\u9009\u8D26\u53F7\u7ED3\u679C\u7ED3\u6784\u4E0D\u7B26\uFF0C\u505C\u6B62\u91C7\u7528");
      for (const w of ["accountAlias", "accountName", "phoneMask"]) if (typeof e[w] != "string" || !e[w].trim() || e[w] !== e[w].trim() || e[w].length > 100 || /[\r\n]/.test(e[w])) throw new Error("\u8D26\u53F7\u5FC5\u8981\u5B57\u6BB5\u7F3A\u5931\u6216\u683C\u5F0F\u65E0\u6548\uFF0C\u505C\u6B62\u91C7\u7528");
      if (!/^[+\d ()-]*\*{2,}[\d ()-]+$/.test(e.phoneMask) || /登录|注册|验证码/.test(e.accountName)) throw new Error("\u8D26\u53F7\u6765\u6E90\u7F3A\u5C11\u6709\u6548\u7684\u53EF\u89C1\u59D3\u540D\u6216\u624B\u673A\u53F7\u63A9\u7801");
      if (typeof e.reason != "string" || !e.reason.trim()) throw new Error("\u8D26\u53F7\u7ED3\u679C\u7F3A\u5C11\u660E\u786E\u6838\u5BF9\u8BF4\u660E");
      const u = Date.parse(e.confirmedAt), l = Date.parse(e.checkedAt);
      if (typeof e.confirmedAt != "string" || typeof e.checkedAt != "string" || !Number.isFinite(u) || !Number.isFinite(l) || u <= 0 || l < u || l > Date.now() + 6e4) throw new Error("\u8D26\u53F7\u786E\u8BA4\u6216\u590D\u9A8C\u65F6\u95F4\u65E0\u6CD5\u6838\u5BF9\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4");
      if (typeof e.sourceUrl != "string" || typeof e.jobseekerResumeHref != "string" || !e.sourceUrl.trim() || !e.jobseekerResumeHref.trim() || e.sourceUrl.length > 16384 || e.jobseekerResumeHref.length > 16384) throw new Error("\u8D26\u53F7\u9875\u9762\u6216\u7B80\u5386\u5165\u53E3\u5730\u5740\u65E0\u6548");
      const c = new URL(e.sourceUrl), m = new URL(e.jobseekerResumeHref, e.sourceUrl);
      if (c.origin !== "https://www.zhipin.com" || c.pathname !== "/web/geek/account" || c.searchParams.get("type") !== "accountSet" || c.username || c.password || c.hash || m.origin !== c.origin || m.pathname !== "/web/geek/resume" || m.username || m.password) throw new Error("\u8D26\u53F7\u8BB0\u5F55\u7684\u9875\u9762\u6216\u6C42\u804C\u8005\u5165\u53E3\u6765\u6E90\u4E0D\u7B26");
      return i.throwIfAborted(), { version: 1, accountSourceValid: true, currentAccountVerified: false, account: e };
    };
    return t;
  })(), _ = /* @__PURE__ */ (() => {
    async function t({ input: o, signal: i, template: s }) {
      i.throwIfAborted();
      const e = o?.expected?.account;
      if (o?.expected?.accountSourceValid !== true || e?.kind !== "boss-account-source" || e.status !== "account-source-confirmed" || e.accountVerified !== true) throw Error("\u7F3A\u5C11\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\u6765\u6E90");
      const r = async (p, D, E) => {
        i.throwIfAborted();
        const v = await s.browser("browser", { operation: p, ...D ? { selector: D } : {}, ...E === void 0 ? {} : { value: E }, timeoutMs: 3e3 });
        return i.throwIfAborted(), v;
      }, u = await r("url"), l = new URL(u);
      if (l.origin !== "https://www.zhipin.com" || l.username || l.password || !l.pathname.startsWith("/web/") && !/^\/job_detail\/[A-Za-z0-9_~-]+\.html$/.test(l.pathname)) throw Error("\u5F53\u524D\u9875\u9762\u4E0D\u662FBOSS\u6C42\u804C\u9875\u9762\uFF0C\u8BF7\u5148\u767B\u5F55");
      const c = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", m = "span:nth-of-type(1) > li:nth-of-type(1) > a:nth-of-type(1)", w = await r("count", c), n = await r("count", m);
      if (w !== 1 || n !== 1) throw Error("\u5F53\u524D\u9875\u9762\u8D26\u53F7\u5165\u53E3\u6570\u91CF\u5F02\u5E38\uFF1A" + JSON.stringify({ nameCount: w, resumeCount: n }));
      const f = await r("read", c), A = await r("attribute", m, "href");
      if (typeof f != "string" || f.normalize("NFKC").trim() !== e.accountName.normalize("NFKC").trim() || typeof A != "string" || new URL(A, u).href !== new URL(e.jobseekerResumeHref, e.sourceUrl).href || await r("url") !== u) throw Error("\u5F53\u524D\u767B\u5F55\u8EAB\u4EFD\u3001\u6C42\u804C\u5165\u53E3\u6216\u9875\u9762\u5DF2\u53D8\u5316\uFF0C\u505C\u6B62\u672C\u6279");
      return { version: 1, status: "current-account-source-matched", accountAlias: e.accountAlias, accountName: e.accountName, phoneMask: e.phoneMask, jobseekerResumeHref: e.jobseekerResumeHref, sourceUrl: e.sourceUrl, checkedAt: (/* @__PURE__ */ new Date()).toISOString(), currentPageUrl: u, currentAccountVerified: true, platformUniqueIdVerified: false, eligibleForActions: false, accountCheckMode: "confirmed-initial-account-and-visible-header", phoneMaskRechecked: false, reason: "\u4F7F\u7528\u5DF2\u786E\u8BA4\u7684\u521D\u59CB\u5316\u8D26\u53F7\uFF1B\u53EA\u8BFB\u6838\u5BF9\u5F53\u524D\u767B\u5F55\u59D3\u540D\u3001\u6C42\u804C\u5165\u53E3\u53CA\u9875\u9762\u8FDE\u7EED\u6027\uFF0C\u624B\u673A\u53F7\u63A9\u7801\u6CBF\u7528\u786E\u8BA4\u6765\u6E90\uFF0C\u6CA1\u6709\u91CD\u65B0\u8BFB\u53D6\u3002" };
    }
    return t;
  })(), K = (t) => Array.isArray(t) ? t.map(K) : t && typeof t == "object" ? Object.fromEntries(Object.keys(t).sort().map((o) => [o, K(t[o])])) : t, Q = (t) => I("sha256").update(JSON.stringify(K(t))).digest("hex"), j = (t) => Array.isArray(t) ? t.map(j) : t && typeof t == "object" ? Object.fromEntries(Object.keys(t).sort().map((o) => [o, j(t[o])])) : t, M = (t) => I("sha256").update(JSON.stringify(j(t))).digest("hex");
  async function a(t, o, i, s, e = false) {
    const r = "account-outbound-safety-v1-" + i + ".json";
    let u, l = true, c;
    try {
      c = await t.file("communication-cache", { operation: "read", name: r }), u = JSON.parse(c);
    } catch (n) {
      if (!String(n.message || n).includes("ENOENT")) throw n;
      if (!e) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
      l = false, u = { version: 1, kind: "boss-account-outbound-safety", accountKey: i, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    }
    if (l) {
      const { sha256: n, ...f } = u;
      if (n !== M(f)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
    }
    if (u.version !== 1 || u.kind !== "boss-account-outbound-safety" || u.accountKey !== i || !Number.isSafeInteger(u.revision) || u.revision < 0 || !Array.isArray(u.records) || u.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
    const m = /* @__PURE__ */ new Set();
    for (const n of u.records) {
      if (!["first-contact", "reply"].includes(n.type) || !/^[a-f0-9]{64}$/.test(n.businessKey) || !Array.isArray(n.sightings) || !n.sightings.length || n.sightings.length > 100 || m.has(n.type + ":" + n.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
      m.add(n.type + ":" + n.businessKey);
      for (const f of n.sightings) if (typeof f.contextId != "string" || !f.contextId || !/^[a-f0-9]{64}$/.test(f.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(f.status) || !/^\d{4}-\d{2}-\d{2}$/.test(f.day) || typeof f.timeZone != "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
    }
    let w = !l;
    return { data: u, name: r, merge: (n) => {
      if (!Array.isArray(n?.applicationIntents) || !Array.isArray(n?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
      for (const [f, A] of [["first-contact", n.applicationIntents], ["reply", n.replyIntents]]) for (const p of A) {
        if ((f === "first-contact" ? p.accountSourceSha256 : p.accountKey) !== i) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
        if (!/^[a-f0-9]{64}$/.test(p.key) || !p.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(p.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
        const D = f === "first-contact" ? M(["boss-job-safety-v1", i, p.jobId]) : I("sha256").update(["boss-text-reply-v1", i, p.incomingMessageId].join(":")).digest("hex");
        let E = u.records.find((x) => x.type === f && x.businessKey === D);
        if (E || (E = { type: f, businessKey: D, jobId: p.jobId, ...f === "reply" ? { conversationKey: p.conversationKey, incomingMessageId: p.incomingMessageId } : {}, sightings: [] }, u.records.push(E), w = true), E.jobId !== p.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
        const v = { contextId: s, intentKey: p.key, status: p.status, day: p.day, timeZone: p.timeZone, contentSha256: p.contentSha256 || null, sourceSha256: p.sourceSha256 || null };
        if (E.sightings.some((x) => JSON.stringify(j(x)) === JSON.stringify(j(v))) || (E.sightings.push(v), w = true), E.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
      }
      if (u.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
    }, save: async () => {
      if (o.throwIfAborted(), w) {
        if (l && await t.file("communication-cache", { operation: "read", name: r }) !== c) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
        u.records.sort((p, D) => (p.type + ":" + p.businessKey).localeCompare(D.type + ":" + D.businessKey));
        for (const p of u.records) p.sightings.sort((D, E) => JSON.stringify(j(D)).localeCompare(JSON.stringify(j(E))));
        u.revision++, u.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete u.sha256, u.sha256 = M(u), await t.file("communication-cache", { operation: "write", name: r, content: JSON.stringify(u) }), w = false, c = JSON.stringify(u), l = true;
      }
      const n = JSON.parse(await t.file("communication-cache", { operation: "read", name: r })), { sha256: f, ...A } = n;
      if (f !== M(A) || f !== u.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
      return { revision: u.revision, sha256: u.sha256, records: u.records.length };
    }, blocked: (n, f) => u.records.some((A) => A.type === n && A.businessKey === f) };
  }
  const h = (t, o) => async (i, s, e) => {
    o.throwIfAborted();
    try {
      return await t.browser("browser", { operation: i, ...s ? { selector: s } : {}, ...e === void 0 ? {} : { value: e }, timeoutMs: 3e3 });
    } catch (r) {
      const u = String(r.message || r);
      if (!/^\(-3\) loading /u.test(u)) throw r;
      let l = null;
      if (i === "navigate" && e === "https://www.zhipin.com/web/geek/chat" && (l = new URL(e)), i === "click" && s === ".chat-position-content .right-content > :first-child") {
        const c = /^\(-3\) loading '([^']+)'/u.exec(u);
        if (c) {
          const m = new URL(c[1]);
          m.origin === "https://www.zhipin.com" && /^\/job_detail\/[A-Za-z0-9_~-]+\.html$/u.test(m.pathname) && !m.username && !m.password && (l = m);
        }
      }
      if (!l) throw r;
      for (let c = 0; c < 30; c++) {
        o.throwIfAborted();
        const m = await t.browser("browser", { operation: "url", timeoutMs: 3e3 }), w = new URL(m);
        if (w.origin === l.origin && w.pathname === l.pathname) return { navigationObserved: true, url: m, originalClickRepeated: false };
        await new Promise((n) => setTimeout(n, 150));
      }
      throw r;
    }
  }, b = (t) => {
    const { sha256: o, ...i } = t;
    return o === M(i);
  };
  async function g(t, o, i, s) {
    const e = i.progressName, r = await t.file("communication-cache", { operation: "read", name: e }), u = JSON.parse(r);
    if (!b(u) || u.accountKey !== i.accountKey || u.fixedUnreadSetSha256 !== i.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
    if (!s) return u;
    const l = s(structuredClone(u));
    if (l.revision++, l.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete l.sha256, l.sha256 = M(l), await t.file("communication-cache", { operation: "read", name: e }) !== r) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
    o.throwIfAborted(), await t.file("communication-cache", { operation: "write", name: e, content: JSON.stringify(l) });
    const c = JSON.parse(await t.file("communication-cache", { operation: "read", name: e }));
    if (!b(c) || c.sha256 !== l.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
    return c;
  }
  async function F(t) {
    const o = await t("count", "li.message-item");
    if (!Number.isSafeInteger(o) || o < 1 || o > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
    const i = [];
    for (let s = 1; s <= o; s++) {
      const e = "li.message-item:nth-child(" + s + " of li.message-item)", r = await t("attribute", e, "data-mid"), u = await t("attribute", e, "class");
      if (!/^\d{6,40}$/.test(r || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
      const l = await t("count", e + " .text-content");
      if (l > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
      const c = l === 1 ? String(await t("read", e + " .text-content")).trim() : null, m = c === null ? String(await t("read", e)).trim() : null;
      if ((c || m || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
      const w = !!c && /^您正在与Boss.+沟通$/u.test(c), n = !w && c !== null && u.split(/\s+/u).includes("item-myself") ? "outgoing" : !w && c !== null && u.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
      i.push({ mid: r, direction: n, text: c, context: m });
    }
    if (new Set(i.map((s) => s.mid)).size !== i.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
    return i;
  }
  async function B(t, o) {
    const i = new URL(await t("url"));
    if (i.origin !== "https://www.zhipin.com" || i.pathname !== "/web/geek/chat" || await t("count", ".chat-conversation .user-info") !== 1) return false;
    const s = String(await t("read", ".chat-conversation .user-info")).trim(), e = (r) => r.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
    return o.recipientLabel ? String(await t("read", ".chat-conversation .user-info")).trim() === o.recipientLabel && (!o.rows?.length || await t("count", 'li.message-item[data-mid="' + o.rows[0].mid + '"]') === 1) : await t("count", ".friend-content.selected") === 1 && e(String(await t("read", ".friend-content.selected"))).includes(e(o.member.identityLine));
  }
  async function y(t, o, i) {
    const s = h(t, o);
    return await B(s, i) ? String(await s("read", i.accountSelector)).trim() === i.accountLabel && String(await s("read", i.recipientSelector)).trim() === i.recipientLabel && JSON.stringify(await F(s)) === JSON.stringify(i.rows) : false;
  }
  var S = async ({ input: t, template: o, signal: i, artifact: s, onAccountVerified: e }) => {
    const r = t?.cohort, u = t?.profile;
    if (r?.kind !== "unread-closing-cohort" || r.closingPhase !== true || u?.version !== 1 || !u.ref?.versionId || !u.markdown?.trim()) throw Error("\u7F3A\u5C11\u56FA\u5B9A\u672A\u8BFB\u96C6\u5408\u6216\u672C\u6B21\u786E\u8BA4Skill");
    const l = { ...r, sourceReviewVersion: "chat-list-direct-v5", kind: "chat-reply-source", fixedUnreadMember: true, profile: u, returnToJobs: false };
    if (!r.ready) return { ...l, ready: false, status: "fixed-unread-complete", reason: "\u56FA\u5B9A\u96C6\u5408\u5DF2\u5904\u7406\u5B8C\u6BD5\uFF0C\u4E0D\u91CD\u65B0\u626B\u63CF" };
    await _({ input: { expected: r.accountSource }, template: o, signal: i }), e?.();
    const c = String(r.member?.text || "").split(/\r?\n/u).slice(3).join(`
`).trim();
    if (/背景不完全相符|需要其他资质|不太符合|不太?合适|不[是太]*特别契合|不[完全]*符合|不[完全]*匹配|后续有机会再合作|未能通过|暂不考虑/u.test(c) && !/[?？]|(?:是否|有没有|会不会|能否|请问|什么时候|多少|怎么|哪些)/u.test(c)) return { ...l, member: r.member, ready: false, jobId: null, jobSource: null, status: "rejected-no-reply", reason: "\u56FA\u5B9A\u672A\u8BFB\u5FEB\u7167\u4E2D\u5BF9\u65B9\u5DF2\u660E\u786E\u62D2\u7EDD\uFF0C\u4E0D\u56DE\u590D\u3001\u4E0D\u6267\u884C\u539F\u751F\u8BF7\u6C42", previewSource: true };
    const m = h(o, i), w = r.member;
    let n = await g(o, i, r);
    if (n.completed.some((d) => d.memberKey === w.key && !O(d) && !(d.status === "review" && d.replyPolicyVersion !== "work-questions-partial-known-v2"))) return { ...l, ready: false, status: "already-completed", reason: "\u8BE5\u56FA\u5B9A\u6210\u5458\u5DF2\u5904\u7406\uFF0C\u672A\u91CD\u590D\u6253\u5F00" };
    if (n.active && n.active.memberKey !== w.key) throw Error("\u6D3B\u8DC3\u4F1A\u8BDD\u4E0E\u56FA\u5B9A\u6210\u5458\u4E0D\u7B26");
    if (!await B(m, r)) {
      const d = new URL(await m("url"));
      (d.origin !== "https://www.zhipin.com" || d.pathname !== "/web/geek/chat") && await m("navigate", void 0, "https://www.zhipin.com/web/geek/chat"), await P(m, r);
    }
    const f = ".chat-conversation .user-info", A = String(await m("read", f)).trim(), p = ".chat-position-content", D = String(await m("read", p)).trim(), E = D.split(/\r?\n/u)[0], v = await F(m);
    if (!E || !A) throw Error("\u56FA\u5B9A\u4F1A\u8BDD\u7684\u62DB\u8058\u8005\u6216\u804C\u4F4D\u4E0A\u4E0B\u6587\u7F3A\u5931");
    if (/校招|校园|应届/u.test(E)) return { ...l, member: w, ready: false, status: "campus-no-reply", reason: "\u804A\u5929\u4E2D\u660E\u786E\u6821\u62DB\uFF0C\u7EE7\u7EED\u6392\u9664" };
    if (n.active?.firstMessageId && n.active.firstMessageId !== v[0].mid) throw Error("\u91CD\u5F00\u540E\u7684\u4F1A\u8BDD\u539F\u59CB\u6D88\u606F\u94FE\u5DF2\u53D8\u5316\uFF0C\u672A\u8986\u76D6\u65E7\u8FDB\u5EA6");
    n = await g(o, i, r, (d) => {
      if (d.active && d.active.memberKey !== w.key) throw Error("\u6D3B\u8DC3\u6210\u5458\u53D8\u5316");
      return d.active = { ...d.active, memberKey: w.key, identityLine: w.identityLine, recipientName: A.split(/\r?\n/u)[0], contextId: r.contextId, openedAt: d.active?.openedAt || (/* @__PURE__ */ new Date()).toISOString(), firstMessageId: v[0].mid }, d;
    });
    const x = "https://www.zhipin.com/web/geek/chat", R = "chat-" + v[0].mid, U = await F(m), L = U.filter((d) => d.direction !== "system" && d.text), k = L.at(-1), Y = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)", W = r.accountSource.account.accountName, N = { ...l, ownedConversation: L[0]?.direction === "outgoing", member: w, jobId: R, jobSource: x, jobTitle: E, chatJobTitle: D, jobSelector: p, recipientSelector: f, recipientLabel: A, accountSelector: Y, accountLabel: W, conversationKey: "boss-chat:" + U[0].mid, rows: U };
    if (L[0]?.direction === "incoming") return { ...N, ready: false, status: "inbound-first-no-reply", reason: "\u53EF\u89C1\u4F1A\u8BDD\u7531\u5BF9\u65B9\u53D1\u8D77\uFF0C\u6309\u672C\u4EBA\u89C4\u5219\u8DF3\u8FC7" };
    if (!k || k.direction !== "incoming") return { ...N, ready: false, status: "already-replied-or-system-only", reason: "\u6CA1\u6709\u5C1A\u672A\u56DE\u590D\u7684\u771F\u4EBA\u6587\u5B57\u6765\u4FE1\uFF1B\u7CFB\u7EDF\u5361\u7247\u4E0D\u89E6\u53D1\u56DE\u590D" };
    if (/背景不完全相符|需要其他资质|不太符合|不太?合适|不[是太]*特别契合|不[完全]*符合|不[完全]*匹配|后续有机会再合作|未能通过|暂不考虑/u.test(k.text) && !/[?？]|(?:是否|有没有|会不会|能否|请问|什么时候|多少|怎么|哪些)/u.test(k.text)) return { ...N, ready: false, status: "rejected-no-reply", incomingMessageId: k.mid, reason: "\u5BF9\u65B9\u660E\u786E\u8868\u793A\u4E0D\u5408\u9002\uFF0C\u6309\u672C\u4EBA\u6700\u65B0\u8981\u6C42\u4E0D\u56DE\u590D\uFF1B\u4FDD\u7559\u6240\u6709\u539F\u5916\u53D1\u610F\u56FE" };
    const V = I("sha256").update(["boss-text-reply-v1", r.accountKey, k.mid].join(":")).digest("hex"), z = await o.state.get(), T = await a(o, i, r.accountKey, r.contextId);
    if (T.merge(z), await T.save(), z.replyIntents.some((d) => d.accountKey === r.accountKey && d.incomingMessageId === k.mid && ["reserved", "unknown", "failed"].includes(d.status)) || T.data.records.some((d) => d.type === "reply" && d.businessKey === V && d.sightings.some((J) => ["reserved", "unknown", "failed"].includes(J.status)))) {
      const d = "\u539F\u6765\u4FE1\u5DF2\u6709\u9884\u7559\u3001\u672A\u77E5\u6216\u5931\u8D25\u8BB0\u5F55\uFF0C\u4FDD\u7559\u5F85\u529E\u5E76\u7981\u6B62\u91CD\u53D1";
      return await o.attention({ key: "reply-existing-uncertain:" + r.accountKey + ":" + k.mid, title: "\u539F\u56DE\u590D\u7ED3\u679C\u5F85\u6838\u5BF9\uFF0C\u8BF7\u52FF\u91CD\u53D1", detail: { contact: w.identityLine, jobSource: x, incomingMessageId: k.mid, reason: d, externalAction: false } }), { ...N, ready: false, status: "existing-uncertain-reply", decision: "review", replyPolicyVersion: "work-questions-partial-known-v2", incomingMessageId: k.mid, key: V, reason: d };
    }
    if (z.replyIntents.some((d) => d.accountKey === r.accountKey && d.incomingMessageId === k.mid) || T.blocked("reply", V)) return { ...N, ready: false, status: "existing-reply-intent", incomingMessageId: k.mid, reason: "\u8BE5\u539F\u6765\u4FE1\u5DF2\u6709\u5916\u53D1\u610F\u56FE\uFF0C\u9884\u7559\u3001\u672A\u77E5\u53CA\u786E\u8BA4\u5747\u7981\u6B62\u91CD\u653E" };
    if ((z.conversationControls || []).some((d) => d.accountKey === r.accountKey && [N.conversationKey, "boss-chat:" + U[0].mid].includes(d.conversationKey) && d.mode === "paused")) return { ...N, ready: false, status: "manual-control", reason: "\u672C\u4EBA\u5DF2\u63A5\u7BA1\u672C\u4F1A\u8BDD\uFF0C\u81EA\u52A8\u56DE\u590D\u8DF3\u8FC7" };
    const X = new Intl.DateTimeFormat("sv-SE", { timeZone: r.configuration.replyTimeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(/* @__PURE__ */ new Date());
    if (new Set(T.data.records.filter((d) => d.type === "reply" && d.sightings.some((J) => J.day === X && J.timeZone === r.configuration.replyTimeZone && J.status !== "failed")).map((d) => d.businessKey)).size >= r.configuration.replyDailyLimit) throw Error("\u5DF2\u4FDD\u5B58\u7684\u672C\u4EBA\u56DE\u590D\u989D\u5EA6\u5DF2\u6EE1\uFF0C\u4FDD\u7559\u672A\u5B8C\u6210\u6536\u5C3E");
    const H = { ...N, ready: true, key: V, incomingMessageId: k.mid, incomingMessage: k.text, pendingMessages: L.slice(L.map((d) => d.direction).lastIndexOf("outgoing") + 1).filter((d) => d.direction === "incoming"), sourceSha256: I("sha256").update(JSON.stringify({ rows: U, jobSource: x, accountLabel: W })).digest("hex"), day: X, timeZone: r.configuration.replyTimeZone };
    if (!await y(o, i, H)) throw Error("\u5B8C\u6574\u6765\u6E90\u4FDD\u5B58\u524D\u4F1A\u8BDD\u5DF2\u53D8\u5316");
    return await s("fixed-unread-reply-source.json", JSON.stringify(H, null, 2)), H;
  };
  async function C(t) {
    let o = false;
    try {
      return await S({ ...t, onAccountVerified: () => {
        o = true;
      } });
    } catch (i) {
      const s = String(i.message || i), e = t.input?.cohort, r = /关联职位返回后的完整消息或对象变化|完整岗位标题缺失或截断|固定姓名搜索未取得唯一的姓名、公司和角色组合|固定成员缺少可核对的定向搜索姓名，未猜测|未读会话的实际职位链接未核对|关联职位没有可核对的继续沟通入口|固定成员当前列表|固定成员缺少唯一可见身份|固定成员可见身份|固定会话返回|关联职位完整标题与固定会话不符/u.test(s), u = o && !/账号|安全索引|账本|摘要|配置|状态|进度|Skill|预留/u.test(s) && /固定成员|固定会话|关联职位|网页操作超时|元素|目标不可见|点击目标|点击期间|\(-3\) loading/u.test(s);
      if (!(r || u) || e?.kind !== "unread-closing-cohort" || !e.member?.key) throw i;
      return await t.template.attention({ key: "fixed-member-source-review:" + e.accountKey + ":" + e.member.key, title: "\u8BE5\u672A\u8BFB\u4F1A\u8BDD\u6765\u6E90\u5F85\u6838\u5BF9\uFF0C\u672A\u6267\u884C\u5916\u53D1", detail: { contact: e.member.identityLine, fixedUnreadSetSha256: e.fixedUnreadSetSha256, memberKey: e.member.key, reason: s, externalAction: false } }), { ...e, sourceReviewVersion: "chat-list-direct-v5", kind: "chat-reply-source", fixedUnreadMember: true, profile: t.input.profile, ready: false, jobId: null, jobSource: null, status: "member-needs-review", decision: "review", replyPolicyVersion: "work-questions-partial-known-v2", reason: s };
    }
  }
  return C;
})(), et = /* @__PURE__ */ (() => {
  const I = (a) => Array.isArray(a) ? a.map(I) : a && typeof a == "object" ? Object.fromEntries(Object.keys(a).sort().map((h) => [h, I(a[h])])) : a, O = (a) => $("sha256").update(JSON.stringify(I(a))).digest("hex"), P = (a) => $("sha256").update(a).digest("hex"), q = (a, h) => (b, g, F) => (h.throwIfAborted(), a.browser("browser", { operation: b, ...g ? { selector: g } : {}, ...F === void 0 ? {} : { value: F }, timeoutMs: 3e3 }));
  async function Z(a, h, b, g, F = null) {
    let B = null;
    try {
      B = await a.file("communication-cache", { operation: "read", name: h });
    } catch (S) {
      if (!String(S.message || S).includes("ENOENT")) throw S;
    }
    const y = B === null ? F : JSON.parse(B);
    if (!y) throw Error("\u7F3A\u5C11\u6062\u590D\u6765\u6E90 " + h);
    if (B !== null) {
      const { sha256: S, ...C } = y;
      if (S !== O(C)) throw Error("\u6062\u590D\u6765\u6E90\u6458\u8981\u4E0D\u7B26 " + h);
    }
    if (y.kind !== b || y.accountKey !== g) throw Error("\u6062\u590D\u6765\u6E90\u8D26\u53F7\u6216\u7C7B\u578B\u4E0D\u7B26");
    return { name: h, raw: B, value: y };
  }
  async function G(a, h) {
    let b = null;
    try {
      b = await a.file("communication-cache", { operation: "read", name: h.name });
    } catch (B) {
      if (!String(B.message || B).includes("ENOENT")) throw B;
    }
    if (b !== h.raw) throw Error("\u6062\u590D\u8BB0\u5F55\u5E76\u53D1\u53D8\u5316");
    const g = h.value;
    g.revision++, g.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete g.sha256, g.sha256 = O(g);
    const F = JSON.stringify(g);
    if (await a.file("communication-cache", { operation: "write", name: h.name, content: F }), await a.file("communication-cache", { operation: "read", name: h.name }) !== F) throw Error("\u6062\u590D\u8BB0\u5F55\u672A\u51C6\u786E\u8BFB\u56DE");
    h.raw = F;
  }
  async function _(a, h) {
    return Z(a, "unknown-chat-reviews-v1-" + h + ".json", "boss-unknown-chat-reviews", h, { version: 1, kind: "boss-unknown-chat-reviews", accountKey: h, revision: 0, reviews: [] });
  }
  async function K(a) {
    const h = await a("count", "li.message-item");
    if (!Number.isSafeInteger(h) || h < 1 || h > 150) throw Error("\u4F1A\u8BDD\u53EF\u89C1\u6D88\u606F\u8303\u56F4\u65E0\u6548");
    const b = [];
    for (let g = 1; g <= h; g++) {
      const F = "li.message-item:nth-child(" + g + " of li.message-item)", B = await a("attribute", F, "data-mid"), y = String(await a("attribute", F, "class") || "");
      if (!/^\d{6,40}$/u.test(B || "")) throw Error("\u7F3A\u5C11\u771F\u5B9E\u670D\u52A1\u5668\u6D88\u606F\u7F16\u53F7");
      const S = await a("count", F + " .text-content");
      if (S > 1) throw Error("\u5355\u6761\u6B63\u6587\u4E0D\u552F\u4E00");
      const C = S === 1 ? String(await a("read", F + " .text-content")).trim() : null, t = S === 1 ? null : String(await a("read", F)).trim(), o = !!C && /^您正在与Boss.+沟通$/u.test(C), i = !o && C !== null && y.split(/\s/u).includes("item-myself") ? "outgoing" : !o && C !== null && y.split(/\s/u).includes("item-friend") ? "incoming" : "system", s = F + " > div > div > i", e = await a("count", s) === 1 ? String(await a("read", s)).trim() : null;
      b.push({ mid: B, direction: i, text: C, context: t, receipt: e });
    }
    if (new Set(b.map((g) => g.mid)).size !== b.length) throw Error("\u670D\u52A1\u5668\u6D88\u606F\u7F16\u53F7\u91CD\u590D");
    return b;
  }
  async function Q(a, h, b = true) {
    const g = new URL(await a("url"));
    if (g.origin !== "https://www.zhipin.com" || g.pathname !== "/web/geek/chat" || String(await a("read", h.accountSelector)).trim() !== h.accountLabel || await a("count", 'li.message-item[data-mid="' + h.member.originalIncomingMid + '"]') !== 1 || await a("count", 'li.message-item[data-mid="' + h.member.firstMessageId + '"]') !== 1) throw Error("\u672A\u77E5\u6062\u590D\u7684\u8D26\u53F7\u6216\u539F\u6D88\u606F\u94FE\u53D8\u5316");
    if (b && O(await K(a)) !== h.messagesHash) throw Error("AI\u5224\u65AD\u671F\u95F4\u804A\u5929\u5185\u5BB9\u53D8\u5316\uFF0C\u672A\u5916\u53D1");
  }
  async function j(a, h) {
    const b = 'li.message-item[data-mid="' + h.originalIncomingMid + '"]';
    if (await a("count", b) === 1) return;
    if (h.lookupQuery && h.recipientName) {
      const t = ".list-warp.v2 input";
      if (await a("count", t) !== 1) throw Error("\u8054\u7CFB\u4EBA\u641C\u7D22\u5165\u53E3\u4E0D\u552F\u4E00");
      await a("click", t), await a("fill", t, h.lookupQuery), await new Promise((r) => setTimeout(r, 600));
      const o = ".boss-search-result .search-list";
      let i = 0;
      for (let r = 0; r < 30 && (i = await a("count", o), !(i > 0)); r++) await new Promise((u) => setTimeout(u, 150));
      if (i < 1 || i > 50) throw Error("\u672A\u627E\u5230\u539Funknown\u8054\u7CFB\u4EBA");
      const s = [];
      for (let r = 1; r <= i; r++) {
        const u = [o + ":nth-child(" + r + " of .search-list)"];
        let l = 0;
        for (; u.length; ) {
          const c = u.shift();
          if (++l > 150) throw Error("\u59D3\u540D\u63A7\u4EF6\u8303\u56F4\u8FC7\u5927");
          const m = String(await a("read", c)).trim(), w = await a("count", c + " > *");
          if (m === h.recipientName && s.push({ selector: c, text: m }), w > 0 && w < 30) for (let n = 1; n <= w; n++) u.push(c + " > :nth-child(" + n + ")");
        }
      }
      const e = s.filter((r) => !s.some((u) => u !== r && u.selector.startsWith(r.selector + " > ")));
      if (e.length < 1 || e.length > 8) throw Error("\u539Funknown\u59D3\u540D\u5019\u9009\u8303\u56F4\u4E0D\u660E\u786E");
      for (const r of e) {
        if (String(await a("read", r.selector)).trim() !== r.text) throw Error("\u641C\u7D22\u7ED3\u679C\u53D8\u5316");
        await a("click", r.selector);
        for (let u = 0; u < 16; u++) {
          if (await a("count", b) === 1) return;
          await new Promise((l) => setTimeout(l, 100));
        }
        e.length > 1 && (await a("click", t), await a("fill", t, h.lookupQuery), await new Promise((u) => setTimeout(u, 600)));
      }
      throw Error("\u59D3\u540D\u5019\u9009\u4E2D\u672A\u8BFB\u56DE\u539Funknown\u6D88\u606F\u94FE");
    }
    const g = ".list-warp.v2 input";
    await a("count", g) === 1 && (await a("click", g), await a("fill", g, ""));
    const F = ".list-warp.v2 ul:has(> .selected)", B = F + " > :first-child";
    if (await a("count", B) !== 1 || String(await a("read", B)).trim() !== "\u5168\u90E8") throw Error("\u65E0\u6CD5\u8BFB\u53D6\u65E2\u6709\u4F1A\u8BDD\u5217\u8868");
    await a("click", B);
    const y = ".user-list-content > :first-child", S = /* @__PURE__ */ new Set();
    let C = 0;
    for (let t = 0; t < 20; t++) {
      const o = await a("count", y + " > *");
      if (o < 1 || o > 500) throw Error("\u65E2\u6709\u4F1A\u8BDD\u5217\u8868\u8303\u56F4\u65E0\u6548");
      let i = 0;
      for (let s = 1; s <= o; s++) {
        const e = y + " > :nth-child(" + s + ")", r = e + " .friend-content";
        if (await a("count", r) !== 1) continue;
        const u = String(await a("read", r)).trim();
        if (!(!u || S.has(u))) {
          if (S.add(u), i++, await a("click", r), await new Promise((l) => setTimeout(l, 250)), await a("count", b) === 1) return;
          if (S.size >= 200) throw Error("\u5DF2\u8BFB\u53D6200\u4E2A\u65E2\u6709\u4F1A\u8BDD\uFF0C\u539F\u6D88\u606F\u4ECD\u672A\u627E\u5230");
        }
      }
      if (C = i ? 0 : C + 1, C >= 2) break;
      await new Promise((s) => setTimeout(s, 250));
    }
    throw Error("\u65E2\u6709\u4F1A\u8BDD\u8303\u56F4\u5185\u6CA1\u6709\u539F\u670D\u52A1\u5668\u6D88\u606F\uFF0C\u4E0D\u731C\u6D4B\u6536\u4EF6\u4EBA");
  }
  return async function({ input: a, template: h, signal: b, artifact: g }) {
    const F = a.cohort, B = a.profile;
    if (!F?.unknownRecovery || !F.member || !B?.ref?.versionId || !B.markdown) throw Error("\u7F3A\u5C11unknown\u961F\u5217\u6216\u786E\u8BA4Skill");
    const y = q(h, b), S = "div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1), :root:not(:has(div:nth-of-type(3) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1))) div:nth-of-type(4) > ul:nth-of-type(1) > li:nth-of-type(2) > a:nth-of-type(1) > span:nth-of-type(1)";
    if (String(await y("read", S)).trim() !== F.accountSource.account.accountName) throw Error("\u5F53\u524D\u8D26\u53F7\u53D8\u5316");
    try {
      await j(y, F.member);
    } catch (f) {
      return { ...F, profile: B, kind: "unknown-chat-review-source", ready: false, sourceIssue: String(f.message || f), rows: [], messagesHash: O([]) };
    }
    if (!F.member.firstMessageId) {
      const f = await K(y);
      F.member = { ...F.member, firstMessageId: f[0]?.mid };
    }
    const C = await K(y), t = C.findIndex((f) => f.mid === F.member.originalIncomingMid);
    if (t < 0) throw Error("\u7F3A\u5C11\u539Funknown\u6765\u4FE1");
    const o = C.filter((f) => f.direction !== "system" && f.text), i = o.at(-1), s = String(await y("read", ".chat-conversation .user-info")).trim(), e = await y("count", ".chat-position-content") === 1 ? String(await y("read", ".chat-position-content")).trim() : "", r = C.slice(t + 1).filter((f) => /您的附件简历[\s\S]*已发送给Boss/u.test(f.text || f.context || "")), u = 'li.message-item[data-mid="' + F.member.originalIncomingMid + '"]', l = u + " .message-dialog-both .card-btn:nth-child(2)", c = u + " .message-dialog-both .card-btn:nth-child(1)", m = F.member.parentKind === "resume" && await y("count", l) === 1 && await y("count", c) === 1 && String(await y("read", l)).trim() === "\u540C\u610F" && String(await y("read", c)).trim() === "\u62D2\u7EDD", w = F.member.originalApprovedText ? C.slice(t + 1).filter((f) => f.direction === "outgoing" && f.text?.replace(/\s/gu, "") === F.member.originalApprovedText.replace(/\s/gu, "")) : [], n = { ...F, kind: "unknown-chat-review-source", ready: true, profile: B, rows: C, messagesHash: O(C), accountSelector: S, accountLabel: F.accountSource.account.accountName, recipientLabel: s, jobContext: e, firstMessageId: F.member.firstMessageId, latestIncomingMid: i?.direction === "incoming" ? i.mid : null, lastRealDirection: i?.direction || null, priorExactOutgoing: w, attachmentReceiptRows: r, nativePending: m, nativeAgreeSelector: l, nativeRequestRoot: u, nativeRequestText: String(await y("read", u)).trim(), nativeResumeEligible: m && r.length === 0 && F.member.historicalVerification?.state !== "confirmed", campus: /校招|校园|应届/u.test(e), initiatedByUs: o[0]?.direction === "outgoing", confirmedSupplementalFacts: String(F.configuration.confirmedPersonalFacts || "") };
    return await Q(y, n), await g("unknown-chat-source-" + F.member.key.split(":")[1] + ".json", JSON.stringify(n)), n;
  };
})();
async function rt(I) {
  return I.input?.cohort?.unknownRecovery ? et(I) : tt(I);
}
export {
  rt as default
};
