import { createHash as F } from "node:crypto";
const v = /* @__PURE__ */ (() => {
  const c = F, m = (t) => Array.isArray(t) ? t.map(m) : t && typeof t == "object" ? Object.fromEntries(Object.keys(t).sort().map((u) => [u, m(t[u])])) : t, l = (t) => c("sha256").update(JSON.stringify(m(t))).digest("hex"), h = (t, u) => (s, i, e) => (u.throwIfAborted(), t.browser("browser", { operation: s, ...i ? { selector: i } : {}, ...e === void 0 ? {} : { value: e }, timeoutMs: 3e3 }));
  async function p(t, u, s) {
    const i = new URL(await t("url"));
    if (i.origin !== "https://www.zhipin.com" || i.pathname !== "/web/geek/chat" || String(await t("read", u.recipientSelector)).trim() !== u.recipientLabel || String(await t("read", u.accountSelector)).trim() !== u.accountLabel || await t("count", 'li.message-item[data-mid="' + u.firstMessageId + '"]') !== 1) throw Error("\u5F53\u524D\u8D26\u53F7\u6216\u4F1A\u8BDD\u6D88\u606F\u94FE\u53D8\u5316\uFF0C\u4E0D\u64CD\u4F5C");
    if (((await s.state.get()).conversationControls || []).some((e) => e.accountKey === u.accountKey && [u.conversationKey, "boss-chat:" + u.firstMessageId].includes(e.conversationKey) && e.mode === "paused")) throw Error("\u672C\u4EBA\u5DF2\u63A5\u7BA1\u4F1A\u8BDD");
  }
  async function E(t) {
    const u = await t("count", "li.message-item");
    if (!Number.isSafeInteger(u) || u < 1 || u > 100) throw Error("\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u8303\u56F4\u65E0\u6548");
    const s = [];
    for (let i = 1; i <= u; i++) {
      const e = "li.message-item:nth-child(" + i + " of li.message-item)", r = await t("attribute", e, "data-mid"), a = String(await t("attribute", e, "class") || ""), n = String(await t("read", e)).trim();
      if (!/^\d{6,40}$/u.test(r || "") || n.length > 2e4) throw Error("\u539F\u751F\u6D88\u606F\u8EAB\u4EFD\u4E0D\u5B8C\u6574");
      s.push({ mid: r, cls: a, text: n });
    }
    return s;
  }
  async function A(t, u) {
    const s = "resume-delivery-index-v1-" + u.accountKey + ".json";
    let i = null;
    try {
      i = await t.file("communication-cache", { operation: "read", name: s });
    } catch (r) {
      if (!String(r.message || r).includes("ENOENT")) throw r;
    }
    const e = i ? JSON.parse(i) : { version: 1, kind: "boss-resume-delivery-index", accountKey: u.accountKey, revision: 0, uploads: [], deliveries: [] };
    if (i) {
      const { sha256: r, ...a } = e;
      if (r !== l(a)) throw Error("\u539F\u9644\u4EF6\u8D26\u672C\u6458\u8981\u4E0D\u7B26");
    }
    if (e.accountKey !== u.accountKey || e.kind !== "boss-resume-delivery-index" || !Array.isArray(e.deliveries) || !Array.isArray(e.uploads) || e.deliveries.length > 2e3 || new Set(e.deliveries.map((r) => r.key)).size !== e.deliveries.length) throw Error("\u539F\u9644\u4EF6\u8D26\u672C\u7ED3\u6784\u4E0D\u7B26");
    return { book: e, save: async () => {
      let r = null;
      try {
        r = await t.file("communication-cache", { operation: "read", name: s });
      } catch (n) {
        if (!String(n.message || n).includes("ENOENT")) throw n;
      }
      if (r !== i) throw Error("\u9644\u4EF6\u8D26\u672C\u5E76\u53D1\u53D8\u5316");
      e.revision++, e.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete e.sha256, e.sha256 = l(e);
      const a = JSON.stringify(e);
      if (await t.file("communication-cache", { operation: "write", name: s, content: a }), await t.file("communication-cache", { operation: "read", name: s }) !== a) throw Error("\u9644\u4EF6\u8D26\u672C\u672A\u51C6\u786E\u8BFB\u56DE");
      i = a;
    } };
  }
  async function D({ input: t, template: u, signal: s, artifact: i }) {
    const e = t?.closingSource;
    if (e?.kind !== "chat-reply-source" || !e.member?.key) throw Error("\u7F3A\u5C11\u56FA\u5B9A\u4F1A\u8BDD\u6765\u6E90");
    if (e.ownedConversation !== true || ["rejected-no-reply", "campus-no-reply", "manual-control", "already-completed"].includes(e.status)) return { version: 1, kind: "boss-resume-request-source", ready: false, status: "fixed-member-native-skipped", reason: e.reason };
    const r = { ...e, kind: "boss-resume-request-source", firstMessageId: e.rows[0].mid }, a = h(u, s);
    await p(a, r, u);
    const n = await E(a), d = [];
    for (const o of n) {
      if (!o.cls.split(/\s/u).includes("item-friend") || !o.text.includes("\u6211\u60F3\u8981\u4E00\u4EFD\u60A8\u7684\u9644\u4EF6\u7B80\u5386\uFF0C\u60A8\u662F\u5426\u540C\u610F")) continue;
      const f = 'li.message-item[data-mid="' + o.mid + '"]', w = f + " .message-dialog-both .card-btn:nth-child(2)", g = f + " .message-dialog-both .card-btn:nth-child(1)";
      await a("count", w) === 1 && await a("count", g) === 1 && String(await a("read", w)).trim() === "\u540C\u610F" && String(await a("read", g)).trim() === "\u62D2\u7EDD" && d.push({ mid: o.mid, root: f, agree: w, text: o.text, key: l(["boss-resume-request-v1", e.accountKey, r.firstMessageId, o.mid]) });
    }
    const y = { ...r, requests: d, ready: d.length > 0, status: d.length ? "pending-native-resume-requests" : "no-pending-resume-request", sourceMessageIds: n.map((o) => o.mid), sourceSha256: l({ accountKey: e.accountKey, recipientLabel: e.recipientLabel, firstMessageId: r.firstMessageId, requests: d }) };
    return await i("native-resume-source.json", JSON.stringify(y)), y;
  }
  return D;
})(), b = async function() {
  return { version: 1, kind: "boss-resume-request-source", ready: false, status: "unknown-review-no-native-replay", reason: "\u672C\u8F6E\u5148\u6838\u5BF9unknown\u804A\u5929\u4E0EAI\u5224\u65AD\uFF0C\u4E0D\u91CD\u653E\u539F\u751F\u9644\u4EF6\u610F\u56FE" };
};
async function C(c) {
  return c.input?.closingSource?.unknownRecovery ? b(c) : v(c);
}
export {
  C as default
};
