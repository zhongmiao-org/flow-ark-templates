import { createHash as O } from "node:crypto";
const K = /* @__PURE__ */ (() => {
  const F = O;
  function D(e) {
    return e.status === "review" && !e.operationKey && !e.modelRequestId && e.sourceReviewVersion !== "chat-list-direct-v5" && /固定成员姓名控件不唯一|固定成员定向搜索结果不唯一|关联职位没有可核对的继续沟通入口|固定成员缺少可核对的定向搜索姓名，未猜测|固定成员缺少唯一可见身份|关联职位返回后的完整消息或对象变化/u.test(String(e.reason || ""));
  }
  const b = (e) => Array.isArray(e) ? e.map(b) : e && typeof e == "object" ? Object.fromEntries(Object.keys(e).sort().map((u) => [u, b(e[u])])) : e, S = (e) => F("sha256").update(JSON.stringify(b(e))).digest("hex");
  async function v(e, u, t, o, c = false) {
    const d = "account-outbound-safety-v1-" + t + ".json";
    let r, a = true, w;
    try {
      w = await e.file("communication-cache", { operation: "read", name: d }), r = JSON.parse(w);
    } catch (n) {
      if (!String(n.message || n).includes("ENOENT")) throw n;
      if (!c) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u7F3A\u5931\uFF1B\u4FDD\u7559\u539F\u5B9E\u4F8B\uFF0C\u4E0D\u5141\u8BB8\u65B0\u7248\u672C\u7EED\u53D1");
      a = false, r = { version: 1, kind: "boss-account-outbound-safety", accountKey: t, revision: 0, records: [], updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    }
    if (a) {
      const { sha256: n, ...s } = r;
      if (n !== S(s)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u6458\u8981\u4E0D\u7B26\uFF0C\u505C\u6B62\u7EED\u53D1");
    }
    if (r.version !== 1 || r.kind !== "boss-account-outbound-safety" || r.accountKey !== t || !Number.isSafeInteger(r.revision) || r.revision < 0 || !Array.isArray(r.records) || r.records.length > 2e3) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u8EAB\u4EFD\u6216\u7ED3\u6784\u4E0D\u7B26");
    const f = /* @__PURE__ */ new Set();
    for (const n of r.records) {
      if (!["first-contact", "reply"].includes(n.type) || !/^[a-f0-9]{64}$/.test(n.businessKey) || !Array.isArray(n.sightings) || !n.sightings.length || n.sightings.length > 100 || f.has(n.type + ":" + n.businessKey)) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u8BB0\u5F55\u65E0\u6548");
      f.add(n.type + ":" + n.businessKey);
      for (const s of n.sightings) if (typeof s.contextId != "string" || !s.contextId || !/^[a-f0-9]{64}$/.test(s.intentKey) || !["reserved", "confirmed", "failed", "unknown"].includes(s.status) || !/^\d{4}-\d{2}-\d{2}$/.test(s.day) || typeof s.timeZone != "string") throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u8BB0\u5F55\u65E0\u6548");
    }
    let h = !a;
    return { data: r, name: d, merge: (n) => {
      if (!Array.isArray(n?.applicationIntents) || !Array.isArray(n?.replyIntents)) throw Error("\u539F\u5B9E\u4F8B\u5B8C\u6574\u5916\u53D1\u8D26\u672C\u7F3A\u5931");
      for (const [s, g] of [["first-contact", n.applicationIntents], ["reply", n.replyIntents]]) for (const l of g) {
        if ((s === "first-contact" ? l.accountSourceSha256 : l.accountKey) !== t) throw Error("\u539F\u5B9E\u4F8B\u8D26\u672C\u5305\u542B\u5176\u4ED6\u8D26\u53F7\uFF0C\u4E0D\u81EA\u52A8\u5408\u5E76");
        if (!/^[a-f0-9]{64}$/.test(l.key) || !l.jobId || !["reserved", "confirmed", "failed", "unknown"].includes(l.status)) throw Error("\u539F\u5B9E\u4F8B\u5916\u53D1\u8BB0\u5F55\u65E0\u6548");
        const p = s === "first-contact" ? S(["boss-job-safety-v1", t, l.jobId]) : F("sha256").update(["boss-text-reply-v1", t, l.incomingMessageId].join(":")).digest("hex");
        let m = r.records.find((y) => y.type === s && y.businessKey === p);
        if (m || (m = { type: s, businessKey: p, jobId: l.jobId, ...s === "reply" ? { conversationKey: l.conversationKey, incomingMessageId: l.incomingMessageId } : {}, sightings: [] }, r.records.push(m), h = true), m.jobId !== l.jobId) throw Error("\u5B89\u5168\u7D22\u5F15\u540C\u952E\u5C97\u4F4D\u51B2\u7A81");
        const E = { contextId: o, intentKey: l.key, status: l.status, day: l.day, timeZone: l.timeZone, contentSha256: l.contentSha256 || null, sourceSha256: l.sourceSha256 || null };
        if (m.sightings.some((y) => JSON.stringify(b(y)) === JSON.stringify(b(E))) || (m.sightings.push(E), h = true), m.sightings.length > 100) throw Error("\u5B89\u5168\u7D22\u5F15\u5386\u53F2\u5BB9\u91CF\u5DF2\u6EE1");
      }
      if (r.records.length > 2e3) throw Error("\u5B89\u5168\u7D22\u5F15\u64CD\u4F5C\u5BB9\u91CF\u5DF2\u6EE1");
    }, save: async () => {
      if (u.throwIfAborted(), h) {
        if (a && await e.file("communication-cache", { operation: "read", name: d }) !== w) throw Error("\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u5728\u5199\u5165\u524D\u53D8\u5316\uFF0C\u505C\u6B62\u800C\u4E0D\u8986\u76D6");
        r.records.sort((l, p) => (l.type + ":" + l.businessKey).localeCompare(p.type + ":" + p.businessKey));
        for (const l of r.records) l.sightings.sort((p, m) => JSON.stringify(b(p)).localeCompare(JSON.stringify(b(m))));
        r.revision++, r.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete r.sha256, r.sha256 = S(r), await e.file("communication-cache", { operation: "write", name: d, content: JSON.stringify(r) }), h = false, w = JSON.stringify(r), a = true;
      }
      const n = JSON.parse(await e.file("communication-cache", { operation: "read", name: d })), { sha256: s, ...g } = n;
      if (s !== S(g) || s !== r.sha256) throw Error("\u5B89\u5168\u7D22\u5F15\u5199\u51FA\u540E\u8BFB\u56DE\u4E0D\u4E00\u81F4");
      return { revision: r.revision, sha256: r.sha256, records: r.records.length };
    }, blocked: (n, s) => r.records.some((g) => g.type === n && g.businessKey === s) };
  }
  const I = (e, u) => async (t, o, c) => (u.throwIfAborted(), e.browser("browser", { operation: t, ...o ? { selector: o } : {}, ...c === void 0 ? {} : { value: c }, timeoutMs: 3e3 })), B = (e) => {
    const { sha256: u, ...t } = e;
    return u === S(t);
  };
  async function k(e, u, t, o) {
    const c = t.progressName, d = await e.file("communication-cache", { operation: "read", name: c }), r = JSON.parse(d);
    if (!B(r) || r.accountKey !== t.accountKey || r.fixedUnreadSetSha256 !== t.fixedUnreadSetSha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u8EAB\u4EFD\u6216\u6458\u8981\u53D8\u5316");
    if (!o) return r;
    const a = o(structuredClone(r));
    if (a.revision++, a.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete a.sha256, a.sha256 = S(a), await e.file("communication-cache", { operation: "read", name: c }) !== d) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u5199\u5165\u524D\u53D8\u5316\uFF0C\u672A\u8986\u76D6");
    u.throwIfAborted(), await e.file("communication-cache", { operation: "write", name: c, content: JSON.stringify(a) });
    const w = JSON.parse(await e.file("communication-cache", { operation: "read", name: c }));
    if (!B(w) || w.sha256 !== a.sha256) throw Error("\u56FA\u5B9A\u672A\u8BFB\u8FDB\u5EA6\u672A\u5B8C\u6574\u8BFB\u56DE");
    return w;
  }
  async function A(e) {
    const u = await e("count", "li.message-item");
    if (!Number.isSafeInteger(u) || u < 1 || u > 100) throw Error("\u5B8C\u6574\u53EF\u89C1\u4F1A\u8BDD\u6D88\u606F\u6570\u91CF\u65E0\u6548\uFF0C\u672A\u622A\u65AD");
    const t = [];
    for (let o = 1; o <= u; o++) {
      const c = "li.message-item:nth-child(" + o + " of li.message-item)", d = await e("attribute", c, "data-mid"), r = await e("attribute", c, "class");
      if (!/^\d{6,40}$/.test(d || "")) throw Error("\u7F3A\u5C11\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7");
      const a = await e("count", c + " .text-content");
      if (a > 1) throw Error("\u5355\u6761\u6D88\u606F\u6B63\u6587\u4E0D\u552F\u4E00");
      const w = a === 1 ? String(await e("read", c + " .text-content")).trim() : null, f = w === null ? String(await e("read", c)).trim() : null;
      if ((w || f || "").length > 1e4) throw Error("\u5355\u6761\u53EF\u89C1\u6D88\u606F\u8FC7\u957F\uFF0C\u672A\u622A\u65AD\u540E\u53D1\u9001");
      const h = !!w && /^您正在与Boss.+沟通$/u.test(w), n = !h && w !== null && r.split(/\s+/u).includes("item-myself") ? "outgoing" : !h && w !== null && r.split(/\s+/u).includes("item-friend") ? "incoming" : "system";
      t.push({ mid: d, direction: n, text: w, context: f });
    }
    if (new Set(t.map((o) => o.mid)).size !== t.length) throw Error("\u7F51\u7AD9\u6D88\u606F\u7F16\u53F7\u4E0D\u552F\u4E00");
    return t;
  }
  async function C(e, u) {
    const t = new URL(await e("url"));
    if (t.origin !== "https://www.zhipin.com" || t.pathname !== "/web/geek/chat" || await e("count", ".chat-conversation .user-info") !== 1) return false;
    const o = String(await e("read", ".chat-conversation .user-info")).trim(), c = (d) => d.replace(/[\s\uE000-\uF8FF]/gu, "").replace(/更多$/u, "");
    return String(await e("read", ".chat-conversation .user-info")).trim() === u.recipientLabel && await e("count", 'li.message-item[data-mid="' + u.rows[0].mid + '"]') === 1;
  }
  async function N(e, u, t) {
    const o = I(e, u);
    return await C(o, t) ? String(await o("read", t.accountSelector)).trim() === t.accountLabel && String(await o("read", t.recipientSelector)).trim() === t.recipientLabel && JSON.stringify(await A(o)) === JSON.stringify(t.rows) : false;
  }
  var i = async ({ input: e, signal: u, template: t, artifact: o, logger: c }) => {
    if (e?.kind !== "chat-reply-dispatch") throw Error("Missing single-dispatch stage");
    const d = (n) => F("sha256").update(n).digest("hex"), r = (n) => String(n).replace(/\s+/g, ""), a = (n, s, g) => (u.throwIfAborted(), t.browser("browser", { operation: n, ...s ? { selector: s } : {}, ...g !== void 0 ? { value: g } : {}, timeoutMs: 3e3 })), w = () => A(a);
    let f = null;
    if (e.dispatched) try {
      const n = Date.now() + 1e4;
      for (; Date.now() < n; ) {
        if (new URL(await a("url")).origin !== "https://www.zhipin.com" || new URL(await a("url")).pathname !== "/web/geek/chat" || String(await a("read", e.accountSelector)).trim() !== e.accountLabel || !await C(a, e) || String(await a("read", e.recipientSelector)).trim() !== e.recipientLabel) throw Error("Conversation changed after dispatch");
        const m = await w();
        if (JSON.stringify(m.slice(0, e.rows.length)) !== JSON.stringify(e.rows)) throw Error("Original conversation history changed after dispatch");
        const E = m.slice(e.rows.length).filter((y) => y.direction === "outgoing");
        if (E.length > 1) throw Error("More than one new outbound message; no attribution");
        if (E.length === 1) {
          const y = E[0];
          if (r(y.text) !== r(e.reply)) throw Error("New outbound content differs from fixed AI reply");
          const j = 'li.message-item[data-mid="' + y.mid + '"] > div > div > i';
          if (await a("count", j) === 1) {
            const x = String(await a("read", j)).trim();
            if (["\u9001\u8FBE", "\u5DF2\u8BFB"].includes(x)) {
              f = { version: 1, kind: "existing-conversation-ai-reply-delivery", incomingMessageId: e.incomingMessageId, outgoingMessageId: y.mid, jobId: e.jobId, jobSource: e.jobSource, conversationKey: e.conversationKey, accountKey: e.accountKey, operationId: e.effect.id, operationKey: e.key, runId: e.effect.runId, sourceSha256: e.sourceSha256, approvedText: e.reply, contentSha256: e.contentSha256, observedText: y.text, observedSha256: d(y.text), receipt: x, observedAt: (/* @__PURE__ */ new Date()).toISOString(), model: e.model, profileRef: e.profile.ref, configurationRevision: e.configurationRevision, rows: m };
              break;
            }
          }
        }
        await new Promise((y) => setTimeout(y, 200));
      }
      if (!f) throw Error("Website delivery receipt did not appear within the bounded observation");
      await o("reply-delivery-proof.json", JSON.stringify(f, null, 2)), await t.effect.resolve({ id: e.effect.id, state: "confirmed", evidence: f });
      const s = await t.state.get();
      if (s.replyIntents.filter((m) => m.key === e.key && m.status === "reserved" && m.contentSha256 === e.contentSha256).length !== 1) throw Error("Reply reservation changed before receipt persistence");
      await t.state.set({ ...s, replyIntents: s.replyIntents.map((m) => m.key === e.key ? { ...m, status: "confirmed" } : m) });
      const g = await t.state.get();
      if (g.replyIntents.filter((m) => m.key === e.key && m.status === "confirmed").length !== 1) throw Error("Reply confirmation could not be read back");
      const l = await v(t, u, e.accountKey, e.contextId);
      l.merge(g);
      const p = await l.save();
      if (!l.data.records.some((m) => m.type === "reply" && m.businessKey === e.key && m.sightings.some((E) => E.contextId === e.contextId && E.intentKey === e.key && E.status === "confirmed"))) throw Error("\u9001\u8FBE\u5DF2\u6838\u5BF9\uFF0C\u4F46\u8D26\u53F7\u5B89\u5168\u7D22\u5F15\u786E\u8BA4\u672A\u8BFB\u56DE\uFF1B\u4FDD\u7559\u539F\u610F\u56FE\uFF0C\u4E0D\u91CD\u53D1");
      await o("reply-safety-confirmation.json", JSON.stringify({ operationKey: e.key, incomingMessageId: e.incomingMessageId, ...p }, null, 2)), c.info({ status: "reply-confirmed", incomingMessageId: e.incomingMessageId, outgoingMessageId: f.outgoingMessageId, receipt: f.receipt });
    } catch (n) {
      if (!f) {
        await t.effect.resolve({ id: e.effect.id, state: "unknown", evidence: { reason: String(n.message || n), incomingMessageId: e.incomingMessageId, jobSource: e.jobSource, doNotReplay: true } });
        const s = await t.state.get();
        await t.state.set({ ...s, replyIntents: s.replyIntents.map((p) => p.key === e.key ? { ...p, status: "unknown" } : p) });
        const g = await t.state.get(), l = await v(t, u, e.accountKey, e.contextId);
        l.merge(g), await l.save();
      }
      throw await t.attention({ key: "reply-unresolved:" + e.key, title: "\u672C\u6761\u56DE\u590D\u9700\u8981\u6838\u5BF9\u9001\u8FBE\uFF0C\u8BF7\u52FF\u91CD\u53D1", detail: { jobTitle: e.jobTitle, jobSource: e.jobSource, incomingMessageId: e.incomingMessageId, reason: String(n.message || n), doNotReplay: true } }), n;
    }
    const h = { kind: "chat-reply-result", accountKey: e.accountKey, status: f ? "confirmed" : e.decision === "skip" ? "skipped-no-work-question" : e.status || "skipped", jobId: e.jobId || null, jobTitle: e.jobTitle || null, jobSource: e.jobSource || null, reason: f ? "AI reply has a real website delivery receipt" : e.reason, incomingMessageId: e.incomingMessageId || null, outgoingMessageId: f?.outgoingMessageId || null, receipt: f?.receipt || null, newGreeting: false, nativeActions: e.nativeActions || [], attachmentSent: (e.nativeActions || []).some((n) => n.type === "resume" && n.status === "confirmed") };
    if (e.member) {
      const n = await k(t, u, e, (s) => {
        const g = s.completed.find((l) => l.memberKey === e.member.key);
        if (g) {
          if (g.status !== "review" || g.replyPolicyVersion === e.replyPolicyVersion && !D(g)) return s;
          s.reviewHistory = [...s.reviewHistory || [], g], s.completed = s.completed.filter((l) => l.memberKey !== e.member.key);
        }
        if (s.active && s.active.memberKey !== e.member.key) throw Error("\u9001\u8FBE\u6838\u5BF9\u540E\u7684\u6D3B\u8DC3\u4F1A\u8BDD\u5DF2\u53D8\u5316");
        return s.completed.push({ sourceReviewVersion: e.sourceReviewVersion || null, nativeActions: e.nativeActions || [], memberKey: e.member.key, identityLine: e.member.identityLine, replyPolicyVersion: e.replyPolicyVersion || null, status: f ? "confirmed" : e.decision === "review" ? "review" : e.decision === "skip" ? "skipped-no-work-question" : e.status || "skipped", reason: h.reason, incomingMessageId: e.incomingMessageId || null, outgoingMessageId: f?.outgoingMessageId || null, receipt: f?.receipt || null, operationKey: e.key || null, modelRequestId: e.model?.requestId || null, checkedAt: (/* @__PURE__ */ new Date()).toISOString() }), s.active = null, s;
      });
      h.fixedUnreadSetSha256 = e.fixedUnreadSetSha256, h.memberKey = e.member.key, h.completed = n.completed.length, h.remaining = e.memberCount - n.completed.length, h.progressSha256 = n.sha256;
    }
    return await o("fixed-unread-member-result.json", JSON.stringify(h, null, 2)), h;
  };
  return i;
})(), M = /* @__PURE__ */ (() => {
  const F = (i) => Array.isArray(i) ? i.map(F) : i && typeof i == "object" ? Object.fromEntries(Object.keys(i).sort().map((e) => [e, F(i[e])])) : i, D = (i) => O("sha256").update(JSON.stringify(F(i))).digest("hex"), b = (i) => O("sha256").update(i).digest("hex"), S = (i, e) => (u, t, o) => (e.throwIfAborted(), i.browser("browser", { operation: u, ...t ? { selector: t } : {}, ...o === void 0 ? {} : { value: o }, timeoutMs: 3e3 }));
  async function v(i, e, u, t, o = null) {
    let c = null;
    try {
      c = await i.file("communication-cache", { operation: "read", name: e });
    } catch (r) {
      if (!String(r.message || r).includes("ENOENT")) throw r;
    }
    const d = c === null ? o : JSON.parse(c);
    if (!d) throw Error("\u7F3A\u5C11\u6062\u590D\u6765\u6E90 " + e);
    if (c !== null) {
      const { sha256: r, ...a } = d;
      if (r !== D(a)) throw Error("\u6062\u590D\u6765\u6E90\u6458\u8981\u4E0D\u7B26 " + e);
    }
    if (d.kind !== u || d.accountKey !== t) throw Error("\u6062\u590D\u6765\u6E90\u8D26\u53F7\u6216\u7C7B\u578B\u4E0D\u7B26");
    return { name: e, raw: c, value: d };
  }
  async function I(i, e) {
    let u = null;
    try {
      u = await i.file("communication-cache", { operation: "read", name: e.name });
    } catch (c) {
      if (!String(c.message || c).includes("ENOENT")) throw c;
    }
    if (u !== e.raw) throw Error("\u6062\u590D\u8BB0\u5F55\u5E76\u53D1\u53D8\u5316");
    const t = e.value;
    t.revision++, t.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), delete t.sha256, t.sha256 = D(t);
    const o = JSON.stringify(t);
    if (await i.file("communication-cache", { operation: "write", name: e.name, content: o }), await i.file("communication-cache", { operation: "read", name: e.name }) !== o) throw Error("\u6062\u590D\u8BB0\u5F55\u672A\u51C6\u786E\u8BFB\u56DE");
    e.raw = o;
  }
  async function B(i, e) {
    return v(i, "unknown-chat-reviews-v1-" + e + ".json", "boss-unknown-chat-reviews", e, { version: 1, kind: "boss-unknown-chat-reviews", accountKey: e, revision: 0, reviews: [] });
  }
  async function k(i) {
    const e = await i("count", "li.message-item");
    if (!Number.isSafeInteger(e) || e < 1 || e > 150) throw Error("\u4F1A\u8BDD\u53EF\u89C1\u6D88\u606F\u8303\u56F4\u65E0\u6548");
    const u = [];
    for (let t = 1; t <= e; t++) {
      const o = "li.message-item:nth-child(" + t + " of li.message-item)", c = await i("attribute", o, "data-mid"), d = String(await i("attribute", o, "class") || "");
      if (!/^\d{6,40}$/u.test(c || "")) throw Error("\u7F3A\u5C11\u771F\u5B9E\u670D\u52A1\u5668\u6D88\u606F\u7F16\u53F7");
      const r = await i("count", o + " .text-content");
      if (r > 1) throw Error("\u5355\u6761\u6B63\u6587\u4E0D\u552F\u4E00");
      const a = r === 1 ? String(await i("read", o + " .text-content")).trim() : null, w = r === 1 ? null : String(await i("read", o)).trim(), f = !!a && /^您正在与Boss.+沟通$/u.test(a), h = !f && a !== null && d.split(/\s/u).includes("item-myself") ? "outgoing" : !f && a !== null && d.split(/\s/u).includes("item-friend") ? "incoming" : "system", n = o + " > div > div > i", s = await i("count", n) === 1 ? String(await i("read", n)).trim() : null;
      u.push({ mid: c, direction: h, text: a, context: w, receipt: s });
    }
    if (new Set(u.map((t) => t.mid)).size !== u.length) throw Error("\u670D\u52A1\u5668\u6D88\u606F\u7F16\u53F7\u91CD\u590D");
    return u;
  }
  async function A(i, e, u = true) {
    const t = new URL(await i("url"));
    if (t.origin !== "https://www.zhipin.com" || t.pathname !== "/web/geek/chat" || String(await i("read", e.accountSelector)).trim() !== e.accountLabel || await i("count", 'li.message-item[data-mid="' + e.member.originalIncomingMid + '"]') !== 1 || await i("count", 'li.message-item[data-mid="' + e.member.firstMessageId + '"]') !== 1) throw Error("\u672A\u77E5\u6062\u590D\u7684\u8D26\u53F7\u6216\u539F\u6D88\u606F\u94FE\u53D8\u5316");
    if (u && D(await k(i)) !== e.messagesHash) throw Error("AI\u5224\u65AD\u671F\u95F4\u804A\u5929\u5185\u5BB9\u53D8\u5316\uFF0C\u672A\u5916\u53D1");
  }
  async function C(i, e) {
    const u = ".list-warp.v2 input";
    if (await i("count", u) !== 1) throw Error("\u8054\u7CFB\u4EBA\u641C\u7D22\u5165\u53E3\u4E0D\u552F\u4E00");
    await i("click", u), await i("fill", u, e.lookupQuery || e.recipientName);
    const t = ".boss-search-result .search-list";
    let o = 0;
    for (let r = 0; r < 30 && (o = await i("count", t), !(o > 0)); r++) await new Promise((a) => setTimeout(a, 150));
    if (o < 1 || o > 50) throw Error("\u672A\u627E\u5230\u539Funknown\u8054\u7CFB\u4EBA");
    const c = [];
    for (let r = 1; r <= o; r++) {
      const a = t + ":nth-child(" + r + " of .search-list)", w = [a];
      let f = 0;
      for (; w.length; ) {
        const h = w.shift();
        if (++f > 150) throw Error("\u59D3\u540D\u63A7\u4EF6\u8303\u56F4\u8FC7\u5927");
        const n = String(await i("read", h)).trim(), s = await i("count", h + " > *");
        if (n === e.recipientName && c.push({ selector: h, text: n }), s > 0 && s < 30) for (let g = 1; g <= s; g++) w.push(h + " > :nth-child(" + g + ")");
      }
    }
    const d = c.filter((r) => !c.some((a) => a !== r && a.selector.startsWith(r.selector + " > ")));
    if (d.length !== 1) throw Error("\u539Funknown\u59D3\u540D\u63A7\u4EF6\u4E0D\u552F\u4E00");
    if (String(await i("read", d[0].selector)).trim() !== d[0].text) throw Error("\u641C\u7D22\u7ED3\u679C\u53D8\u5316");
    await i("click", d[0].selector);
    for (let r = 0; r < 40; r++) {
      if (await i("count", 'li.message-item[data-mid="' + e.originalIncomingMid + '"]') === 1 && await i("count", 'li.message-item[data-mid="' + e.firstMessageId + '"]') === 1) return;
      await new Promise((a) => setTimeout(a, 150));
    }
    throw Error("\u641C\u7D22\u540E\u672A\u8BFB\u56DE\u539Funknown\u670D\u52A1\u5668\u6D88\u606F\u94FE");
  }
  return async function({ input: i, template: e, artifact: u }) {
    if (i?.kind !== "unknown-chat-review-dispatch") throw Error("\u7F3A\u5C11unknown\u5224\u65AD\u7ED3\u679C");
    const t = await B(e, i.accountKey), o = t.value.reviews.find((d) => d.key === i.member.key);
    o && i.status === "review" && (o.status = "review", o.reason = i.reason, await I(e, t));
    const c = { key: i.member.key, decision: i.decision, status: i.readOnly ? "reviewed-no-external-action" : i.status, reason: i.reason, modelRequestId: i.model?.requestId || null, reply: i.reply, newGreeting: false, readOnly: i.readOnly };
    return await u("unknown-review-result-" + i.member.key.split(":")[1] + ".json", JSON.stringify(c)), c;
  };
})();
async function R(F) {
  return F.input?.unknownRecovery ? M(F) : K(F);
}
export {
  R as default
};
