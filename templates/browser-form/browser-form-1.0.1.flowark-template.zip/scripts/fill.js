// development/browser-form/src/fill.ts
var fill_default = async ({ template: t }) => {
  const c = await t.configuration();
  await t.browser("browser", { operation: "navigate", value: c.url });
  const effect = await t.effect.prepare({ action: "form-write", key: "name:" + c.name + ":" + c.url, description: "\u586B\u5199\u865A\u6784\u540D\u79F0" });
  if (!effect.execute) return t.result({ updated: false, state: effect.state });
  try {
    await t.browser("browser", { operation: "fill", selector: "#full-name", value: c.name });
    const value = await t.browser("browser", { operation: "inputValue", selector: "#full-name" });
    if (value !== c.name) throw new Error("\u5B57\u6BB5\u56DE\u8BFB\u4E0D\u5339\u914D");
    await t.effect.resolve({ id: effect.id, state: "confirmed", evidence: value });
    return t.result({ updated: true, value });
  } catch (e) {
    await t.effect.resolve({ id: effect.id, state: "unknown" });
    throw e;
  }
};
export {
  fill_default as default
};
