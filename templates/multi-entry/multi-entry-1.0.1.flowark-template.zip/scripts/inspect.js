// development/multi-entry/src/inspect.ts
var inspect_default = async ({ template: t }) => t.result({ configuration: await t.configuration() });
export {
  inspect_default as default
};
