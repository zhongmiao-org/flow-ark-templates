// development/multi-entry/src/draft.ts
var draft_default = async ({ template: t }) => {
  const c = await t.configuration();
  const response = await t.ai("ai", { instructions: "\u53EA\u6309\u8F93\u5165\u8F93\u51FA JSON\uFF0C\u4E0D\u65B0\u589E\u4E8B\u5B9E\u3002", input: { name: c.name }, schema: { type: "object", properties: { name: { type: "string" } }, required: ["name"], additionalProperties: false } });
  if (response.output.name !== c.name) throw new Error("\u6A21\u578B\u6539\u53D8\u4E86\u5DF2\u6388\u6743\u4E8B\u5B9E");
  await t.state.set(response.output);
  return t.result(response.output);
};
export {
  draft_default as default
};
